globalThis.PhysLang?.translateTree(document.documentElement);
var physTranslate = globalThis.PhysLang?.t || (value => value);
(function () {
  "use strict";

  const PI = Math.PI;
  const ROTATING_FIELD_OMEGA = 2 * PI / 10;
  const MAX_INITIAL_SPEED = 10;
  const VELOCITY_DISPLAY_SCALE = 0.05;
  const VECTOR_INSET = 12;
  const VELOCITY_HANDLE_INSET = 23;
  const POWER_UNITS = Object.freeze([
    { exponent: -24, prefix: "y" }, { exponent: -21, prefix: "z" },
    { exponent: -18, prefix: "a" }, { exponent: -15, prefix: "f" },
    { exponent: -12, prefix: "p" }, { exponent: -9, prefix: "n" },
    { exponent: -6, prefix: "\\mu" }, { exponent: -3, prefix: "m" },
    { exponent: -2, prefix: "c" }, { exponent: -1, prefix: "d" },
    { exponent: 0, prefix: "" }, { exponent: 1, prefix: "da" },
    { exponent: 2, prefix: "h" }, { exponent: 3, prefix: "k" },
    { exponent: 6, prefix: "M" }, { exponent: 9, prefix: "G" },
    { exponent: 12, prefix: "T" }, { exponent: 15, prefix: "P" },
    { exponent: 18, prefix: "E" }, { exponent: 21, prefix: "Z" },
    { exponent: 24, prefix: "Y" }
  ]);
  const DOMAIN = Object.freeze({ xMin: 0, xMax: 2 * PI, yMin: 0, yMax: 3 * PI });
  const COLORS = Object.freeze({
    ink: "#233449",
    muted: "#607185",
    grid: "#dce4ec",
    accent: "#276aa0",
    field: "#20a486",
    force: "#9b7bea",
    velocity: "#6db9ed",
    trajectory: "#f7fbff",
    progress: "#d5e6f3",
    particle: "#ed8a58",
    point: "#ed8a58",
    work: "#2775b6",
    kinetic: "#e98d55",
    positive: "#268576",
    negative: "#b5687b"
  });

  const FIELD_TYPES = Object.freeze({
    cellular: {
      note: physTranslate("Champ de force périodique non conservatif."),
      maxMagnitudeFactor: 1
    },
    periodic: {
      note: physTranslate("Champ conservatif : la particule oscille entre des puits périodiques."),
      maxMagnitudeFactor: Math.SQRT2
    },
    central: {
      note: physTranslate("Champ conservatif, borné et dirigé vers le centre de la figure."),
      maxMagnitudeFactor: 1
    },
    vortex: {
      note: physTranslate("Champ tournant spatial, non conservatif et borné autour du centre C."),
      maxMagnitudeFactor: 1
    },
    rotating: {
      note: physTranslate("Champ uniforme tournant et explicitement dépendant du temps."),
      maxMagnitudeFactor: 1
    },
    traveling: {
      note: physTranslate("Champ non uniforme dont les tourbillons se déplacent avec le temps."),
      maxMagnitudeFactor: 1
    },
    gravity: {
      note: physTranslate("Champ de pesanteur uniforme et conservatif."),
      maxMagnitudeFactor: 1
    }
  });

  const PRESETS = Object.freeze({
    positive: {
      fieldId: "cellular",
      mass: 20,
      forceScale: 1,
      x0: 4.4,
      y0: 6.8,
      speed0: Math.SQRT2 * 0.2,
      angle0: -45,
      duration: 15 * PI,
      note: physTranslate("Avec le champ tourbillonnaire, le travail total est positif et la particule arrive plus rapide.")
    },
    zero: {
      fieldId: "cellular",
      mass: 20,
      forceScale: 1,
      x0: 4.4,
      y0: 6.8,
      speed0: Math.SQRT2 * 0.2,
      angle0: -45,
      duration: 36.6022792668,
      note: physTranslate("Les aires positive et négative se compensent : la vitesse finale a la même norme qu’au départ.")
    },
    negative: {
      fieldId: "cellular",
      mass: 20,
      forceScale: 1,
      x0: 4.4,
      y0: 6.8,
      speed0: Math.SQRT2 * 0.2,
      angle0: -45,
      duration: 7 * PI,
      note: physTranslate("Le travail total est négatif : l’énergie cinétique finale est inférieure à l’énergie initiale.")
    }
  });

  const number2 = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
    useGrouping: false
  });
  const number3 = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 3,
    maximumFractionDigits: 3,
    useGrouping: false
  });
  const number6 = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 6,
    maximumFractionDigits: 6,
    useGrouping: false
  });
  const tickNumber = new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 2,
    useGrouping: false
  });

  const dom = {
    forceField: document.getElementById("force-field-select"),
    forceFieldNote: document.getElementById("force-field-note"),
    fieldFormulaBlocks: Array.from(document.querySelectorAll("[data-force-field]")),
    scenario: document.getElementById("scenario-select"),
    scenarioNote: document.getElementById("scenario-note"),
    forceStrengthLabel: document.getElementById("force-strength-label"),
    mass: document.getElementById("mass-slider"),
    forceScale: document.getElementById("force-slider"),
    initialVelocityHandle: document.getElementById("initial-velocity-handle"),
    initialVelocityReadout: document.getElementById("initial-velocity-readout"),
    duration: document.getElementById("duration-slider"),
    massOutput: document.getElementById("mass-output-digits"),
    forceOutput: document.getElementById("force-output-digits"),
    forceOutputContainer: document.getElementById("force-output"),
    forceUnitNewton: document.getElementById("force-unit-newton"),
    forceUnitGravity: document.getElementById("force-unit-gravity"),
    forceSymbolF0: document.getElementById("force-symbol-f0"),
    forceSymbolG: document.getElementById("force-symbol-g"),
    initialSpeedOutput: document.getElementById("initial-speed-output-digits"),
    durationOutput: document.getElementById("duration-output-digits"),
    play: document.getElementById("play-button"),
    reset: document.getElementById("reset-button"),
    speed: document.getElementById("speed-select"),
    time: document.getElementById("time-slider"),
    timeOutput: document.getElementById("time-output-digits"),
    loop: document.getElementById("loop-toggle"),
    fieldToggle: document.getElementById("field-toggle"),
    forceToggle: document.getElementById("force-toggle"),
    velocityToggle: document.getElementById("velocity-toggle"),
    trajectoryToggle: document.getElementById("trajectory-toggle"),
    areaToggle: document.getElementById("area-toggle"),
    clearOverlays: document.getElementById("clear-overlays"),
    sceneViewport: document.getElementById("scene-viewport"),
    sceneLengthScale: document.getElementById("scene-length-scale"),
    sceneCanvas: document.getElementById("scene-canvas"),
    powerCanvas: document.getElementById("power-canvas"),
    kineticCanvas: document.getElementById("kinetic-canvas"),
    kineticTicks: document.getElementById("kinetic-ticks"),
    kineticResultDigits: document.getElementById("kinetic-result-digits"),
    resetView: document.getElementById("reset-view"),
    loading: document.getElementById("loading-message"),
    timeBadge: document.getElementById("time-badge-digits"),
    sceneLabelA: document.getElementById("scene-label-a"),
    sceneLabelB: document.getElementById("scene-label-b"),
    sceneLabelForce: document.getElementById("scene-label-force"),
    sceneLabelVelocity: document.getElementById("scene-label-velocity"),
    chartTicks: document.getElementById("chart-ticks"),
    powerAxisUnit: document.getElementById("power-axis-unit"),
    instantaneousVectorCard: document.getElementById("instantaneous-vector-card"),
    powerLegendSignFormulas: {
      positive: document.getElementById("power-legend-positive"),
      negative: document.getElementById("power-legend-negative"),
      neutral: document.getElementById("power-legend-neutral")
    },
    instantaneousForceLabel: document.querySelector(".force-vector-label"),
    instantaneousVelocityLabel: document.querySelector(".velocity-vector-label"),
    instantForceArrow: document.getElementById("instant-force-arrow"),
    instantVelocityArrow: document.getElementById("instant-velocity-arrow"),
    powerSignBadge: document.getElementById("power-sign-badge"),
    workResultBadge: document.getElementById("work-result-badge"),
    workResultDigits: document.getElementById("work-result-digits"),
    powerReadout: document.getElementById("power-readout"),
    workReadout: document.getElementById("work-readout"),
    deltaKReadout: document.getElementById("delta-k-readout"),
    angleReadout: document.getElementById("angle-readout"),
    theoremReadout: document.getElementById("theorem-readout"),
    accessibleSummary: document.getElementById("accessible-summary")
  };

  const state = {
    parameters: { ...PRESETS.positive },
    simulation: null,
    time: 0,
    playing: false,
    playbackRate: 1,
    loop: false,
    lastFrameTime: 0,
    animationFrame: 0,
    lastAccessibleUpdate: -Infinity,
    view: { centerX: PI, centerY: 1.5 * PI, zoom: 1.25 },
    drag: null,
    display: {
      field: true,
      force: true,
      velocity: true,
      trajectory: true,
      area: true
    },
    nonGravitySettings: null
  };

  let mathIsReady = false;
  let imposedWork = null;
  const mathGlyphTemplates = new Map();
  let chartTickSignature = "";
  let powerAxisUnitExponent = null;
  let kineticTickSignature = "";

  async function initializeMathGlyphs() {
    const characters = "0123456789.,-+—";
    for (const character of characters) {
      const tex = character === "-"
        ? "{-}"
        : character === ","
          ? "{,}"
          : character === "—"
            ? "\\text{—}"
            : character;
      const rendered = await window.MathJax.tex2svgPromise(tex, { display: false });
      rendered.setAttribute("aria-hidden", "true");
      mathGlyphTemplates.set(character, rendered);
    }
  }

  function setMathDigits(element, text) {
    if (!element) return;
    const value = String(text);
    if (!mathIsReady || mathGlyphTemplates.size === 0) {
      element.textContent = value;
      element.dataset.value = value;
      return;
    }
    if (element.dataset.value === value && element.classList.contains("typeset")) return;
    const fragment = document.createDocumentFragment();
    for (const character of value) {
      const wrapper = document.createElement("span");
      wrapper.className = "math-glyph";
      wrapper.setAttribute("aria-hidden", "true");
      const template = mathGlyphTemplates.get(character);
      if (template) wrapper.append(template.cloneNode(true));
      else wrapper.textContent = character;
      fragment.append(wrapper);
    }
    element.replaceChildren(fragment);
    element.classList.add("typeset");
    element.dataset.value = value;
  }

  function forceAt(x, y, time = state.time, parameters = state.parameters) {
    const fieldId = parameters.fieldId || "cellular";
    const amplitude = parameters.forceScale;
    if (fieldId === "periodic") {
      return {
        x: -amplitude * Math.sin(x - PI),
        y: -amplitude * Math.sin(y - 1.5 * PI)
      };
    }
    if (fieldId === "central") {
      const dx = x - PI;
      const dy = y - 1.5 * PI;
      const factor = -amplitude / Math.sqrt(1 + dx * dx + dy * dy);
      return { x: factor * dx, y: factor * dy };
    }
    if (fieldId === "vortex") {
      const dx = x - PI;
      const dy = y - 1.5 * PI;
      const factor = amplitude / Math.sqrt(1 + dx * dx + dy * dy);
      return { x: -factor * dy, y: factor * dx };
    }
    if (fieldId === "rotating") {
      return {
        x: amplitude * Math.cos(ROTATING_FIELD_OMEGA * time),
        y: amplitude * Math.sin(ROTATING_FIELD_OMEGA * time)
      };
    }
    if (fieldId === "traveling") {
      const phase = x - ROTATING_FIELD_OMEGA * time;
      return {
        x: amplitude * Math.sin(phase) * Math.cos(y),
        y: -amplitude * Math.cos(phase) * Math.sin(y)
      };
    }
    if (fieldId === "gravity") {
      return { x: 0, y: -parameters.mass * amplitude };
    }
    return {
      x: amplitude * Math.sin(x) * Math.cos(y),
      y: -amplitude * Math.cos(x) * Math.sin(y)
    };
  }

  function fieldReferenceMagnitude(parameters = state.parameters) {
    const fieldType = FIELD_TYPES[parameters.fieldId] || FIELD_TYPES.cellular;
    if (parameters.fieldId === "gravity") {
      return Math.max(1e-9, parameters.mass * parameters.forceScale);
    }
    return Math.max(1e-9, parameters.forceScale * fieldType.maxMagnitudeFactor);
  }

  function derivative(vector, time, parameters) {
    const field = forceAt(vector[0], vector[1], time, parameters);
    return [vector[2], vector[3], field.x / parameters.mass, field.y / parameters.mass];
  }

  function addScaled(vector, increment, scale) {
    return [
      vector[0] + scale * increment[0],
      vector[1] + scale * increment[1],
      vector[2] + scale * increment[2],
      vector[3] + scale * increment[3]
    ];
  }

  function integrate(parameters) {
    const count = Math.max(1600, Math.ceil(parameters.duration / 0.005));
    const dt = parameters.duration / count;
    const t = new Float64Array(count + 1);
    const x = new Float64Array(count + 1);
    const y = new Float64Array(count + 1);
    const vx = new Float64Array(count + 1);
    const vy = new Float64Array(count + 1);
    const fx = new Float64Array(count + 1);
    const fy = new Float64Array(count + 1);
    const power = new Float64Array(count + 1);
    const work = new Float64Array(count + 1);
    const kinetic = new Float64Array(count + 1);

    const initialAngleRadians = parameters.angle0 * PI / 180;
    let vector = [
      parameters.x0,
      parameters.y0,
      parameters.speed0 * Math.cos(initialAngleRadians),
      parameters.speed0 * Math.sin(initialAngleRadians)
    ];
    const record = (index) => {
      t[index] = index * dt;
      const field = forceAt(vector[0], vector[1], t[index], parameters);
      x[index] = vector[0];
      y[index] = vector[1];
      vx[index] = vector[2];
      vy[index] = vector[3];
      fx[index] = field.x;
      fy[index] = field.y;
      power[index] = field.x * vector[2] + field.y * vector[3];
      kinetic[index] = 0.5 * parameters.mass * (vector[2] ** 2 + vector[3] ** 2);
    };

    record(0);
    let maxAbsPower = Math.abs(power[0]);
    let maxKinetic = kinetic[0];
    for (let i = 0; i < count; i += 1) {
      const currentTime = i * dt;
      const k1 = derivative(vector, currentTime, parameters);
      const k2 = derivative(addScaled(vector, k1, dt / 2), currentTime + dt / 2, parameters);
      const k3 = derivative(addScaled(vector, k2, dt / 2), currentTime + dt / 2, parameters);
      const k4 = derivative(addScaled(vector, k3, dt), currentTime + dt, parameters);
      vector = vector.map((value, component) => value + (dt / 6) * (
        k1[component] + 2 * k2[component] + 2 * k3[component] + k4[component]
      ));
      record(i + 1);
      work[i + 1] = work[i] + 0.5 * (power[i] + power[i + 1]) * dt;
      maxAbsPower = Math.max(maxAbsPower, Math.abs(power[i + 1]));
      maxKinetic = Math.max(maxKinetic, kinetic[i + 1]);
    }

    return {
      count,
      dt,
      t,
      x,
      y,
      vx,
      vy,
      fx,
      fy,
      power,
      work,
      kinetic,
      initialKinetic: kinetic[0],
      maxKinetic,
      maxAbsPower: Math.max(0.05, maxAbsPower)
    };
  }

  function sampleSimulation(time) {
    const simulation = state.simulation;
    const normalized = Math.max(0, Math.min(simulation.count, time / simulation.dt));
    const low = Math.min(simulation.count - 1, Math.floor(normalized));
    const high = Math.min(simulation.count, low + 1);
    const fraction = normalized - low;
    const interpolate = (array) => array[low] + fraction * (array[high] - array[low]);
    return {
      index: low,
      fraction,
      t: time,
      x: interpolate(simulation.x),
      y: interpolate(simulation.y),
      vx: interpolate(simulation.vx),
      vy: interpolate(simulation.vy),
      fx: interpolate(simulation.fx),
      fy: interpolate(simulation.fy),
      power: interpolate(simulation.power),
      work: interpolate(simulation.work),
      kinetic: interpolate(simulation.kinetic)
    };
  }

  function canvasContext(canvas) {
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(2.25, window.devicePixelRatio || 1);
    const width = Math.max(1, Math.round(rect.width));
    const height = Math.max(1, Math.round(rect.height));
    const pixelWidth = Math.round(width * dpr);
    const pixelHeight = Math.round(height * dpr);
    if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
      canvas.width = pixelWidth;
      canvas.height = pixelHeight;
    }
    const context = canvas.getContext("2d");
    context.setTransform(dpr, 0, 0, dpr, 0, 0);
    context.clearRect(0, 0, width, height);
    return { context, width, height };
  }

  function viewTransform(width, height) {
    const padding = 26;
    const baseScale = Math.min(
      (width - 2 * padding) / (DOMAIN.xMax - DOMAIN.xMin),
      (height - 2 * padding) / (DOMAIN.yMax - DOMAIN.yMin)
    );
    const scale = Math.max(8, baseScale * state.view.zoom);
    // For uniform gravity, use the available width independently from height:
    // this keeps the full parabolic flight visible while making its curvature
    // easier to read. Other fields retain equal axis scales.
    const scaleX = state.parameters.fieldId === "gravity"
      ? Math.max(8, ((width - 2 * padding) / (DOMAIN.xMax - DOMAIN.xMin)) * state.view.zoom)
      : scale;
    const scaleY = scale;
    return {
      scale,
      scaleX,
      scaleY,
      worldToScreen(x, y) {
        return {
          x: width / 2 + (x - state.view.centerX) * scaleX,
          y: height / 2 - (y - state.view.centerY) * scaleY
        };
      },
      screenToWorld(x, y) {
        return {
          x: state.view.centerX + (x - width / 2) / scaleX,
          y: state.view.centerY - (y - height / 2) / scaleY
        };
      }
    };
  }

  function hexToRgb(hex) {
    const value = hex.replace("#", "");
    return [0, 2, 4].map((offset) => parseInt(value.slice(offset, offset + 2), 16));
  }

  function viridis(value, alpha = 1) {
    const stops = ["#440154", "#3b528b", "#21918c", "#5ec962", "#fde725"];
    const position = Math.max(0, Math.min(1, value)) * (stops.length - 1);
    const low = Math.floor(position);
    const high = Math.min(stops.length - 1, low + 1);
    const fraction = position - low;
    const a = hexToRgb(stops[low]);
    const b = hexToRgb(stops[high]);
    const rgb = a.map((channel, i) => Math.round(channel + fraction * (b[i] - channel)));
    return `rgba(${rgb[0]}, ${rgb[1]}, ${rgb[2]}, ${alpha})`;
  }

  function drawArrow(context, startX, startY, deltaX, deltaY, options = {}) {
    const length = Math.hypot(deltaX, deltaY);
    if (!Number.isFinite(length) || length < 1.5) return;
    const color = options.color || COLORS.ink;
    const lineWidth = options.lineWidth || 2;
    const headLength = Math.min(options.headLength || 9, 0.65 * length);
    const endX = startX + deltaX;
    const endY = startY + deltaY;
    const ux = deltaX / length;
    const uy = deltaY / length;
    const depth = headLength * Math.cos(Math.PI / 6);
    const halfWidth = headLength * Math.sin(Math.PI / 6);
    const overlap = Math.min(lineWidth, 0.2 * depth);
    const baseX = endX - depth * ux;
    const baseY = endY - depth * uy;
    const shaftEndX = baseX + overlap * ux;
    const shaftEndY = baseY + overlap * uy;
    const leftX = baseX - halfWidth * uy;
    const leftY = baseY + halfWidth * ux;
    const rightX = baseX + halfWidth * uy;
    const rightY = baseY - halfWidth * ux;
    context.save();
    context.lineCap = "round";
    context.lineJoin = "round";
    if (options.halo) {
      context.beginPath();
      context.moveTo(startX, startY);
      context.lineTo(shaftEndX, shaftEndY);
      context.strokeStyle = "rgba(255,255,255,.82)";
      context.lineWidth = lineWidth + 3.5;
      context.stroke();
    }
    context.beginPath();
    context.moveTo(startX, startY);
    context.lineTo(shaftEndX, shaftEndY);
    context.strokeStyle = color;
    context.lineWidth = lineWidth;
    context.stroke();
    context.beginPath();
    context.moveTo(endX, endY);
    context.lineTo(leftX, leftY);
    context.lineTo(rightX, rightY);
    context.closePath();
    context.fillStyle = color;
    context.fill();
    context.restore();
  }

  function positionSceneLabel(element, x, y, visible, width, height) {
    const onScreen = x > -24 && x < width + 24 && y > -24 && y < height + 24;
    element.hidden = !(visible && onScreen);
    if (element.hidden) return;
    element.style.left = `${x}px`;
    element.style.top = `${y}px`;
  }

  function positionVectorLabel(element, originX, originY, deltaX, deltaY, visible, width, height, side) {
    const length = Math.hypot(deltaX, deltaY);
    if (!visible || length <= 4 || originX < 0 || originX > width || originY < 0 || originY > height) {
      positionSceneLabel(element, 0, 0, false, width, height);
      return;
    }
    const ux = deltaX / length;
    const uy = deltaY / length;
    const along = 16;
    const normal = 10 * side;
    element.hidden = false;
    const halfWidth = element.offsetWidth / 2 + 5;
    const halfHeight = element.offsetHeight / 2 + 5;
    const x = originX + deltaX + ux * along - uy * normal;
    const y = originY + deltaY + uy * along + ux * normal;
    positionSceneLabel(element,
      Math.max(halfWidth, Math.min(width - halfWidth, x)),
      Math.max(halfHeight, Math.min(height - halfHeight, y)),
      true, width, height);
  }

  function vectorRoom(origin, directionX, directionY, width, height, inset) {
    if (origin.x < inset || origin.x > width - inset ||
        origin.y < inset || origin.y > height - inset) return 0;
    const xRoom = directionX > 0 ? (width - inset - origin.x) / directionX
      : directionX < 0 ? (inset - origin.x) / directionX : Infinity;
    const yRoom = directionY > 0 ? (height - inset - origin.y) / directionY
      : directionY < 0 ? (inset - origin.y) / directionY : Infinity;
    return Math.max(0, Math.min(xRoom, yRoom));
  }

  function sceneVectorLength(width, height) {
    return Math.min(220, 0.57 * Math.min(width, height));
  }

  function velocityFraction(speed) {
    return Math.min(1, Math.log1p(Math.max(0, speed) / VELOCITY_DISPLAY_SCALE) /
      Math.log1p(MAX_INITIAL_SPEED / VELOCITY_DISPLAY_SCALE));
  }

  function velocityVector(origin, vx, vy, transform, width, height) {
    // Use the projected velocity as the direction, so the arrow is tangent even
    // when the gravity view has different horizontal and vertical scales.
    const projectedX = vx * transform.scaleX;
    const projectedY = -vy * transform.scaleY;
    const norm = Math.hypot(projectedX, projectedY);
    if (norm < 1e-10) return { x: 0, y: 0 };
    const ux = projectedX / norm;
    const uy = projectedY / norm;
    const room = Math.min(sceneVectorLength(width, height),
      vectorRoom(origin, ux, uy, width, height, VELOCITY_HANDLE_INSET));
    const length = room * velocityFraction(Math.hypot(vx, vy));
    return { x: ux * length, y: uy * length };
  }

  function forceVector(origin, fx, fy, transform, width, height) {
    const projectedX = fx * transform.scaleX;
    const projectedY = -fy * transform.scaleY;
    const norm = Math.hypot(projectedX, projectedY);
    if (norm < 1e-10) return { x: 0, y: 0 };
    const ux = projectedX / norm;
    const uy = projectedY / norm;
    const field = FIELD_TYPES[state.parameters.fieldId] || FIELD_TYPES.cellular;
    const reference = state.parameters.fieldId === "gravity"
      ? 20 * 9.81 : field.maxMagnitudeFactor;
    const strength = Math.min(1, Math.sqrt(Math.hypot(fx, fy) / reference));
    const length = Math.min(0.78 * sceneVectorLength(width, height),
      vectorRoom(origin, ux, uy, width, height, VECTOR_INSET)) * strength;
    return { x: ux * length, y: uy * length };
  }

  function drawScene(sample) {
    const { context, width, height } = canvasContext(dom.sceneCanvas);
    const transform = viewTransform(width, height);
    dom.sceneLengthScale.style.setProperty("--length-scale-px", `${transform.scale}px`);
    context.fillStyle = "#101d2c";
    context.fillRect(0, 0, width, height);

    const topLeft = transform.worldToScreen(DOMAIN.xMin, DOMAIN.yMax);
    const bottomRight = transform.worldToScreen(DOMAIN.xMax, DOMAIN.yMin);
    context.save();
    context.strokeStyle = "rgba(174, 199, 228, .22)";
    context.lineWidth = 1;
    context.strokeRect(topLeft.x, topLeft.y, bottomRight.x - topLeft.x, bottomRight.y - topLeft.y);
    context.restore();

    if (state.display.field) {
      const xSteps = 26;
      const ySteps = 35;
      const xSpacing = Math.max((DOMAIN.xMax - DOMAIN.xMin) / (xSteps - 1), 18 / transform.scaleX);
      const ySpacing = Math.max((DOMAIN.yMax - DOMAIN.yMin) / (ySteps - 1), 18 / transform.scaleY);
      const cellSize = Math.min(xSpacing * transform.scaleX, ySpacing * transform.scaleY);
      const maxArrowLength = Math.min(17, 0.54 * cellSize);
      const visibleTopLeft = transform.screenToWorld(0, 0);
      const visibleBottomRight = transform.screenToWorld(width, height);
      const xStart = Math.floor(visibleTopLeft.x / xSpacing) * xSpacing;
      const xEnd = visibleBottomRight.x;
      const yStart = Math.floor(visibleBottomRight.y / ySpacing) * ySpacing;
      const yEnd = visibleTopLeft.y;
      for (let x = xStart; x <= xEnd; x += xSpacing) {
        for (let y = yStart; y <= yEnd; y += ySpacing) {
          const point = transform.worldToScreen(x, y);
          const field = forceAt(x, y);
          const magnitude = Math.hypot(field.x, field.y);
          if (magnitude < 0.015) continue;
          const relative = Math.min(1, magnitude / fieldReferenceMagnitude());
          const arrowLength = maxArrowLength * (0.28 + 0.72 * Math.sqrt(relative));
          const dx = (field.x / magnitude) * arrowLength;
          const dy = -(field.y / magnitude) * arrowLength;
          if (point.x < 5 || point.x + dx < 5 || point.x > width - 5 || point.x + dx > width - 5 ||
              point.y < 5 || point.y + dy < 5 || point.y > height - 5 || point.y + dy > height - 5) continue;
          drawArrow(
            context,
            point.x,
            point.y,
            dx,
            dy,
            { color: viridis(relative, 0.78), lineWidth: 1.15, headLength: 4.2 }
          );
        }
      }
    }

    const simulation = state.simulation;
    const pathStep = Math.max(1, Math.floor(simulation.count / 1400));
    if (state.display.trajectory) {
      context.save();
      context.beginPath();
      for (let i = 0; i <= simulation.count; i += pathStep) {
        const point = transform.worldToScreen(simulation.x[i], simulation.y[i]);
        if (i === 0) context.moveTo(point.x, point.y);
        else context.lineTo(point.x, point.y);
      }
      const finalPoint = transform.worldToScreen(
        simulation.x[simulation.count],
        simulation.y[simulation.count]
      );
      context.lineTo(finalPoint.x, finalPoint.y);
      context.strokeStyle = "rgba(247,251,255,.35)";
      context.lineWidth = 1.6;
      context.stroke();
      context.restore();
    }

    context.save();
    context.beginPath();
    const currentIndex = sample.index;
    for (let i = 0; i <= currentIndex; i += pathStep) {
      const point = transform.worldToScreen(simulation.x[i], simulation.y[i]);
      if (i === 0) context.moveTo(point.x, point.y);
      else context.lineTo(point.x, point.y);
    }
    const currentPoint = transform.worldToScreen(sample.x, sample.y);
    context.lineTo(currentPoint.x, currentPoint.y);
    context.strokeStyle = COLORS.progress;
    context.lineWidth = 2.6;
    context.shadowColor = "rgba(213,230,243,.2)";
    context.shadowBlur = 0;
    context.stroke();
    context.restore();

    const start = transform.worldToScreen(simulation.x[0], simulation.y[0]);
    const end = transform.worldToScreen(simulation.x[simulation.count], simulation.y[simulation.count]);
    for (const point of [start, end]) {
      context.beginPath();
      context.arc(point.x, point.y, 3.5, 0, 2 * PI);
      context.fillStyle = COLORS.point;
      context.fill();
    }
    positionSceneLabel(dom.sceneLabelA, start.x + 10, start.y - 11, true, width, height);
    positionSceneLabel(dom.sceneLabelB, end.x + 10, end.y - 11, true, width, height);

    const editingVelocity = canEditInitialVelocity();
    const showVelocity = state.display.velocity || editingVelocity;
    let forceDeltaX = 0;
    let forceDeltaY = 0;
    if (state.display.force) {
      const forceMagnitude = Math.hypot(sample.fx, sample.fy);
      const forceColor = viridis(
        Math.min(1, forceMagnitude / fieldReferenceMagnitude()),
        1
      );
      const forceDelta = forceVector(currentPoint, sample.fx, sample.fy, transform, width, height);
      forceDeltaX = forceDelta.x;
      forceDeltaY = forceDelta.y;
      drawArrow(
        context,
        currentPoint.x,
        currentPoint.y,
        forceDeltaX,
        forceDeltaY,
        { color: forceColor, lineWidth: 2.6, headLength: 10 }
      );
      dom.sceneLabelForce.style.color = forceColor;
    }
    let velocityDeltaX = 0;
    let velocityDeltaY = 0;
    if (showVelocity) {
      const velocityDelta = velocityVector(currentPoint, sample.vx, sample.vy, transform, width, height);
      velocityDeltaX = velocityDelta.x;
      velocityDeltaY = velocityDelta.y;
      drawArrow(
        context,
        currentPoint.x,
        currentPoint.y,
        velocityDeltaX,
        velocityDeltaY,
        { color: COLORS.velocity, lineWidth: 2.6, headLength: 10 }
      );
    }
    positionVectorLabel(
      dom.sceneLabelForce,
      currentPoint.x,
      currentPoint.y,
      forceDeltaX,
      forceDeltaY,
      state.display.force,
      width,
      height,
      -1
    );
    positionVectorLabel(
      dom.sceneLabelVelocity,
      currentPoint.x,
      currentPoint.y,
      velocityDeltaX,
      velocityDeltaY,
      showVelocity,
      width,
      height,
      1
    );

    context.save();
    context.beginPath();
    context.arc(currentPoint.x, currentPoint.y, 3.5, 0, 2 * PI);
    context.fillStyle = COLORS.particle;
    context.shadowColor = "rgba(237,138,88,.3)";
    context.shadowBlur = 3;
    context.fill();
    context.lineWidth = 1.5;
    context.strokeStyle = "#fff";
    context.stroke();
    context.restore();
    updateInitialVelocityHandle(transform, context, width, height);
  }

  function canEditInitialVelocity() {
    return state.time <= 1e-9 && !state.playing && !imposedWork?.isActive();
  }

  function initialVelocityGeometry(transform, width, height) {
    const start = transform.worldToScreen(state.parameters.x0, state.parameters.y0);
    const angle = state.parameters.angle0 * PI / 180;
    const delta = velocityVector(start,
      state.parameters.speed0 * Math.cos(angle),
      state.parameters.speed0 * Math.sin(angle),
      transform, width, height);
    const tip = {
      x: start.x + delta.x,
      y: start.y + delta.y
    };
    return { start, tip, handle: tip, offset: { x: 0, y: 0 } };
  }

  function updateInitialVelocityHandle(transform, context, width, height) {
    const editable = canEditInitialVelocity();
    dom.initialVelocityHandle.hidden = !editable;
    dom.initialVelocityReadout.hidden = !editable;
    if (!editable) return;
    const { tip, handle, offset } = initialVelocityGeometry(transform, width, height);
    dom.initialVelocityHandle.style.left = handle.x + "px";
    dom.initialVelocityHandle.style.top = handle.y + "px";
    if (Math.hypot(offset.x, offset.y) > 2) {
      context.save();
      context.setLineDash([3, 4]);
      context.strokeStyle = COLORS.velocity;
      context.globalAlpha = 0.65;
      context.lineWidth = 1;
      context.beginPath(); context.moveTo(tip.x, tip.y); context.lineTo(handle.x, handle.y);
      context.stroke(); context.restore();
    }
  }

  function setInitialVelocity(vx, vy) {
    const speed = Math.hypot(vx, vy);
    state.parameters.speed0 = speed < 1e-10 ? 0 : Math.min(MAX_INITIAL_SPEED, speed);
    if (speed >= 1e-10) state.parameters.angle0 = Math.atan2(vy, vx) * 180 / PI;
    markCustom();
    recompute();
  }

  function drawPowerChart(sample) {
    const { context, width, height } = canvasContext(dom.powerCanvas);
    context.fillStyle = "#ffffff";
    context.fillRect(0, 0, width, height);

    const compact = width < 430;
    const margin = { left: compact ? 52 : 66, right: 24, top: 120, bottom: 48 };
    const plotWidth = Math.max(10, width - margin.left - margin.right);
    const plotHeight = Math.max(10, height - margin.top - margin.bottom);
    const yLimit = state.simulation.maxAbsPower * 1.18;
    const yLimitMagnitude = Math.max(Math.abs(yLimit), 1e-300);
    const powerUnit = POWER_UNITS.reduce((closest, unit) => {
      const distance = Math.abs(Math.log10(yLimitMagnitude) - unit.exponent);
      return distance < closest.distance ? { ...unit, distance } : closest;
    }, { ...POWER_UNITS[10], distance: Infinity });
    const yScaleFactor = 10 ** powerUnit.exponent;
    if (powerUnit.exponent !== powerAxisUnitExponent) {
      powerAxisUnitExponent = powerUnit.exponent;
      window.MathJax?.typesetClear?.([dom.powerAxisUnit]);
      dom.powerAxisUnit.textContent = `\\(\\,[\\mathrm{${powerUnit.prefix}W}]\\)`;
      if (mathIsReady && window.MathJax?.typesetPromise) {
        window.MathJax.typesetPromise([dom.powerAxisUnit]).catch(() => {});
      }
    }
    const plotDuration = Math.max(state.parameters.duration, 1e-9);
    const xMap = (value) => margin.left + (value / plotDuration) * plotWidth;
    const yMap = (value) => margin.top + ((yLimit - value) / (2 * yLimit)) * plotHeight;
    const zeroY = yMap(0);
    const finalArea = document.getElementById('final-work-area');
    finalArea.hidden = !(state.display.area && state.time >= state.parameters.duration - 1e-8);
    if (!finalArea.hidden) {
      finalArea.style.maxWidth = `${Math.max(100, plotWidth - 12)}px`;
      finalArea.style.left = `${width / 2}px`;
      finalArea.style.top = `${height * 0.3}px`;
    }

    const tickSignature = [
      Math.round(width),
      Math.round(height),
      state.parameters.duration.toFixed(6),
      yLimit.toFixed(8),
      mathIsReady ? "latex" : "plain"
    ].join("|");
    if (tickSignature !== chartTickSignature) {
      const fragment = document.createDocumentFragment();
      const addTick = (value, x, y, className) => {
        const label = document.createElement("span");
        label.className = `chart-tick-label ${className}`;
        label.style.left = `${x}px`;
        label.style.top = `${y}px`;
        const digits = document.createElement("span");
        digits.className = "math-digits";
        label.append(digits);
        setMathDigits(digits, tickNumber.format(value));
        fragment.append(label);
      };
      const timeDivisions = compact ? 3 : 5;
      for (let i = 0; i <= timeDivisions; i += 1) {
        const value = (i / timeDivisions) * state.parameters.duration;
        addTick(value, xMap(value), margin.top + plotHeight + 15, "x-tick");
      }
      for (let i = -2; i <= 2; i += 1) {
        const value = (i / 2) * yLimit;
        addTick(value / yScaleFactor, margin.left - 8, yMap(value), "y-tick");
      }
      if (mathIsReady) window.MathJax?.typesetClear?.([dom.chartTicks]);
      dom.chartTicks.replaceChildren(fragment);
      chartTickSignature = tickSignature;
    }

    context.save();
    context.strokeStyle = COLORS.grid;
    context.lineWidth = 1;
    const timeDivisions = compact ? 3 : 5;
    for (let i = 0; i <= timeDivisions; i += 1) {
      const t = (i / timeDivisions) * state.parameters.duration;
      const x = xMap(t);
      context.beginPath();
      context.moveTo(x, margin.top);
      context.lineTo(x, margin.top + plotHeight);
      context.stroke();
    }
    for (let i = -2; i <= 2; i += 1) {
      const value = (i / 2) * yLimit;
      const y = yMap(value);
      context.beginPath();
      context.moveTo(margin.left, y);
      context.lineTo(margin.left + plotWidth, y);
      context.strokeStyle = i === 0 ? "#8a97a8" : COLORS.grid;
      context.setLineDash(i === 0 ? [5, 4] : []);
      context.stroke();
    }
    context.setLineDash([]);

    const simulation = state.simulation;
    const fullStep = Math.max(1, Math.floor(simulation.count / 900));
    context.beginPath();
    for (let i = 0; i <= simulation.count; i += fullStep) {
      const x = xMap(simulation.t[i]);
      const y = yMap(simulation.power[i]);
      if (i === 0) context.moveTo(x, y);
      else context.lineTo(x, y);
    }
    context.strokeStyle = "rgba(39,117,182,.28)";
    context.lineWidth = 1.5;
    context.stroke();

    const progressPoints = [];
    const progressStep = Math.max(1, Math.floor(Math.max(1, sample.index) / 600));
    for (let i = 0; i <= sample.index; i += progressStep) {
      progressPoints.push({ t: simulation.t[i], p: simulation.power[i] });
    }
    const last = progressPoints[progressPoints.length - 1];
    if (!last || Math.abs(last.t - sample.t) > 1e-8) {
      progressPoints.push({ t: sample.t, p: sample.power });
    }

    if (state.display.area && progressPoints.length > 1) {
      const fillPart = (first, second, color) => {
        context.beginPath();
        context.moveTo(xMap(first.t), zeroY);
        context.lineTo(xMap(first.t), yMap(first.p));
        context.lineTo(xMap(second.t), yMap(second.p));
        context.lineTo(xMap(second.t), zeroY);
        context.closePath();
        context.fillStyle = color;
        context.fill();
      };
      for (let i = 0; i < progressPoints.length - 1; i += 1) {
        const first = progressPoints[i];
        const second = progressPoints[i + 1];
        if (first.p === 0 || second.p === 0 || Math.sign(first.p) === Math.sign(second.p)) {
          const positive = (first.p + second.p) / 2 >= 0;
          fillPart(first, second, positive ? "rgba(38,133,118,.24)" : "rgba(181,104,123,.24)");
        } else {
          const fraction = -first.p / (second.p - first.p);
          const crossing = { t: first.t + fraction * (second.t - first.t), p: 0 };
          fillPart(first, crossing, first.p > 0 ? "rgba(38,133,118,.24)" : "rgba(181,104,123,.24)");
          fillPart(crossing, second, second.p > 0 ? "rgba(38,133,118,.24)" : "rgba(181,104,123,.24)");
        }
      }
    }

    if (progressPoints.length > 1) {
      context.beginPath();
      progressPoints.forEach((point, index) => {
        const x = xMap(point.t);
        const y = yMap(point.p);
        if (index === 0) context.moveTo(x, y);
        else context.lineTo(x, y);
      });
      context.strokeStyle = COLORS.work;
      context.lineWidth = 2.3;
      context.stroke();
    }

    const currentX = xMap(sample.t);
    const currentY = yMap(sample.power);
    context.beginPath();
    context.moveTo(currentX, margin.top);
    context.lineTo(currentX, margin.top + plotHeight);
    context.strokeStyle = "rgba(23,32,51,.38)";
    context.setLineDash([3, 4]);
    context.stroke();
    context.setLineDash([]);
    context.beginPath();
    context.arc(currentX, currentY, 4.5, 0, 2 * PI);
    context.fillStyle = COLORS.work;
    context.fill();
    context.lineWidth = 2;
    context.strokeStyle = "#fff";
    context.stroke();
    context.restore();
  }

  function signed(value, digits = 3) {
    const formatter = digits === 2 ? number2 : digits === 6 ? number6 : number3;
    if (Math.abs(value) < 0.5 * 10 ** (-digits)) return formatter.format(0);
    return formatter.format(value);
  }

  function angleBetween(sample) {
    const forceNorm = Math.hypot(sample.fx, sample.fy);
    const speed = Math.hypot(sample.vx, sample.vy);
    if (forceNorm < 1e-10 || speed < 1e-10) return null;
    const cosine = Math.max(-1, Math.min(1, sample.power / (forceNorm * speed)));
    return Math.acos(cosine) * 180 / PI;
  }

  function updatePowerBadge(power) {
    dom.powerSignBadge.classList.remove("positive", "negative", "neutral");
    if (power > 0.002) {
      dom.powerSignBadge.classList.add("positive");
      dom.powerSignBadge.textContent = physTranslate("Puissance motrice");
    } else if (power < -0.002) {
      dom.powerSignBadge.classList.add("negative");
      dom.powerSignBadge.textContent = physTranslate("Puissance résistante");
    } else {
      dom.powerSignBadge.classList.add("neutral");
      dom.powerSignBadge.textContent = physTranslate("Puissance quasi nulle");
    }
  }

  function updateInstantaneousVectorCard(sample) {
    const card = dom.instantaneousVectorCard;
    const sign = sample.power > 1e-8 ? "positive" : sample.power < -1e-8 ? "negative" : "neutral";
    card.classList.remove("positive", "negative", "neutral");
    card.classList.add(sign);
    for (const [formulaSign, formula] of Object.entries(dom.powerLegendSignFormulas)) {
      formula.hidden = formulaSign !== sign;
    }

    const forceLimit = Math.max(1e-9, fieldReferenceMagnitude());
    const speedLimit = Math.max(1e-9, Math.sqrt(2 * state.simulation.maxKinetic / state.parameters.mass));
    const updateArrow = (group, x, y, limit, color) => {
      group.style.setProperty("--instant-vector-color", color);
      const magnitude = Math.hypot(x, y);
      const line = group.querySelector(".instant-vector-line");
      const head = group.querySelector(".instant-vector-head");
      const zero = group.querySelector(".instant-vector-zero");
      if (magnitude < 1e-8) {
        line.hidden = true;
        head.hidden = true;
        zero.hidden = false;
        group.removeAttribute("transform");
        return;
      }
      line.hidden = false;
      head.hidden = false;
      zero.hidden = true;
      const angle = Math.atan2(-y, x) * 180 / PI;
      group.setAttribute("transform", `rotate(${angle} 38 38)`);
      const relative = Math.min(1, magnitude / limit);
      const end = 38 + 34 * (0.5 + 0.5 * Math.sqrt(relative));
      // Stop the shaft at the triangle's base so it cannot show through the arrowhead.
      line.setAttribute("x2", String(end - 8));
      head.setAttribute("d", `M${end} 38 L${end - 8} 33 L${end - 8} 43 Z`);
    };
    const forceColor = viridis(Math.min(1, Math.hypot(sample.fx, sample.fy) / fieldReferenceMagnitude()), 1);
    dom.instantaneousForceLabel.style.color = forceColor;
    dom.instantaneousVelocityLabel.style.color = COLORS.velocity;
    updateArrow(dom.instantForceArrow, sample.fx, sample.fy, forceLimit, forceColor);
    updateArrow(dom.instantVelocityArrow, sample.vx, sample.vy, speedLimit, COLORS.velocity);
  }

  function drawKineticChart(sample) {
    const { context, width, height } = canvasContext(dom.kineticCanvas);
    context.fillStyle = "#ffffff";
    context.fillRect(0, 0, width, height);
    const compact = width < 430;
    const margin = { left: compact ? 52 : 66, right: 24, top: 54, bottom: 48 };
    const plotWidth = Math.max(10, width - margin.left - margin.right);
    const plotHeight = Math.max(10, height - margin.top - margin.bottom);
    const simulation = state.simulation;
    const showEndpointEnergies = sample.t >= state.parameters.duration - 1e-6;
    document.getElementById('kinetic-legend-delta').hidden = !showEndpointEnergies;
    // A fixed scale for the full run avoids vertical jumps during playback.
    const yLimit = Math.max(.05, simulation.maxKinetic * 1.15);
    const plotDuration = Math.max(state.parameters.duration, 1e-9);
    const xMap = value => margin.left + value / plotDuration * plotWidth;
    const yMap = value => margin.top + (1 - value / yLimit) * plotHeight;
    const timeDivisions = compact ? 3 : 5;
    // Keep long runs (notably free fall) readable without crowding the y axis.
    const unitScale = yLimit >= 1e6 ? 1e6 : yLimit >= 1e3 ? 1e3 : 1;
    document.querySelectorAll('[data-kinetic-unit]').forEach(el => {
      el.hidden = Number(el.dataset.kineticUnit) !== unitScale;
    });
    const signature = [width, height, state.parameters.duration, yLimit, mathIsReady].join('|');
    if (signature !== kineticTickSignature) {
      const fragment = document.createDocumentFragment();
      const addTick = (value, x, y, className) => {
        const label = document.createElement('span');
        label.className = `chart-tick-label ${className}`;
        label.style.left = `${x}px`;
        label.style.top = `${y}px`;
        const digits = document.createElement('span');
        digits.className = 'math-digits';
        setMathDigits(digits, tickNumber.format(value));
        label.append(digits);
        fragment.append(label);
      };
      for (let i = 0; i <= timeDivisions; i += 1) {
        const t = i / timeDivisions * state.parameters.duration;
        addTick(t, xMap(t), margin.top + plotHeight + 15, 'x-tick');
      }
      for (let i = 0; i <= 4; i += 1) {
        const k = i / 4 * yLimit;
        addTick(k / unitScale, margin.left - 8, yMap(k), 'y-tick');
      }
      dom.kineticTicks.replaceChildren(fragment);
      kineticTickSignature = signature;
    }
    context.save();
    context.strokeStyle = COLORS.grid;
    context.lineWidth = 1;
    context.beginPath();
    for (let i = 0; i <= timeDivisions; i += 1) {
      const x = xMap(i / timeDivisions * state.parameters.duration);
      context.moveTo(x, margin.top);
      context.lineTo(x, margin.top + plotHeight);
    }
    for (let i = 0; i <= 4; i += 1) {
      const y = yMap(i / 4 * yLimit);
      context.moveTo(margin.left, y);
      context.lineTo(margin.left + plotWidth, y);
    }
    context.stroke();
    const energyReferenceColor = "#c2413b";
    const deltaKColor = "#a11d2b";
    if (showEndpointEnergies) {
      context.strokeStyle = energyReferenceColor;
      context.setLineDash([5, 4]);
      context.beginPath();
      context.moveTo(margin.left, yMap(simulation.initialKinetic));
      context.lineTo(margin.left + plotWidth, yMap(simulation.initialKinetic));
      context.stroke();
      context.setLineDash([2, 3]);
      context.beginPath();
      context.moveTo(margin.left, yMap(simulation.kinetic[simulation.count]));
      context.lineTo(margin.left + plotWidth, yMap(simulation.kinetic[simulation.count]));
      context.stroke();
      context.setLineDash([]);
    }

    const drawCurve = (endIndex, endTime, endKinetic, color, lineWidth) => {
      const step = Math.max(1, Math.floor(endIndex / 900));
      context.beginPath();
      context.moveTo(xMap(0), yMap(simulation.kinetic[0]));
      for (let i = step; i <= endIndex; i += step) {
        context.lineTo(xMap(simulation.t[i]), yMap(simulation.kinetic[i]));
      }
      context.lineTo(xMap(endTime), yMap(endKinetic));
      context.strokeStyle = color;
      context.lineWidth = lineWidth;
      context.stroke();
    };
    drawCurve(simulation.count, state.parameters.duration, simulation.kinetic[simulation.count], 'rgba(233,141,85,.28)', 1.5);
    drawCurve(sample.index, sample.t, sample.kinetic, COLORS.kinetic, 2.3);

    // Reveal the endpoint energies and their difference only at arrival.
    if (showEndpointEnergies) {
      const startX = xMap(0), startY = yMap(simulation.initialKinetic);
      const endX = xMap(state.parameters.duration);
      const endY = yMap(simulation.kinetic[simulation.count]);
      const drawEnergyTag = (text, x, y, align, color = energyReferenceColor) => {
        context.save();
        context.font = 'italic 17px Georgia, "Times New Roman", serif';
        const subscript = text === 'K_A' ? 'A' : text === 'K_B' ? 'B' : '';
        const mainWidth = context.measureText(subscript ? 'K' : text).width;
        context.font = 'italic 12px Georgia, "Times New Roman", serif';
        const subscriptWidth = subscript ? context.measureText(subscript).width : 0;
        const textWidth = mainWidth + subscriptWidth;
        const textX = align === 'right' ? x - textWidth : x;
        context.fillStyle = color;
        context.textAlign = 'left';
        context.textBaseline = 'alphabetic';
        context.font = 'italic 17px Georgia, "Times New Roman", serif';
        context.lineWidth = 3;
        context.strokeStyle = '#fff';
        context.lineJoin = 'round';
        context.strokeText(subscript ? 'K' : text, textX, y);
        context.fillText(subscript ? 'K' : text, textX, y);
        if (subscript) {
          context.font = 'italic 12px Georgia, "Times New Roman", serif';
          context.strokeText(subscript, textX + mainWidth - 1, y + 4);
          context.fillText(subscript, textX + mainWidth - 1, y + 4);
        }
        context.restore();
      };
      context.save();
      context.fillStyle = energyReferenceColor;
      context.beginPath();
      context.arc(startX, startY, 3.5, 0, 2 * PI);
      context.fill();
      context.beginPath();
      context.arc(endX, endY, 3.5, 0, 2 * PI);
      context.fill();
      const deltaPixel = endY - startY;
      const deltaX = margin.left + plotWidth * 0.52;
      const midY = (startY + endY) / 2;
      context.strokeStyle = deltaKColor;
      context.lineWidth = 1.7;
      context.beginPath();
      if (Math.abs(deltaPixel) < 8) {
        context.moveTo(deltaX, midY - 4);
        context.lineTo(deltaX, midY + 4);
      } else {
        context.moveTo(deltaX, startY);
        context.lineTo(deltaX, endY);
        for (const [tipY, direction] of [[startY, Math.sign(startY - endY)], [endY, Math.sign(endY - startY)]]) {
          context.moveTo(deltaX, tipY);
          context.lineTo(deltaX - 3, tipY + direction * 5);
          context.moveTo(deltaX, tipY);
          context.lineTo(deltaX + 3, tipY + direction * 5);
        }
      }
      context.stroke();
      drawEnergyTag('K_A', startX + 7, startY - 5, 'left');
      drawEnergyTag('K_B', endX - 7, endY - 6, 'right');
      drawEnergyTag('ΔK', deltaX + 5, midY + 4, 'left', deltaKColor);
      context.restore();
    }

    const currentX = xMap(sample.t), currentY = yMap(sample.kinetic);
    context.beginPath();
    context.moveTo(currentX, margin.top);
    context.lineTo(currentX, margin.top + plotHeight);
    context.strokeStyle = 'rgba(23,32,51,.38)';
    context.setLineDash([3, 4]);
    context.stroke();
    context.setLineDash([]);
    context.beginPath();
    context.arc(currentX, currentY, 4.5, 0, 2 * PI);
    context.fillStyle = COLORS.kinetic;
    context.fill();
    context.lineWidth = 2;
    context.strokeStyle = '#fff';
    context.stroke();
    context.restore();
  }

  function updateInterface(sample, forceAccessibleUpdate = false) {
    const deltaK = sample.kinetic - state.simulation.initialKinetic;
    const theoremError = sample.work - deltaK;
    const angle = angleBetween(sample);
    dom.time.value = String(sample.t);
    setMathDigits(dom.timeOutput, number2.format(sample.t));
    setMathDigits(dom.timeBadge, number2.format(sample.t));
    setMathDigits(dom.kineticResultDigits, number3.format(sample.kinetic));
    setMathDigits(dom.powerReadout, signed(sample.power));
    setMathDigits(dom.workReadout, signed(sample.work));
    setMathDigits(dom.deltaKReadout, signed(deltaK));
    setMathDigits(dom.angleReadout, angle === null ? "—" : number2.format(angle));
    setMathDigits(dom.theoremReadout, Math.abs(theoremError) < 5e-6 ? "0" : signed(theoremError, 6));
    setMathDigits(dom.workResultDigits, signed(sample.work));
    updatePowerBadge(sample.power);
    updateInstantaneousVectorCard(sample);

    if (forceAccessibleUpdate || Math.abs(sample.t - state.lastAccessibleUpdate) >= 2) {
      const signDescription = sample.power > 0.002
        ? physTranslate("La force augmente actuellement l’énergie cinétique.")
        : sample.power < -0.002
          ? physTranslate("La force diminue actuellement l’énergie cinétique.")
          : physTranslate("La puissance est actuellement presque nulle.");
      dom.accessibleSummary.textContent = physTranslate(`À ${number2.format(sample.t)} secondes, la puissance vaut ${signed(sample.power)} watt, le travail cumulé ${signed(sample.work)} joule et l’énergie cinétique ${number3.format(sample.kinetic)} joule. ${signDescription}`);
      state.lastAccessibleUpdate = sample.t;
    }
  }

  function render(forceAccessibleUpdate = false) {
    if (imposedWork?.isActive()) { imposedWork.render(); return; }
    if (!state.simulation) return;
    const sample = sampleSimulation(state.time);
    drawScene(sample);
    drawPowerChart(sample);
    drawKineticChart(sample);
    updateInterface(sample, forceAccessibleUpdate);
  }

  function updateParameterOutputs() {
    setMathDigits(dom.massOutput, number2.format(state.parameters.mass));
    setMathDigits(dom.forceOutput, number2.format(state.parameters.forceScale));
    setMathDigits(dom.initialSpeedOutput, number2.format(state.parameters.speed0));
    setMathDigits(dom.durationOutput, number2.format(state.parameters.duration));
  }

  function configureFieldControls() {
    const gravitySelected = state.parameters.fieldId === "gravity";
    dom.forceStrengthLabel.textContent = gravitySelected ? physTranslate("Intensité de la pesanteur") : physTranslate("Intensité du champ");
    dom.forceOutputContainer.setAttribute(
      "aria-label",
      gravitySelected ? physTranslate("Intensité de la pesanteur") : physTranslate("Intensité du champ")
    );
    dom.forceUnitNewton.hidden = gravitySelected;
    dom.forceUnitGravity.hidden = !gravitySelected;
    dom.forceSymbolF0.hidden = gravitySelected;
    dom.forceSymbolG.hidden = !gravitySelected;
    dom.forceScale.min = "0";
    dom.forceScale.max = gravitySelected ? "15" : "2";
    dom.forceScale.step = gravitySelected ? "0.01" : "0.1";
    dom.duration.min = gravitySelected ? "0" : "5";
    dom.duration.max = gravitySelected ? "5" : "100";
  }

  function updateForceFieldInterface() {
    const fieldId = FIELD_TYPES[state.parameters.fieldId] ? state.parameters.fieldId : "cellular";
    state.parameters.fieldId = fieldId;
    dom.forceField.value = fieldId;
    configureFieldControls();
    dom.forceFieldNote.textContent = FIELD_TYPES[fieldId].note;
    dom.sceneLengthScale.hidden = fieldId === "rotating" || fieldId === "gravity";
    for (const block of dom.fieldFormulaBlocks) {
      block.hidden = block.dataset.forceField !== fieldId;
    }
  }

  function updateScenarioConclusion() {
    const simulation = state.simulation;
    const finalWork = simulation.work[simulation.count];
    const relation = finalWork > 0.002
      ? physTranslate("À l’arrivée, le travail total est positif et la particule est plus rapide qu’au départ.")
      : finalWork < -0.002
        ? physTranslate("À l’arrivée, le travail total est négatif et la particule est plus lente qu’au départ.")
        : physTranslate("À l’arrivée, les travaux positif et négatif se compensent : la norme de la vitesse retrouve sa valeur initiale.");
    dom.scenarioNote.textContent = relation;
  }

  function recompute({ resetTime = true } = {}) {
    state.playing = false;
    updatePlayButton();
    state.simulation = integrate(state.parameters);
    if (resetTime) state.time = 0;
    state.time = Math.min(state.time, state.parameters.duration);
    dom.time.max = String(state.parameters.duration);
    updateParameterOutputs();
    updateForceFieldInterface();
    updateScenarioConclusion();
    render(true);
  }

  function setControlsFromParameters() {
    configureFieldControls();
    dom.forceField.value = state.parameters.fieldId || "cellular";
    dom.mass.value = String(state.parameters.mass);
    dom.forceScale.value = String(state.parameters.forceScale);
    dom.duration.value = String(state.parameters.duration);
  }

  function syncScenarioSelection() {
    const match = Object.entries(PRESETS).find(([, preset]) =>
      Object.keys(preset).every(key => key === "note" || state.parameters[key] === preset[key]));
    dom.scenario.value = match ? match[0] : "custom";
  }

  function applyPreset(name) {
    const preset = PRESETS[name];
    if (!preset) return;
    state.parameters = { ...preset };
    dom.scenario.value = name;
    setControlsFromParameters();
    recompute();
  }

  function markCustom() {
    dom.scenario.value = "custom";
  }

  function updatePlayButton() {
    dom.play.textContent = state.playing ? "Pause" : physTranslate("Lire");
    dom.play.setAttribute("aria-label", state.playing ? physTranslate("Mettre l’animation en pause") : physTranslate("Lire l’animation"));
  }

  function setPlaying(value) {
    state.playing = value;
    state.lastFrameTime = 0;
    updatePlayButton();
    render();
    if (value && !state.animationFrame) state.animationFrame = requestAnimationFrame(animate);
  }

  function animate(timestamp) {
    state.animationFrame = 0;
    if (!state.playing) return;
    if (!state.lastFrameTime) state.lastFrameTime = timestamp;
    const elapsed = Math.min(0.1, (timestamp - state.lastFrameTime) / 1000);
    state.lastFrameTime = timestamp;
    state.time += elapsed * state.playbackRate;
    if (state.time >= state.parameters.duration) {
      if (state.loop) state.time %= state.parameters.duration;
      else {
        state.time = state.parameters.duration;
        state.playing = false;
        updatePlayButton();
      }
    }
    render();
    if (state.playing) state.animationFrame = requestAnimationFrame(animate);
  }

  function bindParameter(slider, key) {
    slider.addEventListener("input", () => {
      state.parameters[key] = Number(slider.value);
      markCustom();
      recompute();
    });
  }

  function bindDisplay(toggle, key) {
    toggle.addEventListener("change", () => {
      state.display[key] = toggle.checked;
      render();
    });
  }

  function resetView() {
    state.view = { centerX: PI, centerY: 1.5 * PI, zoom: 1.25 };
    render();
  }

  function installInteractions() {
    dom.forceField.addEventListener("change", () => {
      const previousField = state.parameters.fieldId;
      const nextField = dom.forceField.value;
      if (nextField === "gravity" && previousField !== "gravity") {
        state.nonGravitySettings = {
          forceScale: state.parameters.forceScale,
          duration: state.parameters.duration
        };
        state.parameters.forceScale = 9.81;
        state.parameters.duration = 1;
      } else if (previousField === "gravity" && nextField !== "gravity") {
        const previousSettings = state.nonGravitySettings || { forceScale: 1, duration: 1 };
        state.parameters.forceScale = previousSettings.forceScale;
        state.parameters.duration = previousSettings.duration;
      }
      state.parameters.fieldId = nextField;
      setControlsFromParameters();
      markCustom();
      state.view = { centerX: PI, centerY: 1.5 * PI, zoom: 1.25 };
      recompute();
    });
    dom.scenario.addEventListener("change", () => applyPreset(dom.scenario.value));
    bindParameter(dom.mass, "mass");
    bindParameter(dom.forceScale, "forceScale");
    bindParameter(dom.duration, "duration");

    dom.play.addEventListener("click", () => {
      if (!state.playing && state.time >= state.parameters.duration) state.time = 0;
      setPlaying(!state.playing);
    });
    dom.reset.addEventListener("click", () => {
      setPlaying(false);
      state.time = 0;
      render(true);
    });
    dom.speed.addEventListener("change", () => {
      state.playbackRate = Number(dom.speed.value);
    });
    dom.time.addEventListener("pointerdown", () => setPlaying(false));
    dom.time.addEventListener("input", () => {
      state.time = Number(dom.time.value);
      render(true);
    });
    dom.loop.addEventListener("change", () => { state.loop = dom.loop.checked; });

    bindDisplay(dom.fieldToggle, "field");
    bindDisplay(dom.forceToggle, "force");
    bindDisplay(dom.velocityToggle, "velocity");
    bindDisplay(dom.trajectoryToggle, "trajectory");
    bindDisplay(dom.areaToggle, "area");
    dom.clearOverlays.addEventListener("click", () => {
      state.display = { field: false, force: false, velocity: false, trajectory: false, area: false };
      dom.fieldToggle.checked = false;
      dom.forceToggle.checked = false;
      dom.velocityToggle.checked = false;
      dom.trajectoryToggle.checked = false;
      dom.areaToggle.checked = false;
      render();
    });

    dom.resetView.addEventListener("click", resetView);
    dom.initialVelocityHandle.addEventListener("keydown", event => {
      if (!canEditInitialVelocity()) return;
      if (!["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Home"].includes(event.key)) return;
      event.preventDefault();
      const angle = state.parameters.angle0 * PI / 180;
      let vx = state.parameters.speed0 * Math.cos(angle);
      let vy = state.parameters.speed0 * Math.sin(angle);
      const step = event.shiftKey ? 0.01 : 0.05;
      if (event.key === "Home") vx = vy = 0;
      if (event.key === "ArrowLeft") vx -= step;
      if (event.key === "ArrowRight") vx += step;
      if (event.key === "ArrowUp") vy += step;
      if (event.key === "ArrowDown") vy -= step;
      setInitialVelocity(vx, vy);
    });
    dom.sceneViewport.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || state.drag) return;
      if (event.target.closest("#initial-velocity-handle") && canEditInitialVelocity()) {
        event.preventDefault();
        const rect = dom.sceneCanvas.getBoundingClientRect();
        const geometry = initialVelocityGeometry(viewTransform(rect.width, rect.height), rect.width, rect.height);
        state.drag = { mode: "velocity", pointerId: event.pointerId,
          offsetX: event.clientX - rect.left - geometry.handle.x,
          offsetY: event.clientY - rect.top - geometry.handle.y };
        dom.sceneViewport.setPointerCapture(event.pointerId);
        dom.sceneViewport.classList.add("dragging-velocity");
        dom.initialVelocityHandle.focus({ preventScroll: true });
        return;
      }
      if (event.target.closest("button")) return;
      const rect = dom.sceneCanvas.getBoundingClientRect();
      const transform = viewTransform(rect.width, rect.height);
      const start = transform.worldToScreen(state.simulation.x[0], state.simulation.y[0]);
      const pointerX = event.clientX - rect.left;
      const pointerY = event.clientY - rect.top;
      const movingPointA = Math.hypot(pointerX - start.x, pointerY - start.y) <= 22;
      dom.sceneViewport.setPointerCapture(event.pointerId);
      state.drag = {
        mode: movingPointA ? "point-a" : "view",
        pointerId: event.pointerId,
        x: event.clientX,
        y: event.clientY
      };
      if (movingPointA) {
        setPlaying(false);
        dom.sceneViewport.classList.add("dragging-a");
      }
    });
    dom.sceneViewport.addEventListener("pointermove", (event) => {
      if (!state.drag || state.drag.pointerId !== event.pointerId) return;
      const rect = dom.sceneCanvas.getBoundingClientRect();
      const transform = viewTransform(rect.width, rect.height);
      if (state.drag.mode === "velocity") {
        const start = transform.worldToScreen(state.parameters.x0, state.parameters.y0);
        const dx = event.clientX - rect.left - state.drag.offsetX - start.x;
        const dy = event.clientY - rect.top - state.drag.offsetY - start.y;
        const distance = Math.hypot(dx, dy);
        if (distance < 1e-10) {
          setInitialVelocity(0, 0);
          return;
        }
        const ux = dx / distance;
        const uy = dy / distance;
        const room = Math.min(sceneVectorLength(rect.width, rect.height),
          vectorRoom(start, ux, uy, rect.width, rect.height, VELOCITY_HANDLE_INSET));
        const fraction = room > 1 ? Math.min(1, distance / room) : 0;
        const speed = VELOCITY_DISPLAY_SCALE *
          Math.expm1(fraction * Math.log1p(MAX_INITIAL_SPEED / VELOCITY_DISPLAY_SCALE));
        const physicalX = ux / transform.scaleX;
        const physicalY = -uy / transform.scaleY;
        const physicalNorm = Math.hypot(physicalX, physicalY);
        setInitialVelocity(speed * physicalX / physicalNorm, speed * physicalY / physicalNorm);
        return;
      }
      if (state.drag.mode === "point-a") {
        const world = transform.screenToWorld(
          event.clientX - rect.left,
          event.clientY - rect.top
        );
        state.parameters.x0 = Math.max(DOMAIN.xMin, Math.min(DOMAIN.xMax, world.x));
        state.parameters.y0 = Math.max(DOMAIN.yMin, Math.min(DOMAIN.yMax, world.y));
        markCustom();
        recompute();
        return;
      }
      const dx = event.clientX - state.drag.x;
      const dy = event.clientY - state.drag.y;
      state.view.centerX -= dx / transform.scaleX;
      state.view.centerY += dy / transform.scaleY;
      state.drag.x = event.clientX;
      state.drag.y = event.clientY;
      render();
    });
    const endDrag = (event) => {
      if (state.drag && state.drag.pointerId === event.pointerId) {
        state.drag = null;
        dom.sceneViewport.classList.remove("dragging-a", "dragging-velocity");
        if (dom.sceneViewport.hasPointerCapture(event.pointerId)) dom.sceneViewport.releasePointerCapture(event.pointerId);
        render();
      }
    };
    dom.sceneViewport.addEventListener("pointerup", endDrag);
    dom.sceneViewport.addEventListener("pointercancel", endDrag);
    dom.sceneViewport.addEventListener("lostpointercapture", endDrag);
    dom.sceneViewport.addEventListener("wheel", (event) => {
      event.preventDefault();
      const rect = dom.sceneCanvas.getBoundingClientRect();
      const before = viewTransform(rect.width, rect.height).screenToWorld(
        event.clientX - rect.left,
        event.clientY - rect.top
      );
      const factor = Math.exp(-event.deltaY * 0.00125);
      state.view.zoom = Math.max(0.55, Math.min(7, state.view.zoom * factor));
      const after = viewTransform(rect.width, rect.height).screenToWorld(
        event.clientX - rect.left,
        event.clientY - rect.top
      );
      state.view.centerX += before.x - after.x;
      state.view.centerY += before.y - after.y;
      render();
    }, { passive: false });

    document.addEventListener("keydown", (event) => {
      if (imposedWork?.isActive()) return;
      const target = event.target;
      const editing = target instanceof HTMLInputElement || target instanceof HTMLSelectElement || target instanceof HTMLButtonElement;
      if (editing) return;
      if (event.code === "Space") {
        event.preventDefault();
        setPlaying(!state.playing);
      } else if (event.key.toLowerCase() === "r") {
        setPlaying(false);
        state.time = 0;
        render(true);
      }
    });
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) setPlaying(false);
    });

    // Render after layout settles, not inside ResizeObserver's delivery cycle.
    // Math labels can themselves change a card's size (notably in WebKit).
    let resizeFrame = 0;
    const resizeObserver = new ResizeObserver(() => {
      if (!resizeFrame) resizeFrame = requestAnimationFrame(() => {
        resizeFrame = 0;
        render();
      });
    });
    resizeObserver.observe(dom.sceneCanvas);
    resizeObserver.observe(dom.powerCanvas);
    resizeObserver.observe(dom.kineticCanvas);
  }

  function numericalSelfCheck() {
    const simulation = state.simulation;
    const last = simulation.count;
    const deltaK = simulation.kinetic[last] - simulation.initialKinetic;
    const error = Math.abs(simulation.work[last] - deltaK);
    const expectedWork = 1.30696085;
    const isPositivePreset = state.parameters.fieldId === PRESETS.positive.fieldId
      && Math.abs(state.parameters.duration - PRESETS.positive.duration) < 1e-8
      && Math.abs(state.parameters.x0 - PRESETS.positive.x0) < 1e-8
      && Math.abs(state.parameters.y0 - PRESETS.positive.y0) < 1e-8;
    if ((isPositivePreset && Math.abs(simulation.work[last] - expectedWork) > 8e-4) || error > 8e-5) {
      console.warn(physTranslate("Contrôle numérique du théorème travail–énergie hors tolérance."), {
        work: simulation.work[last],
        deltaK,
        error
      });
    }
  }

  function typesetMath() {
    if (!window.MathJax || !window.MathJax.startup) {
      dom.loading.textContent = physTranslate("Les formules mathématiques n’ont pas pu être préparées.");
      return;
    }
    window.MathJax.startup.promise
      .then(() => window.MathJax.typesetPromise())
      .then(() => initializeMathGlyphs())
      .then(async () => {
        mathIsReady = true;
        chartTickSignature = "";
        kineticTickSignature = "";
        updateParameterOutputs();
        render(true);
        dom.loading.hidden = true;
        await window.PhysShare?.register({id:'energy',pause:()=>setPlaying(false),
          capture:()=>({parameters:{...state.parameters},time:state.time,playbackRate:state.playbackRate,loop:state.loop,view:{...state.view},display:{...state.display},nonGravitySettings:state.nonGravitySettings,imposed:imposedWork.capture()}),
          restore:(s,ui)=>{
            PhysShare.member(s.parameters.fieldId,Object.keys(FIELD_TYPES));PhysShare.range(s.parameters.duration,.1,120);PhysShare.range(s.time,0,s.parameters.duration);PhysShare.range(s.view.zoom,.01,100);
            setPlaying(false);state.drag=null;dom.sceneViewport.classList.remove("dragging-a", "dragging-velocity");state.parameters={...s.parameters};state.time=s.time;state.playbackRate=s.playbackRate;dom.speed.value=String(state.playbackRate);state.loop=s.loop;state.nonGravitySettings=s.nonGravitySettings;
            PhysShare.set(state.view,s.view);PhysShare.set(state.display,s.display);setControlsFromParameters();syncScenarioSelection();recompute({resetTime:false});ui();imposedWork.restore(s.imposed,ui);render(true);
          }
        });
      })
      .catch(() => {
        dom.loading.textContent = physTranslate("Les formules mathématiques n’ont pas pu être préparées.");
      });
  }

  function initialize() {
    setControlsFromParameters();
    syncScenarioSelection();
    dom.speed.value = String(state.playbackRate);
    state.simulation = integrate(state.parameters);
    updateParameterOutputs();
    updateForceFieldInterface();
    updateScenarioConclusion();
    updatePlayButton();
    installInteractions();
    imposedWork = createImposedWorkUI({
      forceAt, canvasContext, drawArrow, setMathDigits,
      onModeChange() { setPlaying(false); render(true); }
    });
    numericalSelfCheck();
    render(true);
    typesetMath();
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => render());
  }

  initialize();
}());
