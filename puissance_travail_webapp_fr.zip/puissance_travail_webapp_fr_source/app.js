(function () {
  "use strict";

  const PI = Math.PI;
  const ROTATING_FIELD_OMEGA = 2 * PI / 10;
  const DOMAIN = Object.freeze({ xMin: 0, xMax: 2 * PI, yMin: 0, yMax: 3 * PI });
  const INITIAL_POSITION = Object.freeze({ x: 4.4, y: 6.8 });
  const COLORS = Object.freeze({
    ink: "#172033",
    muted: "#64748b",
    grid: "#d8e1ec",
    accent: "#0f62fe",
    field: "#20a486",
    force: "#9b7bea",
    velocity: "#ff8c00",
    trajectory: "#f7fbff",
    progress: "#8ec5ff",
    particle: "#ff8c00",
    point: "#ff453a",
    work: "#1874cd",
    positive: "#138a72",
    negative: "#cc4b68"
  });

  const FIELD_TYPES = Object.freeze({
    cellular: {
      note: "Champ de force périodique non conservatif.",
      maxMagnitudeFactor: 1
    },
    periodic: {
      note: "Champ conservatif : la particule oscille entre des puits périodiques.",
      maxMagnitudeFactor: Math.SQRT2
    },
    central: {
      note: "Champ conservatif, borné et dirigé vers le centre de la figure.",
      maxMagnitudeFactor: 1
    },
    rotating: {
      note: "Champ uniforme tournant et explicitement dépendant du temps.",
      maxMagnitudeFactor: 1
    },
    gravity: {
      note: "Champ de pesanteur uniforme et conservatif.",
      maxMagnitudeFactor: 1
    }
  });

  const PRESETS = Object.freeze({
    positive: {
      fieldId: "cellular",
      mass: 20,
      forceScale: 1,
      vx0: 0.2,
      vy0: -0.2,
      duration: 15 * PI,
      note: "Avec le champ tourbillonnaire, le travail total est positif et la particule arrive plus rapide."
    },
    zero: {
      fieldId: "cellular",
      mass: 20,
      forceScale: 1,
      vx0: 0.2,
      vy0: -0.2,
      duration: 36.6022792668,
      note: "Les aires positive et négative se compensent : la vitesse finale a la même norme qu’au départ."
    },
    negative: {
      fieldId: "cellular",
      mass: 20,
      forceScale: 1,
      vx0: 0.2,
      vy0: -0.2,
      duration: 7 * PI,
      note: "Le travail total est négatif : l’énergie cinétique finale est inférieure à l’énergie initiale."
    }
  });

  const number2 = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
    useGrouping: false
  });
  const number3 = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 3,
    maximumFractionDigits: 3,
    useGrouping: false
  });
  const number6 = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 6,
    maximumFractionDigits: 6,
    useGrouping: false
  });
  const tickNumber = new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 2,
    useGrouping: false
  });

  const dom = {
    forceField: document.getElementById("force-field-select"),
    forceFieldNote: document.getElementById("force-field-note"),
    fieldFormulaBlocks: Array.from(document.querySelectorAll("[data-force-field]")),
    scenario: document.getElementById("scenario-select"),
    scenarioNote: document.getElementById("scenario-note"),
    forceStrengthLabel: document.getElementById("force-strength-label"),
    mass: document.getElementById("mass-slider"),
    forceScale: document.getElementById("force-slider"),
    vx: document.getElementById("vx-slider"),
    vy: document.getElementById("vy-slider"),
    duration: document.getElementById("duration-slider"),
    massOutput: document.getElementById("mass-output-digits"),
    forceOutput: document.getElementById("force-output-digits"),
    forceOutputContainer: document.getElementById("force-output"),
    forceUnitNewton: document.getElementById("force-unit-newton"),
    forceUnitGravity: document.getElementById("force-unit-gravity"),
    forceSymbolF0: document.getElementById("force-symbol-f0"),
    forceSymbolG: document.getElementById("force-symbol-g"),
    vxOutput: document.getElementById("vx-output-digits"),
    vyOutput: document.getElementById("vy-output-digits"),
    durationOutput: document.getElementById("duration-output-digits"),
    play: document.getElementById("play-button"),
    reset: document.getElementById("reset-button"),
    speed: document.getElementById("speed-select"),
    time: document.getElementById("time-slider"),
    timeOutput: document.getElementById("time-output-digits"),
    loop: document.getElementById("loop-toggle"),
    fieldToggle: document.getElementById("field-toggle"),
    forceToggle: document.getElementById("force-toggle"),
    velocityToggle: document.getElementById("velocity-toggle"),
    trajectoryToggle: document.getElementById("trajectory-toggle"),
    areaToggle: document.getElementById("area-toggle"),
    clearOverlays: document.getElementById("clear-overlays"),
    sceneViewport: document.getElementById("scene-viewport"),
    sceneCanvas: document.getElementById("scene-canvas"),
    powerCanvas: document.getElementById("power-canvas"),
    resetView: document.getElementById("reset-view"),
    loading: document.getElementById("loading-message"),
    timeBadge: document.getElementById("time-badge-digits"),
    sceneKinetic: document.getElementById("scene-kinetic-digits"),
    sceneLabelA: document.getElementById("scene-label-a"),
    sceneLabelB: document.getElementById("scene-label-b"),
    sceneLabelForce: document.getElementById("scene-label-force"),
    sceneLabelVelocity: document.getElementById("scene-label-velocity"),
    chartTicks: document.getElementById("chart-ticks"),
    powerSignBadge: document.getElementById("power-sign-badge"),
    workResultBadge: document.getElementById("work-result-badge"),
    workResultDigits: document.getElementById("work-result-digits"),
    powerReadout: document.getElementById("power-readout"),
    workReadout: document.getElementById("work-readout"),
    deltaKReadout: document.getElementById("delta-k-readout"),
    angleReadout: document.getElementById("angle-readout"),
    theoremReadout: document.getElementById("theorem-readout"),
    accessibleSummary: document.getElementById("accessible-summary")
  };

  const state = {
    parameters: { ...PRESETS.positive },
    simulation: null,
    time: 0,
    playing: false,
    playbackRate: 1,
    loop: true,
    lastFrameTime: 0,
    animationFrame: 0,
    lastAccessibleUpdate: -Infinity,
    view: { centerX: PI, centerY: 1.5 * PI, zoom: 1 },
    drag: null,
    display: {
      field: true,
      force: true,
      velocity: true,
      trajectory: true,
      area: true
    },
    nonGravitySettings: null
  };

  let mathIsReady = false;
  const mathGlyphTemplates = new Map();
  let chartTickSignature = "";

  async function initializeMathGlyphs() {
    const characters = "0123456789.,-+—";
    for (const character of characters) {
      const tex = character === "-"
        ? "{-}"
        : character === ","
          ? "{,}"
          : character === "—"
            ? "\\text{—}"
            : character;
      const rendered = await window.MathJax.tex2svgPromise(tex, { display: false });
      rendered.setAttribute("aria-hidden", "true");
      mathGlyphTemplates.set(character, rendered);
    }
  }

  function setMathDigits(element, text) {
    if (!element) return;
    const value = String(text);
    if (!mathIsReady || mathGlyphTemplates.size === 0) {
      element.textContent = value;
      element.dataset.value = value;
      return;
    }
    if (element.dataset.value === value && element.classList.contains("typeset")) return;
    const fragment = document.createDocumentFragment();
    for (const character of value) {
      const wrapper = document.createElement("span");
      wrapper.className = "math-glyph";
      wrapper.setAttribute("aria-hidden", "true");
      const template = mathGlyphTemplates.get(character);
      if (template) wrapper.append(template.cloneNode(true));
      else wrapper.textContent = character;
      fragment.append(wrapper);
    }
    element.replaceChildren(fragment);
    element.classList.add("typeset");
    element.dataset.value = value;
  }

  function forceAt(x, y, time = state.time, parameters = state.parameters) {
    const fieldId = parameters.fieldId || "cellular";
    const amplitude = parameters.forceScale;
    if (fieldId === "periodic") {
      return {
        x: -amplitude * Math.sin(x - PI),
        y: -amplitude * Math.sin(y - 1.5 * PI)
      };
    }
    if (fieldId === "central") {
      const dx = x - PI;
      const dy = y - 1.5 * PI;
      const factor = -amplitude / Math.sqrt(1 + dx * dx + dy * dy);
      return { x: factor * dx, y: factor * dy };
    }
    if (fieldId === "rotating") {
      return {
        x: amplitude * Math.cos(ROTATING_FIELD_OMEGA * time),
        y: amplitude * Math.sin(ROTATING_FIELD_OMEGA * time)
      };
    }
    if (fieldId === "gravity") {
      return { x: 0, y: -parameters.mass * amplitude };
    }
    return {
      x: amplitude * Math.sin(x) * Math.cos(y),
      y: -amplitude * Math.cos(x) * Math.sin(y)
    };
  }

  function fieldReferenceMagnitude(parameters = state.parameters) {
    const fieldType = FIELD_TYPES[parameters.fieldId] || FIELD_TYPES.cellular;
    if (parameters.fieldId === "gravity") {
      return Math.max(1e-9, parameters.mass * parameters.forceScale);
    }
    return Math.max(1e-9, parameters.forceScale * fieldType.maxMagnitudeFactor);
  }

  function derivative(vector, time, parameters) {
    const field = forceAt(vector[0], vector[1], time, parameters);
    return [vector[2], vector[3], field.x / parameters.mass, field.y / parameters.mass];
  }

  function addScaled(vector, increment, scale) {
    return [
      vector[0] + scale * increment[0],
      vector[1] + scale * increment[1],
      vector[2] + scale * increment[2],
      vector[3] + scale * increment[3]
    ];
  }

  function integrate(parameters) {
    const count = Math.max(1600, Math.ceil(parameters.duration / 0.005));
    const dt = parameters.duration / count;
    const t = new Float64Array(count + 1);
    const x = new Float64Array(count + 1);
    const y = new Float64Array(count + 1);
    const vx = new Float64Array(count + 1);
    const vy = new Float64Array(count + 1);
    const fx = new Float64Array(count + 1);
    const fy = new Float64Array(count + 1);
    const power = new Float64Array(count + 1);
    const work = new Float64Array(count + 1);
    const kinetic = new Float64Array(count + 1);

    let vector = [INITIAL_POSITION.x, INITIAL_POSITION.y, parameters.vx0, parameters.vy0];
    const record = (index) => {
      t[index] = index * dt;
      const field = forceAt(vector[0], vector[1], t[index], parameters);
      x[index] = vector[0];
      y[index] = vector[1];
      vx[index] = vector[2];
      vy[index] = vector[3];
      fx[index] = field.x;
      fy[index] = field.y;
      power[index] = field.x * vector[2] + field.y * vector[3];
      kinetic[index] = 0.5 * parameters.mass * (vector[2] ** 2 + vector[3] ** 2);
    };

    record(0);
    let maxAbsPower = Math.abs(power[0]);
    for (let i = 0; i < count; i += 1) {
      const currentTime = i * dt;
      const k1 = derivative(vector, currentTime, parameters);
      const k2 = derivative(addScaled(vector, k1, dt / 2), currentTime + dt / 2, parameters);
      const k3 = derivative(addScaled(vector, k2, dt / 2), currentTime + dt / 2, parameters);
      const k4 = derivative(addScaled(vector, k3, dt), currentTime + dt, parameters);
      vector = vector.map((value, component) => value + (dt / 6) * (
        k1[component] + 2 * k2[component] + 2 * k3[component] + k4[component]
      ));
      record(i + 1);
      work[i + 1] = work[i] + 0.5 * (power[i] + power[i + 1]) * dt;
      maxAbsPower = Math.max(maxAbsPower, Math.abs(power[i + 1]));
    }

    return {
      count,
      dt,
      t,
      x,
      y,
      vx,
      vy,
      fx,
      fy,
      power,
      work,
      kinetic,
      initialKinetic: kinetic[0],
      maxAbsPower: Math.max(0.05, maxAbsPower)
    };
  }

  function sampleSimulation(time) {
    const simulation = state.simulation;
    const normalized = Math.max(0, Math.min(simulation.count, time / simulation.dt));
    const low = Math.min(simulation.count - 1, Math.floor(normalized));
    const high = Math.min(simulation.count, low + 1);
    const fraction = normalized - low;
    const interpolate = (array) => array[low] + fraction * (array[high] - array[low]);
    return {
      index: low,
      fraction,
      t: time,
      x: interpolate(simulation.x),
      y: interpolate(simulation.y),
      vx: interpolate(simulation.vx),
      vy: interpolate(simulation.vy),
      fx: interpolate(simulation.fx),
      fy: interpolate(simulation.fy),
      power: interpolate(simulation.power),
      work: interpolate(simulation.work),
      kinetic: interpolate(simulation.kinetic)
    };
  }

  function canvasContext(canvas) {
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(2.25, window.devicePixelRatio || 1);
    const width = Math.max(1, Math.round(rect.width));
    const height = Math.max(1, Math.round(rect.height));
    const pixelWidth = Math.round(width * dpr);
    const pixelHeight = Math.round(height * dpr);
    if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
      canvas.width = pixelWidth;
      canvas.height = pixelHeight;
    }
    const context = canvas.getContext("2d");
    context.setTransform(dpr, 0, 0, dpr, 0, 0);
    context.clearRect(0, 0, width, height);
    return { context, width, height };
  }

  function viewTransform(width, height) {
    const padding = 26;
    const baseScale = Math.min(
      (width - 2 * padding) / (DOMAIN.xMax - DOMAIN.xMin),
      (height - 2 * padding) / (DOMAIN.yMax - DOMAIN.yMin)
    );
    const scale = Math.max(8, baseScale * state.view.zoom);
    return {
      scale,
      worldToScreen(x, y) {
        return {
          x: width / 2 + (x - state.view.centerX) * scale,
          y: height / 2 - (y - state.view.centerY) * scale
        };
      },
      screenToWorld(x, y) {
        return {
          x: state.view.centerX + (x - width / 2) / scale,
          y: state.view.centerY - (y - height / 2) / scale
        };
      }
    };
  }

  function hexToRgb(hex) {
    const value = hex.replace("#", "");
    return [0, 2, 4].map((offset) => parseInt(value.slice(offset, offset + 2), 16));
  }

  function viridis(value, alpha = 1) {
    const stops = ["#440154", "#3b528b", "#21918c", "#5ec962", "#fde725"];
    const position = Math.max(0, Math.min(1, value)) * (stops.length - 1);
    const low = Math.floor(position);
    const high = Math.min(stops.length - 1, low + 1);
    const fraction = position - low;
    const a = hexToRgb(stops[low]);
    const b = hexToRgb(stops[high]);
    const rgb = a.map((channel, i) => Math.round(channel + fraction * (b[i] - channel)));
    return `rgba(${rgb[0]}, ${rgb[1]}, ${rgb[2]}, ${alpha})`;
  }

  function drawArrow(context, startX, startY, deltaX, deltaY, options = {}) {
    const length = Math.hypot(deltaX, deltaY);
    if (!Number.isFinite(length) || length < 1.5) return;
    const color = options.color || COLORS.ink;
    const lineWidth = options.lineWidth || 2;
    const headLength = Math.min(options.headLength || 9, 0.65 * length);
    const endX = startX + deltaX;
    const endY = startY + deltaY;
    const ux = deltaX / length;
    const uy = deltaY / length;
    const depth = headLength * Math.cos(Math.PI / 6);
    const halfWidth = headLength * Math.sin(Math.PI / 6);
    const overlap = Math.min(lineWidth, 0.2 * depth);
    const baseX = endX - depth * ux;
    const baseY = endY - depth * uy;
    const shaftEndX = baseX + overlap * ux;
    const shaftEndY = baseY + overlap * uy;
    const leftX = baseX - halfWidth * uy;
    const leftY = baseY + halfWidth * ux;
    const rightX = baseX + halfWidth * uy;
    const rightY = baseY - halfWidth * ux;
    context.save();
    context.lineCap = "round";
    context.lineJoin = "round";
    if (options.halo) {
      context.beginPath();
      context.moveTo(startX, startY);
      context.lineTo(shaftEndX, shaftEndY);
      context.strokeStyle = "rgba(255,255,255,.82)";
      context.lineWidth = lineWidth + 3.5;
      context.stroke();
    }
    context.beginPath();
    context.moveTo(startX, startY);
    context.lineTo(shaftEndX, shaftEndY);
    context.strokeStyle = color;
    context.lineWidth = lineWidth;
    context.stroke();
    context.beginPath();
    context.moveTo(endX, endY);
    context.lineTo(leftX, leftY);
    context.lineTo(rightX, rightY);
    context.closePath();
    context.fillStyle = color;
    context.fill();
    context.restore();
  }

  function positionSceneLabel(element, x, y, visible, width, height) {
    const onScreen = x > -24 && x < width + 24 && y > -24 && y < height + 24;
    element.hidden = !(visible && onScreen);
    if (element.hidden) return;
    element.style.left = `${x}px`;
    element.style.top = `${y}px`;
  }

  function positionVectorLabel(element, originX, originY, deltaX, deltaY, visible, width, height, side) {
    const length = Math.hypot(deltaX, deltaY);
    if (!visible || length <= 4) {
      positionSceneLabel(element, 0, 0, false, width, height);
      return;
    }
    const ux = deltaX / length;
    const uy = deltaY / length;
    const along = 16;
    const normal = 10 * side;
    positionSceneLabel(
      element,
      originX + deltaX + ux * along - uy * normal,
      originY + deltaY + uy * along + ux * normal,
      true,
      width,
      height
    );
  }

  function drawScene(sample) {
    const { context, width, height } = canvasContext(dom.sceneCanvas);
    const transform = viewTransform(width, height);
    context.fillStyle = "#08111e";
    context.fillRect(0, 0, width, height);

    const topLeft = transform.worldToScreen(DOMAIN.xMin, DOMAIN.yMax);
    const bottomRight = transform.worldToScreen(DOMAIN.xMax, DOMAIN.yMin);
    context.save();
    context.strokeStyle = "rgba(174, 199, 228, .22)";
    context.lineWidth = 1;
    context.strokeRect(topLeft.x, topLeft.y, bottomRight.x - topLeft.x, bottomRight.y - topLeft.y);
    context.restore();

    if (state.display.field) {
      const xSteps = 18;
      const ySteps = 25;
      const xSpacing = (DOMAIN.xMax - DOMAIN.xMin) / (xSteps - 1);
      const ySpacing = (DOMAIN.yMax - DOMAIN.yMin) / (ySteps - 1);
      const visibleTopLeft = transform.screenToWorld(-20, -20);
      const visibleBottomRight = transform.screenToWorld(width + 20, height + 20);
      const xStart = Math.floor(visibleTopLeft.x / xSpacing) * xSpacing;
      const xEnd = visibleBottomRight.x;
      const yStart = Math.floor(visibleBottomRight.y / ySpacing) * ySpacing;
      const yEnd = visibleTopLeft.y;
      for (let x = xStart; x <= xEnd; x += xSpacing) {
        for (let y = yStart; y <= yEnd; y += ySpacing) {
          const point = transform.worldToScreen(x, y);
          const field = forceAt(x, y);
          const magnitude = Math.hypot(field.x, field.y);
          if (magnitude < 0.015) continue;
          const relative = Math.min(1, magnitude / fieldReferenceMagnitude());
          const arrowLength = 5 + 17 * relative * Math.min(1.4, state.parameters.forceScale);
          drawArrow(
            context,
            point.x,
            point.y,
            (field.x / magnitude) * arrowLength,
            -(field.y / magnitude) * arrowLength,
            { color: viridis(relative, 0.78), lineWidth: 1.15, headLength: 4.2 }
          );
        }
      }
    }

    const simulation = state.simulation;
    const pathStep = Math.max(1, Math.floor(simulation.count / 1400));
    if (state.display.trajectory) {
      context.save();
      context.beginPath();
      for (let i = 0; i <= simulation.count; i += pathStep) {
        const point = transform.worldToScreen(simulation.x[i], simulation.y[i]);
        if (i === 0) context.moveTo(point.x, point.y);
        else context.lineTo(point.x, point.y);
      }
      const finalPoint = transform.worldToScreen(
        simulation.x[simulation.count],
        simulation.y[simulation.count]
      );
      context.lineTo(finalPoint.x, finalPoint.y);
      context.strokeStyle = "rgba(247,251,255,.35)";
      context.lineWidth = 1.6;
      context.stroke();
      context.restore();
    }

    context.save();
    context.beginPath();
    const currentIndex = sample.index;
    for (let i = 0; i <= currentIndex; i += pathStep) {
      const point = transform.worldToScreen(simulation.x[i], simulation.y[i]);
      if (i === 0) context.moveTo(point.x, point.y);
      else context.lineTo(point.x, point.y);
    }
    const currentPoint = transform.worldToScreen(sample.x, sample.y);
    context.lineTo(currentPoint.x, currentPoint.y);
    context.strokeStyle = COLORS.progress;
    context.lineWidth = 2.6;
    context.shadowColor = "rgba(142,197,255,.55)";
    context.shadowBlur = 5;
    context.stroke();
    context.restore();

    const start = transform.worldToScreen(simulation.x[0], simulation.y[0]);
    const end = transform.worldToScreen(simulation.x[simulation.count], simulation.y[simulation.count]);
    for (const point of [start, end]) {
      context.beginPath();
      context.arc(point.x, point.y, 4.5, 0, 2 * PI);
      context.fillStyle = COLORS.point;
      context.fill();
    }
    positionSceneLabel(dom.sceneLabelA, start.x + 10, start.y - 11, true, width, height);
    positionSceneLabel(dom.sceneLabelB, end.x + 10, end.y - 11, true, width, height);

    const forceLength = 52 * Math.min(1.5, 0.7 + 0.3 * state.parameters.forceScale);
    const velocityLength = 118;
    let forceDeltaX = 0;
    let forceDeltaY = 0;
    if (state.display.force) {
      const forceMagnitude = Math.hypot(sample.fx, sample.fy);
      const forceColor = viridis(
        Math.min(1, forceMagnitude / fieldReferenceMagnitude()),
        1
      );
      forceDeltaX = sample.fx * forceLength;
      forceDeltaY = -sample.fy * forceLength;
      drawArrow(
        context,
        currentPoint.x,
        currentPoint.y,
        forceDeltaX,
        forceDeltaY,
        { color: forceColor, lineWidth: 2.6, headLength: 10 }
      );
      dom.sceneLabelForce.style.color = forceColor;
    }
    let velocityDeltaX = 0;
    let velocityDeltaY = 0;
    if (state.display.velocity) {
      velocityDeltaX = sample.vx * velocityLength;
      velocityDeltaY = -sample.vy * velocityLength;
      drawArrow(
        context,
        currentPoint.x,
        currentPoint.y,
        velocityDeltaX,
        velocityDeltaY,
        { color: COLORS.velocity, lineWidth: 2.6, headLength: 10 }
      );
    }
    positionVectorLabel(
      dom.sceneLabelForce,
      currentPoint.x,
      currentPoint.y,
      forceDeltaX,
      forceDeltaY,
      state.display.force,
      width,
      height,
      -1
    );
    positionVectorLabel(
      dom.sceneLabelVelocity,
      currentPoint.x,
      currentPoint.y,
      velocityDeltaX,
      velocityDeltaY,
      state.display.velocity,
      width,
      height,
      1
    );

    context.save();
    context.beginPath();
    context.arc(currentPoint.x, currentPoint.y, 6.5, 0, 2 * PI);
    context.fillStyle = COLORS.particle;
    context.shadowColor = "rgba(255,140,0,.75)";
    context.shadowBlur = 10;
    context.fill();
    context.lineWidth = 2;
    context.strokeStyle = "#fff";
    context.stroke();
    context.restore();
  }

  function drawPowerChart(sample) {
    const { context, width, height } = canvasContext(dom.powerCanvas);
    context.fillStyle = "#ffffff";
    context.fillRect(0, 0, width, height);

    const compact = width < 430;
    const margin = { left: compact ? 48 : 62, right: 16, top: 30, bottom: 48 };
    const plotWidth = Math.max(10, width - margin.left - margin.right);
    const plotHeight = Math.max(10, height - margin.top - margin.bottom);
    const yLimit = state.simulation.maxAbsPower * 1.18;
    const xMap = (value) => margin.left + (value / state.parameters.duration) * plotWidth;
    const yMap = (value) => margin.top + ((yLimit - value) / (2 * yLimit)) * plotHeight;
    const zeroY = yMap(0);

    const tickSignature = [
      Math.round(width),
      Math.round(height),
      state.parameters.duration.toFixed(6),
      yLimit.toFixed(8),
      mathIsReady ? "latex" : "plain"
    ].join("|");
    if (tickSignature !== chartTickSignature) {
      const fragment = document.createDocumentFragment();
      const addTick = (value, x, y, className) => {
        const label = document.createElement("span");
        label.className = `chart-tick-label ${className}`;
        label.style.left = `${x}px`;
        label.style.top = `${y}px`;
        const digits = document.createElement("span");
        digits.className = "math-digits";
        label.append(digits);
        setMathDigits(digits, tickNumber.format(value));
        fragment.append(label);
      };
      for (let i = 0; i <= 5; i += 1) {
        const value = (i / 5) * state.parameters.duration;
        addTick(value, xMap(value), margin.top + plotHeight + 15, "x-tick");
      }
      for (let i = -2; i <= 2; i += 1) {
        const value = (i / 2) * yLimit;
        addTick(value, margin.left - 8, yMap(value), "y-tick");
      }
      dom.chartTicks.replaceChildren(fragment);
      chartTickSignature = tickSignature;
    }

    context.save();
    context.strokeStyle = COLORS.grid;
    context.lineWidth = 1;
    for (let i = 0; i <= 5; i += 1) {
      const t = (i / 5) * state.parameters.duration;
      const x = xMap(t);
      context.beginPath();
      context.moveTo(x, margin.top);
      context.lineTo(x, margin.top + plotHeight);
      context.stroke();
    }
    for (let i = -2; i <= 2; i += 1) {
      const value = (i / 2) * yLimit;
      const y = yMap(value);
      context.beginPath();
      context.moveTo(margin.left, y);
      context.lineTo(margin.left + plotWidth, y);
      context.strokeStyle = i === 0 ? "#8a97a8" : COLORS.grid;
      context.setLineDash(i === 0 ? [5, 4] : []);
      context.stroke();
    }
    context.setLineDash([]);

    const simulation = state.simulation;
    const fullStep = Math.max(1, Math.floor(simulation.count / 900));
    context.beginPath();
    for (let i = 0; i <= simulation.count; i += fullStep) {
      const x = xMap(simulation.t[i]);
      const y = yMap(simulation.power[i]);
      if (i === 0) context.moveTo(x, y);
      else context.lineTo(x, y);
    }
    context.strokeStyle = "rgba(24,116,205,.24)";
    context.lineWidth = 1.5;
    context.stroke();

    const progressPoints = [];
    const progressStep = Math.max(1, Math.floor(Math.max(1, sample.index) / 600));
    for (let i = 0; i <= sample.index; i += progressStep) {
      progressPoints.push({ t: simulation.t[i], p: simulation.power[i] });
    }
    const last = progressPoints[progressPoints.length - 1];
    if (!last || Math.abs(last.t - sample.t) > 1e-8) {
      progressPoints.push({ t: sample.t, p: sample.power });
    }

    if (state.display.area && progressPoints.length > 1) {
      const fillPart = (first, second, color) => {
        context.beginPath();
        context.moveTo(xMap(first.t), zeroY);
        context.lineTo(xMap(first.t), yMap(first.p));
        context.lineTo(xMap(second.t), yMap(second.p));
        context.lineTo(xMap(second.t), zeroY);
        context.closePath();
        context.fillStyle = color;
        context.fill();
      };
      for (let i = 0; i < progressPoints.length - 1; i += 1) {
        const first = progressPoints[i];
        const second = progressPoints[i + 1];
        if (first.p === 0 || second.p === 0 || Math.sign(first.p) === Math.sign(second.p)) {
          const positive = (first.p + second.p) / 2 >= 0;
          fillPart(first, second, positive ? "rgba(19,138,114,.28)" : "rgba(204,75,104,.25)");
        } else {
          const fraction = -first.p / (second.p - first.p);
          const crossing = { t: first.t + fraction * (second.t - first.t), p: 0 };
          fillPart(first, crossing, first.p > 0 ? "rgba(19,138,114,.28)" : "rgba(204,75,104,.25)");
          fillPart(crossing, second, second.p > 0 ? "rgba(19,138,114,.28)" : "rgba(204,75,104,.25)");
        }
      }
    }

    if (progressPoints.length > 1) {
      context.beginPath();
      progressPoints.forEach((point, index) => {
        const x = xMap(point.t);
        const y = yMap(point.p);
        if (index === 0) context.moveTo(x, y);
        else context.lineTo(x, y);
      });
      context.strokeStyle = COLORS.work;
      context.lineWidth = 2.3;
      context.stroke();
    }

    const currentX = xMap(sample.t);
    const currentY = yMap(sample.power);
    context.beginPath();
    context.moveTo(currentX, margin.top);
    context.lineTo(currentX, margin.top + plotHeight);
    context.strokeStyle = "rgba(23,32,51,.38)";
    context.setLineDash([3, 4]);
    context.stroke();
    context.setLineDash([]);
    context.beginPath();
    context.arc(currentX, currentY, 4.5, 0, 2 * PI);
    context.fillStyle = COLORS.work;
    context.fill();
    context.lineWidth = 2;
    context.strokeStyle = "#fff";
    context.stroke();
    context.restore();
  }

  function signed(value, digits = 3) {
    const formatter = digits === 2 ? number2 : digits === 6 ? number6 : number3;
    if (Math.abs(value) < 0.5 * 10 ** (-digits)) return formatter.format(0);
    return formatter.format(value);
  }

  function angleBetween(sample) {
    const forceNorm = Math.hypot(sample.fx, sample.fy);
    const speed = Math.hypot(sample.vx, sample.vy);
    if (forceNorm < 1e-10 || speed < 1e-10) return null;
    const cosine = Math.max(-1, Math.min(1, sample.power / (forceNorm * speed)));
    return Math.acos(cosine) * 180 / PI;
  }

  function updatePowerBadge(power) {
    dom.powerSignBadge.classList.remove("positive", "negative", "neutral");
    if (power > 0.002) {
      dom.powerSignBadge.classList.add("positive");
      dom.powerSignBadge.textContent = "Puissance motrice";
    } else if (power < -0.002) {
      dom.powerSignBadge.classList.add("negative");
      dom.powerSignBadge.textContent = "Puissance résistante";
    } else {
      dom.powerSignBadge.classList.add("neutral");
      dom.powerSignBadge.textContent = "Puissance quasi nulle";
    }
  }

  function updateInterface(sample, forceAccessibleUpdate = false) {
    const deltaK = sample.kinetic - state.simulation.initialKinetic;
    const theoremError = sample.work - deltaK;
    const angle = angleBetween(sample);
    dom.time.value = String(sample.t);
    setMathDigits(dom.timeOutput, number2.format(sample.t));
    setMathDigits(dom.timeBadge, number2.format(sample.t));
    setMathDigits(dom.sceneKinetic, number3.format(sample.kinetic));
    setMathDigits(dom.powerReadout, signed(sample.power));
    setMathDigits(dom.workReadout, signed(sample.work));
    setMathDigits(dom.deltaKReadout, signed(deltaK));
    setMathDigits(dom.angleReadout, angle === null ? "—" : number2.format(angle));
    setMathDigits(dom.theoremReadout, Math.abs(theoremError) < 5e-6 ? "0" : signed(theoremError, 6));
    setMathDigits(dom.workResultDigits, signed(sample.work));
    updatePowerBadge(sample.power);

    if (forceAccessibleUpdate || Math.abs(sample.t - state.lastAccessibleUpdate) >= 2) {
      const signDescription = sample.power > 0.002
        ? "La force augmente actuellement l’énergie cinétique."
        : sample.power < -0.002
          ? "La force diminue actuellement l’énergie cinétique."
          : "La puissance est actuellement presque nulle.";
      dom.accessibleSummary.textContent = `À ${number2.format(sample.t)} secondes, la puissance vaut ${signed(sample.power)} watt, le travail cumulé ${signed(sample.work)} joule et l’énergie cinétique ${number3.format(sample.kinetic)} joule. ${signDescription}`;
      state.lastAccessibleUpdate = sample.t;
    }
  }

  function render(forceAccessibleUpdate = false) {
    if (!state.simulation) return;
    const sample = sampleSimulation(state.time);
    drawScene(sample);
    drawPowerChart(sample);
    updateInterface(sample, forceAccessibleUpdate);
  }

  function updateParameterOutputs() {
    setMathDigits(dom.massOutput, number2.format(state.parameters.mass));
    setMathDigits(dom.forceOutput, number2.format(state.parameters.forceScale));
    setMathDigits(dom.vxOutput, number2.format(state.parameters.vx0));
    setMathDigits(dom.vyOutput, number2.format(state.parameters.vy0));
    setMathDigits(dom.durationOutput, number2.format(state.parameters.duration));
  }

  function configureFieldControls() {
    const gravitySelected = state.parameters.fieldId === "gravity";
    dom.forceStrengthLabel.textContent = gravitySelected ? "Intensité de la pesanteur" : "Intensité du champ";
    dom.forceOutputContainer.setAttribute(
      "aria-label",
      gravitySelected ? "Intensité de la pesanteur" : "Intensité du champ"
    );
    dom.forceUnitNewton.hidden = gravitySelected;
    dom.forceUnitGravity.hidden = !gravitySelected;
    dom.forceSymbolF0.hidden = gravitySelected;
    dom.forceSymbolG.hidden = !gravitySelected;
    dom.forceScale.min = gravitySelected ? "0.5" : "0.2";
    dom.forceScale.max = gravitySelected ? "15" : "2";
    dom.forceScale.step = gravitySelected ? "0.01" : "0.1";
    dom.duration.min = gravitySelected ? "0.5" : "5";
    dom.duration.max = gravitySelected ? "5" : "50";
  }

  function updateForceFieldInterface() {
    const fieldId = FIELD_TYPES[state.parameters.fieldId] ? state.parameters.fieldId : "cellular";
    state.parameters.fieldId = fieldId;
    dom.forceField.value = fieldId;
    configureFieldControls();
    dom.forceFieldNote.textContent = FIELD_TYPES[fieldId].note;
    for (const block of dom.fieldFormulaBlocks) {
      block.hidden = block.dataset.forceField !== fieldId;
    }
  }

  function updateScenarioConclusion() {
    const simulation = state.simulation;
    const finalWork = simulation.work[simulation.count];
    const relation = finalWork > 0.002
      ? "À l’arrivée, le travail total est positif et la particule est plus rapide qu’au départ."
      : finalWork < -0.002
        ? "À l’arrivée, le travail total est négatif et la particule est plus lente qu’au départ."
        : "À l’arrivée, les travaux positif et négatif se compensent : la norme de la vitesse retrouve sa valeur initiale.";
    dom.scenarioNote.textContent = relation;
  }

  function recompute({ resetTime = true } = {}) {
    state.playing = false;
    updatePlayButton();
    state.simulation = integrate(state.parameters);
    if (resetTime) state.time = 0;
    state.time = Math.min(state.time, state.parameters.duration);
    dom.time.max = String(state.parameters.duration);
    updateParameterOutputs();
    updateForceFieldInterface();
    updateScenarioConclusion();
    render(true);
  }

  function setControlsFromParameters() {
    configureFieldControls();
    dom.forceField.value = state.parameters.fieldId || "cellular";
    dom.mass.value = String(state.parameters.mass);
    dom.forceScale.value = String(state.parameters.forceScale);
    dom.vx.value = String(state.parameters.vx0);
    dom.vy.value = String(state.parameters.vy0);
    dom.duration.value = String(state.parameters.duration);
  }

  function applyPreset(name) {
    const preset = PRESETS[name];
    if (!preset) return;
    state.parameters = { ...preset };
    dom.scenario.value = name;
    setControlsFromParameters();
    recompute();
  }

  function markCustom() {
    dom.scenario.value = "custom";
  }

  function updatePlayButton() {
    dom.play.textContent = state.playing ? "Pause" : "Lire";
    dom.play.setAttribute("aria-label", state.playing ? "Mettre l’animation en pause" : "Lire l’animation");
  }

  function setPlaying(value) {
    state.playing = value;
    state.lastFrameTime = 0;
    updatePlayButton();
    if (value && !state.animationFrame) state.animationFrame = requestAnimationFrame(animate);
  }

  function animate(timestamp) {
    state.animationFrame = 0;
    if (!state.playing) return;
    if (!state.lastFrameTime) state.lastFrameTime = timestamp;
    const elapsed = Math.min(0.1, (timestamp - state.lastFrameTime) / 1000);
    state.lastFrameTime = timestamp;
    state.time += elapsed * state.playbackRate;
    if (state.time >= state.parameters.duration) {
      if (state.loop) state.time %= state.parameters.duration;
      else {
        state.time = state.parameters.duration;
        state.playing = false;
        updatePlayButton();
      }
    }
    render();
    if (state.playing) state.animationFrame = requestAnimationFrame(animate);
  }

  function bindParameter(slider, key) {
    slider.addEventListener("input", () => {
      state.parameters[key] = Number(slider.value);
      markCustom();
      recompute();
    });
  }

  function bindDisplay(toggle, key) {
    toggle.addEventListener("change", () => {
      state.display[key] = toggle.checked;
      render();
    });
  }

  function resetView() {
    state.view = { centerX: PI, centerY: 1.5 * PI, zoom: 1 };
    render();
  }

  function installInteractions() {
    dom.forceField.addEventListener("change", () => {
      const previousField = state.parameters.fieldId;
      const nextField = dom.forceField.value;
      if (nextField === "gravity" && previousField !== "gravity") {
        state.nonGravitySettings = {
          forceScale: state.parameters.forceScale,
          duration: state.parameters.duration
        };
        state.parameters.forceScale = 9.81;
        state.parameters.duration = 1.2;
      } else if (previousField === "gravity" && nextField !== "gravity") {
        const previousSettings = state.nonGravitySettings || { forceScale: 1, duration: 15 * PI };
        state.parameters.forceScale = previousSettings.forceScale;
        state.parameters.duration = previousSettings.duration;
      }
      state.parameters.fieldId = nextField;
      setControlsFromParameters();
      markCustom();
      state.view = { centerX: PI, centerY: 1.5 * PI, zoom: 1 };
      recompute();
    });
    dom.scenario.addEventListener("change", () => applyPreset(dom.scenario.value));
    bindParameter(dom.mass, "mass");
    bindParameter(dom.forceScale, "forceScale");
    bindParameter(dom.vx, "vx0");
    bindParameter(dom.vy, "vy0");
    bindParameter(dom.duration, "duration");

    dom.play.addEventListener("click", () => {
      if (!state.playing && state.time >= state.parameters.duration) state.time = 0;
      setPlaying(!state.playing);
    });
    dom.reset.addEventListener("click", () => {
      setPlaying(false);
      state.time = 0;
      render(true);
    });
    dom.speed.addEventListener("change", () => {
      state.playbackRate = Number(dom.speed.value);
    });
    dom.time.addEventListener("pointerdown", () => setPlaying(false));
    dom.time.addEventListener("input", () => {
      state.time = Number(dom.time.value);
      render(true);
    });
    dom.loop.addEventListener("change", () => { state.loop = dom.loop.checked; });

    bindDisplay(dom.fieldToggle, "field");
    bindDisplay(dom.forceToggle, "force");
    bindDisplay(dom.velocityToggle, "velocity");
    bindDisplay(dom.trajectoryToggle, "trajectory");
    bindDisplay(dom.areaToggle, "area");
    dom.clearOverlays.addEventListener("click", () => {
      state.display = { field: false, force: false, velocity: false, trajectory: false, area: false };
      dom.fieldToggle.checked = false;
      dom.forceToggle.checked = false;
      dom.velocityToggle.checked = false;
      dom.trajectoryToggle.checked = false;
      dom.areaToggle.checked = false;
      render();
    });

    dom.resetView.addEventListener("click", resetView);
    dom.sceneViewport.addEventListener("pointerdown", (event) => {
      if (event.target.closest("button")) return;
      dom.sceneViewport.setPointerCapture(event.pointerId);
      state.drag = { pointerId: event.pointerId, x: event.clientX, y: event.clientY };
    });
    dom.sceneViewport.addEventListener("pointermove", (event) => {
      if (!state.drag || state.drag.pointerId !== event.pointerId) return;
      const rect = dom.sceneCanvas.getBoundingClientRect();
      const transform = viewTransform(rect.width, rect.height);
      const dx = event.clientX - state.drag.x;
      const dy = event.clientY - state.drag.y;
      state.view.centerX -= dx / transform.scale;
      state.view.centerY += dy / transform.scale;
      state.drag.x = event.clientX;
      state.drag.y = event.clientY;
      render();
    });
    const endDrag = (event) => {
      if (state.drag && state.drag.pointerId === event.pointerId) state.drag = null;
    };
    dom.sceneViewport.addEventListener("pointerup", endDrag);
    dom.sceneViewport.addEventListener("pointercancel", endDrag);
    dom.sceneViewport.addEventListener("wheel", (event) => {
      event.preventDefault();
      const rect = dom.sceneCanvas.getBoundingClientRect();
      const before = viewTransform(rect.width, rect.height).screenToWorld(
        event.clientX - rect.left,
        event.clientY - rect.top
      );
      const factor = Math.exp(-event.deltaY * 0.00125);
      state.view.zoom = Math.max(0.55, Math.min(7, state.view.zoom * factor));
      const after = viewTransform(rect.width, rect.height).screenToWorld(
        event.clientX - rect.left,
        event.clientY - rect.top
      );
      state.view.centerX += before.x - after.x;
      state.view.centerY += before.y - after.y;
      render();
    }, { passive: false });

    document.addEventListener("keydown", (event) => {
      const target = event.target;
      const editing = target instanceof HTMLInputElement || target instanceof HTMLSelectElement || target instanceof HTMLButtonElement;
      if (editing) return;
      if (event.code === "Space") {
        event.preventDefault();
        setPlaying(!state.playing);
      } else if (event.key.toLowerCase() === "r") {
        setPlaying(false);
        state.time = 0;
        render(true);
      }
    });
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) setPlaying(false);
    });

    const resizeObserver = new ResizeObserver(() => render());
    resizeObserver.observe(dom.sceneCanvas);
    resizeObserver.observe(dom.powerCanvas);
  }

  function numericalSelfCheck() {
    const simulation = state.simulation;
    const last = simulation.count;
    const deltaK = simulation.kinetic[last] - simulation.initialKinetic;
    const error = Math.abs(simulation.work[last] - deltaK);
    const expectedWork = 1.30696085;
    if (Math.abs(simulation.work[last] - expectedWork) > 8e-4 || error > 8e-5) {
      console.warn("Contrôle numérique du théorème travail–énergie hors tolérance.", {
        work: simulation.work[last],
        deltaK,
        error
      });
    }
  }

  function typesetMath() {
    if (!window.MathJax || !window.MathJax.startup) {
      dom.loading.textContent = "Les formules mathématiques n’ont pas pu être préparées.";
      return;
    }
    window.MathJax.startup.promise
      .then(() => window.MathJax.typesetPromise())
      .then(() => initializeMathGlyphs())
      .then(() => {
        mathIsReady = true;
        chartTickSignature = "";
        updateParameterOutputs();
        render(true);
        dom.loading.hidden = true;
      })
      .catch(() => {
        dom.loading.textContent = "Les formules mathématiques n’ont pas pu être préparées.";
      });
  }

  function initialize() {
    setControlsFromParameters();
    state.simulation = integrate(state.parameters);
    updateParameterOutputs();
    updateForceFieldInterface();
    updateScenarioConclusion();
    updatePlayButton();
    installInteractions();
    numericalSelfCheck();
    render(true);
    typesetMath();
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => render());
  }

  initialize();
}());
