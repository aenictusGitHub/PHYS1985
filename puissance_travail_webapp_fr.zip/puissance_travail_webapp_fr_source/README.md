# Travail et puissance — animation interactive

Application web autonome en français pour le cours PHYS1985, construite à partir de la vidéo vector_field_DKg0_.mp4.

## Modèle physique

La particule de masse \(m\) est soumise au champ

\[
\mathbf F(x,y)=F_0
\begin{pmatrix}
\sin(x/L_0)\cos(y/L_0)\\
-\cos(x/L_0)\sin(y/L_0)
\end{pmatrix},
\qquad L_0=1\ \mathrm m.
\]

Le mouvement est intégré par une méthode de Runge–Kutta d’ordre 4. La puissance et le travail sont calculés indépendamment :

\[
P(t)=\mathbf F(t)\cdot\mathbf v(t),\qquad
W_{A\to t}=\int_{t_A}^{t}P(\tau)\,\mathrm d\tau.
\]

La comparaison en temps réel avec

\[
\Delta K_{A\to t}=K(t)-K_A
\]

illustre le théorème de l’énergie cinétique.

## Cas reproduisant la vidéo

- \(m=20\ \mathrm{kg}\) ;
- \(F_0=1\ \mathrm N\) ;
- \(A=(4{,}4;\,6{,}8)\ \mathrm m\) ;
- \(\mathbf v_A=(0{,}2;\,-0{,}2)\ \mathrm{m\,s^{-1}}\) ;
- \(t_B=15\pi\simeq47{,}12\ \mathrm s\).

Le résultat attendu est \(W_{AB}=\Delta K_{AB}\simeq1{,}307\ \mathrm J>0\).

## Fonctionnalités

- animation synchronisée de la particule et du graphe de puissance ;
- choix entre le champ tourbillonnaire de la vidéo et deux champs conservatifs ;
- champ de force coloré en Viridis, trajectoire, force et vitesse ;
- aire positive et négative sous \(P(t)\), représentant le travail cumulé ;
- valeurs instantanées de \(P\), \(W\), \(\Delta K\), angle force–vitesse et erreur numérique ;
- préréglages pour un travail total positif, nul ou négatif ;
- réglage de la masse, de l’intensité du champ, de la vitesse initiale et de l’instant final ;
- déplacement de la vue par glissement et zoom à la molette ;
- mise en page adaptative et tous les symboles mathématiques rendus localement à partir de LaTeX par MathJax.

## Utilisation

Ouvrir le fichier autonome puissance_travail_webapp_fr.html, ou lancer ./serve.sh dans le dossier source, puis ouvrir http://127.0.0.1:8000.

## Commandes

- Espace : lire ou mettre en pause ;
- R : revenir à \(t=0\) ;
- glissement dans la figure : déplacer la vue ;
- molette : zoomer autour du pointeur.

## Structure

    puissance_travail_webapp_fr_source/
    ├── index.html
    ├── style.css
    ├── app.js
    ├── serve.sh
    ├── README.md
    └── vendor/
        └── mathjax/
            ├── tex-svg.js
            └── LICENSE

## Identification

L’en-tête affiche « PHYS1985 - ULiege » et le pied de page « © J. Martin ».
