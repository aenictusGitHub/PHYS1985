# Travail et puissance — animation interactive

Application web autonome en français pour le cours PHYS1985, construite à partir de la vidéo vector_field_DKg0_.mp4.

## Modèle physique

La particule de masse \(m\) peut notamment être soumise au champ

\[
\vec{F}(x,y)=F_0
\begin{pmatrix}
\sin(x/L_0)\cos(y/L_0)\\
-\cos(x/L_0)\sin(y/L_0)
\end{pmatrix},
\qquad L_0=1\ \mathrm m.
\]

Le mouvement est intégré par une méthode de Runge–Kutta d’ordre 4. La puissance et le travail sont calculés indépendamment :

\[
P(t)=\vec{F}(t)\cdot\vec{v}(t),\qquad
W_{A\to t}=\int_{t_A}^{t}P(\tau)\,\mathrm d\tau.
\]

La comparaison en temps réel avec

\[
\Delta K_{A\to t}=K(t)-K_A
\]

illustre le théorème de l’énergie cinétique.

L’application propose aussi un champ uniforme dépendant explicitement du temps :

\[
\vec{F}(t)=F_0
\begin{pmatrix}
\cos(\omega_0 t)\\
\sin(\omega_0 t)
\end{pmatrix},
\qquad \omega_0=\frac{2\pi}{10\ \mathrm s}.
\]

Elle propose également un tourbillon central spatial, non conservatif et borné :

\[
\vec{F}(x,y)=F_0
\frac{(-(y-y_c),\,x-x_c)}
{\sqrt{L_0^2+(x-x_c)^2+(y-y_c)^2}}.
\]

Un second champ dépend à la fois de la position et du temps :

\[
\vec{F}(x,y,t)=F_0
\begin{pmatrix}
\sin(x/L_0-\omega_0t)\cos(y/L_0)\\
-\cos(x/L_0-\omega_0t)\sin(y/L_0)
\end{pmatrix}.
\]

Il forme un réseau non uniforme de tourbillons qui se déplace au cours du temps.

Le champ de pesanteur uniforme est présenté avec son potentiel :

\[
\vec{F}=-mg\,\vec e_z,
\qquad U_g(z)=mgz.
\]

## Cas reproduisant la vidéo

- \(m=20\ \mathrm{kg}\) ;
- \(F_0=1\ \mathrm N\) ;
- \(A=(4.4;\,6.8)\ \mathrm m\) ;
- \(|\vec{v}_A|=0.28284271\ \mathrm{m\,s^{-1}}\) et \(\alpha_A=-45^{\circ}\), mesuré depuis \(+x\) ;
- \(t_B=15\pi\simeq47.12\ \mathrm s\).

Le résultat attendu est \(W_{AB}=\Delta K_{AB}\simeq1.307\ \mathrm J>0\).

## Fonctionnalités

- animation synchronisée de la particule et du graphe de puissance ;
- choix entre les tourbillons périodiques, un tourbillon central spatial, deux champs conservatifs, un champ tournant uniforme, un champ non uniforme dépendant du temps et le champ de pesanteur uniforme ;
- champ de force coloré en Viridis, trajectoire, force et vitesse ;
- aire positive et négative sous \(P(t)\), représentant le travail cumulé ;
- valeurs instantanées de \(P\), \(W\), \(\Delta K\), angle force–vitesse et erreur numérique ;
- préréglages pour un travail total positif, nul ou négatif ;
- réglage de la masse, de l’intensité du champ, du module \(|\vec v_A|\) jusqu’à \(2.00\ \mathrm{m\,s^{-1}}\), de l’angle initial et de l’instant final ;
- déplacement direct du point initial \(A\), déplacement de la vue par glissement et zoom à la molette ;
- mise en page adaptative et tous les symboles mathématiques rendus localement à partir de LaTeX par MathJax.

## Utilisation

### Mode « Chemin imposé »

Ce mode est indépendant du mouvement libre. Deux chemins lisses de formes différentes relient les mêmes
points A et B, déplaçables à la souris, au toucher, ou avec les flèches du clavier
après avoir sélectionné leur étiquette. Le premier est un arc parabolique, le second
une courbe en S. Un curseur règle leur amplitude ; à zéro, ils se confondent avec AB.

- **Comparaison** : les deux points parcourent simultanément A → B ; le graphique
  montre leurs travaux cumulés et les cartes donnent les travaux complets.
  Les vecteurs force (violet) et vitesse (orange) partent de chacun des deux points,
  avec des échelles communes aux deux chemins. Une légende fixe en haut à droite
  remplace les étiquettes individuelles et les traits de rappel.
  Le champ en arrière-plan utilise le même violet que la force : ses flèches
  sont plus contrastées, épaisses et longues pour rester lisibles. Le réglage
  est partagé par les modes deux chemins, contour fermé et comparaison des intégrales.
  Leur échelle reste fixe quand on change l’intensité : doubler celle-ci double
  la longueur des flèches du fond et des forces appliquées aux particules.
  Les vitesses et les trajectoires imposées ne sont pas modifiées.
- **Contour fermé** : aller par C1, retour par C2 ; le travail total vaut W1 − W2.
  L’inversion du sens change son signe (W2 − W1).
- Cinq champs stationnaires : tourbillon central, tourbillons périodiques,
  attraction centrale, puits périodiques, pesanteur uniforme (m = 1 kg).
- Les champs dépendants du temps sont réservés au mouvement libre : l’expérience
  isole ici la dépendance au chemin, sans dépendance à l’horaire de parcours.
- Les parcours utilisent r(s) = (1−s)A+sB + g(s)n et la loi horaire s(u)=3u²−2u³.
  Pour l’arc : g1(s)=4h s(1−s). Pour le S : g2(s)=−0.6h ε sin(2πs), où ε
  conserve l’orientation canonique de la normale n quand on échange A et B.
  Le S a un point d’inflexion ; les deux courbes n’ont pas d’intersection intérieure
  pour h>0. Les vitesses utilisent les dérivées analytiques de ces mêmes parcours.
  Les points s’arrêtent aux extrémités, y compris au raccord en B.
- Le travail est intégré indépendamment sur chaque chemin par Simpson composite
  (800 intervalles avec point milieu). Les champs conservatifs sont aussi vérifiés
  par U(A)−U(B). Les calculs ne forcent jamais l’égalité des deux intégrales.
- Les échelles de force et de vitesse sont linéaires et fixes pour une expérience,
  distinctes de l’échelle spatiale. La force n’est pas normalisée point par point.

Le dispositif qui impose le parcours peut fournir un travail. Le travail affiché
est celui du champ étudié, **pas nécessairement la variation d’énergie cinétique**.
Un contour de travail non nul suffit à réfuter le caractère conservatif ; un seul
contour de travail nul ne suffit pas à le prouver. La durée n’influence pas les
travaux complets, mais modifie les vitesses et les puissances.

Les contrôles et les paramètres du mouvement libre sont conservés lorsqu’on
bascule d’un mode à l’autre ; la lecture est alors mise en pause.

### Mode « Puissance et force — deux intégrales »

Un troisième mode compare, sur un même trajet imposé (arc, S, ou contour fermé),
l’intégrale temporelle de P(t) et l’intégrale curviligne de la force.

- Le premier graphique montre P(t), le second la composante tangentielle signée
  F_parallel(ell), en fonction de la longueur parcourue ell, toujours croissante.
  Cette longueur n’est ni x, ni la distance en ligne droite depuis A.
- Les deux aires sont colorées selon leur signe, jusqu’au même point atteint par
  la particule. Les valeurs courantes sont affichées à six décimales, avec leur
  différence. L’égalité ne nécessite pas que le champ soit conservatif.
- Les calculs sont indépendants : Simpson sur 1200 intervalles de temps, à partir
  de la vitesse analytique ; 1600 déplacements géométriques, avec la force au
  milieu de chaque corde, pour l’intégrale spatiale. Cette seconde intégrale
  n’utilise ni la vitesse, ni le temps, ni le travail calculé par la première.
- Le graphique spatial est l’approximation par segments utilisée pour le calcul.
  Un petit écart de quadrature est attendu et n’est jamais artificiellement annulé.
- Aux arrêts, la puissance vaut zéro ; la composante tangentielle est affichée
  avec la tangente géométrique unilatérale. Elle peut changer de signe au raccord
  du contour fermé. Changer la durée change P(t), pas le travail total.

### Lancement des fichiers

Ouvrir le fichier autonome puissance_travail_webapp_fr.html, ou lancer ./serve.sh dans le dossier source, puis ouvrir http://127.0.0.1:8000.

## Commandes

- Espace : lire ou mettre en pause ;
- R : revenir à \(t=0\) ;
- glissement du point \(A\) : déplacer la position initiale ;
- glissement ailleurs dans la figure : déplacer la vue ;
- molette : zoomer autour du pointeur.

## Structure

    puissance_travail_webapp_fr_source/
    ├── index.html
    ├── style.css
    ├── app.js
    ├── serve.sh
    ├── README.md
    └── vendor/
        └── mathjax/
            ├── tex-svg.js
            └── LICENSE

## Identification

L’en-tête affiche « PHYS1985 - ULiege » et le pied de page « © J. Martin ».
# Lisibilité des relations

Les champs de force sont présentés par composantes sur plusieurs lignes, dans tous les modes d’expérience. Les écarts au centre des champs centraux sont définis explicitement par Δx = x − x_c et Δy = y − y_c. Les longues chaînes d’égalités du travail et de la puissance sont également réparties sur plusieurs lignes. Le panneau reste dans sa largeur, sans défilement horizontal ni formule tronquée ; un ajustement proportionnel des SVG sert de sécurité sur les écrans étroits. Aucun calcul physique n’est modifié.
