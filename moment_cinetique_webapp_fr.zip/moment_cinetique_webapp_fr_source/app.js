/* Fixed-axis models. Radial motion is imposed; only rotational energy is shown.
 * L_z evolves from the external torque, never by normalizing a numeric solution. */
const RotationModels=(()=>{
  'use strict';
  const minRadius=.25,maxRadius=1.2;
  const definitions={
    particle:{mass:1,base:0,r:.8,omega:1.5},
    stool:{mass:2,base:2,r:.8,omega:1.5},
    shell:{mass:3,base:0,r:1,omega:1},
  };
  const clampRadius=r=>Math.max(minRadius,Math.min(maxRadius,r));
  function inertia(model,mass,base,r) {
    if(!definitions[model]||![mass,base,r].every(Number.isFinite)||mass<=0||base<0||r<=0)throw new Error('Paramètres physiques non valides.');
    return (model==='stool'?base:0)+(model==='shell'?2/3:model==='stool'?2:1)*mass*r*r;
  }
  class Simulation {
    constructor(model='stool',parameters={}) {
      if(!definitions[model])throw new Error('Modèle inconnu.');
      this.model=model;this.p={...definitions[model],duration:20,torque:0,...parameters};
      if(![this.p.omega,this.p.duration,this.p.torque].every(Number.isFinite)||this.p.duration<=0)throw new Error('Paramètres temporels non valides.');
      this.p.r=clampRadius(this.p.r);this.L0=inertia(model,this.p.mass,this.p.base,this.p.r)*this.p.omega;
      this.x={t:0,r:this.p.r,L:this.L0,theta:0,impulse:0,torque:this.p.torque};
      this.history=[{...this.x}];this.motion=null;this.started=false;
    }
    snapshot(x=this.x) {const I=inertia(this.model,this.p.mass,this.p.base,x.r);return {...x,I,omega:x.L/I,K:x.L*x.L/(2*I),balance:x.L-this.L0-x.impulse};}
    get end(){return this.history[this.history.length-1].t;}
    branch() {this.history=this.history.filter(s=>s.t<this.x.t-1e-10);this.history.push({...this.x});}
    record() {if(Math.abs(this.end-this.x.t)<1e-10)this.history[this.history.length-1]={...this.x};else this.history.push({...this.x});}
    setRadius(r) {
      if(!Number.isFinite(r))throw new Error('Rayon non valide.');
      r=clampRadius(r);this.branch();this.motion=null;this.x.r=r;
      if(!this.started){this.p.r=r;this.L0=inertia(this.model,this.p.mass,this.p.base,r)*this.p.omega;this.x.L=this.L0;}
      this.record();
    }
    moveTo(r) {
      if(!Number.isFinite(r))throw new Error('Rayon non valide.');
      this.branch();this.started=true;
      this.motion={from:this.x.r,to:clampRadius(r),start:this.x.t,duration:2};
    }
    setTorque(torque) {
      if(!Number.isFinite(torque))throw new Error('Moment extérieur non valide.');
      this.branch();this.x.torque=torque;this.record();
      if(!this.started)this.p.torque=torque;
    }
    radiusAt(t) {if(!this.motion)return this.x.r;const m=this.motion,u=Math.max(0,Math.min(1,(t-m.start)/m.duration));return m.from+(m.to-m.from)*u*u*(3-2*u);}
    advance(dt) {
      if(!Number.isFinite(dt)||dt<0)throw new Error('Pas de temps non valide.');
      dt=Math.min(dt,this.p.duration-this.x.t);if(dt<=0)return this.snapshot();
      if(this.p.duration-this.x.t-dt<1e-9)dt=this.p.duration-this.x.t;
      const endTime=this.x.t+dt;
      this.started=true;if(this.x.t<this.end-1e-10)this.branch();
      const n=Math.ceil(dt*120),h=dt/n;
      for(let i=0;i<n;i++) {
        const x=this.x,rMid=this.radiusAt(x.t+h/2),Lmid=x.L+x.torque*h/2;
        const theta=x.theta+h*Lmid/inertia(this.model,this.p.mass,this.p.base,rMid),r=this.radiusAt(x.t+h);
        this.x={...x,t:x.t+h,r,L:x.L+x.torque*h,impulse:x.impulse+x.torque*h,theta};this.record();
      }
      this.x.t=endTime;this.record();
      if(this.motion&&this.x.t>=this.motion.start+this.motion.duration-1e-10)this.motion=null;
      return this.snapshot();
    }
    seek(t) {
      if(!Number.isFinite(t))throw new Error('Instant non valide.');
      t=Math.max(0,Math.min(this.end,t));let lo=0,hi=this.history.length-1;
      while(hi-lo>1){const mid=(lo+hi)>>1;if(this.history[mid].t<=t)lo=mid;else hi=mid;}
      const a=this.history[lo],b=this.history[hi],u=b.t===a.t?0:(t-a.t)/(b.t-a.t);
      this.x={...a,t};for(const k of ['r','L','theta','impulse'])this.x[k]=a[k]+u*(b[k]-a[k]);
      if(u>=1)this.x.torque=b.torque;this.motion=null;return this.snapshot();
    }
  }
  return {definitions,inertia,Simulation,minRadius,maxRadius};
})();

if(typeof document!=='undefined') {
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',startRotationApp);
  else startRotationApp();
}
async function startRotationApp(){
  'use strict';
  const $=id=>document.getElementById(id),tex=String.raw;
  try {
    await MathJax.startup.promise;
    const colors={body:'#2775b6',body2:'#74c9b2',v:'#2775b6',v2:'#237a68',torque:'#b14866',L:'#7758a6',I:'#bc8b3b',r:'#d9683b',K:'#b5688b',ink:'#233449',muted:'#607185',grid:'#dce4ec'};
    const state={sim:new RotationModels.Simulation(),playing:false,frame:0,last:null,lastReadout:-Infinity,drag:null};
    const glyphs=new Map(),units=new Map(),labels=new Map();
    function math(el,value){if(el.dataset.math===value)return;el.replaceChildren(MathJax.tex2svg(value,{display:false}));el.dataset.math=value;}
    function numericPart(value){const svg=MathJax.tex2svg(value,{display:false}).querySelector('svg');const [x,y,width,height]=svg.getAttribute('viewBox').split(/\s+/).map(Number);return {svg,x,y,width,height,exPerUnit:parseFloat(svg.getAttribute('width'))/width};}
    for(const el of document.querySelectorAll('[data-tex]'))math(el,el.dataset.tex);
    for(const c of '0123456789.-')glyphs.set(c,numericPart(c));
    const numericTop=Math.min(...[...glyphs.values()].map(g=>g.y)),numericBottom=Math.max(...[...glyphs.values()].map(g=>g.y+g.height));
    MathJax.startup.document.updateDocument();
    function number(el,value,digits=3,unit=''){
      if(!Number.isFinite(value))throw new Error('Valeur non finie.');
      const string=(Math.abs(value)<.5*10**-digits?0:value).toFixed(digits),key=string+'|'+unit;
      if(el.dataset.number===key)return;
      const parts=[...string].map(c=>glyphs.get(c));if(unit){if(!units.has(unit))units.set(unit,numericPart(unit));parts.push(units.get(unit));}
      const svg=parts[0].svg.cloneNode(false),ex=glyphs.get('0').exPerUnit;let width=0,top=numericTop,bottom=numericBottom;
      for(const [i,p] of parts.entries()){
        if(i===string.length)width+=1000/6;
        const g=document.createElementNS('http://www.w3.org/2000/svg','g');g.setAttribute('transform',`translate(${width-p.x},0)`);
        g.append(...[...p.svg.children].map(child=>child.cloneNode(true)));svg.append(g);width+=p.width;top=Math.min(top,p.y);bottom=Math.max(bottom,p.y+p.height);
      }
      svg.setAttribute('viewBox',`0 ${top} ${width} ${bottom-top}`);svg.setAttribute('width',`${width*ex}ex`);svg.setAttribute('height',`${(bottom-top)*ex}ex`);
      svg.style.verticalAlign=`${-bottom*ex}ex`;svg.setAttribute('role','img');svg.setAttribute('aria-label',string+' '+unit.replace(/\\mathrm|[{}]/g,'').replace(/\\,/g,' '));
      el.classList.add('number');el.replaceChildren(svg);el.dataset.number=key;
    }
    function pause(){state.playing=false;state.last=null;if(state.frame)cancelAnimationFrame(state.frame);state.frame=0;$('play').textContent='Lire';$('play').setAttribute('aria-pressed','false');}
    function play(){if(state.sim.x.t>=state.sim.p.duration-1e-9)restart();state.sim.started=true;state.playing=true;state.last=null;$('play').textContent='Pause';$('play').setAttribute('aria-pressed','true');if(!state.frame)state.frame=requestAnimationFrame(frame);}
    function restart(){endMassDrag();pause();state.sim=new RotationModels.Simulation(state.sim.model,state.sim.p);syncControls();render();}
    function configure(model){endMassDrag();pause();state.sim=new RotationModels.Simulation(model);syncControls();render();}
    function syncControls(){
      const sim=state.sim,p=sim.p;$('model-select').value=sim.model;
      for(const [id,value] of [['mass',p.mass],['base',p.base],['omega-initial',p.omega],['radius',sim.x.r],['torque',sim.x.torque],['duration',p.duration]])$(id).value=value;
      $('base-control').hidden=sim.model!=='stool';
      $('mass-name').textContent=sim.model==='stool'?'Masse de chaque haltère':sim.model==='shell'?'Masse de la coquille':'Masse du point';
      $('radius-name').textContent=sim.model==='shell'?'Rayon de la sphère':sim.model==='stool'?'Distance des haltères à l’axe':'Distance à l’axe';
      const factor=distanceFactor(),live=$('scene-radius');
      live.min=factor*RotationModels.minRadius;live.max=factor*RotationModels.maxRadius;live.step=factor*.01;
      $('scene-radius-name').textContent=sim.model==='stool'?'Distance entre les masses':sim.model==='shell'?'Rayon de la sphère':'Distance à l’axe';
      math($('scene-radius-symbol'),sim.model==='stool'?tex`d=2r`:'r');
      $('live-radius-help').textContent=sim.model==='shell'?'Déplacer ce curseur ou faire glisser le point repère sur la sphère pour changer le rayon, même pendant la rotation.':'Déplacer ce curseur ou faire glisser une masse vers l’axe ou vers l’extérieur, même pendant la rotation.';
      $('velocity-name').textContent=sim.model==='stool'?'Vitesses tangentielles':'Vitesse tangentielle';
      math($('velocity-symbol'),sim.model==='stool'?tex`\vec v_1,\;\vec v_2`:tex`\vec v`);
      $('scene-title').textContent=sim.model==='stool'?'Tabouret tournant':sim.model==='shell'?'Sphère rétractable':'Point matériel en rotation';
      $('model-note').textContent=sim.model==='stool'?'Deux haltères sont rapprochés symétriquement du corps. Le tabouret et le corps sont représentés par une inertie fixe, les haltères par deux masses ponctuelles.':sim.model==='shell'?'La structure rétractable de la vidéo est idéalisée par une coquille sphérique mince et uniforme, de masse constante.':'Une masse ponctuelle décrit un cercle dans un plan perpendiculaire à l’axe fixe. Faire varier sa distance à l’axe change le moment d’inertie.';
      math($('inertia-formula'),sim.model==='stool'?tex`I_z=I_0+2mr^2`:sim.model==='shell'?tex`I_z=\frac23 mr^2`:tex`I_z=mr^2,\quad\vec L_O=\vec r\times m\vec v`);
      updateVectorScale();
    }
    function updateVectorScale(){
      const sim=state.sim,s=sim.x;
      // Hold the scale fixed until the applied torque or experiment changes.
      // Previously accumulated momentum still matters after removing a torque.
      state.vectorBound=Math.max(1,Math.abs(sim.L0),Math.abs(s.L)+Math.abs(s.torque)*(sim.p.duration-s.t),...sim.history.map(x=>Math.abs(x.L)));
    }
    function surface(id){const canvas=$(id),r=canvas.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1),ctx=canvas.getContext('2d');if(canvas.width!==Math.round(r.width*dpr)||canvas.height!==Math.round(r.height*dpr)){canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,r.width,r.height);return {ctx,w:r.width,h:r.height};}
    function line(ctx,points,color,width=1,dash=[]){if(!points.length)return;ctx.beginPath();ctx.moveTo(...points[0]);for(const p of points.slice(1))ctx.lineTo(...p);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.setLineDash(dash);ctx.stroke();ctx.setLineDash([]);}
    function dot(ctx,x,y,r,color){ctx.beginPath();ctx.arc(x,y,r,0,2*Math.PI);ctx.fillStyle=color;ctx.fill();}
    // Same purely graphical relief as Collisions; physical radii are unchanged.
    function sphere(ctx,x,y,r,index,palette=null,outline=null){
      const colors=palette||(index===1?['#b8ddf6','#62a8d9','#2775b6','#1c5280']:['#e1f8ee','#b6e8d7','#94d9c5','#529c89']);
      const shade=ctx.createRadialGradient(x-r*.34,y-r*.38,r*.03,x-r*.08,y-r*.1,r*1.14);
      for(const [offset,color]of [[0,colors[0]],[.3,colors[1]],[.7,colors[2]],[1,colors[3]]])shade.addColorStop(offset,color);
      ctx.save();ctx.shadowColor='rgba(35,52,73,.16)';ctx.shadowBlur=Math.min(7,r*.3);ctx.shadowOffsetY=Math.min(3,r*.12);
      ctx.beginPath();ctx.arc(x,y,r,0,2*Math.PI);ctx.fillStyle=shade;ctx.fill();ctx.restore();
      ctx.strokeStyle=outline||(index===1?'#23679c':'#68ae9a');ctx.lineWidth=.7;ctx.stroke();
    }
    function label(layer,key,value,x,y,color=colors.ink,tick=false){const id=layer+':'+key;let el=labels.get(id);if(!el){el=document.createElement('span');$(layer).append(el);labels.set(id,el);}el.hidden=false;el.className='plot-label'+(tick?' tick':'');math(el,value);el.style.left=x+'px';el.style.top=y+'px';el.style.color=color;return el;}
    function arrow(ctx,a,b,color,width=2.5){const dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);if(length<1e-8)return;const ux=dx/length,uy=dy/length,head=Math.min(9,length*.35);line(ctx,[a,b],color,width);line(ctx,[[b[0]-head*ux-head*.48*uy,b[1]-head*uy+head*.48*ux],b,[b[0]-head*ux+head*.48*uy,b[1]-head*uy-head*.48*ux]],color,width);}
    function sceneGeometry(w,h){return {cx:w/2,cy:h*.52,scale:Math.min(w*.32,h*.29)/RotationModels.maxRadius};}
    function distanceFactor(){return state.sim.model==='stool'?2:1;}
    function setLiveRadius(r){state.sim.setRadius(r);if(!state.sim.started)updateVectorScale();render();}
    function endMassDrag(){
      if(state.drag){const canvas=$('scene-canvas'),id=state.drag.id;state.drag=null;if(canvas.hasPointerCapture(id))canvas.releasePointerCapture(id);}
      $('scene-canvas').style.cursor='default';
    }
    function scenePointer(event){
      const rect=$('scene-canvas').getBoundingClientRect(),g=sceneGeometry(rect.width,rect.height),x=event.clientX-rect.left,y=event.clientY-rect.top;
      return {...g,x,y,r:Math.hypot((x-g.cx)/g.scale,(y-g.cy)/(.42*g.scale))};
    }
    function hitsMass(q){
      const s=state.sim.x,angles=state.sim.model==='stool'?[s.theta,s.theta+Math.PI]:[s.theta];
      return angles.some(a=>Math.hypot(q.x-q.cx-q.scale*s.r*Math.cos(a),q.y-q.cy+.42*q.scale*s.r*Math.sin(a))<=22);
    }
    function drawScene(s){
      const {ctx,w,h}=surface('scene-canvas'),sim=state.sim,p=sim.p;
      for(const el of $('scene-labels').children)el.hidden=true;
      const {cx,cy,scale}=sceneGeometry(w,h);
      const P=(x,y,z=0)=>[cx+scale*x,cy-scale*(.42*y+.9075*z)];
      const circle=(r,z=0)=>Array.from({length:121},(_,i)=>P(r*Math.cos(i*Math.PI/60),r*Math.sin(i*Math.PI/60),z));
      line(ctx,[[cx,35],[cx,h-32]],colors.grid,1.3,[4,5]);label('scene-labels','axis',tex`+z`,cx+17,38,colors.muted);
      if($('show-radius').checked)line(ctx,circle(p.r),colors.grid,1.5,[4,5]);
      if(sim.model==='shell'){
        sphere(ctx,cx,cy,scale*s.r,1,['#fcfdff','#f1f3f6','#e2e7ee','#cdd5df'],'#9ba9ba');
        for(let j=1;j<6;j++){const a=j*Math.PI/6;line(ctx,circle(s.r*Math.sin(a),s.r*Math.cos(a)),'#b3becc',1);}
        for(let j=0;j<10;j++){const angle=s.theta+j*Math.PI/5;line(ctx,Array.from({length:65},(_,i)=>{const a=i*Math.PI/64;return P(s.r*Math.sin(a)*Math.cos(angle),s.r*Math.sin(a)*Math.sin(angle),s.r*Math.cos(a));}),j===0?'#899aaf':'#b3becc',j===0?2:1);}
      }else{
        line(ctx,circle(s.r),colors.grid,1.3);
        if(sim.model==='stool'){line(ctx,circle(.18),'#9dafbf',10);line(ctx,[P(-.16,0),P(.16,0)],'#9dafbf',5);label('scene-labels','base','I_0',cx-25,cy+33,colors.muted);}
      }
      const angles=sim.model==='stool'?[s.theta,s.theta+Math.PI]:[s.theta];
      const Lbound=state.vectorBound,Lscale=110/Lbound;
      // Independent fixed units for linear velocity and angular momentum.
      let maxV=0;for(let i=0;i<=100;i++){const r=RotationModels.minRadius+(RotationModels.maxRadius-RotationModels.minRadius)*i/100;maxV=Math.max(maxV,Lbound*r/RotationModels.inertia(sim.model,p.mass,p.base,r));}
      // A larger, fixed linear scale makes the point-particle velocity readable.
      // Its maximum still fits the viewport throughout contraction and rotation.
      const velocityPixels=sim.model==='particle'?Math.min(140,w*.42):46;
      const vScale=velocityPixels/Math.max(.2,maxV);
      const velocityArrows=[];
      for(const [i,a] of angles.entries()){
        const pos=P(s.r*Math.cos(a),s.r*Math.sin(a));
        line(ctx,[[cx,cy],pos],sim.model==='stool'?'#93a7b8':colors.r,sim.model==='stool'?4:1.8);
        if(i===0)label('scene-labels','radius','r',(cx+pos[0])/2-8,(cy+pos[1])/2+15,colors.r);
        if(sim.model==='shell')dot(ctx,...pos,5.5,colors.ink);
        else sphere(ctx,...pos,10,i+1);
        if(sim.model!=='shell')label('scene-labels','mass'+i,sim.model==='stool'?'m_'+(i+1):'m',pos[0],pos[1]+22,i?colors.v2:colors.body);
        if($('show-v').checked&&Math.abs(s.omega)>1e-9){
          const vx=-s.r*s.omega*Math.sin(a),vy=s.r*s.omega*Math.cos(a),tip=[pos[0]+vScale*vx,pos[1]-.42*vScale*vy];
          velocityArrows.push({i,pos,tip});
        }
      }
      // Draw vectors after all bodies and the mesh, so they remain in front.
      for(const {i,pos,tip}of velocityArrows){
        const color=i?colors.v2:colors.v;
        arrow(ctx,pos,tip,color);
        const dx=tip[0]-pos[0],dy=tip[1]-pos[1],length=Math.hypot(dx,dy);
        label('scene-labels','velocity'+i,sim.model==='stool'?tex`\vec v_${i+1}`:tex`\vec v`,
          Math.max(25,Math.min(w-25,tip[0]+16*dy/length)),Math.max(65,Math.min(h-90,tip[1]-16*dx/length)),color);
      }
      dot(ctx,cx,cy,3.5,colors.ink);label('scene-labels','origin','O',cx+15,cy+16,colors.muted);
      if($('show-l').checked){if(Math.abs(s.L)<1e-9)label('scene-labels','L',tex`\vec L_O=\vec 0`,cx+48,cy-50,colors.L);else{
        const length=Math.abs(s.L)*Lscale,tip=[cx,cy-Math.sign(s.L)*length];arrow(ctx,[cx,cy],tip,colors.L,3);
        label('scene-labels','L',tex`\vec L_O`,cx+24,tip[1]-Math.sign(s.L)*8,colors.L);
      }}
      const hasTorque=Math.abs(s.torque)>1e-12;
      $('scene-torque').hidden=!hasTorque;
      if(hasTorque){
        // Separate torque scale: 18 pixels per N m, along the same +z direction.
        arrow(ctx,[24,h-48],[24,h-48-18*s.torque],colors.torque,3);
        number($('scene-torque-value'),s.torque,2,tex`\mathrm{N\,m}`);
      }
      $('scene').setAttribute('aria-label',$('scene-title').textContent+'. Instant '+s.t.toFixed(2)+' s ; rayon '+s.r.toFixed(2)+' m ; vitesse angulaire '+s.omega.toFixed(3)+' rad/s ; moment cinétique '+s.L.toFixed(3)+' kg m²/s ; moment extérieur '+s.torque.toFixed(2)+' N m, selon l’axe Oz.');
    }
    function chartGeometry(w,h){return {left:70,right:Math.max(90,w-24),top:40,bottom:h-44};}
    function drawHistory(s){
      const {ctx,w,h}=surface('history-canvas'),g=chartGeometry(w,h),sim=state.sim,key=$('chart-select').value;
      for(const el of $('history-labels').children)el.hidden=true;
      const info={L:{color:colors.L,tex:tex`L_z\,[\mathrm{kg\,m^2\,s^{-1}}]`},omega:{color:colors.v,tex:tex`\omega\,[\mathrm{rad\,s^{-1}}]`},I:{color:colors.I,tex:tex`I_z\,[\mathrm{kg\,m^2}]`}}[key];
      const data=sim.history.map(x=>sim.snapshot(x));
      const values=data.map(x=>x[key]),min=Math.min(0,...values),max=Math.max(0,...values),span=Math.max(.2,max-min);
      const low=min-.12*span,high=max+.15*span,X=t=>g.left+t/sim.p.duration*(g.right-g.left),Y=value=>g.bottom-(value-low)/(high-low)*(g.bottom-g.top);
      const ticks=w<450?4:5;
      for(let i=0;i<=ticks;i++){const t=i*sim.p.duration/ticks,x=X(t);line(ctx,[[x,g.top],[x,g.bottom]],colors.grid);label('history-labels','x'+i,String(Number(t.toFixed(1))),x,g.bottom+16,colors.muted,true);}
      for(let i=0;i<=4;i++){const value=low+(high-low)*i/4,y=Y(value);line(ctx,[[g.left,y],[g.right,y]],colors.grid);label('history-labels','y'+i,(Math.abs(value)<.0005?0:value).toFixed(high-low<10?2:1),g.left-30,y,colors.muted,true);}
      label('history-labels','unitY',info.tex,g.left,15).style.transform='translate(0,-50%)';label('history-labels','unitX',tex`t\,[\mathrm s]`,(g.left+g.right)/2,h-9);
      line(ctx,[[g.left,Y(0)],[g.right,Y(0)]],colors.muted,1,[4,4]);
      line(ctx,data.map(x=>[X(x.t),Y(x[key])]),info.color,2.2);
      line(ctx,[[X(s.t),g.top],[X(s.t),g.bottom]],colors.muted,1,[4,4]);dot(ctx,X(s.t),Y(s[key]),4.5,info.color);
      $('history').setAttribute('aria-valuemax',sim.end);$('history').setAttribute('aria-valuenow',s.t);$('history').setAttribute('aria-valuetext',s.t.toFixed(2)+' s');
    }
    function render(readouts=true){
      const sim=state.sim,s=sim.snapshot(),p=sim.p;
      $('radius').value=s.r;$('scene-radius').value=distanceFactor()*s.r;$('torque').value=s.torque;
      if(readouts){
        number($('time-value'),s.t,2,tex`\mathrm s`);number($('radius-value'),s.r,2,tex`\mathrm m`);
        number($('scene-radius-value'),distanceFactor()*s.r,2,tex`\mathrm m`);
        number($('mass-value'),p.mass,2,tex`\mathrm{kg}`);number($('base-value'),p.base,2,tex`\mathrm{kg\,m^2}`);number($('omega-initial-value'),p.omega,2,tex`\mathrm{rad\,s^{-1}}`);number($('torque-value'),s.torque,2,tex`\mathrm{N\,m}`);number($('duration-value'),p.duration,0,tex`\mathrm s`);
        number($('inertia-value'),s.I,3,tex`\mathrm{kg\,m^2}`);number($('omega-value'),s.omega,3,tex`\mathrm{rad\,s^{-1}}`);number($('momentum-value'),s.L,3,tex`\mathrm{kg\,m^2\,s^{-1}}`);number($('energy-value'),s.K,3,tex`\mathrm J`);number($('balance-value'),s.balance,Math.abs(s.balance)<1e-7?0:6,tex`\mathrm{kg\,m^2\,s^{-1}}`);
      }
      for(const [id,value,unit]of [['radius',s.r,'m'],['mass',p.mass,'kg'],['base',p.base,'kg m²'],['omega-initial',p.omega,'rad/s'],['torque',s.torque,'N m'],['duration',p.duration,'s']])$(id).setAttribute('aria-valuetext',value.toFixed(id==='duration'?0:2)+' '+unit);
      $('scene-radius').setAttribute('aria-valuetext',(distanceFactor()*s.r).toFixed(2)+' m');
      $('conservation-badge').textContent=Math.abs(s.torque)<1e-12?'Moment cinétique conservé':'Moment extérieur appliqué';
      $('observation').textContent=Math.abs(s.torque)>1e-12?'Le moment extérieur modifie le moment cinétique. Son signe indique le sens de cette variation, pas nécessairement le sens de rotation.':Math.abs(s.L)<1e-10?'Sans moment cinétique initial ni moment extérieur, rapprocher les masses ne suffit pas à lancer la rotation.':s.r<p.r-.01?'Les masses se rapprochent de l’axe : le moment d’inertie diminue et la rotation accélère. Le moment cinétique reste constant.':s.r>p.r+.01?'Les masses s’éloignent de l’axe : le moment d’inertie augmente et la rotation ralentit. Le moment cinétique reste constant.':'Rapprochez les masses de l’axe pour réduire le moment d’inertie, puis éloignez-les. Comparez les variations d’inertie et de vitesse angulaire au moment cinétique conservé.';
      drawScene(s);if(readouts)drawHistory(s);
    }
    function frame(now){
      state.frame=0;if(!state.playing)return;
      const dt=state.last===null?0:Math.min(.05,Math.max(0,(now-state.last)/1000))*Number($('speed').value);state.last=now;
      try{state.sim.advance(dt);const refresh=now-state.lastReadout>=65;if(refresh)state.lastReadout=now;render(refresh);if(state.sim.x.t>=state.sim.p.duration-1e-9){pause();render();return;}}
      catch(error){pause();$('loading').hidden=false;$('loading').textContent='L’animation a été interrompue. '+error.message;console.error(error);return;}
      state.frame=requestAnimationFrame(frame);
    }
    $('model-select').addEventListener('change',()=>configure($('model-select').value));
    $('radius').addEventListener('input',()=>{endMassDrag();setLiveRadius(Number($('radius').value));});
    $('scene-radius').addEventListener('input',()=>{endMassDrag();setLiveRadius(Number($('scene-radius').value)/distanceFactor());});
    const sceneCanvas=$('scene-canvas');
    sceneCanvas.addEventListener('pointerdown',event=>{
      if(state.drag||(event.button!==undefined&&event.button!==0))return;
      const q=scenePointer(event);if(!hitsMass(q))return;
      event.preventDefault();state.drag={id:event.pointerId,r:state.sim.x.r,pointerRadius:q.r};
      state.sim.motion=null;sceneCanvas.setPointerCapture(event.pointerId);sceneCanvas.style.cursor='grabbing';
    });
    sceneCanvas.addEventListener('pointermove',event=>{
      if(state.drag){if(event.pointerId!==state.drag.id)return;event.preventDefault();const q=scenePointer(event);setLiveRadius(state.drag.r+q.r-state.drag.pointerRadius);}
      else sceneCanvas.style.cursor=hitsMass(scenePointer(event))?'grab':'default';
    });
    for(const type of ['pointerup','pointercancel','lostpointercapture'])sceneCanvas.addEventListener(type,event=>{if(state.drag?.id===event.pointerId)endMassDrag();});
    sceneCanvas.addEventListener('pointerleave',()=>{if(!state.drag)sceneCanvas.style.cursor='default';});
    for(const [id,key]of [['mass','mass'],['base','base'],['omega-initial','omega'],['duration','duration']])$(id).addEventListener('input',()=>{state.sim.p[key]=Number($(id).value);restart();});
    $('torque').addEventListener('input',()=>{state.sim.setTorque(Number($('torque').value));updateVectorScale();render();});
    $('zero-torque').addEventListener('click',()=>{state.sim.setTorque(0);updateVectorScale();render();});
    $('contract').addEventListener('click',()=>{endMassDrag();if(state.sim.x.t>=state.sim.p.duration-1e-9)restart();state.sim.moveTo(RotationModels.minRadius);if(!state.playing)play();render();});
    $('expand').addEventListener('click',()=>{endMassDrag();if(state.sim.x.t>=state.sim.p.duration-1e-9)restart();state.sim.moveTo(RotationModels.maxRadius);if(!state.playing)play();render();});
    $('play').addEventListener('click',()=>{if(state.playing){pause();render();}else play();});
    $('restart').addEventListener('click',restart);$('reset').addEventListener('click',()=>configure(state.sim.model));
    for(const id of ['show-l','show-v','show-radius','chart-select'])$(id).addEventListener('change',()=>render());
    const seek=t=>{endMassDrag();pause();state.sim.seek(t);updateVectorScale();render();},plot=$('history');
    const seekPointer=event=>{const r=plot.getBoundingClientRect(),g=chartGeometry(r.width,r.height);seek((event.clientX-r.left-g.left)/(g.right-g.left)*state.sim.p.duration);};
    plot.addEventListener('pointerdown',event=>{if(event.button!==undefined&&event.button!==0)return;plot.setPointerCapture(event.pointerId);seekPointer(event);});
    plot.addEventListener('pointermove',event=>{if(plot.hasPointerCapture(event.pointerId))seekPointer(event);});
    for(const type of ['pointerup','pointercancel'])plot.addEventListener(type,event=>{if(plot.hasPointerCapture(event.pointerId))plot.releasePointerCapture(event.pointerId);});
    plot.addEventListener('keydown',event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();seek(event.key==='Home'?0:event.key==='End'?state.sim.end:state.sim.x.t+(event.key==='ArrowLeft'?-.1:.1)*(event.shiftKey?10:1));}});
    document.addEventListener('keydown',event=>{if(event.target.closest('input,select,button,[role="slider"]')||event.ctrlKey||event.metaKey||event.altKey)return;if(event.code==='Space'){event.preventDefault();$('play').click();}if(event.key.toLowerCase()==='r')restart();});
    document.addEventListener('visibilitychange',()=>{if(document.hidden){endMassDrag();pause();render();}});
    new ResizeObserver(()=>render()).observe($('scene'));syncControls();render();$('loading').hidden=true;
  }catch(error){$('loading').hidden=false;$('loading').textContent='L’animation n’a pas pu démarrer. '+error.message;console.error(error);}
}
