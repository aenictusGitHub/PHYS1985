# Moment cinétique — PHYS1985

Ouvrir `index.html`. L’application est autonome : MathJax et le thème PHYS1985
sont fournis localement. Les vidéos « Ivariable », « Tabouret tournant » et
« Universe_4min11s » servent de références pédagogiques ; elles ne sont pas
redistribuées et les schémas sont calculés dans l’application.

Le relief des masses et de la coquille sphérique reprend celui de Collisions :
dégradé radial bleu ou vert clair, reflet supérieur gauche et ombre discrète.
Le maillage de la coquille reste visible. Ce rendu ne modifie ni les modèles
d’inertie, ni les dimensions, ni les commandes de déplacement en direct.

## Modèles

Trois systèmes tournent autour de l’axe fixe Oz, sans frottement :

- Un point matériel dans le plan z = 0 : I_z = m r².
- Un tabouret et un corps d’inertie fixe I_0, avec deux haltères ponctuels de
  même masse m, placés symétriquement : I_z = I_0 + 2 m r². Les bras sont
  idéalisés sans masse ; le disque central symbolise l’inertie fixe et ne
  représente pas la morphologie d’une personne.
- Une coquille sphérique mince et uniforme : I_z = (2/3) m r². C’est une
  idéalisation à masse constante de la structure rétractable de la vidéo,
  pas un calcul exact de son assemblage de tiges.

Pour ces géométries, L_z = I_z omega et le vecteur L_O est parallèle à Oz.
Ce parallélisme n’est pas généralisé à un solide quelconque : seule la relation
sur la composante axiale vaut en général pour une rotation autour d’un axe fixe.
Le moment extérieur règle dL_z/dt = tau_z. Le rayon peut varier sans modifier
directement L_z ; en l’absence de moment extérieur, la rotation accélère lorsque
l’inertie diminue. L’axe ne se déplace pas et les affichages ne recadrent pas la scène.

Le rayon est imposé (curseur direct ou transition douce de deux secondes).
Les flèches de vitesse représentent uniquement la composante tangentielle
v_theta = r omega. Pendant une contraction, elles ne représentent donc pas la
vitesse totale, qui possède aussi une composante radiale. L’énergie affichée
K_rot = L_z²/(2 I_z) est celle de la rotation seule. Sa variation à moment nul
correspond à un travail interne ; ni le mouvement radial, ni l’énergie interne
du mécanisme de contraction ne sont simulés.

Références :

- https://openstax.org/books/university-physics-volume-1/pages/11-2-angular-momentum
- https://openstax.org/books/university-physics-volume-1/pages/11-3-conservation-of-angular-momentum
- https://www.phys.ufl.edu/~mitselmakher/PHY2053_S08_ppt/PHY2053_S08_ppt/chapter8_PC-V4.pdf

## Commandes

Avant la lecture, le curseur radial fixe la distance initiale à vitesse angulaire
initiale inchangée. Pendant la lecture ou en pause après le démarrage, ce curseur
fait varier l’inertie en conservant instantanément L_z. Un second curseur sous
la scène affiche la distance entre les haltères d = 2r (ou le rayon r pour les
autres modèles). Les deux curseurs sont synchronisés. Faire glisser une masse
sur la scène change également le rayon sans arrêter la rotation, sans déplacer
l’axe ni modifier l’angle ; la perspective est prise en compte. Les haltères
restent symétriques. Le point bleu de la sphère permet de régler son rayon.
Les gestes sont bornés et fonctionnent à la souris ou au toucher ; les curseurs
restent utilisables au clavier. « Rapprocher » et « Éloigner » lancent une transition lisse,
en commençant ou en reprenant la lecture. Masse, inertie fixe, vitesse angulaire
initiale et durée recommencent l’expérience ; le moment extérieur se modifie en
direct. « Recommencer » restaure les paramètres initiaux de l’expérience, et
« Réinitialiser » ceux du modèle choisi.

Le graphique propose L_z, omega ou I_z, chacun avec son unité et un axe propre.
Il conserve toute l’histoire depuis l’instant initial. Un clic, un glissement,
les flèches du clavier ou Début/Fin permettent de revoir les instants déjà
calculés. Reprendre ou modifier la configuration dans le passé crée une nouvelle
suite à partir de cet instant. Aucun mouvement ne démarre sans une action de
l’utilisateur. La lecture s’arrête à la durée choisie et lorsque la page est masquée.

Les flèches de L_O et de vitesse utilisent des échelles indépendantes et linéaires.
Ces échelles sont fixées pour le moment extérieur choisi, et recalculées lorsqu’il
change pour tenir compte du moment cinétique déjà acquis. Elles ne déplacent ni
l’axe ni les corps. Les pointes sont à l’extrémité des vecteurs.

## Calcul et vérification

L_z et l’impulsion angulaire intègrent exactement chaque segment de moment
constant. L’angle est intégré au point milieu, avec des sous-pas d’au plus 1/120 s.
La loi radiale est un smoothstep cubique ; aucune renormalisation de L_z ou de
l’énergie n’est utilisée. Le bilan L_z - L_z(0) - intégrale(tau_z dt) est affiché
à zéro sous 10^-7 kg m²/s. Les nombres et unités LaTeX partagent une seule ligne
de base SVG, et les décimales utilisent un point.

Reconstruction depuis le dépôt :
`python3 tools/build_apps.py --app moment_cinetique_webapp_fr`.

Tests : `node tools/check_angular.cjs`. Ils vérifient inerties, conservation,
contraction, énergie, couple et inversion, convergence de l’angle, horloges de
60 secondes, histoire complète, reprise dans le passé, commandes, glissement
des masses pendant la lecture, synchronisation des distances, nettoyage des
captures de pointeur et bornes des vecteurs. Pour tester aussi les formules avec MathJax réel, définir
`PHYS1985_MATHJAX_ROOT` vers le dossier `js` de mathjax-full.
