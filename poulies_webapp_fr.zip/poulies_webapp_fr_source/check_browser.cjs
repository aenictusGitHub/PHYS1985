'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{pathToFileURL}=require('node:url');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'/Users/jmartin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const near=(a,b,tol=1e-7)=>assert(Math.abs(a-b)<tol*Math.max(1,Math.abs(a),Math.abs(b)),a+' != '+b);
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROME_PATH||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
 try{
  const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  await page.addInitScript(()=>Object.defineProperty(document,'modelContext',{value:{registerTool(tool){(window.__pulleyTools??={})[tool.name]=tool;}}}));
  await page.goto(process.env.PULLEY_APP_URL||pathToFileURL(path.join(__dirname,'index.html')).href);
  await page.waitForFunction(()=>document.getElementById('loading').hidden);
  const read=()=>page.evaluate(()=>window.__pulleyTools.read_pulley_experiment.execute({}));
  const configure=p=>page.evaluate(p=>window.__pulleyTools.configure_pulley_experiment.execute(p),p);
  const seek=t=>page.evaluate(time=>window.__pulleyTools.control_pulley_experiment.execute({action:'seek',time}),t);
  const input=(id,value)=>page.locator('#'+id).evaluate((el,value)=>{el.value=value;el.dispatchEvent(new Event('input',{bubbles:true}));},String(value));
  assert.equal((await read()).parameters.mode,'prescribed');
  // The Atwood teaching preset makes rotation visible without changing the
  // common scale of the energy contributions or overwriting later edits.
  for(const width of [1440,390]){
   await page.setViewportSize({width,height:1000});await page.locator('#reset').click();
   await page.selectOption('#model','atwood');const p=(await read()).parameters;
   near(p.mass,1);near(p.mass2,3);near(p.pulleyMass,8);assert(p.inertia);near(p.height,20);
   assert(await page.locator('#inertia').isChecked());assert(await page.locator('#pulley-mass-control').isVisible());
   for(const key of ['mass','mass2','pulleyMass'])near(Number(await page.locator('#'+key).inputValue()),p[key]);
   for(const fraction of [.5,.75,1]){
    await seek((await read()).state.duration*fraction);const s=(await read()).state;
    near(s.rotation/s.kinetic,.5);near(s.totalEnergy,0);
    near(await page.locator('#atwood-krot-bar').evaluate(el=>parseFloat(el.style.height)),50*fraction*fraction/(3*1.08),1e-5);
    if(fraction===1)assert((await page.locator('#atwood-krot-bar').boundingBox()).height>30);
   }
   if(process.env.QA_OUTPUT)await page.locator('#atwood-energy').screenshot({path:path.join(process.env.QA_OUTPUT,`atwood-default-energy-${width}.png`)});
   await input('mass',2);await input('pulleyMass',6);await page.locator('#restart').click();
   near((await read()).parameters.mass,2);near((await read()).parameters.pulleyMass,6);
   await page.locator('#inertia').uncheck();await seek(1);near((await read()).state.rotation,0);
   await page.selectOption('#model','fixed');
   await configure({model:'atwood',mass:10,mass2:16,inertia:false,pulleyMass:2});
   const explicit=(await read()).parameters;near(explicit.mass,10);near(explicit.mass2,16);near(explicit.pulleyMass,2);assert(!explicit.inertia);
  }
  await page.locator('#reset').click();
  // Reproduce the reported mismatch: selecting "Vitesses" during prescribed
  // motion must show speeds, not the displacement chart as a fallback.
  for(const width of [1440,390])for(const mode of ['prescribed','dynamic','prescribed']){
   await page.setViewportSize({width,height:1000});
   await configure({model:'tackle',pairs:2,mode,height:.5,mass:10,speed:.25,effort:1.25});
   await seek((await read()).state.duration*.5);const before=await read();
   assert(await page.locator('#chart').evaluate(el=>[...el.options].every(option=>!option.hidden&&!option.disabled)));
   for(const [chart,title,unit]of [['distance','Déplacements',String.raw`\mathrm m`],['work','Travail',String.raw`\mathrm J`],['velocity','Vitesses',String.raw`\mathrm{m\,s^{-1}}`],['acceleration','Accélérations',String.raw`\mathrm{m\,s^{-2}}`]]){
    await page.selectOption('#chart',chart);assert((await page.locator('#chart-title').innerText()).startsWith(title));
    assert((await page.locator('#history-labels [data-label-key="unit"]').getAttribute('data-math')).includes(unit));
    assert.deepEqual(await read(),before);assert.equal(await page.locator('[data-mml-node="merror"]').count(),0);
    const expected=chart==='velocity'?(mode==='prescribed'?['u','v']:['v','u']):chart==='acceleration'?(mode==='prescribed'?[String.raw`a_{\mathrm{corde}}`,'a']:['a',String.raw`a_{\mathrm{corde}}`]):null;
    if(expected)assert.deepEqual(await page.locator('#chart-key [data-math]').evaluateAll(els=>els.map(el=>el.dataset.math)),expected);
    if(process.env.QA_OUTPUT&&mode==='prescribed'&&['velocity','acceleration'].includes(chart))await page.locator('#history-card').screenshot({path:path.join(process.env.QA_OUTPUT,`prescribed-${chart}-${width}.png`)});
   }
  }
  await page.setViewportSize({width:1440,height:1000});await page.selectOption('#chart','distance');await page.locator('#reset').click();
  // Explanations sit next to the pulleys, never over the drawing.
  for(const width of [1440,1200,900,390]){
   await page.setViewportSize({width,height:1000});
   for(const model of ['fixed','mobile','tackle'])for(const pairs of [1,4]){
    await configure({model,pairs,mode:'prescribed'});await seek((await read()).state.duration*.45);
    const scene=await page.locator('.motion-card').boundingBox(),panel=await page.locator('#insight-panel').boundingBox(),chart=await page.locator('#history-card').boundingBox(),readouts=await page.locator('.readout-panel').boundingBox();
    if(width>=1200){assert(panel.x>=scene.x+scene.width);near(panel.y,scene.y);}else assert(panel.y>=scene.y+scene.height);
    near(chart.x,panel.x);near(chart.width,panel.width);assert(chart.y>=panel.y+panel.height);assert(chart.y-panel.y-panel.height<20);
    assert(readouts.y>=chart.y+chart.height);
    const n=(await read()).state.n;
    assert.equal(await page.locator('#insight-title').innerText(),n===1?'Changer le sens de l’effort':'Diviser l’effort par '+n);
    near(await page.locator('#force-bar').evaluate(el=>parseFloat(el.style.width)),100/n,1e-5);
    assert.equal(await page.locator('#force-comparison').isVisible(),true);
    assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));
    assert.equal(await page.locator('[data-mml-node="merror"]').count(),0);
    const clipped=await page.locator('#history-labels').evaluate(layer=>{
     const bounds=layer.getBoundingClientRect();return [...layer.children].filter(el=>!el.hidden).filter(el=>{const r=el.getBoundingClientRect();return r.left<bounds.left-1||r.right>bounds.right+1||r.top<bounds.top-1||r.bottom>bounds.bottom+1;}).map(el=>el.dataset.labelKey);
    });assert.deepEqual(clipped,[],JSON.stringify({width,model,pairs,clipped}));
    const history=await page.locator('#history').boundingBox(),duration=(await read()).state.duration;
    await page.locator('#history').click({position:{x:68+(history.width-93)*.7,y:100}});
    assert(Math.abs((await read()).state.t-.7*duration)<.005*duration);
    await page.locator('#history').press('Home');near((await read()).state.t,0);
    await page.selectOption('#chart','work');assert.equal(await page.locator('#chart-title').innerText(),'Travail et énergie gagnée');
    await page.selectOption('#chart','distance');await seek(duration*.45);
    if(process.env.QA_OUTPUT&&pairs===4&&model==='tackle')await page.locator('#scene-layout').screenshot({path:path.join(process.env.QA_OUTPUT,`pulley-explanation-${width}.png`)});
   }
  }
  await page.setViewportSize({width:1440,height:1000});
  await page.locator('#reset').click();
  await page.selectOption('#mode','dynamic');assert(await page.locator('#effort-control').isVisible());
  assert(!(await page.locator('#speed-control').isVisible()));near((await read()).state.acceleration,2.4525);
  await page.locator('#balance-force').click();near((await read()).state.acceleration,0);
  await page.locator('#play').click();await page.waitForTimeout(180);await page.locator('#play').click();assert((await read()).state.t>0);near((await read()).state.height,0);
  await input('effort',.5*(await read()).state.threshold);assert(!(await read()).playing);near((await read()).state.t,0);assert((await read()).state.acceleration<0);
  const imposedForce=(await read()).state.force;
  await page.locator('#inertia').check();near((await read()).state.force,imposedForce);assert((await read()).parameters.inertia);assert(await page.locator('#pulley-mass-control').isVisible());
  const labelIssues=[];
  for(const width of [1440,390]){
   await page.setViewportSize({width,height:1000});
   for(const model of ['fixed','mobile','tackle','atwood'])for(const effort of [.5,1,1.25]){
    await configure({model,mode:'dynamic',inertia:true,effort,pairs:2,height:model==='atwood'?20:1,mass:10,mass2:16});
    const duration=(await read()).state.duration;
    for(const fraction of [0,.5,1]){
     await seek(duration*fraction);const state=(await read()).state;near(state.balance,0);
     const issues=await page.locator('#scene-labels').evaluate(layer=>{
      const bounds=layer.getBoundingClientRect(),els=[...layer.children].filter(el=>!el.hidden).map(el=>({key:el.dataset.labelKey,r:el.getBoundingClientRect()})),issues=[];
      for(const {key,r}of els)if(r.left<bounds.left||r.right>bounds.right||r.top<bounds.top||r.bottom>bounds.bottom)issues.push('clipped '+key);
      for(let i=0;i<els.length;i++)for(let j=i+1;j<els.length;j++){const a=els[i],b=els[j];if(a.r.left<b.r.right&&a.r.right>b.r.left&&a.r.top<b.r.bottom&&a.r.bottom>b.r.top)issues.push(a.key+' overlaps '+b.key);}
      return issues;
     });
     labelIssues.push(...issues.map(issue=>({width,model,effort,fraction,issue})));
    }
    for(const chart of ['distance','velocity','acceleration','work']){
     await page.selectOption('#chart',chart);
     assert(await page.locator('#history-labels [data-number]').evaluateAll(els=>els.some(el=>!el.hidden&&el.dataset.labelKey.startsWith('y')&&Number(el.dataset.number.split('|')[0])===0)));
     assert.equal(await page.locator('[data-mml-node="merror"]').count(),0);
    }
    assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));
   }
  }
  console.log('Scene label checks:',JSON.stringify(labelIssues));assert.deepEqual(labelIssues,[]);
  await page.setViewportSize({width:1440,height:1000});
  for(const model of ['tackle','atwood']){
   await configure({model,mode:'dynamic',inertia:true,mass:10,mass2:16,effort:1.25,pairs:2});
   await seek((await read()).state.duration*.7);await page.selectOption('#chart','work');
   if(process.env.QA_OUTPUT){await page.locator('.visualization-panel').screenshot({path:path.join(process.env.QA_OUTPUT,'poulies-'+model+'.png')});await page.locator('#scene').screenshot({path:path.join(process.env.QA_OUTPUT,'poulies-scene-'+model+'.png')});await page.locator('#history').screenshot({path:path.join(process.env.QA_OUTPUT,'poulies-chart-'+model+'.png')});}
  }
  await page.selectOption('#model','atwood');assert(await page.locator('#mode').isDisabled());assert(!(await page.locator('#effort-control').isVisible()));
  near((await read()).parameters.height,20);assert(await page.locator('#height').isDisabled());assert(!(await page.locator('#height-control').isVisible()));assert(await page.locator('#atwood-course-note').isVisible());
  assert.equal(await page.locator('#inertia-label').innerText(),'Inertie de la poulie');
  assert((await page.locator('#pulley-mass-label').innerText()).startsWith('Masse de la poulie'));
  assert((await page.locator('#inertia-note').innerText()).includes('Une seule poulie fixe'));assert(!(await page.locator('#inertia-note').innerText()).includes('soulevée'));
  assert.equal(await page.locator('#inertia-equation mjx-container svg').count(),1);
  await page.locator('#history').press('End');assert(Math.abs((await read()).state.height)>19.999);
  const checkEnergy=async()=>{
   const s=(await read()).state;
   let positive=0,negative=0,scale=null;
   for(const [id,key]of [['k1','kinetic1'],['k2','kinetic2'],['krot','rotation'],['u1','potential1'],['u2','potential2']]){
    near(Number((await page.locator('#atwood-'+id).getAttribute('data-number')).split('|')[0]),Number(s[key].toFixed(2)));
    near(Number(await page.locator('#atwood-'+id+'-bar').getAttribute('data-energy')),s[key]);
    const bar=await page.locator('#atwood-'+id+'-bar').evaluate(el=>({top:parseFloat(el.style.top),height:parseFloat(el.style.height)}));
    assert(bar.top>=0&&bar.top+bar.height<=100+1e-7);
    // CSS percentages are serialized with fewer digits than JS numbers.
    if(s[key]>=0){near(bar.top+bar.height,50-positive,1e-5);positive+=bar.height;}else{near(bar.top,50+negative,1e-5);negative+=bar.height;}
    if(Math.abs(s[key])>1e-10){if(scale===null)scale=bar.height/Math.abs(s[key]);else near(scale,bar.height/Math.abs(s[key]),1e-5);}
   }
   near(positive,negative,1e-5); // E = 0 with the selected potential origins.
   near(Number((await page.locator('#atwood-e').getAttribute('data-number')).split('|')[0]),0);
  };
  for(const width of [1440,900,390]){
   await page.setViewportSize({width,height:1000});await page.waitForTimeout(100);
   const scene=await page.locator('.motion-card').boundingBox(),panel=await page.locator('#atwood-energy').boundingBox();
   if(width===1440)assert(panel.x>=scene.x+scene.width-1);else assert(panel.y>=scene.y+scene.height-1);
   assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));
   assert.equal(await page.locator('#atwood-energy-title').innerText(),'Répartition instantanée');
   assert.equal(await page.locator('#atwood-energy-stack .energy-segment').count(),5);
   for(const inertia of [false,true])for(const mass2 of [5,10,16]){
    await configure({model:'atwood',inertia,mass2});
    for(const fraction of [0,.5,1]){await seek((await read()).state.duration*fraction);await checkEnergy();}
   }
   if(process.env.QA_OUTPUT)await page.locator('#scene-layout').screenshot({path:path.join(process.env.QA_OUTPUT,'atwood-energy-'+width+'.png')});
  }
  await page.setViewportSize({width:1440,height:1000});
  await page.selectOption('#model','fixed');near((await read()).parameters.height,5);assert.equal(await page.locator('#height').getAttribute('max'),'20');assert(await page.locator('#height-control').isVisible());assert(!(await page.locator('#atwood-energy').isVisible()));
  await page.selectOption('#model','atwood');near((await read()).parameters.height,20);
  await input('mass2',1);near((await read()).state.acceleration,0);await input('mass',3);assert((await read()).state.acceleration<0);
  await input('mass2',16);await page.locator('#play').click();await page.waitForFunction(()=>document.getElementById('play').textContent==='Lire');
  assert((await read()).state.done);await page.locator('#history').press('Home');near((await read()).state.t,0);
  await page.locator('#play').click();await page.waitForTimeout(150);await page.locator('#play').click();assert((await read()).state.t>0);
  await page.locator('#restart').click();near((await read()).state.t,0);assert(!(await read()).playing);await checkEnergy();
  await page.locator('#reset').click();assert.equal((await read()).parameters.mode,'prescribed');assert(await page.locator('#speed-control').isVisible());
  await input('pull',1);near((await read()).state.height,.25);near((await read()).state.work,(await read()).state.potential);
  // The fixed pulley has its own longer course, in both experience modes.
  await page.selectOption('#model','fixed');near((await read()).parameters.height,5);near((await read()).state.duration,20);
  await input('height',20);near((await read()).parameters.height,20);near((await read()).state.duration,80);
  await page.selectOption('#model','mobile');near((await read()).parameters.height,.5);assert.equal(await page.locator('#height').getAttribute('max'),'1');
  await page.selectOption('#model','fixed');near((await read()).parameters.height,5);
  for(const width of [1440,390]){
   await page.setViewportSize({width,height:1000});
   for(const mode of ['prescribed','dynamic'])for(const height of [5,20])for(const effort of [.5,1.25]){
    await configure({model:'fixed',mode,height,effort,inertia:true,mass:10,pulleyMass:2,speed:.25});
    const duration=(await read()).state.duration;
    for(let frame=0;frame<=20;frame++){
     await seek(duration*frame/20);near((await read()).state.balance,0);
     const issues=await page.locator('#scene-labels').evaluate(layer=>{
      const bounds=layer.getBoundingClientRect(),els=[...layer.children].filter(el=>!el.hidden).map(el=>({key:el.dataset.labelKey,r:el.getBoundingClientRect()})),issues=[];
      for(const {key,r}of els)if(r.left<bounds.left||r.right>bounds.right||r.top<bounds.top||r.bottom>bounds.bottom)issues.push('clipped '+key);
      for(let i=0;i<els.length;i++)for(let j=i+1;j<els.length;j++){const a=els[i],b=els[j];if(a.r.left<b.r.right&&a.r.right>b.r.left&&a.r.top<b.r.bottom&&a.r.bottom>b.r.top)issues.push(a.key+' overlaps '+b.key);}
      return issues;
     });
     assert.deepEqual(issues,[],JSON.stringify({width,mode,height,effort,frame,issues}));
    }
    if(mode==='prescribed')near((await read()).state.pull,height);else near(Math.abs((await read()).state.height),height);
    if(process.env.QA_OUTPUT&&height===5&&effort===1.25){
     await page.locator('#scene-layout').screenshot({path:path.join(process.env.QA_OUTPUT,`fixed-${mode}-${width}-end.png`)});
     await seek(0);await page.locator('#scene-layout').screenshot({path:path.join(process.env.QA_OUTPUT,`fixed-${mode}-${width}-start.png`)});
    }
   }
  }
  await page.locator('#reset').click();assert.equal((await read()).parameters.model,'tackle');near((await read()).parameters.height,.5);
  assert.deepEqual(errors,[]);
  console.log('PASS browser: dynamic controls, signed motion, Atwood, inertia, graphs/zero ticks, MathJax, mobile, playback/seek/restart and prescribed regression.');
 }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
