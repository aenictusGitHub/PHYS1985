/* Node controller adapter, not browser visual QA. Supports real MathJax metrics. */
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'index.html'),'utf8'),source=fs.readFileSync(path.join(__dirname,'physics.js'),'utf8')+'\n'+fs.readFileSync(path.join(__dirname,'app.js'),'utf8');
const near=(a,b,tol=1e-8)=>assert(Math.abs(a-b)<tol,`${a} != ${b}`);
let width=700,fontPixels=15,clock=0,frameId=0;const nodes=new Map(),plots=new Map(),frames=new Map(),events={},tools=new Map(),errors=[];
function canvasContext(id){let points=[];const strokes=[],bodies=[];const context=new Proxy({}, {get(target,key){if(key in target)return target[key];return (...args)=>{for(const n of args.flat())if(typeof n==='number')assert(Number.isFinite(n),'finite geometry');if(key==='clearRect'){strokes.length=0;bodies.length=0;}if(key==='beginPath')points=[];if(key==='moveTo'||key==='lineTo')points.push([...args]);if(key==='createLinearGradient')return {type:'linear',args,stops:[],addColorStop(offset,color){this.stops.push([offset,color]);}};if(key==='stroke')strokes.push({points,color:target.strokeStyle,width:target.lineWidth});if(key==='fillRect')bodies.push({rect:args,fill:target.fillStyle});};}});plots.set(id,{context,strokes,bodies});return context;}
class Element{
  constructor(tag='span'){this.tag=tag;this.children=[];this.dataset={};this.style={};this.attrs={};this.events={};this.classList={add(){}};this.value='';this.hidden=false;this.checked=false;}
  set id(id){this._id=id;nodes.set(id,this);}get id(){return this._id;}
  append(...children){this.children.push(...children);}replaceChildren(...children){this.children=children;}
  setAttribute(k,v){this.attrs[k]=String(v);}getAttribute(k){return this.attrs[k];}querySelector(tag){return this.children.find(el=>el.tag===tag);}
  cloneNode(deep){const el=new Element(this.tag);el.attrs={...this.attrs};el.style={...this.style};el.dataset={...this.dataset};if(deep)el.children=this.children.map(c=>c.cloneNode(true));return el;}
  addEventListener(k,fn){this.events[k]=fn;}fire(k,args={}){this.events[k]?.({target:this,preventDefault(){},...args});}click(){this.fire('click');}closest(){return null;}
  setPointerCapture(id){this.capture=id;}hasPointerCapture(id){return this.capture===id;}releasePointerCapture(){this.capture=undefined;}
  getBoundingClientRect(){
    if(this.className?.includes('plot-label')){const first=this.children[0],svg=first?.tag==='svg'?first:first?.querySelector('svg'),factor=fontPixels*.52,w=parseFloat(svg?.getAttribute('width')||'1.131')*factor,h=Math.max(fontPixels*1.4,parseFloat(svg?.getAttribute('height')||'2')*factor),left=parseFloat(this.style.left)-w/2,top=parseFloat(this.style.top)-h/2;return {left,top,right:left+w,bottom:top+h,width:w,height:h};}
    const height=this.id?.startsWith('scene')?Math.max(width<=480?540:560,fontPixels*30):265;return {left:0,top:0,right:width,bottom:height,width,height};
  }
  getContext(){return plots.get(this.id)?.context||canvasContext(this.id);}
}
for(const m of html.matchAll(/<([\w-]+)\b([^>]*\bid="([^"]+)"[^>]*)>/g)){const el=new Element(m[1]);el.id=m[3];el.value=/\bvalue="([^"]*)"/.exec(m[2])?.[1]||'';el.checked=/\bchecked\b/.test(m[2]);}
const $=id=>{assert(nodes.has(id),'missing '+id);return nodes.get(id);};$('model').value='tackle';$('playback').value='1';$('chart').value='distance';
const staticMath=[...html.matchAll(/\bdata-tex="([^"]*)"/g)].map(m=>{const el=new Element();el.dataset.tex=m[1];return el;});
let convertTex;
if(process.env.PHYS1985_MATHJAX_ROOT){
  const root=process.env.PHYS1985_MATHJAX_ROOT,{mathjax}=require(path.join(root,'mathjax.js')),{TeX}=require(path.join(root,'input/tex.js')),{SVG}=require(path.join(root,'output/svg.js')),adaptor=require(path.join(root,'adaptors/liteAdaptor.js')).liteAdaptor();require(path.join(root,'handlers/html.js')).RegisterHTMLHandler(adaptor);require(path.join(root,'input/tex/ams/AmsConfiguration.js'));require(path.join(root,'input/tex/newcommand/NewcommandConfiguration.js'));
  const doc=mathjax.document('',{InputJax:new TeX({packages:['base','ams','newcommand']}),OutputJax:new SVG({fontCache:'none'})});
  function convert(n){const el=new Element(n.kind);for(const {name,value}of adaptor.allAttributes(n))el.setAttribute(name,value);el.append(...adaptor.childNodes(n).filter(c=>c.kind!=='#text').map(convert));return el;}
  convertTex=text=>{const out=doc.convert(text,{display:false});assert(!adaptor.outerHTML(out).includes('data-mml-node="merror"'),'valid TeX: '+text);return convert(out);};
}
function typeset(text){assert(!/[\x00-\x1f]/.test(text));assert(!text.includes('NaN'));if(convertTex)return convertTex(text);const out=new Element('mjx-container'),svg=new Element('svg');svg.setAttribute('viewBox','0 -700 500 722');svg.setAttribute('width','1.131ex');svg.setAttribute('height','1.6ex');svg.append(new Element('g'));out.append(svg);return out;}
const document={readyState:'complete',getElementById:$,createElement:t=>new Element(t),createElementNS:(_,t)=>new Element(t),querySelectorAll:()=>staticMath,addEventListener:(name,fn)=>events[name]=fn,modelContext:{registerTool(tool,options){assert(!tools.has(tool.name));tools.set(tool.name,tool);options.signal.addEventListener('abort',()=>tools.delete(tool.name));}}};
const context={document,window:{devicePixelRatio:1,getComputedStyle:()=>({fontSize:fontPixels+'px'}),addEventListener:(name,fn)=>events[name]=fn},AbortController,console:{error:e=>errors.push(e),warn:e=>errors.push(e)},ResizeObserver:class{observe(){}disconnect(){}},requestAnimationFrame:fn=>{frames.set(++frameId,fn);return frameId;},cancelAnimationFrame:id=>frames.delete(id),MathJax:{startup:{promise:Promise.resolve(),document:{updateDocument(){}}},tex2svg:typeset}};
const value=id=>parseFloat($(id).dataset.number),input=(id,v)=>{$(id).value=v;$(id).fire('input');};
function tick(){clock+=1000/60;const callbacks=[...frames.values()];frames.clear();callbacks.forEach(fn=>fn(clock));}
function advance(seconds){tick();for(let i=0;i<Math.ceil(seconds*60);i++)tick();}
const read=()=>tools.get('read_pulley_experiment').execute({}),configure=p=>tools.get('configure_pulley_experiment').execute(p),control=p=>tools.get('control_pulley_experiment').execute(p);
const body=()=>JSON.stringify(plots.get('scene-canvas').bodies),overlap=(a,b)=>a.left<b.right+1&&a.right>b.left-1&&a.top<b.bottom+1&&a.bottom>b.top-1;
async function main(){
  vm.runInNewContext(source,context);await new Promise(r=>setImmediate(r));assert.deepEqual(errors,[]);assert($('loading').hidden);assert.equal(frames.size,0);assert.equal(tools.size,3);assert.equal(read().parameters.model,'tackle');near(read().state.n,4);
  for(const viewport of [280,700,1000])for(const model of ['fixed','mobile','tackle']){
    width=viewport;$('model').value=model;$('model').fire('change');assert.equal($('pairs-control').hidden,model!=='tackle');near(value('time-value'),0);
    for(const id of ['pairs-value','mass-value','height-value','speed-value','duration-value','force-value','weight-value','work-value','energy-value','time-value','height-now','pull-now','velocity-now']){assert.equal($(id).children.length,1);assert.equal($(id).children[0].tag,'svg');assert(!$(id).dataset.number.split('|')[0].includes(','));for(const g of $(id).children[0].children)assert(/,0\)$/.test(g.getAttribute('transform')));}
    $('play').click();advance(.5);$('play').click();near(read().state.t,.5,.001);near(value('work-value'),value('energy-value'));const before=body(),time=read().state.t;
    for(const id of ['strands','forces','distances']){$(id).checked=!$(id).checked;$(id).fire('change');assert.equal(body(),before);near(read().state.t,time);$(id).checked=!$(id).checked;$(id).fire('change');}
    for(const key of ['work','distance']){$('chart').value=key;$('chart').fire('change');assert.equal(body(),before);const zero=$('history-labels').children.filter(el=>!el.hidden&&el.dataset.labelKey==='y0');assert.equal(zero.length,1);near(parseFloat(zero[0].dataset.number),0);}
    $('history').fire('keydown',{key:'End'});near(read().state.t,read().state.duration);$('history').fire('keydown',{key:'Home'});near(read().state.t,0);
    $('scene').fire('keydown',{key:'ArrowUp'});near(read().state.t,read().state.duration/100);
    $('history').fire('pointerdown',{pointerId:1,clientX:68+(width-93)*.6,button:0});near(read().state.t,read().state.duration*.6);$('history').fire('pointerup',{pointerId:1});assert.equal($('history').capture,undefined);
    input('pull',read().state.n*.5*.25);near(read().state.height,.125);near(value('height-now'),.13);
    // Drag either the free end or the mass, using the same scale as the scene.
    for(const kind of ['handle','load']){
      $('restart').click();const P=require('./physics.js'),g=P.geometry(read().parameters,width,$('scene').getBoundingClientRect().height,0),p=g[kind];
      $('scene').fire('pointerdown',{pointerId:2,clientX:p[0],clientY:p[1],button:0});assert.equal($('scene').capture,2);
      const targetPull=read().state.n*.2,dy=kind==='handle'?g.direction*targetPull*g.scale:-.2*g.scale;
      $('scene').fire('pointermove',{pointerId:2,clientX:p[0],clientY:p[1]+dy});near(read().state.pull,targetPull);near(read().state.height,.2);
      $('scene').fire('pointerup',{pointerId:2});assert.equal($('scene').capture,undefined);assert(!read().playing);
    }
    input('mass',22);near(read().state.t,0);near(read().parameters.mass,22);$('play').click();advance(.1);input('height',.2);assert.equal(frames.size,0);near(read().state.t,0);input('speed',1);$('play').click();advance(2);assert.equal(frames.size,0);near(read().state.t,read().state.duration);assert.equal($('play').textContent,'Lire');$('reset').click();
  }
  // Mathematical captions remain separate and inside the canvas, using actual
  // MathJax metrics when available. This is not a browser screenshot test.
  for(const viewport of [280,700])for(const font of [15,22])for(const model of ['fixed','mobile','tackle'])for(const pairs of [1,4]){
    width=viewport;fontPixels=font;configure({model,pairs,height:1});
    for(const fraction of [0,.1,.35,.6,1]){
      control({action:'seek',time:read().state.duration*fraction});
      const items=$('scene-labels').children.filter(el=>!el.hidden);
      for(const el of items){const r=el.getBoundingClientRect();assert(r.left>=0&&r.right<=width&&r.top>=0&&r.bottom<=$('scene').getBoundingClientRect().height,'label inside: '+el.dataset.labelKey);}
      for(let i=0;i<items.length;i++)for(const other of items.slice(i+1))assert(!overlap(items[i].getBoundingClientRect(),other.getBoundingClientRect()),`separate labels ${model}/${pairs}/${font}/${width}/${fraction}: ${items[i].dataset.labelKey} & ${other.dataset.labelKey}`);
      near(value('work-value'),value('energy-value'));
    }
  }
  configure({model:'tackle',pairs:3,mass:9,height:.5,speed:.5});near(read().state.n,6);const before=JSON.stringify(read());
  for(const invalid of [null,[],{model:'bad'},{mass:0},{pairs:3.1},{g:5},{speed:Infinity},{unknown:1}]){assert.throws(()=>configure(invalid));assert.equal(JSON.stringify(read()),before);}
  for(const invalid of [{action:'wat'},{action:'play',time:1},{action:'seek'},{action:'seek',time:-1},{action:'seek',time:20},{action:'pause',unknown:1}]){assert.throws(()=>control(invalid));assert.equal(JSON.stringify(read()),before);}
  control({action:'play'});advance(.3);assert(read().playing);control({action:'pause'});const time=read().state.t;assert(time>0);control({action:'seek',time:.1});near(read().state.t,.1);control({action:'restart'});near(read().state.t,0);
  for(const viewport of [280,700])for(const model of ['fixed','mobile','tackle'])for(const height of [.2,.5,1])for(const speed of [.05,.25,1])for(const chart of ['distance','work']){
    width=viewport;configure({model,height,speed,mass:1});$('chart').value=chart;$('chart').fire('change');
    for(const axis of ['x','y']){const ticks=$('history-labels').children.filter(el=>!el.hidden&&new RegExp('^'+axis+'[0-9]').test(el.dataset.labelKey));assert.equal(new Set(ticks.map(el=>el.dataset.number)).size,ticks.length,'distinct tick labels');assert(ticks.some(el=>parseFloat(el.dataset.number)===0));}
  }
  events.pagehide();assert.equal(tools.size,0);assert.equal(frames.size,0);assert.deepEqual(errors,[]);
  // A missing or failed optional browser registry must not break the app.
  document.modelContext=undefined;vm.runInNewContext(source,{...context});await new Promise(r=>setImmediate(r));assert($('loading').hidden);assert.deepEqual(errors,[]);events.pagehide();
  document.modelContext={registerTool(){throw new Error('unsupported registry');}};vm.runInNewContext(source,{...context});await new Promise(r=>setImmediate(r));assert($('loading').hidden);assert.equal(errors.length,3);events.pagehide();
  console.log('Poulies : contrôles, glisser, bilan, formules, positions et contrat des outils vérifiés'+(convertTex?' avec MathJax réel.':'.'));
}
main().catch(error=>{console.error(error);process.exit(1);});
