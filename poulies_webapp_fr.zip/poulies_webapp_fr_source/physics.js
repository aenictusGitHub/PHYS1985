/* Ideal pulleys: prescribed slow lifting, massless inextensible rope,
 * massless frictionless pulleys. Starting/stopping inertia is not modelled. */
const PulleyPhysics=(()=>{
  'use strict';
  const models=['fixed','mobile','tackle'];
  const defaults={model:'tackle',pairs:2,mass:10,g:9.81,height:.5,speed:.25};
  function parameters(input={}){
    if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!Object.hasOwn(defaults,k)))throw new Error('Paramètres inconnus.');
    const p={...defaults,...input};
    if(!models.includes(p.model)||!Number.isInteger(p.pairs)||p.pairs<1||p.pairs>4||
      ![p.mass,p.g,p.height,p.speed].every(Number.isFinite)||p.mass<1||p.mass>50||
      p.g<1||p.g>20||p.height<.2||p.height>1||p.speed<.05||p.speed>1)throw new Error('Paramètres hors limites.');
    return p;
  }
  function ratio(p){return p.model==='fixed'?1:p.model==='mobile'?2:2*p.pairs;}
  class Experiment{
    constructor(input={}){this.p=parameters(input);this.t=0;}
    get n(){return ratio(this.p);}
    get duration(){return this.n*this.p.height/this.p.speed;}
    get done(){return this.t>=this.duration-1e-10;}
    at(t=this.t){
      if(!Number.isFinite(t))throw new Error('Instant non valide.');
      t=Math.max(0,Math.min(this.duration,t));
      const p=this.p,n=this.n,pull=Math.min(n*p.height,p.speed*t),height=pull/n,weight=p.mass*p.g,force=weight/n;
      return {t,n,pull,height,weight,force,tension:force,support:n*force,
        work:force*pull,potential:weight*height,balance:force*pull-weight*height,
        loadSpeed:p.speed/n,pullSpeed:p.speed,duration:this.duration,
        done:t>=this.duration-1e-10};
    }
    advance(dt){if(!Number.isFinite(dt)||dt<0)throw new Error('Pas de temps non valide.');this.t=Math.min(this.duration,this.t+dt);return this.at();}
    seek(t){const s=this.at(t);this.t=s.t;return s;}
    setPull(pull){if(!Number.isFinite(pull))throw new Error('Déplacement non valide.');return this.seek(pull/this.p.speed);}
  }
  // Pixel geometry for one continuous rope; geometry changes only with the
  // configuration/viewport, never its visibility toggles or current position.
  function geometry(p,w,h,pull){
    p=parameters(p);
    if(![w,h,pull].every(Number.isFinite)||w<240||h<400)throw new Error('Dimensions non valides.');
    const n=ratio(p),q=Math.max(0,Math.min(n*p.height,pull)),rise=q/n;
    const r=Math.max(9,Math.min(22,(w-100)/(p.model==='tackle'?4*p.pairs+4:8)));
    const top=95,maxPull=n*p.height;
    const scale=Math.min(110,(h-top-2*r-200)/(p.model==='mobile'?maxPull:maxPull+p.height));
    const moving=[],fixed=[],legs=[],arcs=[];
    let load,handle,anchor,bar=null,initialLoad;
    if(p.model==='fixed'){
      const cx=w/2,rise0=top+2*r+65+p.height*scale,y=rise0-rise*scale,free=top+r+40+q*scale;
      fixed.push({x:cx,y:top,angle:rise*scale/r});
      legs.push({a:[cx-r,y],b:[cx-r,top],support:true},{a:[cx+r,top],b:[cx+r,free],support:false});
      arcs.push({x:cx,y:top,r,bottom:false});
      load=[cx-r,y+26];initialLoad=[cx-r,rise0+26];handle=[cx+r,free];anchor=null;
    }else if(p.model==='mobile'){
      const cx=w/2,base=top+2*r+80+maxPull*scale,y=base-rise*scale,free=top+30+maxPull*scale-q*scale;
      moving.push({x:cx,y,angle:-rise*scale/r});
      legs.push({a:[cx-r,top],b:[cx-r,y],support:true},{a:[cx+r,y],b:[cx+r,free],support:true});
      arcs.push({x:cx,y,r,bottom:true});
      anchor=[cx-r,top];load=[cx,y+r+38];initialLoad=[cx,base+r+38];handle=[cx+r,free];
    }else{
      const x0=(w-4*p.pairs*r)/2,base=top+2*r+64+p.height*scale,y=base-rise*scale;
      anchor=[x0,top];
      for(let j=0;j<p.pairs;j++){
        const x=x0+4*j*r;
        moving.push({x:x+r,y,angle:-(2*j+1)*rise*scale/r});
        fixed.push({x:x+3*r,y:top,angle:2*(j+1)*rise*scale/r});
        legs.push({a:[x,top],b:[x,y],support:true},{a:[x+2*r,y],b:[x+2*r,top],support:true});
        arcs.push({x:x+r,y,r,bottom:true},{x:x+3*r,y:top,r,bottom:false});
      }
      handle=[x0+4*p.pairs*r,top+r+40+q*scale];
      legs.push({a:[handle[0],top],b:handle,support:false});
      bar={left:x0+r,right:x0+(4*p.pairs-3)*r,y:y+r+12};
      const cx=(bar.left+bar.right)/2;load=[cx,bar.y+30];initialLoad=[cx,base+r+42];
    }
    const length=legs.reduce((s,l)=>s+Math.hypot(l.b[0]-l.a[0],l.b[1]-l.a[1]),0)+arcs.length*Math.PI*r;
    return {w,h,n,r,top,scale,moving,fixed,legs,arcs,anchor,bar,load,initialLoad,handle,length,direction:p.model==='mobile'?-1:1};
  }
  return {models,defaults,parameters,ratio,Experiment,geometry};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=PulleyPhysics;
