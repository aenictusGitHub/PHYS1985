var physTranslate = globalThis.PhysLang?.t || (value => value);
/* Ideal pulleys: prescribed slow lifting, massless inextensible rope,
 * massless frictionless pulleys. Starting/stopping inertia is not modelled. */
const PulleyPhysics=(()=>{
  'use strict';
  const models=['fixed','mobile','tackle'];
  const allModels=[...models,'atwood'];
  const defaults={model:'tackle',pairs:2,mass:10,g:9.81,height:.5,speed:.25,mode:'prescribed',mass2:16,effort:1.25,inertia:false,pulleyMass:2};
  // I/R² = mp/2 = m1 + m2: rotation receives half of the kinetic energy.
  const atwoodDefaults=Object.freeze({mass:1,mass2:3,inertia:true,pulleyMass:8});
  const ATWOOD_HEIGHT=20,ATWOOD_MAX_HEIGHT=20;
  const FIXED_HEIGHT=5,FIXED_MAX_HEIGHT=20;
  const defaultHeight=model=>model==='atwood'?ATWOOD_HEIGHT:model==='fixed'?FIXED_HEIGHT:defaults.height;
  const maxHeight=model=>model==='atwood'?ATWOOD_MAX_HEIGHT:model==='fixed'?FIXED_MAX_HEIGHT:1;
  function parameters(input={}){
    if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!Object.hasOwn(defaults,k)))throw new Error(physTranslate('Paramètres inconnus.'));
    const p={...defaults,...(input.model==='atwood'?atwoodDefaults:{}),...input};
    if(!Object.hasOwn(input,'height'))p.height=defaultHeight(p.model);
    if(p.model==='atwood'&&p.height!==ATWOOD_HEIGHT)throw new Error(physTranslate('La course de la machine d’Atwood est fixée à 20 m.'));
    if(!allModels.includes(p.model)||!['prescribed','dynamic'].includes(p.mode)||typeof p.inertia!=='boolean'||!Number.isInteger(p.pairs)||p.pairs<1||p.pairs>4||
      ![p.mass,p.g,p.height,p.speed].every(Number.isFinite)||p.mass<1||p.mass>50||
      p.g<1||p.g>20||p.height<.2||p.height>maxHeight(p.model)||p.speed<.05||p.speed>1||
      ![p.mass2,p.effort,p.pulleyMass].every(Number.isFinite)||p.mass2<1||p.mass2>50||p.effort<0||p.effort>2||p.pulleyMass<.1||p.pulleyMass>10)throw new Error(physTranslate('Paramètres hors limites.'));
    return p;
  }
  function ratio(p){return p.model==='fixed'?1:p.model==='mobile'?2:2*p.pairs;}
  class Experiment{
    constructor(input={}){this.p=parameters(input);if(this.p.mode!=='prescribed'||this.p.model==='atwood')throw new Error(physTranslate('Choisissez le modèle dynamique.'));this.t=0;}
    get n(){return ratio(this.p);}
    get duration(){return this.n*this.p.height/this.p.speed;}
    get done(){return this.t>=this.duration-1e-10;}
    at(t=this.t){
      if(!Number.isFinite(t))throw new Error(physTranslate('Instant non valide.'));
      t=Math.max(0,Math.min(this.duration,t));
      const p=this.p,n=this.n,pull=Math.min(n*p.height,p.speed*t),height=pull/n,weight=p.mass*p.g,force=weight/n;
      return {t,n,pull,height,weight,force,tension:force,support:n*force,
        work:force*pull,potential:weight*height,balance:force*pull-weight*height,
        loadSpeed:p.speed/n,pullSpeed:p.speed,duration:this.duration,
        done:t>=this.duration-1e-10};
    }
    advance(dt){if(!Number.isFinite(dt)||dt<0)throw new Error(physTranslate('Pas de temps non valide.'));this.t=Math.min(this.duration,this.t+dt);return this.at();}
    seek(t){const s=this.at(t);this.t=s.t;return s;}
    setPull(pull){if(!Number.isFinite(pull))throw new Error(physTranslate('Déplacement non valide.'));return this.seek(pull/this.p.speed);}
  }
  // Constant-force dynamics from rest. All wheels are homogeneous disks of
  // equal radius R; bearings are frictionless, the rope is taut and no-slip.
  // The rotating equivalent mass I/R² = mp/2 is independent of R. Moving
  // wheel masses also contribute to the lifted weight and translation.
  function dynamicCoefficients(input={}){
    const p=parameters({...parameters(input),mode:'dynamic'}),atwood=p.model==='atwood',n=atwood?1:ratio(p);
    const mp=p.inertia?p.pulleyMass:0,k=p.model==='mobile'?1:p.model==='tackle'?p.pairs:0;
    const coefficients=p.model==='tackle'?Array.from({length:n},(_,i)=>i+1):[1];
    const rotationalMass=.5*mp*coefficients.reduce((sum,c)=>sum+c*c,0);
    const liftedMass=p.mass+k*mp,totalMass=atwood?p.mass+p.mass2:liftedMass;
    const threshold=liftedMass*p.g/n,force=atwood?0:p.effort*threshold;
    const acceleration=(atwood?(p.mass2-p.mass)*p.g:n*force-liftedMass*p.g)/(totalMass+rotationalMass);
    let tensions;
    if(atwood)tensions=[p.mass*(p.g+acceleration),p.mass2*(p.g-acceleration)];
    else{
      tensions=Array(coefficients.length+1).fill(force);
      for(let i=coefficients.length-1;i>=0;i--)tensions[i]=tensions[i+1]-.5*mp*coefficients[i]*acceleration;
    }
    // 0 <= F <= 2 F_eq keeps every rope segment in nonnegative tension,
    // including the massless limiting case F=0 (free fall).
    if(tensions.some(T=>T< -1e-8))throw new Error(physTranslate('La corde ne peut pas pousser : tension négative.'));
    return {p,n,mp,k,coefficients,rotationalMass,liftedMass,totalMass,threshold,force,acceleration,tensions};
  }
  class DynamicExperiment{
    constructor(input={}){Object.assign(this,dynamicCoefficients(input));this.t=0;}
    get duration(){return Math.abs(this.acceleration)<1e-12?10:Math.min(10,Math.sqrt(2*this.p.height/Math.abs(this.acceleration)));}
    get done(){return this.t>=this.duration-1e-10;}
    at(t=this.t){
      if(!Number.isFinite(t))throw new Error(physTranslate('Instant non valide.'));
      t=Math.max(0,Math.min(this.duration,t));
      const p=this.p,a=this.acceleration,v=a*t,height=.5*a*t*t,pull=this.n*height,atwood=p.model==='atwood';
      const work=this.force*pull,potential=(atwood?p.mass-p.mass2:this.liftedMass)*p.g*height;
      const translation=.5*this.totalMass*v*v,rotation=.5*this.rotationalMass*v*v,kinetic=translation+rotation;
      const contributions=atwood?{kinetic1:.5*p.mass*v*v,kinetic2:.5*p.mass2*v*v,potential1:p.mass*p.g*height,potential2:-p.mass2*p.g*height}:{};
      return {t,n:this.n,pull,height,height2:-height,weight:this.liftedMass*p.g,force:this.force,tension:this.tensions[0],tensions:[...this.tensions],
        support:atwood?this.tensions[0]:this.tensions.slice(0,this.n).reduce((sum,T)=>sum+T,0),
        work,potential,translation,rotation,kinetic,totalEnergy:potential+kinetic,balance:work-potential-kinetic,...contributions,
        loadSpeed:v,pullSpeed:this.n*v,acceleration:a,threshold:this.threshold,liftedMass:this.liftedMass,rotationalMass:this.rotationalMass,
        duration:this.duration,done:t>=this.duration-1e-10,travelLimit:Math.abs(height)>=p.height-1e-9};
    }
    advance(dt){if(!Number.isFinite(dt)||dt<0)throw new Error(physTranslate('Pas de temps non valide.'));this.t=Math.min(this.duration,this.t+dt);return this.at();}
    seek(t){const s=this.at(t);this.t=s.t;return s;}
  }
  // Pixel geometry for one continuous rope; geometry changes only with the
  // configuration/viewport, never its visibility toggles or current position.
  function geometry(p,w,h,pull){
    p=parameters(p);
    if(![w,h,pull].every(Number.isFinite)||w<240||h<400)throw new Error(physTranslate('Dimensions non valides.'));
    const n=ratio(p),q=Math.max(0,Math.min(n*p.height,pull)),rise=q/n;
    const r=Math.max(9,Math.min(22,(w-100)/(p.model==='tackle'?4*p.pairs+4:8)));
    const top=95,maxPull=n*p.height;
    // The fixed pulley uses the full safe vertical travel, with a spatial
    // scale chosen before playback. The body and the force arrows stay in view.
    const scale=p.model==='fixed'?(h-108-(top+2*r+65))/p.height:Math.min(110,(h-top-2*r-200)/(p.model==='mobile'?maxPull:maxPull+p.height));
    const moving=[],fixed=[],legs=[],arcs=[];
    let load,handle,anchor,bar=null,initialLoad;
    if(p.model==='fixed'){
      const cx=w/2,rise0=top+2*r+65+p.height*scale,y=rise0-rise*scale,free=top+r+40+q*scale;
      fixed.push({x:cx,y:top,angle:rise*scale/r});
      legs.push({a:[cx-r,y],b:[cx-r,top],support:true},{a:[cx+r,top],b:[cx+r,free],support:false});
      arcs.push({x:cx,y:top,r,bottom:false});
      load=[cx-r,y+26];initialLoad=[cx-r,rise0+26];handle=[cx+r,free];anchor=null;
    }else if(p.model==='mobile'){
      const cx=w/2,base=top+2*r+80+maxPull*scale,y=base-rise*scale,free=top+30+maxPull*scale-q*scale;
      moving.push({x:cx,y,angle:-rise*scale/r});
      legs.push({a:[cx-r,top],b:[cx-r,y],support:true},{a:[cx+r,y],b:[cx+r,free],support:true});
      arcs.push({x:cx,y,r,bottom:true});
      anchor=[cx-r,top];load=[cx,y+r+38];initialLoad=[cx,base+r+38];handle=[cx+r,free];
    }else{
      const x0=(w-4*p.pairs*r)/2,base=top+2*r+64+p.height*scale,y=base-rise*scale;
      anchor=[x0,top];
      for(let j=0;j<p.pairs;j++){
        const x=x0+4*j*r;
        moving.push({x:x+r,y,angle:-(2*j+1)*rise*scale/r});
        fixed.push({x:x+3*r,y:top,angle:2*(j+1)*rise*scale/r});
        legs.push({a:[x,top],b:[x,y],support:true},{a:[x+2*r,y],b:[x+2*r,top],support:true});
        arcs.push({x:x+r,y,r,bottom:true},{x:x+3*r,y:top,r,bottom:false});
      }
      handle=[x0+4*p.pairs*r,top+r+40+q*scale];
      legs.push({a:[handle[0],top],b:handle,support:false});
      bar={left:x0+r,right:x0+(4*p.pairs-3)*r,y:y+r+12};
      const cx=(bar.left+bar.right)/2;load=[cx,bar.y+30];initialLoad=[cx,base+r+42];
    }
    const length=legs.reduce((s,l)=>s+Math.hypot(l.b[0]-l.a[0],l.b[1]-l.a[1]),0)+arcs.length*Math.PI*r;
    return {w,h,n,r,top,scale,moving,fixed,legs,arcs,anchor,bar,load,initialLoad,handle,length,direction:p.model==='mobile'?-1:1};
  }
  function dynamicGeometry(p,w,h,pull){
    p=parameters(p);
    if(p.model==='atwood'){
      if(![w,h,pull].every(Number.isFinite)||w<240||h<400)throw new Error(physTranslate('Dimensions non valides.'));
      // A smaller fixed wheel, with the full available vertical travel used
      // in both directions. One spatial scale is chosen before playback.
      const r=Math.min(38,w*.12),cx=w/2,top=120;
      const upper=top+r+65,lower=h-82,base=(upper+lower)/2;
      const scale=(lower-upper)/(2*p.height);
      const q=Math.max(-p.height,Math.min(p.height,pull)),load=[cx-r,base-q*scale],load2=[cx+r,base+q*scale];
      return {w,h,n:1,r,top,scale,fixed:[{x:cx,y:top,angle:q*scale/r}],moving:[],arcs:[{x:cx,y:top,r,bottom:false}],
        legs:[{a:[cx-r,top],b:[load[0],load[1]-16],support:true},{a:[cx+r,top],b:[load2[0],load2[1]-16],support:true}],
        load,load2,initialLoad:[cx-r,base],initialLoad2:[cx+r,base],handle:null,anchor:null,bar:null,length:2*(base-16-top)+Math.PI*r};
    }
    const n=ratio(p),g=geometry(p,w,h,(n*p.height+pull)/2),initial=geometry(p,w,h,n*p.height/2);
    g.scale/=2;g.initialLoad=initial.load;
    for(const kind of ['fixed','moving'])g[kind].forEach((wheel,i)=>wheel.angle-=initial[kind][i].angle);
    return g;
  }
  return {models,allModels,defaults,atwoodDefaults,ATWOOD_HEIGHT,ATWOOD_MAX_HEIGHT,FIXED_HEIGHT,FIXED_MAX_HEIGHT,defaultHeight,maxHeight,parameters,ratio,Experiment,DynamicExperiment,dynamicCoefficients,geometry,dynamicGeometry};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=PulleyPhysics;
