"""Build the local pulley app, with no network access or publication."""
from pathlib import Path

root = Path(__file__).resolve().parent
html = (root / "index.html").read_text(encoding="utf-8")
for name in ("style.css", "phys1985-theme.css"):
    marker = f'<link rel="stylesheet" href="./{name}" />'
    assert html.count(marker) == 1
    html = html.replace(marker, "<style>\n" + (root / name).read_text(encoding="utf-8") + "\n</style>")
for name in ("vendor/mathjax/tex-svg.js", "physics.js", "app.js"):
    marker = f'<script src="./{name}" defer></script>'
    assert html.count(marker) == 1
    html = html.replace(marker, "<script>\n" + (root / name).read_text(encoding="utf-8") + "\n</script>")
output = root / "poulies_webapp_fr.html"
output.write_text(html, encoding="utf-8")
print(output)
