const assert=require('node:assert/strict'),P=require('./physics.js');
const near=(a,b,e=1e-8)=>assert(Math.abs(a-b)<e,`${a} != ${b}`);
let cases=0;
for(const model of P.models)for(const pairs of [1,2,3,4])for(const mass of [1,10,50])for(const height of [.2,.5,1])for(const speed of [.05,.25,1]){
  const p={model,pairs,mass,height,speed},sim=new P.Experiment(p),n=model==='fixed'?1:model==='mobile'?2:2*pairs;
  near(sim.n,n);near(sim.duration,n*height/speed);
  for(const fraction of [0,.001,.1,.3,.5,.8,1]){
    const s=sim.at(fraction*sim.duration);near(s.force*n,s.weight);near(s.tension,s.force);near(s.pull,n*s.height);near(s.work,s.potential);near(s.balance,0);near(s.loadSpeed*n,s.pullSpeed);
    near(s.height,fraction*height);near(s.pull,fraction*n*height);
    for(const width of [240,280,700,1200])for(const screenHeight of [400,540,560,750]){
      const a=P.geometry(p,width,screenHeight,0),b=P.geometry(p,width,screenHeight,s.pull);
      near(a.length,b.length);near(a.load[1]-b.load[1],s.height*a.scale);near((b.handle[1]-a.handle[1])*b.direction,s.pull*a.scale);near(a.scale,b.scale);near(a.r,b.r);
      assert.equal(b.legs.filter(l=>l.support).length,n);assert.equal(b.moving.length,model==='fixed'?0:model==='mobile'?1:pairs);
      for(const q of [...b.fixed,...b.moving]){assert(q.x>=b.r&&q.x<=width-b.r);assert(q.y>=b.r&&q.y<=screenHeight-b.r);assert(Number.isFinite(q.angle));}
      for(const [x,y]of [b.load,b.handle])assert(x>=8&&x<=width-8&&y>=8&&y<=screenHeight-8,JSON.stringify({p,width,screenHeight,x,y}));
      assert(b.scale>0);assert(b.load[1]+54<=screenHeight,'weight arrow stays visible');
      // Anchored and free ends remain above each movable wheel tangent.
      for(const leg of b.legs)assert(Math.abs(leg.a[1]-leg.b[1])>1);
      cases++;
    }
  }
  sim.seek(sim.duration*.5);sim.advance(sim.duration*2);assert(sim.done);near(sim.t,sim.duration);sim.setPull(-1);near(sim.t,0);sim.setPull(1e5);near(sim.t,sim.duration);
}
for(const p of [null,[],{model:'bad'},{mass:NaN},{mass:51},{pairs:2.5},{height:0},{speed:Infinity},{hello:1}])assert.throws(()=>new P.Experiment(p));
const sim=new P.Experiment();for(const v of [NaN,Infinity,'1']){assert.throws(()=>sim.seek(v));assert.throws(()=>sim.setPull(v));assert.throws(()=>sim.advance(v));near(sim.t,0);}assert.throws(()=>sim.advance(-1));
console.log(`Poulies : ${cases} géométries et bilans vérifiés.`);
