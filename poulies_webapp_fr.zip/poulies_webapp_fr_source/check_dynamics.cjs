const assert=require('node:assert/strict'),P=require('./physics.js');
const near=(a,b,tol=1e-8)=>assert(Math.abs(a-b)<tol*Math.max(1,Math.abs(a),Math.abs(b)),`${a} != ${b}`);
let cases=0;
for(const model of P.allModels)for(const pairs of [1,2,4])for(const mass of [1,10,50])for(const mass2 of [1,16,50])for(const inertia of [false,true])for(const pulleyMass of [.1,2,10])for(const effort of [0,.5,1,1.25,2]){
  const sim=new P.DynamicExperiment({model,pairs,mass,mass2,inertia,pulleyMass,effort}),p=sim.p,mp=inertia?pulleyMass:0;
  assert(sim.duration>0&&sim.duration<=10);assert(sim.tensions.every(T=>T>=-1e-9));
  const s=sim.at(sim.duration),a=s.acceleration;
  near(s.height,.5*a*s.t*s.t);near(s.loadSpeed,a*s.t);near(s.pull,s.n*s.height);assert(Math.abs(s.height)<=p.height+1e-8);
  near(s.work,s.potential+s.kinetic);near(s.kinetic,s.translation+s.rotation);near(s.balance,0);
  if(model==='atwood'){
    near(a,(mass2-mass)*p.g/(mass+mass2+.5*mp));near(s.tensions[0]-mass*p.g,mass*a);near(mass2*p.g-s.tensions[1],mass2*a);
    near(s.tensions[1]-s.tensions[0],.5*mp*a);near(s.work,0);near(s.totalEnergy,0);
    near(s.kinetic1,.5*mass*s.loadSpeed**2);near(s.kinetic2,.5*mass2*s.loadSpeed**2);
    near(s.kinetic1+s.kinetic2,s.translation);near(s.potential1+s.potential2,s.potential);
    near(s.potential1,mass*p.g*s.height);near(s.potential2,mass2*p.g*s.height2);
    near(s.kinetic1+s.kinetic2+s.rotation+s.potential1+s.potential2,0);
    if(!inertia)near(s.rotation,0);
  }else{
    near(s.support-s.weight,sim.liftedMass*a);
    sim.coefficients.forEach((c,i)=>near(s.tensions[i+1]-s.tensions[i],.5*mp*c*a));
    near(s.tensions.at(-1),s.force);
    if(!inertia)near(a,(s.n*s.force-mass*p.g)/mass);
    if(effort===1){near(a,0);near(s.height,0);near(s.kinetic,0);}
  }
  for(const [width,height]of [[280,540],[700,560],[1200,750]]){
    const first=P.dynamicGeometry(p,width,height,0),last=P.dynamicGeometry(p,width,height,s.pull);
    near(first.length,last.length);near(first.scale,last.scale);near(first.r,last.r);assert(first.scale>0);
    near(first.load[1]-last.load[1],s.height*first.scale);
    if(model==='atwood')near(last.load2[1]-first.load2[1],s.height*first.scale);
    else near((last.handle[1]-first.handle[1])*last.direction,s.pull*first.scale);
    for(const point of [last.load,...(last.load2?[last.load2]:[last.handle])])assert(point.every(Number.isFinite)&&point[0]>0&&point[0]<width&&point[1]>16&&point[1]<height-55,JSON.stringify({p,point,width,height}));
  }
  sim.advance(sim.duration/3);const one=sim.at();sim.seek(0);for(let i=0;i<10;i++)sim.advance(sim.duration/30);near(sim.at().height,one.height);
  sim.advance(50);assert(sim.done);sim.seek(0);near(sim.t,0);assert(!sim.done);
  cases++;
}
for(const input of [null,[],{model:'bad'},{mass:0},{mass2:51},{mode:'bad'},{inertia:1},{pulleyMass:0},{effort:-.1},{effort:2.1},{mass:NaN},{what:1}])assert.throws(()=>new P.DynamicExperiment(input));
const e=new P.DynamicExperiment();for(const bad of [NaN,Infinity,'1']){assert.throws(()=>e.at(bad));assert.throws(()=>e.seek(bad));assert.throws(()=>e.advance(bad));}assert.throws(()=>e.advance(-1));
const atwood=new P.DynamicExperiment({model:'atwood'});near(atwood.p.height,20);
assert.equal(atwood.p.inertia,true);near(atwood.p.mass,1);near(atwood.p.mass2,3);near(atwood.p.pulleyMass,8);
for(const fraction of [.25,.5,.75,1]){
 const s=atwood.at(fraction*atwood.duration);
 near(s.rotation/s.kinetic,.5);near(s.rotation/(s.kinetic+s.potential1),1/3);near(s.totalEnergy,0);
}
const explicitAtwood=new P.DynamicExperiment({model:'atwood',mass:10,mass2:16,inertia:false,pulleyMass:2});
near(explicitAtwood.p.mass,10);near(explicitAtwood.p.mass2,16);assert.equal(explicitAtwood.p.inertia,false);near(explicitAtwood.p.pulleyMass,2);near(explicitAtwood.at(1).rotation,0);
for(const model of P.models){const p=P.parameters({model});near(p.mass,10);near(p.pulleyMass,2);assert.equal(p.inertia,false);}
for(const height of [.2,.5,1,5,19.9,20.1])assert.throws(()=>new P.DynamicExperiment({model:'atwood',height}));
for(const height of [20])for(const mass2 of [5,10,16])for(const inertia of [false,true]){
 const sim=new P.DynamicExperiment({model:'atwood',height,mass2,inertia});
 for(const [w,h]of [[240,400],[390,540],[700,560],[1200,750]]){
  const initial=P.dynamicGeometry(sim.p,w,h,0);assert(initial.r<=38);assert.equal(initial.fixed.length,1);assert.equal(initial.moving.length,0);
  for(const q of [-height,0,height]){
   const g=P.dynamicGeometry(sim.p,w,h,q);near(g.length,initial.length);near(g.scale,initial.scale);near(g.fixed[0].angle,q*g.scale/g.r);
   for(const body of [g.load,g.load2]){assert(body[1]>g.top+g.r+60);assert(body[1]+62<h);}
   for(const leg of g.legs)assert(leg.b[1]>leg.a[1]);
  }
  const high=P.dynamicGeometry(sim.p,w,h,height);assert(initial.load[1]-high.load[1]>.8*(h-82-(initial.top+initial.r+65))/2);
 }
 near(sim.at(sim.duration).balance,0);
}
assert.throws(()=>new P.DynamicExperiment({model:'atwood',height:20.1}));assert.throws(()=>new P.DynamicExperiment({model:'fixed',height:20.1}));
near(new P.DynamicExperiment({model:'fixed'}).p.height,5);
for(const height of [.2,5,20])for(const effort of [0,.5,1,1.25,2])for(const inertia of [false,true]){
 const sim=new P.DynamicExperiment({model:'fixed',height,effort,inertia});
 for(const [w,h]of [[240,400],[390,540],[700,560]]){
  const initial=P.dynamicGeometry(sim.p,w,h,0);
  for(const fraction of [0,.25,.5,.75,1]){
   const s=sim.at(fraction*sim.duration),g=P.dynamicGeometry(sim.p,w,h,s.pull);
   near(s.work,s.potential+s.kinetic);near(g.length,initial.length);near(g.scale,initial.scale);near(g.fixed[0].angle,s.pull*g.scale/g.r);
   near(initial.load[1]-g.load[1],s.height*g.scale);near(g.handle[1]-initial.handle[1],s.pull*g.scale);
   assert(g.load[1]+55<h);assert(g.handle[1]+55<h);assert(g.legs.every(l=>Math.abs(l.a[1]-l.b[1])>1));
  }
 }
}
console.log(`PASS: ${cases} dynamic configurations; Newton, pulley torques, work-energy, both directions, equilibrium, taut-rope limits, geometry, replay and seek.`);
