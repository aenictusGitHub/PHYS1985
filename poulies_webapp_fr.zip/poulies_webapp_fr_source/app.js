if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',startPulleyApp);else startPulleyApp();
async function startPulleyApp(){
  'use strict';
  const $=id=>document.getElementById(id),PP=PulleyPhysics,tex=String.raw;
  try{
    await MathJax.startup.promise;
    const C={ink:'#233449',muted:'#607185',grid:'#dce4ec',body:'#2775b6',force:'#268576',rope:'#a77942',tension:'#7758a6',energy:'#b5688b'};
    const names={fixed:'Poulie fixe',mobile:'Poulie mobile',tackle:'Palan',atwood:'Machine d’Atwood'};
    const state={sim:new PP.Experiment(),playing:false,frame:0,last:null,geometry:null,drag:null,legend:'',energyScale:1};
    const labels=new Map(),glyphs=new Map(),units=new Map();
    function math(el,value){if(el.dataset.math===value)return;el.replaceChildren(MathJax.tex2svg(value,{display:false}));el.dataset.math=value;}
    function part(value){const svg=MathJax.tex2svg(value,{display:false}).querySelector('svg'),[x,y,width,height]=svg.getAttribute('viewBox').split(/\s+/).map(Number);return {svg,x,y,width,height,ex:parseFloat(svg.getAttribute('width'))/width};}
    for(const el of document.querySelectorAll('[data-tex]'))math(el,el.dataset.tex);
    for(const c of '0123456789.-')glyphs.set(c,part(c));
    const top0=Math.min(...[...glyphs.values()].map(g=>g.y)),bottom0=Math.max(...[...glyphs.values()].map(g=>g.y+g.height));
    MathJax.startup.document.updateDocument();
    // One SVG baseline for all digits and the unit; no typesetting per frame.
    function number(el,value,digits=2,unit=''){
      if(!Number.isFinite(value))throw new Error('Valeur numérique non finie.');
      const string=(Math.abs(value)<.5*10**-digits?0:value).toFixed(digits),key=string+'|'+unit;if(el.dataset.number===key)return;
      const parts=[...string].map(c=>glyphs.get(c));if(unit){if(!units.has(unit))units.set(unit,part(unit));parts.push(units.get(unit));}
      const svg=parts[0].svg.cloneNode(false),ex=glyphs.get('0').ex;let width=0,top=top0,bottom=bottom0;
      for(const [i,p]of parts.entries()){if(i===string.length)width+=1000/6;const g=document.createElementNS('http://www.w3.org/2000/svg','g');g.setAttribute('transform',`translate(${width-p.x},0)`);g.append(...[...p.svg.children].map(c=>c.cloneNode(true)));svg.append(g);width+=p.width;top=Math.min(top,p.y);bottom=Math.max(bottom,p.y+p.height);}
      svg.setAttribute('viewBox',`0 ${top} ${width} ${bottom-top}`);svg.setAttribute('width',`${width*ex}ex`);svg.setAttribute('height',`${(bottom-top)*ex}ex`);svg.style.verticalAlign=`${-bottom*ex}ex`;svg.setAttribute('role','img');svg.setAttribute('aria-label',string+' '+unit.replace(/\\mathrm|[{}]/g,'').replace(/\\,/g,' '));el.classList.add('number');el.replaceChildren(svg);el.dataset.number=key;
    }
    function pause(){state.playing=false;state.last=null;if(state.frame)cancelAnimationFrame(state.frame);state.frame=0;$('play').textContent='Lire';$('play').setAttribute('aria-pressed','false');}
    const dynamic=()=>state.sim instanceof PP.DynamicExperiment;
    function changedParameters(changes){
      const switching=changes.model!==undefined&&changes.model!==state.sim.p.model;
      const p={...state.sim.p,...(switching&&changes.model==='atwood'?PP.atwoodDefaults:{}),...changes};
      if(switching&&!Object.hasOwn(changes,'height')&&(['atwood','fixed'].includes(p.model)||['atwood','fixed'].includes(state.sim.p.model)))p.height=PP.defaultHeight(p.model);
      return p;
    }
    function configure(p){const next=p.mode==='dynamic'||p.model==='atwood'?new PP.DynamicExperiment(p):new PP.Experiment(p);pause();state.drag=null;state.sim=next;sync();render();}
    function restart(){configure(state.sim.p);}
    function play(){if(state.sim.done)restart();state.playing=true;state.last=null;$('play').textContent='Pause';$('play').setAttribute('aria-pressed','true');if(!state.frame)state.frame=requestAnimationFrame(frame);}
    function seek(t){const s=state.sim.at(t);pause();state.sim.seek(s.t);render();}
    function frame(now){state.frame=0;if(!state.playing)return;if(state.last!==null)state.sim.advance(Math.min(.1,Math.max(0,(now-state.last)/1000))*Number($('playback').value));state.last=now;if(state.sim.done)pause();render();if(state.playing)state.frame=requestAnimationFrame(frame);}
    function sync(){
      const p=state.sim.p,n=state.sim.n,dyn=dynamic(),atwood=p.model==='atwood';
      $('height').max=PP.maxHeight(p.model);$('height').step=atwood||p.model==='fixed'?.1:.05;
      $('height-control').hidden=atwood;$('height').disabled=atwood;$('atwood-course-note').hidden=!atwood;
      $('scene-layout').className='scene-layout'+(atwood?' atwood-layout':'');$('atwood-energy').hidden=!atwood;
      if(atwood){
        const end=state.sim.at(state.sim.duration),values=['kinetic1','kinetic2','rotation','potential1','potential2'].map(key=>end[key]);
        state.energyScale=1.08*Math.max(1,values.reduce((sum,v)=>sum+Math.max(0,v),0),values.reduce((sum,v)=>sum+Math.max(0,-v),0));
      }
      for(const key of ['model','pairs','mass','height','speed','mode','mass2','effort','pulleyMass'])$(key).value=p[key];
      $('pairs-control').hidden=p.model!=='tackle';$('scene-title').textContent=names[p.model];
      $('model-note').textContent=p.model==='fixed'?'La poulie change le sens de la traction. Elle ne réduit pas l’effort nécessaire.':p.model==='mobile'?'La poulie accompagne la charge. Deux brins la soutiennent ; on tire ici l’extrémité libre vers le haut.':'Une seule corde passe alternativement autour des poulies mobiles et fixes. Comptez les brins qui soutiennent le bloc mobile.';
      $('ratio-badge').textContent=n+' brin'+(n>1?'s porteurs':' porteur');
      $('scene-note').textContent='Tirez la poignée '+(p.model==='mobile'?'vers le haut':'vers le bas')+' ou faites monter la charge. Les flèches représentent les forces, pas les vitesses. Les pointillés repèrent les positions initiales.';
      $('insight-title').textContent=n===1?'Changer le sens de l’effort':'Diviser l’effort par '+n;
      $('insight').textContent=n===1?'Pour monter la charge de 1 m, il faut tirer 1 m de corde, avec une force égale au poids.':'Pour monter la charge de 1 m, il faut tirer '+n+' m de corde. L’effort et la vitesse de montée sont divisés par '+n+'.';
      $('force-bar').style.width=(100/n)+'%';$('weight-bar').style.width='100%';
      number($('pairs-value'),p.pairs,0);number($('mass-value'),p.mass,1,tex`\mathrm{kg}`);number($('height-value'),p.height,2,tex`\mathrm m`);number($('speed-value'),p.speed,2,tex`\mathrm{m\,s^{-1}}`);number($('duration-value'),state.sim.duration,2,tex`\mathrm s`);
      $('pull').max=n*p.height;$('scene').setAttribute('aria-valuemax',n*p.height);$('history').setAttribute('aria-valuemax',state.sim.duration);state.legend='';
      $('mode').disabled=atwood;$('mass2-control').hidden=!atwood;$('speed-control').hidden=dyn;$('effort-control').hidden=!dyn||atwood;$('inertia-control').hidden=!dyn;
      $('inertia').checked=p.inertia;$('pulley-mass-control').hidden=!dyn||!p.inertia;
      $('inertia-label').textContent=p.model==='tackle'?'Inertie des poulies':'Inertie de la poulie';
      caption('pulley-mass-label',p.model==='tackle'?'Masse de chaque poulie ':'Masse de la poulie ','m_p');
      $('inertia-note').textContent=p.model==='tackle'?'Disques homogènes de même rayon. La masse des poulies mobiles est aussi soulevée.':p.model==='mobile'?'Une seule poulie mobile, modélisée par un disque homogène. Sa masse est soulevée avec la charge.':'Une seule poulie fixe, modélisée par un disque homogène. Sa masse intervient uniquement dans l’inertie de rotation.';
      for(const id of ['acceleration-readout','kinetic-card','rotation-card','balance-card'])$(id).hidden=!dyn;
      $('force-comparison').hidden=dyn;$('tension-key').hidden=!dyn;
      caption('mass-label',atwood?'Masse gauche ':'Masse soulevée ',atwood?'m_1':'m');
      caption('height-label',dyn?'Course maximale depuis le départ ':'Hauteur à gagner ','H');
      caption('scrub-label',dyn?'Instant ':'Longueur de corde tirée ',dyn?'t':tex`\ell`);
      math($('height-symbol'),atwood?'h_1=':'h=');math($('pull-symbol'),atwood?'h_2=':tex`\ell=`);math($('velocity-symbol'),atwood?'v_1=':'v=');
      math($('force-symbol'),atwood?'T_1':dyn?'F':tex`F=mg/n`);math($('weight-symbol'),atwood?'T_2':dyn?'Mg':'mg');
      math($('energy-symbol'),atwood?tex`\Delta U=(m_1-m_2)gh_1`:dyn?tex`\Delta U=Mgh`:tex`\Delta U=mgh`);
      $('force-caption').textContent=atwood?'tension côté gauche':'effort de traction';$('weight-caption').textContent=atwood?'tension côté droit':dyn?'poids de l’ensemble mobile':'poids de la charge';
      $('mode-note').textContent=dyn?'Lâché sans vitesse. L’accélération et la vitesse résultent des forces ; elles ne sont pas imposées.':'Le moteur impose une vitesse constante. Les phases de démarrage et d’arrêt ne sont pas décrites.';
      $('scrub-note').textContent=dyn?'Le curseur temporel et le graphique permettent de revoir l’expérience. La charge n’est pas déplaçable à la main dans ce mode.':'Déplacez le curseur, la poignée de traction ou la charge pour explorer le mouvement.';
      $('energy-note').textContent=dyn?'Le bilan comprend l’énergie cinétique des masses et, si l’option est activée, la translation des poulies mobiles et la rotation de toutes les poulies.':'La force diminue, mais le travail nécessaire ne diminue pas.';
      $('assumptions').textContent=dyn?'Corde inextensible, sans masse et sans glissement sur les poulies ; axes sans frottement. Forces constantes, départ au repos. La lecture s’arrête à la limite de course ou après 10 s ; aucun choc ni freinage de fin de course n’est simulé. Sans l’option d’inertie, la masse des poulies est nulle. ':'Levage idéal à vitesse constante. Corde inextensible et sans masse ; poulies sans masse ni frottement. Les phases d’accélération au démarrage et à l’arrêt sont négligées. ';
      const gravity=document.createElement('span');math(gravity,tex`g=9.81\,\mathrm{m\,s^{-2}}`);$('assumptions').append(gravity);
      number($('mass2-value'),p.mass2,1,tex`\mathrm{kg}`);number($('pulley-mass-value'),p.pulleyMass,1,tex`\mathrm{kg}`);
      let equations=[tex`T=F,\qquad nT=mg`,tex`F=\frac{mg}{n},\qquad \ell=nh`,tex`u=nv,\qquad F\ell=mgh`];
      if(dyn){
        const s=state.sim.at();$('pull').max=state.sim.duration;$('scene').setAttribute('aria-valuemax',state.sim.duration);$('scene').setAttribute('aria-label','Instant de l’expérience dynamique');
        $('ratio-badge').textContent=atwood?'Deux masses couplées':n+' brins · force imposée';
        $('effort').max=2*s.threshold;$('effort').value=s.force;
        number($('effort-value'),s.force,2,tex`\mathrm N`);math($('threshold-value'),tex`F_{\mathrm{eq}}=`+s.threshold.toFixed(2)+tex`\,\mathrm N`);
        $('effort').setAttribute('aria-valuetext',s.force.toFixed(2)+' N ; '+p.effort.toFixed(2)+' fois la force d’équilibre');
        $('scene-note').textContent=(atwood?'Déplacements positifs vers le haut pour chaque masse. La vitesse et l’accélération affichées concernent la masse gauche.':'Montée positive, descente négative. Les flèches indiquent les forces ; les repères numérotés désignent les tensions.')+' Le cadre et l’échelle restent fixes.';
        $('insight-title').textContent=atwood?'La différence des poids entraîne le mouvement':Math.abs(s.acceleration)<1e-10?'Force d’équilibre : aucun départ du repos':s.acceleration>0?'La charge accélère vers le haut':'La charge accélère vers le bas';
        $('insight').textContent=atwood?'La masse la plus lourde descend et l’autre monte. À masses égales, le système lâché au repos reste immobile. L’inertie de la poulie réduit l’accélération et rend les deux tensions différentes.':'La force d’équilibre compense le poids de l’ensemble mobile. Au-dessus, la charge monte ; en dessous, elle descend. Avec des poulies massives, une partie du travail sert aussi à leur mise en rotation.';
        if(atwood){
          $('model-note').textContent='Deux masses suspendues aux extrémités d’une même corde, passant sur une poulie fixe. Aucun effort de traction extérieur.';
          equations=[tex`a_1=\frac{(m_2-m_1)g}{m_1+m_2+I/R^2},\quad a_2=-a_1`,tex`T_1=m_1(g+a_1),\quad T_2=m_2(g-a_1)`,tex`(T_2-T_1)R=I\alpha,\quad \alpha=a_1/R`,tex`K+\Delta U=0`];
        }else{
          const k=state.sim.k,coeff=state.sim.coefficients;
          equations=[tex`\ell=nh,\quad u=nv,\quad F_{\mathrm{eq}}=Mg/n`,tex`a=\frac{nF-Mg}{M+M_{\mathrm{rot}}}`,tex`M=m+`+k+tex`m_p,\quad M_{\mathrm{rot}}=\sum_j\frac{I_jc_j^2}{R^2}`,tex`\omega_j=c_jv/R,\quad |c_j|\in\{`+coeff.join(',')+tex`\}`,tex`W_{\mathrm{app}}=\Delta U+K_{\mathrm{trans}}+K_{\mathrm{rot}}`];
        }
        $('tension-key').replaceChildren(...s.tensions.map((T,i)=>{const el=document.createElement('span');math(el,'T_{'+(atwood?i+1:i)+'}='+T.toFixed(2)+tex`\,\mathrm N`);return el;}));
      }else $('scene').setAttribute('aria-label','Longueur de corde tirée');
      $('equations').replaceChildren(...equations.map(value=>{const el=document.createElement('p');el.className='equation';math(el,value);return el;}));
    }
    function caption(id,text,value){const span=document.createElement('span');math(span,value);$(id).replaceChildren(document.createTextNode(text),span);}
    function surface(id){const canvas=$(id),r=canvas.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1),ctx=canvas.getContext('2d');if(canvas.width!==Math.round(r.width*dpr)||canvas.height!==Math.round(r.height*dpr)){canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,r.width,r.height);return {ctx,w:r.width,h:r.height};}
    function line(ctx,points,color,width=1,dash=[]){if(!points.length)return;ctx.beginPath();ctx.moveTo(...points[0]);for(const p of points.slice(1))ctx.lineTo(...p);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineCap='round';ctx.lineJoin='round';ctx.setLineDash(dash);ctx.stroke();ctx.setLineDash([]);}
    function circle(ctx,x,y,r,color,stroke=null){ctx.beginPath();ctx.arc(x,y,r,0,2*Math.PI);ctx.fillStyle=color;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1.3;ctx.stroke();}}
    function arrow(ctx,a,b,color,width=2.4){const dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);if(length<1e-8)return;const ux=dx/length,uy=dy/length,head=Math.min(8,length*.4);line(ctx,[a,b],color,width);line(ctx,[[b[0]-head*ux-head*.48*uy,b[1]-head*uy+head*.48*ux],b,[b[0]-head*ux+head*.48*uy,b[1]-head*uy-head*.48*ux]],color,width);}
    function getLabel(layer,key,x,y,color,tick){let el=labels.get(layer+key);if(!el){el=document.createElement('span');$(layer).append(el);labels.set(layer+key,el);}el.hidden=false;el.dataset.labelKey=key;el.className='plot-label'+(tick?' tick':'');el.style.left=x+'px';el.style.top=y+'px';el.style.color=color;return el;}
    function label(layer,key,value,x,y,color=C.ink,tick=false){const el=getLabel(layer,key,x,y,color,tick);math(el,value);return el;}
    function numericLabel(layer,key,value,x,y,digits=0){const el=getLabel(layer,key,x,y,C.muted,true);number(el,value,digits);return el;}
    function wheel(ctx,p,r){
      const fill=ctx.createLinearGradient(p.x-r,p.y-r,p.x+r,p.y+r);fill.addColorStop(0,'#f1f5fa');fill.addColorStop(.5,'#d6e1ed');fill.addColorStop(1,'#9cacc0');circle(ctx,p.x,p.y,r-2,fill,'#718398');
      for(let i=0;i<4;i++){const a=p.angle+i*Math.PI/2;line(ctx,[[p.x+4*Math.cos(a),p.y+4*Math.sin(a)],[p.x+(r-6)*Math.cos(a),p.y+(r-6)*Math.sin(a)]],'#7f92a8',1.5);}
      circle(ctx,p.x,p.y,3,'#607185');
    }
    function drawScene(s){
      if(dynamic()){drawDynamicScene(s);return;}
      const {ctx,w,h}=surface('scene-canvas');if(w<240||h<400)return;
      const g=PP.geometry(state.sim.p,w,h,s.pull);state.geometry=g;const initial=PP.geometry(state.sim.p,w,h,0),font=parseFloat(window.getComputedStyle($('scene-labels')).fontSize)||15;
      const fixedXs=g.fixed.map(p=>p.x),mountXs=[...fixedXs,...(g.anchor?[g.anchor[0]]:[])];
      const left=Math.min(...mountXs)-35,right=Math.max(...mountXs)+35;
      ctx.fillStyle='#e8eef5';ctx.fillRect(left,g.top-30,right-left,10);line(ctx,[[left,g.top-20],[right,g.top-20]],C.muted,2);
      for(let x=left+7;x<right;x+=11)line(ctx,[[x,g.top-29],[x-6,g.top-21]],'#adbccd',1);
      for(const p of g.fixed)line(ctx,[[p.x,g.top-20],[p.x,p.y]],C.muted,3);
      if(g.anchor){line(ctx,[[g.anchor[0],g.top-20],g.anchor],C.muted,3);circle(ctx,...g.anchor,3,C.muted);}
      if($('distances').checked){
        const [x,y]=initial.load;ctx.strokeStyle='#a4b7ca';ctx.lineWidth=1;ctx.setLineDash([4,4]);ctx.strokeRect(x-22,y-16,44,32);ctx.setLineDash([]);
        circle(ctx,...initial.handle,7,'#fbfcfe','#b4c5d2');
        const dimX=Math.max(15,Math.min(...g.legs.map(p=>p.a[0]))*.28);
        line(ctx,[[dimX,initial.load[1]],[x-27,initial.load[1]]],C.grid,1,[3,4]);line(ctx,[[dimX,g.load[1]],[x-27,g.load[1]]],C.grid,1,[3,4]);
        if(s.height*g.scale>18){line(ctx,[[dimX,initial.load[1]],[dimX,g.load[1]]],C.body,1.2);for(const y of [initial.load[1],g.load[1]])line(ctx,[[dimX-4,y],[dimX+4,y]],C.body,1.2);label('scene-labels','rise','h',dimX+11,(g.load[1]+initial.load[1])/2,C.body);}
      }
      for(const p of [...g.fixed,...g.moving])wheel(ctx,p,g.r);
      for(const a of g.arcs){ctx.beginPath();ctx.arc(a.x,a.y,a.r,Math.PI,0,a.bottom);ctx.lineWidth=3;ctx.strokeStyle=C.rope;ctx.stroke();}
      for(const leg of g.legs)line(ctx,[leg.a,leg.b],$('strands').checked&&leg.support?C.tension:C.rope,3);
      if(g.bar){for(const p of g.moving)line(ctx,[[p.x,p.y],[p.x,g.bar.y]],C.muted,3);line(ctx,[[g.bar.left,g.bar.y],[g.bar.right,g.bar.y]],C.muted,4);line(ctx,[[g.load[0],g.bar.y],[g.load[0],g.load[1]-16]],C.muted,3);}
      else line(ctx,[[g.load[0],g.moving.length?g.moving[0].y:g.legs[0].a[1]],[g.load[0],g.load[1]-16]],C.muted,3);
      const [x,y]=g.load,body=ctx.createLinearGradient(x-22,y-16,x+22,y+16);body.addColorStop(0,'#b0d8ed');body.addColorStop(.38,'#6daed4');body.addColorStop(1,'#2775b6');ctx.fillStyle=body;ctx.fillRect(x-22,y-16,44,32);ctx.strokeStyle=C.body;ctx.lineWidth=1.8;ctx.strokeRect(x-22,y-16,44,32);line(ctx,[[x-19,y+13],[x-19,y-13],[x+19,y-13]],'#d4e8f4',1.5);
      for(let i=0;i<12;i++){const dx=-16+(i*13)%33,dy=-9+(i*7)%19;circle(ctx,x+dx,y+dy,.55,'rgba(35,52,73,.19)');}
      label('scene-labels','mass','m',x-37,y,C.body);
      circle(ctx,...g.handle,8,'#eff7f4',C.force);circle(ctx,...g.handle,3,C.force);
      let index=0;
      for(const leg of g.legs.filter(p=>p.support)){
        const x=leg.a[0],lo=Math.min(leg.a[1],leg.b[1]),hi=Math.max(leg.a[1],leg.b[1]),cy=(lo+hi)/2;
        if($('strands').checked){const ny=lo+Math.min(20,(hi-lo)*.18);circle(ctx,x,ny,7,'#fbfcfe');numericLabel('scene-labels','strand'+index,++index,x,ny,0);}
        if($('forces').checked){const length=54/s.n;arrow(ctx,[x,cy+length/2],[x,cy-length/2],C.tension,2.5);}
      }
      if($('forces').checked){
        const leg=g.legs[0],cy=(leg.a[1]+leg.b[1])/2;
        label('scene-labels','tension',tex`\vec T`,leg.a[0]-Math.max(18,font),cy,C.tension);
        arrow(ctx,[x,y],[x,y+54],C.body,2.7);label('scene-labels','weight',tex`m\vec g`,state.sim.p.model==='fixed'?x-37:x+27,y+43,C.body);
        const end=[g.handle[0],g.handle[1]+g.direction*54/s.n];arrow(ctx,g.handle,end,C.force,2.7);
        label('scene-labels','effort',tex`\vec F`,g.handle[0]+Math.max(24,font*1.5),(g.handle[1]+end[1])/2,C.force);
      }
      $('scene').style.cursor=state.drag?'grabbing':'grab';
    }
    function dynamicBody(ctx,x,y,color){
      const fill=ctx.createLinearGradient(x-22,y-16,x+22,y+16);fill.addColorStop(0,color===C.body?'#b7dbee':'#c8e9de');fill.addColorStop(1,color);
      ctx.fillStyle=fill;ctx.fillRect(x-22,y-16,44,32);ctx.strokeStyle=color;ctx.lineWidth=1.6;ctx.strokeRect(x-22,y-16,44,32);
      line(ctx,[[x-19,y+13],[x-19,y-13],[x+19,y-13]],'#e1f0f5',1.4);
      for(let i=0;i<12;i++)circle(ctx,x-16+(i*13)%33,y-9+(i*7)%19,.6,'rgba(35,52,73,.18)');
    }
    function drawDynamicScene(s){
      const {ctx,w,h}=surface('scene-canvas');if(w<240||h<400)return;
      const p=state.sim.p,atwood=p.model==='atwood',g=PP.dynamicGeometry(p,w,h,s.pull),initial=PP.dynamicGeometry(p,w,h,0);state.geometry=g;
      const mounts=[...g.fixed.map(q=>q.x),...(g.anchor?[g.anchor[0]]:[])],left=Math.min(...mounts)-30,right=Math.max(...mounts)+30;
      const mountY=atwood?g.top-g.r-22:g.top-30;
      ctx.fillStyle='#e8eef5';ctx.fillRect(left,mountY,right-left,10);line(ctx,[[left,mountY+10],[right,mountY+10]],C.muted,2);
      for(let x=left+7;x<right;x+=11)line(ctx,[[x,mountY+1],[x-6,mountY+9]],'#adbccd',1);
      for(const q of g.fixed)line(ctx,[[q.x,mountY+10],[q.x,q.y]],C.muted,3);
      if(g.anchor){line(ctx,[[g.anchor[0],g.top-20],g.anchor],C.muted,3);circle(ctx,...g.anchor,3,C.muted);}
      if($('distances').checked){for(const q of [initial.load,...(atwood?[initial.load2]:[])]){ctx.setLineDash([4,4]);ctx.strokeStyle='#b4c5d2';ctx.lineWidth=1;ctx.strokeRect(q[0]-22,q[1]-16,44,32);ctx.setLineDash([]);}}
      for(const q of [...g.fixed,...g.moving])wheel(ctx,q,g.r);
      for(const arc of g.arcs){ctx.beginPath();ctx.arc(arc.x,arc.y,arc.r,Math.PI,0,arc.bottom);ctx.strokeStyle=C.rope;ctx.lineWidth=3;ctx.stroke();}
      for(const leg of g.legs)line(ctx,[leg.a,leg.b],$('strands').checked&&leg.support?C.tension:C.rope,3);
      if(g.bar){for(const q of g.moving)line(ctx,[[q.x,q.y],[q.x,g.bar.y]],C.muted,3);line(ctx,[[g.bar.left,g.bar.y],[g.bar.right,g.bar.y]],C.muted,4);line(ctx,[[g.load[0],g.bar.y],[g.load[0],g.load[1]-16]],C.muted,3);}
      else if(!atwood)line(ctx,[[g.load[0],g.moving.length?g.moving[0].y:g.legs[0].a[1]],[g.load[0],g.load[1]-16]],C.muted,3);
      const maximum=Math.max(s.weight,p.mass2*p.g*(atwood?1:0),s.force,...s.tensions,1),forceScale=55/maximum;
      if(atwood){
        [g.load,g.load2].forEach(([x,y],i)=>{
          const color=i?C.force:C.body,mass=i?p.mass2:p.mass;
          dynamicBody(ctx,x,y,color);label('scene-labels','mass'+i,'m_{'+(i+1)+'}',x+(i?40:-40),y,color);
          if($('forces').checked){
            arrow(ctx,[x-7,y],[x-7,y-s.tensions[i]*forceScale],C.tension,2.8);
            arrow(ctx,[x+7,y],[x+7,y+mass*p.g*forceScale],color,2.8);
            label('scene-labels','tension'+i,tex`\vec T_{`+(i+1)+'}',x+(i?42:-42),y-45,C.tension);
            label('scene-labels','weight'+i,'m_{'+(i+1)+tex`}\vec g`,x+(i?42:-42),y+62,color);
          }
        });
      }else{
        const [x,y]=g.load;dynamicBody(ctx,x,y,C.body);label('scene-labels','mass','m',x-37,y,C.body);
        circle(ctx,...g.handle,8,'#eff7f4',C.force);circle(ctx,...g.handle,3,C.force);
        g.legs.forEach((leg,i)=>{
          const cy=(leg.a[1]+leg.b[1])/2,x=leg.a[0];
          if($('strands').checked){circle(ctx,x,Math.min(leg.a[1],leg.b[1])+17,7,'#fbfcfe');numericLabel('scene-labels','strand'+i,i,x,Math.min(leg.a[1],leg.b[1])+17,0);}
          if($('forces').checked&&leg.support)arrow(ctx,[x,cy+s.tensions[i]*forceScale/2],[x,cy-s.tensions[i]*forceScale/2],C.tension,2.7);
        });
        if($('forces').checked){
          arrow(ctx,[x,y],[x,y+s.weight*forceScale],C.body,2.8);label('scene-labels','weight',tex`M\vec g`,p.model==='fixed'?x-37:x+34,y+44,C.body);
          const end=[g.handle[0],g.handle[1]+g.direction*s.force*forceScale];arrow(ctx,g.handle,end,C.force,2.8);
          label('scene-labels','effort',tex`\vec F`,g.handle[0]+28,(g.handle[1]+end[1])/2,C.force);
        }
      }
      $('scene').style.cursor='default';
      const status=s.done?tex`\text{Fin de l’expérience}`:Math.abs(s.acceleration)<1e-10?tex`\text{Équilibre}`:s.t<1e-10?tex`\text{Départ au repos}`:(atwood?tex`m_1\,`:'')+(s.acceleration>0?tex`\text{monte}`:tex`\text{descend}`);
      label('scene-labels','dynamic-status',status,w-100,30,C.muted,true);
    }
    function legend(){
      const key=$('chart').value,work=key==='work',velocity=key==='velocity',acceleration=key==='acceleration';if(state.legend===key)return;state.legend=key;
      $('chart-title').textContent=work?'Travail et énergie gagnée':velocity?'Vitesses au cours du temps':acceleration?'Accélérations au cours du temps':'Déplacements au cours du temps';
      const specs=work?[[tex`W_{\mathrm{app}}`,C.tension,false],[tex`\Delta U`,C.energy,true]]:velocity?[['u',C.force,false],['v',C.body,true]]:acceleration?[[tex`a_{\mathrm{corde}}`,C.force,false],['a',C.body,true]]:[[tex`\ell`,C.force,false],['h',C.body,true]];
      $('chart-key').replaceChildren(...specs.map(([value,color,dashed])=>{const el=document.createElement('span'),swatch=document.createElement('i'),symbol=document.createElement('span');swatch.style.borderColor=color;swatch.style.borderTopStyle=dashed?'dashed':'solid';math(symbol,value);el.append(swatch,symbol);return el;}));
      $('chart-note').textContent=work?'Les deux courbes se superposent : le travail fourni devient de l’énergie potentielle. Aucun gain de travail dans le modèle idéal.':velocity?'La traction impose une vitesse constante à la corde. La charge monte à une vitesse n fois plus faible. Les phases de démarrage et d’arrêt ne sont pas modélisées.':acceleration?'À vitesse prescrite constante, les accélérations de la corde et de la charge sont nulles. Les phases de démarrage et d’arrêt ne sont pas modélisées.':'La corde tirée parcourt n fois la montée de la charge. La partie pâle indique la suite du levage. Cliquez sur le graphique pour choisir l’instant.';
    }
    function drawHistory(s){
      if(dynamic()){drawDynamicHistory(s);return;}
      legend();const {ctx,w,h}=surface('history-canvas'),left=68,right=w-25,top=40,bottom=h-48;if(right<=left)return;
      const chart=$('chart').value,work=chart==='work',velocity=chart==='velocity',acceleration=chart==='acceleration';
      const max=work?s.weight*state.sim.p.height:velocity?s.pullSpeed:acceleration?1:state.sim.n*state.sim.p.height;
      const base=10**Math.floor(Math.log10(max/4)),step=[1,2,2.5,5,10].find(v=>v*base>=max/4-1e-12)*base,ymax=step*4;
      const ymin=acceleration?-ymax:0,X=t=>left+(right-left)*t/s.duration,Y=v=>bottom-(bottom-top)*(v-ymin)/(ymax-ymin);
      const precision=step=>{let d=0;while(d<5&&Math.abs(step*10**d-Math.round(step*10**d))>1e-8)d++;return d;},decimals=precision((ymax-ymin)/4);
      for(let i=0;i<=4;i++){const value=ymin+(ymax-ymin)*i/4,y=Y(value);line(ctx,[[left,y],[right,y]],C.grid);numericLabel('history-labels','y'+i,value,38,y,decimals);}
      const count=w<450?2:4;
      const timeDigits=precision(s.duration/count);
      for(let i=0;i<=count;i++){const t=s.duration*i/count,x=X(t);line(ctx,[[x,top],[x,bottom]],C.grid);numericLabel('history-labels','x'+i,t,x,bottom+17,timeDigits);}
      label('history-labels','unit',work?tex`E\ [\mathrm J]`:velocity?tex`v\ [\mathrm{m\,s^{-1}}]`:acceleration?tex`a\ [\mathrm{m\,s^{-2}}]`:tex`d\ [\mathrm m]`,left+40,16,C.muted);label('history-labels','time',tex`t\ [\mathrm s]`,(left+right)/2,h-12,C.muted);
      const specs=work?[[0,s.work,max,C.tension,[]],[0,s.potential,max,C.energy,[6,5]]]:velocity?[[s.pullSpeed,s.pullSpeed,s.pullSpeed,C.force,[]],[s.loadSpeed,s.loadSpeed,s.loadSpeed,C.body,[6,5]]]:acceleration?[[0,0,0,C.force,[]],[0,0,0,C.body,[6,5]]]:[[0,s.pull,max,C.force,[]],[0,s.height,state.sim.p.height,C.body,[6,5]]];
      for(const [initial,current,final,color,dash]of specs){ctx.globalAlpha=.2;line(ctx,[[X(0),Y(initial)],[X(s.duration),Y(final)]],color,2,dash);ctx.globalAlpha=1;line(ctx,[[X(0),Y(initial)],[X(s.t),Y(current)]],color,2.5,dash);circle(ctx,X(s.t),Y(current),3,color);}
      line(ctx,[[X(s.t),top],[X(s.t),bottom]],'#899caf',1.2,[3,4]);
    }
    function dynamicSeries(){
      const atwood=state.sim.p.model==='atwood',chart=$('chart').value;
      if(chart==='work')return {title:'Travail et énergies',unit:tex`E\ [\mathrm J]`,series:[['work',tex`W_{\mathrm{app}}`,C.tension,[]],['potential',tex`\Delta U`,C.energy,[6,4]],['kinetic','K',C.body,[]],['rotation',tex`K_{\mathrm{rot}}`,C.rope,[2,4]]],note:atwood?'Aucun travail extérieur de traction : la diminution d’énergie potentielle devient énergie cinétique de translation et de rotation.':'Le travail fourni est égal à la variation d’énergie potentielle plus l’énergie cinétique, rotation comprise. Un travail négatif signifie que la force de traction reçoit de l’énergie.'};
      if(chart==='velocity')return {title:'Vitesses au cours du temps',unit:tex`v\ [\mathrm{m\,s^{-1}}]`,series:atwood?[['loadSpeed','v_1',C.body,[]],['otherSpeed','v_2',C.force,[6,4]]]:[['loadSpeed','v',C.body,[]],['pullSpeed','u',C.force,[6,4]]],note:atwood?'Les vitesses verticales sont opposées ; le sens positif est vers le haut pour chaque masse.':'La vitesse de traction est n fois celle de la charge. Une valeur négative correspond à la descente de la charge et au retour de la corde.'};
      if(chart==='acceleration')return {title:'Accélérations au cours du temps',unit:tex`a\ [\mathrm{m\,s^{-2}}]`,series:atwood?[['acceleration','a_1',C.body,[]],['otherAcceleration','a_2',C.force,[6,4]]]:[['acceleration','a',C.body,[]],['pullAcceleration',tex`a_{\mathrm{corde}}`,C.force,[6,4]]],note:'Les forces sont constantes dans cet essai : les accélérations restent constantes, jusqu’à la limite de la simulation.'};
      return {title:'Déplacements au cours du temps',unit:tex`h\ [\mathrm m]`,series:atwood?[['height','h_1',C.body,[]],['height2','h_2',C.force,[6,4]]]:[['height','h',C.body,[]],['pull',tex`\ell`,C.force,[6,4]]],note:'La courbe pâle indique la suite prévue. Cliquez ou glissez sur le graphique pour choisir l’instant. La course maximale est mesurée depuis la position initiale.'};
    }
    function drawDynamicHistory(s){
      const spec=dynamicSeries(),key='dynamic-'+state.sim.p.model+'-'+$('chart').value;
      if(state.legend!==key){state.legend=key;$('chart-title').textContent=spec.title;$('chart-note').textContent=spec.note;
        $('chart-key').replaceChildren(...spec.series.map(([,value,color,dash])=>{const el=document.createElement('span'),swatch=document.createElement('i'),symbol=document.createElement('span');swatch.style.borderColor=color;swatch.style.borderTopStyle=dash.length?'dashed':'solid';math(symbol,value);el.append(swatch,symbol);return el;}));}
      const {ctx,w,h}=surface('history-canvas'),left=76,right=w-25,top=42,bottom=h-48;if(right<=left)return;
      const value=(state,key)=>key==='otherSpeed'?-state.loadSpeed:key==='otherAcceleration'?-state.acceleration:key==='pullAcceleration'?state.n*state.acceleration:state[key];
      const samples=Array.from({length:121},(_,i)=>state.sim.at(s.duration*i/120)),values=samples.flatMap(q=>spec.series.map(([key])=>value(q,key)));
      let min=Math.min(0,...values),max=Math.max(0,...values);if(max-min<1e-9){min=-1;max=1;}
      const raw=(max-min)/4,base=10**Math.floor(Math.log10(raw)),step=[1,2,2.5,5,10].find(v=>v*base>=raw-1e-12)*base;
      const lo=Math.floor(min/step)*step,hi=Math.ceil(max/step)*step,X=t=>left+(right-left)*t/s.duration,Y=v=>bottom-(bottom-top)*(v-lo)/(hi-lo);
      const digits=Math.max(0,Math.min(5,1-Math.floor(Math.log10(step))));
      for(let i=0;i<=Math.round((hi-lo)/step);i++){const v=lo+i*step,y=Y(v);line(ctx,[[left,y],[right,y]],Math.abs(v)<1e-10?'#99aabb':C.grid,1,Math.abs(v)<1e-10?[4,4]:[]);numericLabel('history-labels','y'+i,v,40,y,digits);}
      const count=w<450?2:4;
      for(let i=0;i<=count;i++){const t=s.duration*i/count,x=X(t);line(ctx,[[x,top],[x,bottom]],C.grid);numericLabel('history-labels','x'+i,t,x,bottom+17,2);}
      label('history-labels','unit',spec.unit,left+40,16,C.muted);label('history-labels','time',tex`t\ [\mathrm s]`,(left+right)/2,h-12,C.muted);
      for(const [key,,color,dash] of spec.series){
        ctx.globalAlpha=.2;line(ctx,samples.map(q=>[X(q.t),Y(value(q,key))]),color,2,dash);ctx.globalAlpha=1;
        const past=samples.filter(q=>q.t<s.t);past.push(s);line(ctx,past.map(q=>[X(q.t),Y(value(q,key))]),color,2.5,dash);circle(ctx,X(s.t),Y(value(s,key)),3,color);
      }
      line(ctx,[[X(s.t),top],[X(s.t),bottom]],'#899caf',1.2,[3,4]);
    }
    function render(){
      const s=state.sim.at();for(const el of labels.values())el.hidden=true;
      if(dynamic()){
        const atwood=state.sim.p.model==='atwood';
        if(atwood)renderAtwoodEnergy(s);
        number($('time-value'),s.t,2,tex`\mathrm s`);number($('height-now'),s.height,2,tex`\mathrm m`);number($('pull-now'),atwood?s.height2:s.pull,2,tex`\mathrm m`);number($('velocity-now'),s.loadSpeed,3,tex`\mathrm{m\,s^{-1}}`);number($('acceleration-now'),s.acceleration,3,tex`\mathrm{m\,s^{-2}}`);number($('pull-value'),s.t,2,tex`\mathrm s`);
        number($('force-value'),atwood?s.tensions[0]:s.force,2,tex`\mathrm N`);number($('weight-value'),atwood?s.tensions[1]:s.weight,2,tex`\mathrm N`);
        for(const [id,key]of [['work-value','work'],['energy-value','potential'],['kinetic-value','kinetic'],['rotation-value','rotation'],['balance-value','balance']])number($(id),s[key],2,tex`\mathrm J`);
        $('pull').value=s.t;$('pull').setAttribute('aria-valuetext',s.t.toFixed(2)+' s');$('scene').setAttribute('aria-valuenow',s.t);$('scene').setAttribute('aria-valuetext',s.t.toFixed(2)+' s ; déplacement '+s.height.toFixed(2)+' m ; accélération '+s.acceleration.toFixed(3)+' m/s²');$('history').setAttribute('aria-valuenow',s.t);$('history').setAttribute('aria-valuetext',s.t.toFixed(2)+' s');drawScene(s);drawHistory(s);return;
      }
      number($('time-value'),s.t,2,tex`\mathrm s`);number($('height-now'),s.height,2,tex`\mathrm m`);number($('pull-now'),s.pull,2,tex`\mathrm m`);number($('velocity-now'),s.loadSpeed,3,tex`\mathrm{m\,s^{-1}}`);number($('pull-value'),s.pull,2,tex`\mathrm m`);
      for(const [id,key,unit]of [['force-value','force',tex`\mathrm N`],['weight-value','weight',tex`\mathrm N`],['work-value','work',tex`\mathrm J`],['energy-value','potential',tex`\mathrm J`]])number($(id),s[key],2,unit);
      $('pull').value=s.pull;$('pull').setAttribute('aria-valuetext',s.pull.toFixed(2)+' m');$('scene').setAttribute('aria-valuenow',s.pull);$('scene').setAttribute('aria-valuetext',s.pull.toFixed(2)+' m tirés ; montée '+s.height.toFixed(2)+' m');$('history').setAttribute('aria-valuenow',s.t);$('history').setAttribute('aria-valuetext',s.t.toFixed(2)+' s');drawScene(s);drawHistory(s);
    }
    $('play').addEventListener('click',()=>state.playing?pause():play());$('restart').addEventListener('click',restart);$('reset').addEventListener('click',()=>configure(PP.defaults));
    function changeParameter(key,value){
      if(key==='height'&&state.sim.p.model==='atwood')return;
      const p=changedParameters({[key]:value});
      // Keep the applied force (in N) when comparing pulley inertia or masses.
      // Only clamp if a new configuration lowers the allowed force range.
      if(dynamic()&&p.model!=='atwood'&&['mass','pairs','inertia','pulleyMass'].includes(key))p.effort=Math.min(2,state.sim.force/PP.dynamicCoefficients(p).threshold);
      configure(p);
    }
    function renderAtwoodEnergy(s){
      let positive=0,negative=0;
      for(const [id,key]of [['k1','kinetic1'],['k2','kinetic2'],['krot','rotation'],['u1','potential1'],['u2','potential2']]){
        const value=s[key],size=50*Math.abs(value)/state.energyScale,bar=$('atwood-'+id+'-bar');
        number($('atwood-'+id),value,2,tex`\mathrm J`);
        bar.style.height=size+'%';bar.style.top=(value<0?50+negative:50-positive-size)+'%';bar.dataset.energy=String(value);
        if(value<0)negative+=size;else positive+=size;
      }
      number($('atwood-e'),s.kinetic1+s.kinetic2+s.rotation+s.potential1+s.potential2,2,tex`\mathrm J`);
    }
    for(const key of ['model','pairs','mass','height','speed','mode','mass2','pulleyMass'])$(key).addEventListener(['model','mode'].includes(key)?'change':'input',()=>changeParameter(key,['model','mode'].includes(key)?$(key).value:Number($(key).value)));
    $('effort').addEventListener('input',()=>configure({...state.sim.p,effort:Math.max(0,Math.min(2,Number($('effort').value)/state.sim.threshold))}));
    $('inertia').addEventListener('change',()=>changeParameter('inertia',$('inertia').checked));
    $('balance-force').addEventListener('click',()=>configure({...state.sim.p,effort:1}));
    $('pull').addEventListener('input',()=>seek(dynamic()?Number($('pull').value):Number($('pull').value)/state.sim.p.speed));
    for(const key of ['strands','forces','distances','chart'])$(key).addEventListener('change',render);
    $('playback').addEventListener('change',()=>state.last=null);
    const scene=$('scene');
    function point(e){const r=scene.getBoundingClientRect();return [e.clientX-r.left,e.clientY-r.top];}
    scene.addEventListener('pointerdown',e=>{
      if(dynamic())return;
      if(e.button!==0)return;const g=state.geometry;if(!g)return;const p=point(e),distance=a=>Math.hypot(p[0]-a[0],p[1]-a[1]),handle=distance(g.handle),load=distance(g.load);if(Math.min(handle,load)>34)return;
      e.preventDefault();pause();state.drag={id:e.pointerId,kind:handle<=load?'handle':'load',y:p[1],pull:state.sim.at().pull,scale:g.scale,direction:g.direction};scene.setPointerCapture(e.pointerId);render();
    });
    scene.addEventListener('pointermove',e=>{const d=state.drag;if(!d||e.pointerId!==d.id)return;e.preventDefault();const dy=point(e)[1]-d.y,pull=d.pull+dy/d.scale*(d.kind==='handle'?d.direction:-state.sim.n);state.sim.setPull(pull);render();});
    function endDrag(e){if(!state.drag||state.drag.id!==e.pointerId)return;if(scene.hasPointerCapture(e.pointerId))scene.releasePointerCapture(e.pointerId);state.drag=null;render();}
    for(const name of ['pointerup','pointercancel','lostpointercapture'])scene.addEventListener(name,endDrag);
    const history=$('history');let chartPointer=null;
    function chartSeek(e){const r=history.getBoundingClientRect(),left=dynamic()?76:68;seek((e.clientX-r.left-left)/(r.width-left-25)*state.sim.duration);}
    history.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();chartPointer=e.pointerId;history.setPointerCapture(e.pointerId);chartSeek(e);});
    history.addEventListener('pointermove',e=>{if(chartPointer===e.pointerId){e.preventDefault();chartSeek(e);}});
    for(const name of ['pointerup','pointercancel','lostpointercapture'])history.addEventListener(name,e=>{if(chartPointer!==e.pointerId)return;chartPointer=null;if(history.hasPointerCapture(e.pointerId))history.releasePointerCapture(e.pointerId);});
    for(const el of [scene,history])el.addEventListener('keydown',e=>{let t=state.sim.t;const step=state.sim.duration/100;if(e.key==='Home')t=0;else if(e.key==='End')t=state.sim.duration;else if(['ArrowRight','ArrowUp'].includes(e.key))t+=step;else if(['ArrowLeft','ArrowDown'].includes(e.key))t-=step;else return;e.preventDefault();seek(t);});
    document.addEventListener('keydown',e=>{if(e.target?.closest('input,select,button,textarea,[contenteditable]'))return;if(e.key===' '){e.preventDefault();state.playing?pause():play();}else if(e.key.toLowerCase()==='r')restart();});
    document.addEventListener('visibilitychange',()=>{if(document.hidden)state.last=null;});
    const observer=new ResizeObserver(()=>render());observer.observe(scene);observer.observe(history);
    // Optional page-local tools. Unsupported browsers retain the complete UI.
    const controller=new AbortController();
    if(document.modelContext?.registerTool){
      const register=tool=>{try{Promise.resolve(document.modelContext.registerTool(tool,{signal:controller.signal})).catch(error=>console.warn('Outil facultatif indisponible.',error));}catch(error){console.warn('Outil facultatif indisponible.',error);}};
      register({name:'read_pulley_experiment',description:'Lire le montage de poulies, ses paramètres et son état instantané.',annotations:{readOnlyHint:true},inputSchema:{type:'object',properties:{},additionalProperties:false},execute:()=>({parameters:{...state.sim.p},state:state.sim.at(),playing:state.playing})});
      register({name:'configure_pulley_experiment',description:'Choisir le montage et les paramètres visibles. Recommence et met en pause. En dynamique, effort est F/F_eq, entre 0 et 2. La poulie fixe propose une course de 5 m par défaut, réglable jusqu’à 20 m. Atwood impose le mode dynamique et une course fixe de 20 m. À sa sélection, ses valeurs par défaut sont m1=1 kg, m2=3 kg, mp=8 kg avec inertie, sauf paramètres explicitement fournis.',inputSchema:{type:'object',properties:{model:{type:'string',enum:PP.allModels},mode:{type:'string',enum:['prescribed','dynamic']},pairs:{type:'integer',minimum:1,maximum:4},mass:{type:'number',minimum:1,maximum:50},mass2:{type:'number',minimum:1,maximum:50},height:{type:'number',minimum:.2,maximum:PP.ATWOOD_MAX_HEIGHT,description:'Course maximale en mètres : fixée à 20 pour Atwood, réglable de 0.2 à 20 pour la poulie fixe et de 0.2 à 1 pour la poulie mobile et le palan.'},speed:{type:'number',minimum:.05,maximum:1},effort:{type:'number',minimum:0,maximum:2},inertia:{type:'boolean'},pulleyMass:{type:'number',minimum:.1,maximum:10}},additionalProperties:false},execute:p=>{if(!p||typeof p!=='object'||Array.isArray(p)||Object.keys(p).some(k=>!['model','pairs','mass','height','speed','mode','mass2','effort','inertia','pulleyMass'].includes(k)))throw new Error('Paramètre inconnu.');configure(changedParameters(p));return {parameters:{...state.sim.p},state:state.sim.at()};}});
      register({name:'control_pulley_experiment',description:'Lire, mettre en pause, recommencer ou choisir un instant du levage.',inputSchema:{type:'object',properties:{action:{type:'string',enum:['play','pause','restart','seek']},time:{type:'number',minimum:0}},required:['action'],additionalProperties:false},execute:p=>{if(!p||typeof p!=='object'||Array.isArray(p)||Object.keys(p).some(k=>!['action','time'].includes(k))||!['play','pause','restart','seek'].includes(p.action)||p.action==='seek'&&(!Number.isFinite(p.time)||p.time<0||p.time>state.sim.duration)||p.action!=='seek'&&p.time!==undefined)throw new Error('Commande non valide.');if(p.action==='seek')seek(p.time);else if(p.action==='play')play();else if(p.action==='pause')pause();else restart();return {state:state.sim.at(),playing:state.playing};}});
    }
    window.addEventListener('pagehide',()=>{pause();controller.abort();observer.disconnect();});
    sync();render();$('loading').hidden=true;
  }catch(error){console.error(error);$('loading').hidden=false;$('loading').textContent='L’animation n’a pas pu démarrer. Rechargez la page ; les formules sont incluses localement.';}
}
