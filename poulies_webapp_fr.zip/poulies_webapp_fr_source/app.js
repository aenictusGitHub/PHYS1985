if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',startPulleyApp);else startPulleyApp();
async function startPulleyApp(){
  'use strict';
  const $=id=>document.getElementById(id),PP=PulleyPhysics,tex=String.raw;
  try{
    await MathJax.startup.promise;
    const C={ink:'#233449',muted:'#607185',grid:'#dce4ec',body:'#2775b6',force:'#268576',rope:'#a77942',tension:'#7758a6',energy:'#b5688b'};
    const names={fixed:'Poulie fixe',mobile:'Poulie mobile',tackle:'Palan'};
    const state={sim:new PP.Experiment(),playing:false,frame:0,last:null,geometry:null,drag:null,legend:''};
    const labels=new Map(),glyphs=new Map(),units=new Map();
    function math(el,value){if(el.dataset.math===value)return;el.replaceChildren(MathJax.tex2svg(value,{display:false}));el.dataset.math=value;}
    function part(value){const svg=MathJax.tex2svg(value,{display:false}).querySelector('svg'),[x,y,width,height]=svg.getAttribute('viewBox').split(/\s+/).map(Number);return {svg,x,y,width,height,ex:parseFloat(svg.getAttribute('width'))/width};}
    for(const el of document.querySelectorAll('[data-tex]'))math(el,el.dataset.tex);
    for(const c of '0123456789.-')glyphs.set(c,part(c));
    const top0=Math.min(...[...glyphs.values()].map(g=>g.y)),bottom0=Math.max(...[...glyphs.values()].map(g=>g.y+g.height));
    MathJax.startup.document.updateDocument();
    // One SVG baseline for all digits and the unit; no typesetting per frame.
    function number(el,value,digits=2,unit=''){
      if(!Number.isFinite(value))throw new Error('Valeur numérique non finie.');
      const string=(Math.abs(value)<.5*10**-digits?0:value).toFixed(digits),key=string+'|'+unit;if(el.dataset.number===key)return;
      const parts=[...string].map(c=>glyphs.get(c));if(unit){if(!units.has(unit))units.set(unit,part(unit));parts.push(units.get(unit));}
      const svg=parts[0].svg.cloneNode(false),ex=glyphs.get('0').ex;let width=0,top=top0,bottom=bottom0;
      for(const [i,p]of parts.entries()){if(i===string.length)width+=1000/6;const g=document.createElementNS('http://www.w3.org/2000/svg','g');g.setAttribute('transform',`translate(${width-p.x},0)`);g.append(...[...p.svg.children].map(c=>c.cloneNode(true)));svg.append(g);width+=p.width;top=Math.min(top,p.y);bottom=Math.max(bottom,p.y+p.height);}
      svg.setAttribute('viewBox',`0 ${top} ${width} ${bottom-top}`);svg.setAttribute('width',`${width*ex}ex`);svg.setAttribute('height',`${(bottom-top)*ex}ex`);svg.style.verticalAlign=`${-bottom*ex}ex`;svg.setAttribute('role','img');svg.setAttribute('aria-label',string+' '+unit.replace(/\\mathrm|[{}]/g,'').replace(/\\,/g,' '));el.classList.add('number');el.replaceChildren(svg);el.dataset.number=key;
    }
    function pause(){state.playing=false;state.last=null;if(state.frame)cancelAnimationFrame(state.frame);state.frame=0;$('play').textContent='Lire';$('play').setAttribute('aria-pressed','false');}
    function configure(p){const next=new PP.Experiment(p);pause();state.sim=next;sync();render();}
    function restart(){configure(state.sim.p);}
    function play(){if(state.sim.done)restart();state.playing=true;state.last=null;$('play').textContent='Pause';$('play').setAttribute('aria-pressed','true');if(!state.frame)state.frame=requestAnimationFrame(frame);}
    function seek(t){const s=state.sim.at(t);pause();state.sim.seek(s.t);render();}
    function frame(now){state.frame=0;if(!state.playing)return;if(state.last!==null)state.sim.advance(Math.min(.1,Math.max(0,(now-state.last)/1000))*Number($('playback').value));state.last=now;if(state.sim.done)pause();render();if(state.playing)state.frame=requestAnimationFrame(frame);}
    function sync(){
      const p=state.sim.p,n=state.sim.n;
      for(const key of ['model','pairs','mass','height','speed'])$(key).value=p[key];
      $('pairs-control').hidden=p.model!=='tackle';$('scene-title').textContent=names[p.model];
      $('model-note').textContent=p.model==='fixed'?'La poulie change le sens de la traction. Elle ne réduit pas l’effort nécessaire.':p.model==='mobile'?'La poulie accompagne la charge. Deux brins la soutiennent ; on tire ici l’extrémité libre vers le haut.':'Une seule corde passe alternativement autour des poulies mobiles et fixes. Comptez les brins qui soutiennent le bloc mobile.';
      $('ratio-badge').textContent=n+' brin'+(n>1?'s porteurs':' porteur');
      $('scene-note').textContent='Tirez la poignée '+(p.model==='mobile'?'vers le haut':'vers le bas')+' ou faites monter la charge. Les flèches représentent les forces, pas les vitesses. Les pointillés repèrent les positions initiales.';
      $('insight-title').textContent=n===1?'Changer le sens de l’effort':'Diviser l’effort par '+n;
      $('insight').textContent=n===1?'Pour monter la charge de 1 m, il faut tirer 1 m de corde, avec une force égale au poids.':'Pour monter la charge de 1 m, il faut tirer '+n+' m de corde. L’effort et la vitesse de montée sont divisés par '+n+'.';
      $('force-bar').style.width=(100/n)+'%';$('weight-bar').style.width='100%';
      number($('pairs-value'),p.pairs,0);number($('mass-value'),p.mass,1,tex`\mathrm{kg}`);number($('height-value'),p.height,2,tex`\mathrm m`);number($('speed-value'),p.speed,2,tex`\mathrm{m\,s^{-1}}`);number($('duration-value'),state.sim.duration,2,tex`\mathrm s`);
      $('pull').max=n*p.height;$('scene').setAttribute('aria-valuemax',n*p.height);$('history').setAttribute('aria-valuemax',state.sim.duration);state.legend='';
    }
    function surface(id){const canvas=$(id),r=canvas.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1),ctx=canvas.getContext('2d');if(canvas.width!==Math.round(r.width*dpr)||canvas.height!==Math.round(r.height*dpr)){canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,r.width,r.height);return {ctx,w:r.width,h:r.height};}
    function line(ctx,points,color,width=1,dash=[]){if(!points.length)return;ctx.beginPath();ctx.moveTo(...points[0]);for(const p of points.slice(1))ctx.lineTo(...p);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineCap='round';ctx.lineJoin='round';ctx.setLineDash(dash);ctx.stroke();ctx.setLineDash([]);}
    function circle(ctx,x,y,r,color,stroke=null){ctx.beginPath();ctx.arc(x,y,r,0,2*Math.PI);ctx.fillStyle=color;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1.3;ctx.stroke();}}
    function arrow(ctx,a,b,color,width=2.4){const dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);if(length<1e-8)return;const ux=dx/length,uy=dy/length,head=Math.min(8,length*.4);line(ctx,[a,b],color,width);line(ctx,[[b[0]-head*ux-head*.48*uy,b[1]-head*uy+head*.48*ux],b,[b[0]-head*ux+head*.48*uy,b[1]-head*uy-head*.48*ux]],color,width);}
    function getLabel(layer,key,x,y,color,tick){let el=labels.get(layer+key);if(!el){el=document.createElement('span');$(layer).append(el);labels.set(layer+key,el);}el.hidden=false;el.dataset.labelKey=key;el.className='plot-label'+(tick?' tick':'');el.style.left=x+'px';el.style.top=y+'px';el.style.color=color;return el;}
    function label(layer,key,value,x,y,color=C.ink,tick=false){const el=getLabel(layer,key,x,y,color,tick);math(el,value);return el;}
    function numericLabel(layer,key,value,x,y,digits=0){const el=getLabel(layer,key,x,y,C.muted,true);number(el,value,digits);return el;}
    function wheel(ctx,p,r){
      const fill=ctx.createLinearGradient(p.x-r,p.y-r,p.x+r,p.y+r);fill.addColorStop(0,'#f1f5fa');fill.addColorStop(.5,'#d6e1ed');fill.addColorStop(1,'#9cacc0');circle(ctx,p.x,p.y,r-2,fill,'#718398');
      for(let i=0;i<4;i++){const a=p.angle+i*Math.PI/2;line(ctx,[[p.x+4*Math.cos(a),p.y+4*Math.sin(a)],[p.x+(r-6)*Math.cos(a),p.y+(r-6)*Math.sin(a)]],'#7f92a8',1.5);}
      circle(ctx,p.x,p.y,3,'#607185');
    }
    function drawScene(s){
      const {ctx,w,h}=surface('scene-canvas');if(w<240||h<400)return;
      const g=PP.geometry(state.sim.p,w,h,s.pull);state.geometry=g;const initial=PP.geometry(state.sim.p,w,h,0),font=parseFloat(window.getComputedStyle($('scene-labels')).fontSize)||15;
      const fixedXs=g.fixed.map(p=>p.x),mountXs=[...fixedXs,...(g.anchor?[g.anchor[0]]:[])];
      const left=Math.min(...mountXs)-35,right=Math.max(...mountXs)+35;
      ctx.fillStyle='#e8eef5';ctx.fillRect(left,g.top-30,right-left,10);line(ctx,[[left,g.top-20],[right,g.top-20]],C.muted,2);
      for(let x=left+7;x<right;x+=11)line(ctx,[[x,g.top-29],[x-6,g.top-21]],'#adbccd',1);
      for(const p of g.fixed)line(ctx,[[p.x,g.top-20],[p.x,p.y]],C.muted,3);
      if(g.anchor){line(ctx,[[g.anchor[0],g.top-20],g.anchor],C.muted,3);circle(ctx,...g.anchor,3,C.muted);}
      if($('distances').checked){
        const [x,y]=initial.load;ctx.strokeStyle='#a4b7ca';ctx.lineWidth=1;ctx.setLineDash([4,4]);ctx.strokeRect(x-22,y-16,44,32);ctx.setLineDash([]);
        circle(ctx,...initial.handle,7,'#fbfcfe','#b4c5d2');
        const dimX=Math.max(15,Math.min(...g.legs.map(p=>p.a[0]))*.28);
        line(ctx,[[dimX,initial.load[1]],[x-27,initial.load[1]]],C.grid,1,[3,4]);line(ctx,[[dimX,g.load[1]],[x-27,g.load[1]]],C.grid,1,[3,4]);
        if(s.height*g.scale>18){line(ctx,[[dimX,initial.load[1]],[dimX,g.load[1]]],C.body,1.2);for(const y of [initial.load[1],g.load[1]])line(ctx,[[dimX-4,y],[dimX+4,y]],C.body,1.2);label('scene-labels','rise','h',dimX+11,(g.load[1]+initial.load[1])/2,C.body);}
      }
      for(const p of [...g.fixed,...g.moving])wheel(ctx,p,g.r);
      for(const a of g.arcs){ctx.beginPath();ctx.arc(a.x,a.y,a.r,Math.PI,0,a.bottom);ctx.lineWidth=3;ctx.strokeStyle=C.rope;ctx.stroke();}
      for(const leg of g.legs)line(ctx,[leg.a,leg.b],$('strands').checked&&leg.support?C.tension:C.rope,3);
      if(g.bar){for(const p of g.moving)line(ctx,[[p.x,p.y],[p.x,g.bar.y]],C.muted,3);line(ctx,[[g.bar.left,g.bar.y],[g.bar.right,g.bar.y]],C.muted,4);line(ctx,[[g.load[0],g.bar.y],[g.load[0],g.load[1]-16]],C.muted,3);}
      else line(ctx,[[g.load[0],g.moving.length?g.moving[0].y:g.legs[0].a[1]],[g.load[0],g.load[1]-16]],C.muted,3);
      const [x,y]=g.load,body=ctx.createLinearGradient(x-22,y-16,x+22,y+16);body.addColorStop(0,'#b0d8ed');body.addColorStop(.38,'#6daed4');body.addColorStop(1,'#2775b6');ctx.fillStyle=body;ctx.fillRect(x-22,y-16,44,32);ctx.strokeStyle=C.body;ctx.lineWidth=1.8;ctx.strokeRect(x-22,y-16,44,32);line(ctx,[[x-19,y+13],[x-19,y-13],[x+19,y-13]],'#d4e8f4',1.5);
      for(let i=0;i<12;i++){const dx=-16+(i*13)%33,dy=-9+(i*7)%19;circle(ctx,x+dx,y+dy,.55,'rgba(35,52,73,.19)');}
      label('scene-labels','mass','m',x-37,y,C.body);
      circle(ctx,...g.handle,8,'#eff7f4',C.force);circle(ctx,...g.handle,3,C.force);
      let index=0;
      for(const leg of g.legs.filter(p=>p.support)){
        const x=leg.a[0],lo=Math.min(leg.a[1],leg.b[1]),hi=Math.max(leg.a[1],leg.b[1]),cy=(lo+hi)/2;
        if($('strands').checked){const ny=lo+Math.min(20,(hi-lo)*.18);circle(ctx,x,ny,7,'#fbfcfe');numericLabel('scene-labels','strand'+index,++index,x,ny,0);}
        if($('forces').checked){const length=54/s.n;arrow(ctx,[x,cy+length/2],[x,cy-length/2],C.tension,2.5);}
      }
      if($('forces').checked){
        const leg=g.legs[0],cy=(leg.a[1]+leg.b[1])/2;
        label('scene-labels','tension',tex`\vec T`,leg.a[0]-Math.max(18,font),cy,C.tension);
        arrow(ctx,[x,y],[x,y+54],C.body,2.7);label('scene-labels','weight',tex`m\vec g`,x+27,y+43,C.body);
        const end=[g.handle[0],g.handle[1]+g.direction*54/s.n];arrow(ctx,g.handle,end,C.force,2.7);
        label('scene-labels','effort',tex`\vec F`,g.handle[0]+Math.max(24,font*1.5),(g.handle[1]+end[1])/2,C.force);
      }
      $('scene').style.cursor=state.drag?'grabbing':'grab';
    }
    function legend(){
      const work=$('chart').value==='work',key=work?'work':'distance';if(state.legend===key)return;state.legend=key;
      $('chart-title').textContent=work?'Travail et énergie gagnée':'Déplacements au cours du temps';
      const specs=work?[[tex`W_{\mathrm{app}}`,C.tension,false],[tex`\Delta U`,C.energy,true]]:[[tex`\ell`,C.force,false],['h',C.body,true]];
      $('chart-key').replaceChildren(...specs.map(([value,color,dashed])=>{const el=document.createElement('span'),swatch=document.createElement('i'),symbol=document.createElement('span');swatch.style.borderColor=color;swatch.style.borderTopStyle=dashed?'dashed':'solid';math(symbol,value);el.append(swatch,symbol);return el;}));
      $('chart-note').textContent=work?'Les deux courbes se superposent : le travail fourni devient de l’énergie potentielle. Aucun gain de travail dans le modèle idéal.':'La corde tirée parcourt n fois la montée de la charge. La partie pâle indique la suite du levage. Cliquez sur le graphique pour choisir l’instant.';
    }
    function drawHistory(s){
      legend();const {ctx,w,h}=surface('history-canvas'),left=68,right=w-25,top=40,bottom=h-48;if(right<=left)return;
      const work=$('chart').value==='work',max=work?s.weight*state.sim.p.height:state.sim.n*state.sim.p.height;
      const base=10**Math.floor(Math.log10(max/4)),step=[1,2,2.5,5,10].find(v=>v*base>=max/4-1e-12)*base,ymax=step*4;
      const X=t=>left+(right-left)*t/s.duration,Y=v=>bottom-(bottom-top)*v/ymax;
      const precision=step=>{let d=0;while(d<5&&Math.abs(step*10**d-Math.round(step*10**d))>1e-8)d++;return d;},decimals=precision(step);
      for(let i=0;i<=4;i++){const value=ymax*i/4,y=Y(value);line(ctx,[[left,y],[right,y]],C.grid);numericLabel('history-labels','y'+i,value,38,y,decimals);}
      const count=w<450?2:4;
      const timeDigits=precision(s.duration/count);
      for(let i=0;i<=count;i++){const t=s.duration*i/count,x=X(t);line(ctx,[[x,top],[x,bottom]],C.grid);numericLabel('history-labels','x'+i,t,x,bottom+17,timeDigits);}
      label('history-labels','unit',work?tex`E\ [\mathrm J]`:tex`d\ [\mathrm m]`,left+26,16,C.muted);label('history-labels','time',tex`t\ [\mathrm s]`,(left+right)/2,h-12,C.muted);
      const specs=work?[[s.work,max,C.tension,[]],[s.potential,max,C.energy,[6,5]]]:[[s.pull,max,C.force,[]],[s.height,state.sim.p.height,C.body,[6,5]]];
      for(const [current,final,color,dash]of specs){ctx.globalAlpha=.2;line(ctx,[[X(0),Y(0)],[X(s.duration),Y(final)]],color,2,dash);ctx.globalAlpha=1;line(ctx,[[X(0),Y(0)],[X(s.t),Y(current)]],color,2.5,dash);circle(ctx,X(s.t),Y(current),3,color);}
      line(ctx,[[X(s.t),top],[X(s.t),bottom]],'#899caf',1.2,[3,4]);
    }
    function render(){
      const s=state.sim.at();for(const el of labels.values())el.hidden=true;
      number($('time-value'),s.t,2,tex`\mathrm s`);number($('height-now'),s.height,2,tex`\mathrm m`);number($('pull-now'),s.pull,2,tex`\mathrm m`);number($('velocity-now'),s.loadSpeed,3,tex`\mathrm{m\,s^{-1}}`);number($('pull-value'),s.pull,2,tex`\mathrm m`);
      for(const [id,key,unit]of [['force-value','force',tex`\mathrm N`],['weight-value','weight',tex`\mathrm N`],['work-value','work',tex`\mathrm J`],['energy-value','potential',tex`\mathrm J`]])number($(id),s[key],2,unit);
      $('pull').value=s.pull;$('pull').setAttribute('aria-valuetext',s.pull.toFixed(2)+' m');$('scene').setAttribute('aria-valuenow',s.pull);$('scene').setAttribute('aria-valuetext',s.pull.toFixed(2)+' m tirés ; montée '+s.height.toFixed(2)+' m');$('history').setAttribute('aria-valuenow',s.t);$('history').setAttribute('aria-valuetext',s.t.toFixed(2)+' s');drawScene(s);drawHistory(s);
    }
    $('play').addEventListener('click',()=>state.playing?pause():play());$('restart').addEventListener('click',restart);$('reset').addEventListener('click',()=>configure(PP.defaults));
    for(const key of ['model','pairs','mass','height','speed'])$(key).addEventListener(key==='model'?'change':'input',()=>configure({...state.sim.p,[key]:key==='model'?$(key).value:Number($(key).value)}));
    $('pull').addEventListener('input',()=>seek(Number($('pull').value)/state.sim.p.speed));
    for(const key of ['strands','forces','distances','chart'])$(key).addEventListener('change',render);
    $('playback').addEventListener('change',()=>state.last=null);
    const scene=$('scene');
    function point(e){const r=scene.getBoundingClientRect();return [e.clientX-r.left,e.clientY-r.top];}
    scene.addEventListener('pointerdown',e=>{
      if(e.button!==0)return;const g=state.geometry;if(!g)return;const p=point(e),distance=a=>Math.hypot(p[0]-a[0],p[1]-a[1]),handle=distance(g.handle),load=distance(g.load);if(Math.min(handle,load)>34)return;
      e.preventDefault();pause();state.drag={id:e.pointerId,kind:handle<=load?'handle':'load',y:p[1],pull:state.sim.at().pull,scale:g.scale,direction:g.direction};scene.setPointerCapture(e.pointerId);render();
    });
    scene.addEventListener('pointermove',e=>{const d=state.drag;if(!d||e.pointerId!==d.id)return;e.preventDefault();const dy=point(e)[1]-d.y,pull=d.pull+dy/d.scale*(d.kind==='handle'?d.direction:-state.sim.n);state.sim.setPull(pull);render();});
    function endDrag(e){if(!state.drag||state.drag.id!==e.pointerId)return;if(scene.hasPointerCapture(e.pointerId))scene.releasePointerCapture(e.pointerId);state.drag=null;render();}
    for(const name of ['pointerup','pointercancel','lostpointercapture'])scene.addEventListener(name,endDrag);
    const history=$('history');let chartPointer=null;
    function chartSeek(e){const r=history.getBoundingClientRect();seek((e.clientX-r.left-68)/(r.width-93)*state.sim.duration);}
    history.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();chartPointer=e.pointerId;history.setPointerCapture(e.pointerId);chartSeek(e);});
    history.addEventListener('pointermove',e=>{if(chartPointer===e.pointerId){e.preventDefault();chartSeek(e);}});
    for(const name of ['pointerup','pointercancel','lostpointercapture'])history.addEventListener(name,e=>{if(chartPointer!==e.pointerId)return;chartPointer=null;if(history.hasPointerCapture(e.pointerId))history.releasePointerCapture(e.pointerId);});
    for(const el of [scene,history])el.addEventListener('keydown',e=>{let t=state.sim.t;const step=state.sim.duration/100;if(e.key==='Home')t=0;else if(e.key==='End')t=state.sim.duration;else if(['ArrowRight','ArrowUp'].includes(e.key))t+=step;else if(['ArrowLeft','ArrowDown'].includes(e.key))t-=step;else return;e.preventDefault();seek(t);});
    document.addEventListener('keydown',e=>{if(e.target?.closest('input,select,button,textarea,[contenteditable]'))return;if(e.key===' '){e.preventDefault();state.playing?pause():play();}else if(e.key.toLowerCase()==='r')restart();});
    document.addEventListener('visibilitychange',()=>{if(document.hidden)state.last=null;});
    const observer=new ResizeObserver(()=>render());observer.observe(scene);observer.observe(history);
    // Optional page-local tools. Unsupported browsers retain the complete UI.
    const controller=new AbortController();
    if(document.modelContext?.registerTool){
      const register=tool=>{try{Promise.resolve(document.modelContext.registerTool(tool,{signal:controller.signal})).catch(error=>console.warn('Outil facultatif indisponible.',error));}catch(error){console.warn('Outil facultatif indisponible.',error);}};
      register({name:'read_pulley_experiment',description:'Lire le montage de poulies, ses paramètres et son état instantané.',annotations:{readOnlyHint:true},inputSchema:{type:'object',properties:{},additionalProperties:false},execute:()=>({parameters:{...state.sim.p},state:state.sim.at(),playing:state.playing})});
      register({name:'configure_pulley_experiment',description:'Choisir le montage ou les paramètres visibles. Recommence le levage et le met en pause.',inputSchema:{type:'object',properties:{model:{type:'string',enum:PP.models},pairs:{type:'integer',minimum:1,maximum:4},mass:{type:'number',minimum:1,maximum:50},height:{type:'number',minimum:.2,maximum:1},speed:{type:'number',minimum:.05,maximum:1}},additionalProperties:false},execute:p=>{if(!p||typeof p!=='object'||Array.isArray(p)||Object.keys(p).some(k=>!['model','pairs','mass','height','speed'].includes(k)))throw new Error('Paramètre inconnu.');configure({...state.sim.p,...p});return {parameters:{...state.sim.p},state:state.sim.at()};}});
      register({name:'control_pulley_experiment',description:'Lire, mettre en pause, recommencer ou choisir un instant du levage.',inputSchema:{type:'object',properties:{action:{type:'string',enum:['play','pause','restart','seek']},time:{type:'number',minimum:0}},required:['action'],additionalProperties:false},execute:p=>{if(!p||typeof p!=='object'||Array.isArray(p)||Object.keys(p).some(k=>!['action','time'].includes(k))||!['play','pause','restart','seek'].includes(p.action)||p.action==='seek'&&(!Number.isFinite(p.time)||p.time<0||p.time>state.sim.duration)||p.action!=='seek'&&p.time!==undefined)throw new Error('Commande non valide.');if(p.action==='seek')seek(p.time);else if(p.action==='play')play();else if(p.action==='pause')pause();else restart();return {state:state.sim.at(),playing:state.playing};}});
    }
    window.addEventListener('pagehide',()=>{pause();controller.abort();observer.disconnect();});
    sync();render();$('loading').hidden=true;
  }catch(error){console.error(error);$('loading').hidden=false;$('loading').textContent='L’animation n’a pas pu démarrer. Rechargez la page ; les formules sont incluses localement.';}
}
