# Poulies — PHYS1985

Application créée à partir de la vidéo de cours `Poulies.mp4`.
La vidéo et ses images ne sont pas redistribuées dans l’application.

[Ouvrir l’application](https://aenictusgithub.github.io/PHYS1985/poulies_webapp_fr.html).

## Utilisation

Ouvrir `index.html` dans un navigateur. MathJax est inclus localement ; aucune connexion n’est nécessaire. Le fichier `poulies_webapp_fr.html` rassemble aussi toute l’app dans un document autonome.

- Poulie fixe : un brin porteur ; traction vers le bas.
- Poulie mobile : deux brins porteurs ; traction vers le haut.
- Palan : une corde continue, une à quatre poulies mobiles et autant de poulies fixes, soit deux à huit brins porteurs.
- Machine d’Atwood : deux masses couplées par une poulie fixe, en mode dynamique.
- À la sélection d’Atwood : masses de 1 kg et 3 kg, poulie de 8 kg, inertie activée. La rotation représente alors 50 % de l’énergie cinétique dès que les masses sont en mouvement. Ces réglages restent modifiables ; toutes les contributions conservent la même échelle énergétique.
- Masse, hauteur cible et vitesse de traction réglables.
- Lecture, pause, recommencement, ralenti, exploration par curseur ou en déplaçant verticalement la poignée ou la charge.
- Repérage des brins porteurs, tensions et forces, position initiale et montée de la charge.
- Effort, poids, travail fourni, énergie potentielle et quatre choix de graphes temporels.

Les touches Espace et R commandent la lecture et le recommencement. Le graphique et la scène sont aussi des curseurs accessibles au clavier : flèches, Début et Fin. L’animation ne démarre jamais automatiquement.

Sur grand écran, la carte explicative « Diviser l’effort par… » est à
droite de l’animation, avec la comparaison Poids / Effort et le rappel
du bilan énergétique. Elle s’adapte aussi à la poulie fixe et au mode
dynamique. Le graphique temporel est placé juste sous cette carte, dans
la même colonne de droite. Sur petit écran, l’explication puis le graphique
passent directement sous l’animation, avant les valeurs numériques.
Atwood garde sa carte de répartition des énergies à droite ; son explication
et son graphique restent en pleine largeur sous les deux cartes.

## Mode à vitesse de traction prescrite

Levage vertical idéal à vitesse prescrite constante, en négligeant les transitoires de démarrage et d’arrêt. Corde inextensible sans masse ; poulies sans masse ni frottement. Pesanteur constante `g = 9.81 m/s²`.

Si `n` brins soutiennent le bloc mobile :

```text
T = F = mg/n
h = ℓ/n
v = u/n
W_app = Fℓ = mgh = ΔU
durée = nH/u
```

Dans ce mode, la force est calculée, non imposée. La masse des poulies et leurs inerties sont négligées. La vitesse affichée est la vitesse de levage prescrite ; une pause fige l’instant étudié. Ce mode reste sélectionné par défaut.

Les quatre choix de graphique sont disponibles dans les deux modes :
déplacements, travail et énergie, vitesses, accélérations. À vitesse
prescrite, les courbes u(t) et v(t) sont horizontales (u = nv), et les deux
accélérations sont nulles. Le titre, les unités et la légende suivent
toujours le choix, sans remise à zéro de l’expérience. Le démarrage et
l’arrêt ne sont pas modélisés ; les valeurs à la limite finale sont celles
juste avant l’arrêt, comme pour les indicateurs de vitesse.

La géométrie conserve exactement la longueur totale de la corde (segments et demi-cercles). Les poulies tournent avec des vitesses cohérentes avec une corde sans glissement. Une échelle spatiale fixe est choisie au départ pour l’ensemble du levage ; masquer les forces ou les brins ne change pas le cadrage. Les dessins sont schématiques : diamètre des poulies et dimensions de la charge ne sont pas des paramètres physiques. Les forces partagent une même échelle dans chaque montage ; le graphique horizontal fournit la comparaison quantitative effort/poids.

Référence pédagogique : [OpenStax, Physics, 9.3 Simple Machines](https://openstax.org/books/physics/pages/9-3-simple-machines), avantage mécanique des poulies et conservation du travail dans une machine idéale.

## Mode dynamique (extension locale, 15 septembre 2026)

Choisir **Dynamique — force imposée** sur les trois montages existants.
L’essai démarre au repos. La force constante F est réglée en newtons, de
zéro à deux fois la force d’équilibre. Le bouton **Choisir la force
d’équilibre** permet un réglage exact. Modifier un paramètre recommence et
met en pause ; la force en newtons est conservée lors d’une modification
de masse ou d’inertie, sauf si la nouvelle borne maximale oblige à la réduire.
Le curseur temporel et le graphique permettent de choisir l’instant ; le
déplacement direct de la charge est réservé au mode à vitesse prescrite.

Sans inertie, pour une montée positive :

```text
a = (n F - m g) / m
v = a t ; h = a t² / 2 ; ℓ = n h ; u = n v
```

Une force inférieure à mg/n entraîne donc une descente, pas un maintien
immobile. À l’équilibre, la charge lâchée sans vitesse reste au repos.
Le cadre est fixe pour les deux sens du déplacement. La lecture se termine
à |h| = H ou après 10 secondes, selon la première limite atteinte. Les
valeurs à la fin de course sont les limites avant un éventuel impact :
aucun choc ni freinage n’est simulé et la vitesse n’est pas artificiellement
annulée. Les réglages de force garantissent des tensions non négatives.
La limite idéale F = 0, avec poulies sans masse, est une chute libre à
tension nulle ; le modèle ne décrit pas la détente réelle d’une corde.

### Inertie des poulies

Option disponible dans tous les montages dynamiques. Chaque poulie est un
disque homogène de masse mp et de même rayon R, avec I = mp R² / 2.
Les axes sont sans frottement ; la corde est inextensible, sans masse et
sans glissement. La masse des supports est négligée. Les poulies mobiles
contribuent à la fois au poids, à la translation et à la rotation.

```text
M = m + k mp                       (k poulies mobiles)
M_rot = Σ (I_j / R²) c_j²
a = (n F - M g) / (M + M_rot)
W_app = F ℓ = ΔU + K_trans + K_rot
ΔU = M g h ; K_trans = M v² / 2 ; K_rot = M_rot v² / 2
```

Le sens horaire est positif pour les angles : pour la poulie fixe c = 1,
pour la mobile c = -1. Dans le palan, les poulies mobiles successives ont
c = -1, -3, … et les poulies fixes c = 2, 4, … (ω_j = c_j v/R).
Ainsi, M_rot vaut mp/2 pour les deux premiers montages et
(mp/2) Σ de c² pour c = 1 à n dans le palan.
Le rayon n’apparaît pas dans l’accélération, car I/R² = mp/2 ; la taille
dessinée reste schématique mais les rotations respectent la cinématique
sans glissement de la corde dessinée.

Les tensions sont calculées séparément et numérotées depuis l’ancrage
(ou le côté charge pour la poulie fixe) jusqu’à l’extrémité tirée. Pour
le palan, T_(i+1) - T_i = (mp/2)(i+1)a. La dernière tension est F.
La somme des tensions porteuses satisfait ΣT - Mg = Ma. Si l’option est
désactivée, mp = 0 et toutes les tensions sont égales à F.

### Course de la poulie fixe

La poulie fixe propose une course de **5 m par défaut**, réglable de
0.2 à **20 m**, en mode à vitesse prescrite et en mode dynamique.
À 0.25 m/s, le levage prescrit par défaut dure ainsi 20 s au lieu de 2 s.
Les deux brins utilisent davantage la hauteur disponible, avec une échelle
spatiale fixée avant la lecture : ni recadrage ni changement de taille
pendant le mouvement. La longueur de corde et la rotation sans glissement
sont conservées. Les masses et les flèches restent visibles en fin de course.
En dynamique, le départ est centré pour permettre la montée ou la descente ;
la limite temporelle de 10 s reste inchangée. La poulie mobile et le palan
conservent leur course par défaut de 0.5 m, réglable de 0.2 à 1 m.

### Machine d’Atwood

La course est fixée à **20 m** pour chaque masse depuis le départ, sans
curseur pour ce montage. La sélection d’Atwood impose cette course ; le
retour à un autre montage reprend sa course par défaut (5 m pour la poulie
fixe, 0.5 m pour les autres), sauf valeur explicitement fournie par l’outil
de configuration.
La limite temporelle de sécurité de 10 s reste appliquée.
La seule poulie fixe est dessinée plus petite (rayon maximal 38 pixels)
et les deux brins utilisent davantage la hauteur disponible. Le cadrage
reste constant pendant l’essai et la longueur totale de la corde est
conservée. Les légendes des forces restent à l’extérieur des deux masses.
Le texte d’inertie est au singulier : la masse de cette poulie ne monte
pas avec les corps ; elle intervient dans l’inertie de rotation.

Le mode est nécessairement dynamique. Les déplacements h1 et h2 sont
positifs vers le haut pour chaque masse ; h2 = -h1. Avec a = a1 :

```text
a = (m2 - m1) g / (m1 + m2 + I/R²)
T1 = m1 (g + a) ; T2 = m2 (g - a)
(T2 - T1) R = I α ; α = a/R
ΔU = (m1 - m2) g h1
K_trans = (m1 + m2) v1² / 2 ; K_rot = I v1² / (2 R²)
K_trans + K_rot + ΔU = 0 ; W_app = 0
```

Un panneau à côté de la machine détaille K1, K2, K_rot, U1 et U2 ainsi
que leur somme E. Il reprend la carte « Répartition instantanée » de
l’application « Énergie mécanique » : une seule barre verticale empilée,
une légende avec pastilles colorées et les valeurs sous les symboles.
Les contributions positives s’empilent au-dessus du zéro, les négatives
au-dessous. Les origines des deux potentiels sont les positions
initiales : U1 = m1 g h1 et U2 = m2 g h2. Un potentiel peut donc être
négatif, et E(t) = E(0) = 0 pour ce départ au repos. Sans inertie de la
poulie, K_rot = 0. Les segments partagent une échelle fixée au
début de l’expérience ; elles ne se renormalisent pas pendant la lecture.
Valeurs et barres suivent aussi la pause, la recherche temporelle et le
redémarrage. Sur petit écran, le panneau se place sous la machine.

La masse la plus lourde descend. Des masses égales restent immobiles au
départ du repos. L’inertie diminue la valeur absolue de l’accélération et
entraîne des tensions différentes. Les graphiques proposent déplacements,
vitesses, accélérations et bilan énergétique, avec un zéro sur chaque axe.
Le tracé pâle représente la suite analytique de l’expérience, pas des
mesures déjà acquises. Une pause ou une recherche temporelle ne modifie
pas les forces ou la solution physique.

Références : [OpenStax, Newton’s Laws](https://openstax.org/books/university-physics-volume-1/pages/6-1-solving-problems-with-newtons-laws)
pour Atwood et [OpenStax, Work and Power for Rotational Motion](https://openstax.org/books/university-physics-volume-1/pages/10-8-work-and-power-for-rotational-motion)
pour l’énergie de rotation et les tensions. Le calcul du palan étend ces
lois par la contrainte cinématique de la corde.

## Construction et vérifications

```sh
python3 build.py
node check_physics.cjs
node check_dynamics.cjs
node check_ui.cjs
node check_browser.cjs
# Conversion MathJax réelle facultative (installation externe) :
PHYS1985_MATHJAX_ROOT=/chemin/vers/mathjax-full/js node check_ui.cjs
```

`check_physics.cjs` vérifie 36 288 géométries, le rapport des forces, la conservation du travail et de la longueur de corde, les limites et les entrées invalides.

`check_ui.cjs` utilise un adaptateur DOM/canvas Node : contrôles, lecture, clavier, glisser, absence de saut de cadrage, placement des symboles avec métriques MathJax, décimales avec point, ligne de base commune des chiffres, graduations distinctes et zéro sur l’axe vertical. Ces tests ne constituent pas une inspection visuelle dans un navigateur.

Trois outils WebMCP facultatifs réutilisent les actions de la page : `read_pulley_experiment`, `configure_pulley_experiment`, `control_pulley_experiment`. Entrées validées avant mutation, désinscription lors de la fermeture, absence/échec du registre sans conséquence sur l’interface. Le contrat est testé avec un registre simulé ; validation dans un contexte WebMCP natif non réalisée.

`check_dynamics.cjs` vérifie 3 240 configurations : deuxième loi de Newton,
moments sur les poulies, bilan énergétique, équilibre, montée/descente,
tensions admissibles, cadrage constant, conservation de corde et recherche
temporelle indépendante du pas d’animation.

`check_browser.cjs` utilise Chrome/Playwright : contrôles réels, force
conservée lors du changement d’inertie, graphiques, formules MathJax,
graduations zéro, lecture/reprise et écrans ordinateur/mobile. Les chemins
du navigateur et de Playwright peuvent être fournis via `CHROME_PATH` et
`PLAYWRIGHT_MODULE` ; `PULLEY_APP_URL` permet de tester le fichier autonome
et `QA_OUTPUT` de conserver les captures de vérification.

## Fichiers

- `physics.js` : modèle analytique et géométrie d’une corde continue.
- `app.js` : rendu, interaction et calculs affichés.
- `style.css`, `phys1985-theme.css` : mise en page et thème commun PHYS1985.
- `vendor/mathjax` : formules hors connexion (licence Apache 2.0 incluse).
- `build.py` : création locale du fichier autonome ; aucune publication.

La reconstruction locale ne publie rien ; le catalogue et le QR code sont gérés séparément dans le dépôt PHYS1985.
