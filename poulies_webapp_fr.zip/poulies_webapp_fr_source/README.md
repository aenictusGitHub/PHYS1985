# Poulies — PHYS1985

Application créée à partir de la vidéo de cours `Poulies.mp4`.
La vidéo et ses images ne sont pas redistribuées dans l’application.

[Ouvrir l’application](https://aenictusgithub.github.io/PHYS1985/poulies_webapp_fr.html).

## Utilisation

Ouvrir `index.html` dans un navigateur. MathJax est inclus localement ; aucune connexion n’est nécessaire. Le fichier `poulies_webapp_fr.html` rassemble aussi toute l’app dans un document autonome.

- Poulie fixe : un brin porteur ; traction vers le bas.
- Poulie mobile : deux brins porteurs ; traction vers le haut.
- Palan : une corde continue, une à quatre poulies mobiles et autant de poulies fixes, soit deux à huit brins porteurs.
- Masse, hauteur cible et vitesse de traction réglables.
- Lecture, pause, recommencement, ralenti, exploration par curseur ou en déplaçant verticalement la poignée ou la charge.
- Repérage des brins porteurs, tensions et forces, position initiale et montée de la charge.
- Effort, poids, travail fourni, énergie potentielle et deux graphes temporels.

Les touches Espace et R commandent la lecture et le recommencement. Le graphique et la scène sont aussi des curseurs accessibles au clavier : flèches, Début et Fin. L’animation ne démarre jamais automatiquement.

## Modèle physique et limites

Levage vertical idéal à vitesse prescrite constante, en négligeant les transitoires de démarrage et d’arrêt. Corde inextensible sans masse ; poulies sans masse ni frottement. Pesanteur constante `g = 9.81 m/s²`.

Si `n` brins soutiennent le bloc mobile :

```text
T = F = mg/n
h = ℓ/n
v = u/n
W_app = Fℓ = mgh = ΔU
durée = nH/u
```

La force est calculée, non imposée comme commande dynamique. La masse des poulies et leurs inerties, l’élasticité de la corde, la dissipation et la rupture ne sont pas modélisées. La vitesse affichée est la vitesse de levage prescrite ; une pause fige l’instant étudié.

La géométrie conserve exactement la longueur totale de la corde (segments et demi-cercles). Les poulies tournent avec des vitesses cohérentes avec une corde sans glissement. Une échelle spatiale fixe est choisie au départ pour l’ensemble du levage ; masquer les forces ou les brins ne change pas le cadrage. Les dessins sont schématiques : diamètre des poulies et dimensions de la charge ne sont pas des paramètres physiques. Les forces partagent une même échelle dans chaque montage ; le graphique horizontal fournit la comparaison quantitative effort/poids.

Référence pédagogique : [OpenStax, Physics, 9.3 Simple Machines](https://openstax.org/books/physics/pages/9-3-simple-machines), avantage mécanique des poulies et conservation du travail dans une machine idéale.

## Construction et vérifications

```sh
python3 build.py
node check_physics.cjs
node check_ui.cjs
# Conversion MathJax réelle facultative (installation externe) :
PHYS1985_MATHJAX_ROOT=/chemin/vers/mathjax-full/js node check_ui.cjs
```

`check_physics.cjs` vérifie 36 288 géométries, le rapport des forces, la conservation du travail et de la longueur de corde, les limites et les entrées invalides.

`check_ui.cjs` utilise un adaptateur DOM/canvas Node : contrôles, lecture, clavier, glisser, absence de saut de cadrage, placement des symboles avec métriques MathJax, décimales avec point, ligne de base commune des chiffres, graduations distinctes et zéro sur l’axe vertical. Ces tests ne constituent pas une inspection visuelle dans un navigateur.

Trois outils WebMCP facultatifs réutilisent les actions de la page : `read_pulley_experiment`, `configure_pulley_experiment`, `control_pulley_experiment`. Entrées validées avant mutation, désinscription lors de la fermeture, absence/échec du registre sans conséquence sur l’interface. Le contrat est testé avec un registre simulé ; validation dans un contexte WebMCP natif non réalisée.

## Fichiers

- `physics.js` : modèle analytique et géométrie d’une corde continue.
- `app.js` : rendu, interaction et calculs affichés.
- `style.css`, `phys1985-theme.css` : mise en page et thème commun PHYS1985.
- `vendor/mathjax` : formules hors connexion (licence Apache 2.0 incluse).
- `build.py` : création locale du fichier autonome ; aucune publication.

La reconstruction locale ne publie rien ; le catalogue et le QR code sont gérés séparément dans le dépôt PHYS1985.
