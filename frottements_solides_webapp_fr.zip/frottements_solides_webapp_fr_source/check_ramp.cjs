'use strict';
const assert=require('node:assert/strict'),FP=require('./physics.js');
const near=(a,b,tol=1e-8)=>assert(Math.abs(a-b)<=tol, a+' != '+b);
const p={m1:2,muS:.5,muK:.3,duration:8};
const sim=new FP.RampSimulation(p,15,5),tc=.5*2*9.81/3;
near(sim.thresholdTime,3.27);
for(const t of [0,.1,1,2,tc-.000001]){
  const s=sim.snapshot(sim.sampleAt(t));
  assert.equal(s.mode,'static');near(s.f,-s.F);near(s.F,3*t);near(s.v1,0);near(s.x1,0);
  assert(Math.abs(s.f)<s.limit);near(s.WA,0);near(s.W1,0);
}
const left=sim.snapshot(sim.sampleAt(tc,'left')),right=sim.snapshot(sim.sampleAt(tc));
near(left.f,-9.81);near(right.f,-5.886);assert.equal(right.mode,'kinetic');
for(const t of [tc,tc+.1,4,5,6,8]){
  const s=sim.snapshot(sim.sampleAt(t));near(s.f,-5.886);assert(s.v1>=0);near(s.balance,0,2e-10);
  near(s.W1,-5.886*s.x1);near(s.Q,-s.W1);
}
// Independently integrate F(t)*v(t), including the ramp/plateau junction.
let work=0,dt=8/40000;
for(let i=0;i<40000;i++){const s=sim.sampleAt((i+.5)*dt);work+=s.F*s.v1*dt;}
near(sim.sampleAt(8).WA,work,1e-6);
const fields=['t','F','f','x1','v1','WA','W1','Q','balance'];
for(const pace of [1/30,1/120,.037,2]){
  const run=new FP.RampSimulation(p,15,5);
  while(!run.done)run.advance(Math.min(pace,8-run.s.t));
  for(const field of fields)near(run.snapshot()[field],sim.snapshot(sim.sampleAt(8))[field],1e-8);
  const event=run.history.filter(s=>Math.abs(s.t-tc)<1e-12);
  assert.equal(event.length,2);assert.equal(run.snapshot(event[0]).mode,'static');assert.equal(run.snapshot(event[1]).mode,'kinetic');
  const end=run.end;run.seek(1.7);near(run.s.F,5.1);near(run.s.x1,0);near(run.end,end);
  run.advance(2);near(run.s.t,3.7);assert(run.end<end);near(run.snapshot().balance,0);
}
for(const peak of [0,5,9.81]){
  const run=new FP.RampSimulation(p,peak,5);run.advance(8);assert.equal(run.snapshot().mode,'static');near(run.s.v1,0);near(run.snapshot().f,-peak);
}
for(const mass of [.5,2,5])for(const muS of [0,.3,1])for(const muK of [0,muS])for(const rise of [.5,8]){
  const run=new FP.RampSimulation({m1:mass,muS,muK,duration:8},60,rise);run.advance(8);
  for(const field of fields)assert(Number.isFinite(run.snapshot()[field]),field);
  near(run.snapshot().balance,0,1e-7);assert(run.s.Q>=0);
}
assert.throws(()=>new FP.RampSimulation(p,15,9));assert.throws(()=>new FP.RampSimulation(p,-1,5));assert.throws(()=>sim.setLive('F',2));
for(const run of [new FP.Simulation('horizontal',{...p,F:15}),new FP.RampSimulation(p,15,5)]){
  run.advance(2);run.seek(0);run.advance(.2);near(run.s.t,.2);near(run.end,.2);near(run.snapshot().balance,0);
}
console.log('PASS: analytic ramp, static adaptation, exact release and force jump, kinetic plateau, work/heat, pacing independence, seek/branch, edge cases.');
