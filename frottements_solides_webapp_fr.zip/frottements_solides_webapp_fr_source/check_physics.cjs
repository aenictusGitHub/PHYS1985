const assert=require('node:assert/strict'),FP=require('./physics.js');
const near=(a,b,tol=1e-8)=>assert(Math.abs(a-b)<tol,`${a} != ${b}`);
const energy=s=>{near(s.balance,0,1e-6);near(s.W1+s.W2+s.Q,0,1e-6);assert(s.Q>=-1e-9);};
assert.throws(()=>new FP.Simulation('unknown'));assert.throws(()=>new FP.Simulation('incline',{muK:.8,muS:.2}));assert.throws(()=>new FP.Simulation('incline',{m1:0}));
for(const F of [-3,0,3]){
  const sim=new FP.Simulation('incline',{angle:0,F});sim.advance(10);const s=sim.snapshot();assert.equal(s.mode,'static');near(s.f,-F);near(s.x1,0);near(s.W1,0);assert(Math.abs(s.f)<s.limit);energy(s);
}
// Dedicated horizontal model: symmetric threshold, no slope/second-body motion.
for(const sign of [-1,1])for(const excess of [-.001,0,.001]){
  const sim=new FP.Simulation('horizontal',{angle:35,F:sign*(.5*2*FP.g+excess)});
  const s=sim.advance(.4);near(sim.p.angle,0);near(s.N,2*FP.g);near(s.v2,0);near(s.x2,0);near(s.WG,0);near(s.W2,0);
  assert.equal(s.mode,excess>0?'kinetic':'static');
  if(excess>0){near(s.f,-sign*.3*s.N);assert(sign*s.v1>0);}else {near(s.f,-s.F);near(s.x1,0);}
  energy(s);
}
// Live forcing retains t=0 history; removing the force brakes to a true stop.
const horizontal=new FP.Simulation('horizontal');
horizontal.advance(.5);near(horizontal.snapshot().f,-4);horizontal.setLive('F',8);near(horizontal.s.t,.5);
horizontal.advance(.5);near(horizontal.snapshot().f,-8);horizontal.setLive('F',15);near(horizontal.s.t,1);
horizontal.advance(.5);assert(horizontal.s.v1>0);near(horizontal.snapshot().f,-.3*2*FP.g);horizontal.setLive('F',0);
horizontal.advance(2);near(horizontal.s.v1,0);near(horizontal.snapshot().f,0);assert.equal(horizontal.snapshot().mode,'static');energy(horizontal.snapshot());
for(const [t,F,f]of [[.25,4,-4],[.75,8,-8],[1.25,15,-.3*2*FP.g],[3,0,0]]){
  horizontal.seek(t);near(horizontal.s.F,F);near(horizontal.snapshot().f,f);energy(horizontal.snapshot());
}
horizontal.seek(horizontal.end);const restingX=horizontal.s.x1;
horizontal.setLive('F',-15);horizontal.advance(.2);assert(horizontal.s.x1<restingX);assert(horizontal.snapshot().f>0);energy(horizontal.snapshot());
const critical=Math.atan(.5)*180/Math.PI;
// Live inclination is a quasi-static parameter, not a reset or an impulse.
const tilt=new FP.Simulation('incline',{angle:15});
tilt.setLive('angle',20);near(tilt.p.angle,20);tilt.advance(.5);
const unchanged=tilt.snapshot();tilt.setLive('angle',40);
for(const key of ['t','x1','x2','v1','v2','W1','W2','WA','WG','Q','K'])near(tilt.snapshot()[key],unchanged[key]);
near(tilt.p.angle,20);near(tilt.s.angle,40);near(tilt.snapshot().N,2*FP.g*Math.cos(40*Math.PI/180));
assert.equal(tilt.snapshot().mode,'kinetic');tilt.advance(.4);assert(tilt.s.v1<0);energy(tilt.snapshot());
near(tilt.s.WG,-2*FP.g*Math.sin(40*Math.PI/180)*tilt.s.x1);
const moving=tilt.snapshot();tilt.setLive('angle',0);near(tilt.s.v1,moving.v1);near(tilt.s.x1,moving.x1);
tilt.advance(1);assert.equal(tilt.snapshot().mode,'static');near(tilt.s.v1,0);near(tilt.s.WG,moving.WG);energy(tilt.snapshot());
const tiltEnd=tilt.end;
for(const [t,angle]of [[0,20],[.27,20],[.5,40],[.713,40],[.9,0],[1.337,0],[tiltEnd,0]]){
  tilt.seek(t);near(tilt.s.angle,angle);near(tilt.snapshot().N,2*FP.g*Math.cos(angle*Math.PI/180));energy(tilt.snapshot());
}
tilt.seek(.713);const oldTilt=JSON.stringify([tilt.p,tilt.s,tilt.history]);
for(const value of [-60.1,60.1,NaN,Infinity])assert.throws(()=>tilt.setLive('angle',value));
assert.equal(JSON.stringify([tilt.p,tilt.s,tilt.history]),oldTilt,'invalid angle must not branch history');
tilt.setLive('angle',30);near(tilt.end,.713);near(tilt.s.angle,30);tilt.advance(.2);energy(tilt.snapshot());
tilt.seek(.4);near(tilt.s.angle,20);tilt.seek(.6);near(tilt.s.angle,40);tilt.seek(.8);near(tilt.s.angle,30);energy(tilt.snapshot());
for(const model of ['horizontal','stack']){
  const sim=new FP.Simulation(model),before=JSON.stringify(sim);assert.throws(()=>sim.setLive('angle',10));assert.equal(JSON.stringify(sim),before);
}
for(const sign of [-1,1])for(const delta of [-.001,0,.001]){
  const sim=new FP.Simulation('incline',{angle:sign*(critical+delta)});sim.advance(.3);const s=sim.snapshot();assert.equal(s.mode,delta>0?'kinetic':'static');if(delta>0){assert(sign*s.v1<0);near(s.f,sign*.3*s.N);}energy(s);
}
// Mirroring angle, force and initial velocity mirrors motion, not normal force,
// dissipation or work. Both signed angle limits are accepted on restart.
for(const angle of [0,20,45,60])for(const v0 of [-2,0,2]){
  const a=new FP.Simulation('incline',{angle,v0,F:4}),b=new FP.Simulation('incline',{angle:-angle,v0:-v0,F:-4});
  for(let i=0;i<80;i++){a.advance(.04);b.advance(.04);const sa=a.snapshot(),sb=b.snapshot();for(const key of ['x1','v1','f','a1'])near(sa[key],-sb[key]);for(const key of ['N','W1','WG','WA','Q'])near(sa[key],sb[key]);energy(sa);energy(sb);}
}
const signChange=new FP.Simulation('incline',{angle:40});
signChange.advance(.4);const beforeSignChange=signChange.snapshot();signChange.setLive('angle',-40);
near(signChange.s.t,.4);near(signChange.s.x1,beforeSignChange.x1);near(signChange.s.v1,beforeSignChange.v1);
assert(signChange.snapshot().f>0,'friction still opposes old leftward velocity immediately after tilting');
signChange.advance(1);assert(signChange.s.v1>0&&signChange.snapshot().f<0);energy(signChange.snapshot());
for(const [t,angle]of [[.2,40],[.4,-40],[.731,-40]]){signChange.seek(t);near(signChange.s.angle,angle);energy(signChange.snapshot());}
const launch=new FP.Simulation('incline',FP.presets.incline.launch),a0=launch.snapshot().a1,tStop=-2/a0,xStop=2*tStop+.5*a0*tStop*tStop;
launch.advance(tStop/2);assert(launch.s.v1>0);launch.advance(2);near(launch.s.x1,xStop);near(launch.s.v1,0);assert.equal(launch.snapshot().mode,'static');energy(launch.snapshot());
const stoppedX=launch.s.x1;launch.advance(3);near(launch.s.x1,stoppedX);launch.setLive('F',-20);launch.advance(.3);assert(launch.s.v1<0);energy(launch.snapshot());
// Braking and reversal must switch kinetic-friction sign exactly at v=0.
const reverse=new FP.Simulation('incline',{angle:0,v0:2,F:-20,m1:2});const brake=-2/reverse.snapshot().a1;
reverse.advance(brake+.4);assert(reverse.s.v1<0);assert(reverse.snapshot().f>0);energy(reverse.snapshot());
for(const F of [-6,6])for(const v0 of [-2,0,2]){
  const sim=new FP.Simulation('stack',{F,v0});sim.advance(.5);const s=sim.snapshot(),a=F/4,dx=v0*.5+.5*a*.5**2;
  assert.equal(s.mode,'static');near(s.relative,0);near(s.v1,v0+a*.5);near(s.f,F/4);near(s.x1,dx);near(s.x2,dx);near(s.W1,s.f*dx);near(s.W2,-s.W1);near(s.Q,0);energy(s);
}
const sliding=new FP.Simulation('stack',FP.presets.stack.slide);sliding.advance(.3);const before=sliding.snapshot();assert(before.v1>0&&before.relative<0&&before.f>0);assert(before.W1>0&&before.W2<0&&before.Q>0);energy(before);
sliding.setLive('F',0);const momentum=sliding.s.v1+3*sliding.s.v2;sliding.advance(3);const together=sliding.snapshot();assert.equal(together.mode,'static');near(together.relative,0);near(together.v1+3*together.v2,momentum);energy(together);assert(!together.edge);
const Q=together.Q;sliding.advance(2);near(sliding.s.Q,Q);near(sliding.snapshot().relative,0);
// Static capacity and kinetic coefficient stay coherent under live edits.
sliding.setLive('muS',.1);near(sliding.s.muK,.1);sliding.setLive('muK',1);near(sliding.s.muK,.1);assert.throws(()=>sliding.setLive('muS',-1));assert.throws(()=>sliding.setLive('bad',1));
// Playback and revisiting use exact segments, not energy-inconsistent interpolation.
for(const model of Object.keys(FP.presets))for(const parameters of Object.values(FP.presets[model])){
  const sim=new FP.Simulation(model,parameters);sim.advance(5);const end=sim.end,saved=sim.snapshot();
  for(let i=0;i<17;i++){sim.seek(end*i/17);energy(sim.snapshot());}
  sim.seek(end);near(sim.s.x1,saved.x1);near(sim.s.W1,saved.W1);sim.seek(end*.43);const rewound=sim.s.t;sim.setLive('F',0);sim.advance(.15);assert(sim.end<=rewound+.15+1e-9);energy(sim.snapshot());assert.equal(sim.history[0].t,0);for(let i=1;i<sim.history.length;i++)assert(sim.history[i].t>sim.history[i-1].t);
}
const edge=new FP.Simulation('stack',FP.presets.stack.slide);edge.advance(10);assert(edge.s.edge);near(Math.abs(edge.s.x1-edge.s.x2),FP.supportLimit);energy(edge.snapshot());const final=JSON.stringify(edge.s);edge.advance(1);assert.equal(JSON.stringify(edge.s),final);
// A support event before a relative-speed zero must not prematurely lock velocities.
const edgeFirst=new FP.Simulation('stack',{F:0});edgeFirst.s.x1=-FP.supportLimit+.001;edgeFirst.s.v1=-1;edgeFirst.K0=.5;
edgeFirst.advance(.008);assert(edgeFirst.s.edge);assert(Math.abs(edgeFirst.snapshot().relative)>.9);energy(edgeFirst.snapshot());
// Stress signed forcing, threshold changes and stopping at varied frame rates.
for(const model of Object.keys(FP.presets))for(const hz of [29.97,60,120])for(let j=0;j<8;j++){
  const sim=new FP.Simulation(model,{angle:j*7,m1:.5+j*.3,m2:.5+j*.2,v0:-2+j*.5,F:-25+j*7,muS:.1+j*.1,muK:.05+j*.08,duration:15});let oldQ=0;
  for(let i=0;i<Math.ceil(15*hz);i++){if(i===30)sim.setLive('F',-sim.s.F);if(i===70)sim.setLive('F',0);if(model==='incline'&&i%17===0)sim.setLive('angle',(i*.7)%120-60);sim.advance(1/hz);const s=sim.snapshot();energy(s);assert(s.Q>=oldQ-1e-9);oldQ=s.Q;}
  assert(sim.done);if(!sim.s.edge)near(sim.s.t,15,1e-8);
}
console.log('Physics passed: Coulomb thresholds, exact stops/reversal, sticking and slip recovery, static work, dissipation, energy balances, support boundary, history and live settings.');
