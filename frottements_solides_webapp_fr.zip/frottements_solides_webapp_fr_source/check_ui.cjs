/* Controller adapter, not browser visual QA. Optional real MathJax conversion. */
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'physics.js'),'utf8')+'\n'+fs.readFileSync(path.join(__dirname,'app.js'),'utf8'),html=fs.readFileSync(path.join(__dirname,'index.html'),'utf8');
const near=(a,b,tol=1e-8)=>assert(Math.abs(a-b)<tol,`${a} != ${b}`);
let width=700,fontPixels=15,frameId=0,clock=0;const nodes=new Map(),frames=new Map(),plots=new Map(),errors=[],events={},tools=new Map();
function canvasContext(id){let points=[];const strokes=[],fills=[];const context=new Proxy({}, {get(target,key){if(key in target)return target[key];return (...args)=>{for(const n of args.flat())if(typeof n==='number')assert(Number.isFinite(n),'finite geometry');if(key==='clearRect'){strokes.length=0;fills.length=0;}if(key==='beginPath')points=[];if(key==='moveTo'||key==='lineTo')points.push([...args]);if(key==='createLinearGradient')return {type:'linear',args,stops:[],addColorStop(offset,color){this.stops.push([offset,color]);}};if(key==='stroke')strokes.push({points,color:target.strokeStyle,width:target.lineWidth});if(key==='fill')fills.push({points,color:target.fillStyle});};}});plots.set(id,{context,strokes,fills});return context;}
class Element{
  constructor(tag='span'){this.tag=tag;this.children=[];this.dataset={};this.style={};this.attrs={};this.events={};this.classList={add(){}};this.value='';this.hidden=false;this.checked=false;}
  set id(id){this._id=id;nodes.set(id,this);}get id(){return this._id;}
  append(...children){this.children.push(...children);}replaceChildren(...children){this.children=children;}
  setAttribute(k,v){this.attrs[k]=String(v);}getAttribute(k){return this.attrs[k];}querySelector(tag){return this.children.find(el=>el.tag===tag);}
  cloneNode(deep){const el=new Element(this.tag);el.attrs={...this.attrs};el.style={...this.style};el.dataset={...this.dataset};if(deep)el.children=this.children.map(c=>typeof c==='string'?c:c.cloneNode(true));return el;}
  addEventListener(k,fn){this.events[k]=fn;}fire(k,args={}){this.events[k]?.({target:this,preventDefault(){},...args});}click(){this.fire('click');}closest(){return null;}
  setPointerCapture(id){this.capture=id;}hasPointerCapture(id){return this.capture===id;}releasePointerCapture(){this.capture=undefined;}
  getBoundingClientRect(){
    if(this.className?.includes('plot-label')){
      const first=this.children[0],svg=first?.tag==='svg'?first:first?.querySelector('svg'),factor=fontPixels*.55;
      const width=parseFloat(svg?.getAttribute('width')||'1.131')*factor,height=Math.max(fontPixels*1.4,parseFloat(svg?.getAttribute('height')||'2')*factor);
      const shift=this.style.transform==='translate(0,-50%)'?0:this.style.transform==='translate(-100%,-50%)'?1:.5,left=parseFloat(this.style.left)-width*shift,top=parseFloat(this.style.top)-height/2;
      return {left,top,right:left+width,bottom:top+height,width,height};
    }
    const height=this.id?.startsWith('scene')?Math.max(width<=480?340:360,fontPixels*22):250;return {left:0,top:0,right:width,bottom:height,width,height};
  }
  getContext(){return plots.get(this.id)?.context||canvasContext(this.id);}
}
for(const m of html.matchAll(/<([\w-]+)\b([^>]*\bid="([^"]+)"[^>]*)>/g)){const el=new Element(m[1]);el.id=m[3];el.value=/\bvalue="([^"]*)"/.exec(m[2])?.[1]||'';el.checked=/\bchecked\b/.test(m[2]);el.hidden=/\bhidden\b/.test(m[2]);}
const $=id=>{assert(nodes.has(id),'missing '+id);return nodes.get(id);};$('model-select').value='incline';$('chart-select').value='friction';$('speed').value='1';
const staticMath=[...html.matchAll(/\bdata-tex="([^"]*)"/g)].map(m=>{const el=new Element();el.dataset.tex=m[1];return el;});
let convertTex;
if(process.env.PHYS1985_MATHJAX_ROOT){
  const root=process.env.PHYS1985_MATHJAX_ROOT,{mathjax}=require(path.join(root,'mathjax.js')),{TeX}=require(path.join(root,'input/tex.js')),{SVG}=require(path.join(root,'output/svg.js')),adaptor=require(path.join(root,'adaptors/liteAdaptor.js')).liteAdaptor();require(path.join(root,'handlers/html.js')).RegisterHTMLHandler(adaptor);require(path.join(root,'input/tex/ams/AmsConfiguration.js'));require(path.join(root,'input/tex/newcommand/NewcommandConfiguration.js'));
  const doc=mathjax.document('',{InputJax:new TeX({packages:['base','ams','newcommand']}),OutputJax:new SVG({fontCache:'none'})});
  function convert(n){const el=new Element(n.kind);for(const {name,value}of adaptor.allAttributes(n))el.setAttribute(name,value);el.append(...adaptor.childNodes(n).filter(c=>c.kind!=='#text').map(convert));return el;}
  convertTex=text=>{const out=doc.convert(text,{display:false});assert(!adaptor.outerHTML(out).includes('data-mml-node="merror"'),'valid TeX: '+text);return convert(out);};
}
function typeset(text){assert(!/[\x00-\x1f]/.test(text));assert(!text.includes('NaN'));if(convertTex)return convertTex(text);const out=new Element('mjx-container'),svg=new Element('svg');svg.setAttribute('viewBox','0 -700 500 722');svg.setAttribute('width','1.131ex');svg.append(new Element('g'));out.append(svg);return out;}
const document={readyState:'complete',getElementById:$,createElement:t=>new Element(t),createElementNS:(_,t)=>new Element(t),querySelectorAll:()=>staticMath,addEventListener:(name,fn)=>events[name]=fn,modelContext:{registerTool(tool){assert(!tools.has(tool.name));tools.set(tool.name,tool);}}};
const context={document,window:{devicePixelRatio:1,getComputedStyle:()=>({fontSize:fontPixels+'px'}),addEventListener:(name,fn)=>events[name]=fn},AbortController,console:{error:e=>errors.push(e),warn:e=>errors.push(e)},ResizeObserver:class{observe(){}},requestAnimationFrame:fn=>{frames.set(++frameId,fn);return frameId;},cancelAnimationFrame:id=>frames.delete(id),MathJax:{startup:{promise:Promise.resolve(),document:{updateDocument(){}}},tex2svg:typeset}};
const value=id=>parseFloat($(id).dataset.number),input=(id,v)=>{$(id).value=v;$(id).fire('input');};
const tick=()=>{clock+=1000/60;const callbacks=[...frames.values()];frames.clear();callbacks.forEach(fn=>fn(clock));};
function advance(seconds){tick();for(let i=0;i<Math.ceil(seconds*60);i++)tick();}
function select(model,preset){$('model-select').value=model;$('model-select').fire('change');if(preset){$('preset-select').value=preset;$('preset-select').fire('change');}}
const read=()=>tools.get('read_friction_experiment').execute({});
async function main(){
  vm.runInNewContext(source,context);await new Promise(r=>setImmediate(r));assert.deepEqual(errors,[]);assert($('loading').hidden);assert.equal(frames.size,0);assert.equal(tools.size,3);
  assert.equal(read().model,'horizontal');assert.equal($('chart-select').value,'friction');assert(html.includes('<option value="horizontal">Corps sur une surface horizontale</option>'));
  near(value('vector-scale-value'),2);assert.equal($('vector-scale').getAttribute('aria-valuetext'),'Facteur 2.00');assert(/id="vector-scale"[^>]*max="4"[^>]*value="2"/.test(html));
  for(const viewport of [280,700])for(const model of ['horizontal','incline','stack']){
    width=viewport;select(model);assert.equal($('angle-control').hidden,model!=='incline');assert.equal($('mass-2-control').hidden,model!=='stack');near(value('time-value'),0);
    if(model==='horizontal'){assert($('scene-title').textContent.includes('horizontale'));assert.equal($('model-equation').dataset.math,String.raw`N=mg,\quad v_{\mathrm{rel}}=v`);assert.equal($('motion-equation').dataset.math,String.raw`ma=F_{\mathrm{app},x}+f`);assert(!$('scene-labels').children.some(el=>!el.hidden&&el.dataset.math?.startsWith('\\theta=')));}
    for(const id of ['force-value','mu-static-value','mu-kinetic-value','angle-value','mass-1-value','mass-2-value','initial-speed-value','time-value','friction-value','work-1-value','heat-value']){assert.equal($(id).children.length,1);assert.equal($(id).children[0].tag,'svg');assert(!$(id).dataset.number.split('|')[0].includes(','));for(const g of $(id).children[0].children)assert(/,0\)$/.test(g.getAttribute('transform')));}
    const initialF=value('friction-value');$('play').click();advance(.5);$('play').click();near(value('time-value'),.5,.011);near(value('friction-value'),initialF,.001);near(value('heat-value'),0);
    if(model==='stack'){assert(value('work-1-value')>0);near(value('work-1-value'),-value('work-2-value'),.001);}else near(value('work-1-value'),0);
    const bodies=()=>JSON.stringify(plots.get('scene-canvas').fills.filter(p=>p.color?.type==='linear')),before=bodies();assert.equal(JSON.parse(before).length,model==='stack'?2:1);
    const texture=()=>JSON.stringify(plots.get('scene-canvas').strokes.filter(p=>p.color==='rgba(35,52,73,.14)')),grain=texture();assert.equal(JSON.parse(grain).length,model==='stack'?2:1);assert(JSON.parse(grain).every(p=>p.points.length>4));
    for(const id of ['show-forces','show-normal','show-velocity','show-start']){$(id).checked=!$(id).checked;$(id).fire('change');assert.equal(bodies(),before);assert.equal(texture(),grain,'grain stable across redraws');}
    for(const key of ['velocity','work','friction']){
      $('chart-select').value=key;$('chart-select').fire('change');near(value('time-value'),.5,.011);assert.equal(bodies(),before);
      const ticks=$('history-labels').children.filter(el=>!el.hidden&&parseFloat(el.style.left)===40),zero=ticks.filter(el=>el.dataset.number==='0|');
      assert.equal(zero.length,1);assert(ticks.every(el=>el===zero[0]||Math.abs(parseFloat(el.style.top)-parseFloat(zero[0].style.top))>=22));
    }
    $('play').click();advance(.2);const t=read().state.t;input('force',30);near(read().state.t,t);assert.equal(frames.size,1);assert.equal($('play').textContent,'Pause');advance(.1);$('play').click();assert(read().state.t>t);assert.equal(read().state.mode,'kinetic');assert(value('heat-value')>0);near(value('balance-value'),0,.000001);
    const time=read().state.t;input('mu-static',.1);near(value('mu-kinetic-value'),.1);near(Number($('mu-kinetic').max),.1);near(read().state.t,time);
    $('history').fire('keydown',{key:'Home'});near(value('time-value'),0);$('history').fire('keydown',{key:'End'});near(read().state.t,time);
    $('history').fire('pointerdown',{pointerId:1,clientX:70+(width-95)*time*.4/8,button:0});$('history').fire('pointerup',{pointerId:1});assert.equal($('history').capture,undefined);const rewound=read().state.t;assert(rewound<time);input('force',0);assert(read().state.t<time);$('play').click();advance(.1);$('play').click();assert(Number($('history').getAttribute('aria-valuemax'))<time);
    input('mass-1',2.5);near(value('time-value'),0);near(value('mass-1-value'),2.5);assert.equal(frames.size,0);input('duration',2);$('play').click();advance(2.1);assert.equal(frames.size,0);near(value('time-value'),2,.001);assert.equal($('play').textContent,'Lire');
    $('reset').click();near(value('time-value'),0);assert.equal(read().state.muS,.5);
  }
  // Force history starts at zero and shows vertical jumps (not false ramps).
  select('horizontal','held');assert.equal($('chart-select').value,'friction');assert($('chart-title').textContent.includes('frottement'));assert(!$('chart-note').hidden);
  const forceCurve=()=>plots.get('history-canvas').strokes.find(p=>p.color==='#d9683b').points;
  $('play').click();advance(.5);near(value('friction-value'),-4,.001);
  const oldTime=read().state.t,oldY=forceCurve()[0][1];input('force',8);near(read().state.t,oldTime);near(value('friction-value'),-8,.001);
  const jump=forceCurve().slice(-2);near(jump[0][0],jump[1][0]);assert.notEqual(jump[0][1],jump[1][1]);near(jump[0][0],70+(width-95)*oldTime/8);near(forceCurve()[0][0],70);near(forceCurve()[0][1],oldY);
  advance(.5);input('force',15);assert.equal(read().state.mode,'kinetic');advance(.5);$('zero-force').click();advance(2);$('play').click();
  near(read().state.v1,0);near(value('friction-value'),0);assert.equal(read().state.mode,'static');
  const curve=forceCurve();assert(curve.length>2);for(let i=1;i<curve.length;i++)assert(curve[i][0]===curve[i-1][0]||curve[i][1]===curve[i-1][1],'piecewise-constant force, exact jump times');
  for(const example of ['pushed','slowing']){select('horizontal',example);assert.equal(read().state.mode,'kinetic');assert.equal($('chart-select').value,'friction');$('play').click();advance(1);$('play').click();near(value('balance-value'),0);}
  // Body/force labels occupy stable lanes, including when force reverses or
  // symbols are hidden and restored. Use actual MathJax SVG metrics if present.
  const bodyKeys=['mass','N','F','v1','f','P'],bodyLabels=()=>$('scene-labels').children.filter(el=>!el.hidden&&bodyKeys.includes(el.dataset.labelKey));
  const overlap=(a,b,gap=3)=>a.left<b.right+gap&&a.right>b.left-gap&&a.top<b.bottom+gap&&a.bottom>b.top-gap;
  // Supplied stacked-block crop: m1 and both contact forces overlapped on the
  // small upper block. Captions now use fixed rows outside both bodies.
  for(const viewport of [280,700,870])for(const size of [15,22,30]){
    width=viewport;fontPixels=size;select('stack','stick');$('show-normal').checked=false;$('show-velocity').checked=false;
    const items=()=>$('scene-labels').children.filter(el=>!el.hidden&&['m1','m2','f1','f2','F'].includes(el.dataset.labelKey));
    const positions=()=>Object.fromEntries(items().map(el=>[el.dataset.labelKey,[el.style.left,el.style.top]]));
    input('force',6);const fixed=positions();
    function checkStackCaptions(){
      const current=items(),plot=plots.get('scene-canvas');
      const bodies=plot.fills.filter(p=>p.color?.type==='linear').map(p=>({left:Math.min(...p.points.map(a=>a[0])),right:Math.max(...p.points.map(a=>a[0])),top:Math.min(...p.points.map(a=>a[1])),bottom:Math.max(...p.points.map(a=>a[1]))}));
      for(const el of current){
        const r=el.getBoundingClientRect();assert(r.left>=0&&r.right<=width&&r.top>=0&&r.bottom<=$('scene').getBoundingClientRect().height,'stack caption inside scene');
        if(el.dataset.labelKey!=='m2')for(const body of bodies)assert(!overlap(r,body),'stack caption outside blocks: '+el.dataset.labelKey);
      }
      for(let i=0;i<current.length;i++)for(const other of current.slice(i+1))assert(!overlap(current[i].getBoundingClientRect(),other.getBoundingClientRect()),`separate stacked-block captions: ${current[i].dataset.labelKey}/${other.dataset.labelKey}, viewport=${viewport}, font=${size}, force=${$('force').value}, scale=${$('vector-scale').value}`);
      const shafts=plot.strokes.filter(p=>p.color==='#d9683b'&&p.width===2.5&&p.points.length===2),links=plot.strokes.filter(p=>p.color==='#d9683b'&&p.width===1&&p.points.length===2);
      assert.equal(links.length,shafts.length);
      for(const [i,link]of links.entries()){const a=shafts[i].points;near(link.points[0][0],(a[0][0]+a[1][0])/2);near(link.points[0][1],(a[0][1]+a[1][1])/2);}
    }
    for(const factor of [.25,2,4])for(const force of [-40,-6,0,6,40]){
      input('vector-scale',factor);input('force',force);checkStackCaptions();
      for(const key of ['m1','m2','f1','f2','F'])if(positions()[key])assert.deepEqual(positions()[key],fixed[key],'contact captions do not move with force or scale');
    }
    for(const sign of [-1,1]){
      select('stack','slide');input('force',sign*24);$('show-normal').checked=false;$('show-velocity').checked=false;
      $('play').click();for(let i=0;i<24;i++){advance(.06);checkStackCaptions();}if(read().playing)$('play').click();
    }
  }
  input('vector-scale',2);fontPixels=15;width=700;
  for(const viewport of [280,700])for(const size of [15,22])for(const model of ['horizontal','incline']){
    width=viewport;fontPixels=size;select(model);input('initial-speed',2);$('show-forces').checked=true;$('show-normal').checked=true;$('show-velocity').checked=true;$('show-velocity').fire('change');
    const positions=()=>Object.fromEntries(bodyLabels().map(el=>[el.dataset.labelKey,[el.style.left,el.style.top,el.style.transform]]));
    input('force',4);const fixed=positions();
    for(const force of [-40,-.1,0,.1,40]){
      input('force',force);const current=bodyLabels();
      for(const el of current){assert.deepEqual(positions()[el.dataset.labelKey],fixed[el.dataset.labelKey],'force magnitude/direction must not move a symbol');const r=el.getBoundingClientRect();assert(r.left>=0&&r.right<=width&&r.top>=0&&r.bottom<=$( 'scene').getBoundingClientRect().height,'annotation stays in scene');}
      for(let i=0;i<current.length;i++)for(const other of current.slice(i+1))assert(!overlap(current[i].getBoundingClientRect(),other.getBoundingClientRect()),'separate annotation lanes');
      const ticks=$('scene-labels').children.filter(el=>!el.hidden&&el.className.includes('tick'));for(const tick of ticks)for(const el of current)assert(!overlap(tick.getBoundingClientRect(),el.getBoundingClientRect()),'ruler does not overlap symbols');
      const strokes=plots.get('scene-canvas').strokes,colors=['#d9683b','#268576','#7758a6','#2775b6','#00869c'];
      const arrows=strokes.filter(s=>colors.includes(s.color)&&[2,2.5].includes(s.width)&&s.points.length===2),leaders=strokes.filter(s=>colors.includes(s.color)&&s.width===1&&s.points.length===2);
      assert.equal(leaders.length,arrows.length,'one dotted link per visible vector');
      for(const link of leaders){const shaft=arrows.find(s=>s.color===link.color);assert(shaft);near(link.points[0][0],(shaft.points[0][0]+shaft.points[1][0])/2);near(link.points[0][1],(shaft.points[0][1]+shaft.points[1][1])/2);}
    }
    for(const id of ['show-forces','show-normal','show-velocity']){$(id).checked=false;$(id).fire('change');$(id).checked=true;$(id).fire('change');assert.deepEqual(positions(),fixed);}
    // Every label follows the body by the same amount during playback.
    const before=positions();$('play').click();advance(.15);$('play').click();const after=positions(),dx=parseFloat(after.mass[0])-parseFloat(before.mass[0]),dy=parseFloat(after.mass[1])-parseFloat(before.mass[1]);
    for(const key of bodyKeys){near(parseFloat(after[key][0])-parseFloat(before[key][0]),dx);near(parseFloat(after[key][1])-parseFloat(before[key][1]),dy);}
  }
  fontPixels=15;width=700;
  // Angle input rotates the view live but keeps the tangential state, clock,
  // running callback and accumulated history. Rewinding restores old angles.
  assert(html.indexOf('id="angle-control"')<html.indexOf('Conditions initiales'));
  assert(/id="angle"[^>]*min="-60"[^>]*max="60"/.test(html));
  select('incline','rest');$('play').click();advance(.5);
  const beforeTilt=read().state,bodyBeforeTilt=JSON.stringify(plots.get('scene-canvas').fills);
  input('angle',40);assert(read().playing);assert.equal(frames.size,1);assert.equal($('play').textContent,'Pause');
  for(const key of ['t','x1','v1','W1','WA','WG','Q'])near(read().state[key],beforeTilt[key]);
  near(value('angle-value'),40);near(read().state.N,2*9.81*Math.cos(40*Math.PI/180));
  assert.notEqual(JSON.stringify(plots.get('scene-canvas').fills),bodyBeforeTilt);
  assert($('scene-labels').children.some(el=>!el.hidden&&el.dataset.math===String.raw`\theta=40.0^\circ`));
  advance(.4);assert(read().state.v1<0&&read().state.t>beforeTilt.t);const movingTilt=read().state;
  input('angle',0);near(read().state.v1,movingTilt.v1);near(read().state.x1,movingTilt.x1);
  advance(1);$('play').click();near(read().state.v1,0);assert.equal(read().state.mode,'static');near(value('balance-value'),0);
  const tiltEnd=read().state.t;
  $('history').fire('keydown',{key:'Home'});near(value('angle-value'),20);near(Number($('angle').value),20);near(read().state.t,0);
  $('history').fire('pointerdown',{pointerId:1,clientX:70+(width-95)*.7/8,button:0});$('history').fire('pointerup',{pointerId:1});
  near(read().state.t,.7);near(value('angle-value'),40);near(Number($('angle').value),40);near(value('balance-value'),0);
  $('history').fire('keydown',{key:'End'});near(read().state.t,tiltEnd);near(value('angle-value'),0);
  input('angle',-35);$('restart').click();near(read().state.t,0);near(read().state.angle,-35);near(read().parameters.angle,-35);
  $('history').fire('keydown',{key:'End'});near(read().state.t,0);
  // Dragging the slider through intermediate inclinations must not stop play.
  for(const viewport of [280,700])for(const size of [15,22,30]){
    width=viewport;fontPixels=size;select('incline','rest');$('play').click();
    for(let angle=-60;angle<=60;angle+=1){input('angle',angle);tick();assert(read().playing);assert.equal(frames.size,1);near(value('angle-value'),angle);}
    assert(read().state.t>.9);assert.deepEqual(errors,[]);$('play').click();
  }
  width=700;fontPixels=15;
  // Regression: at large scales N crossed F_app. Check complete arrow shafts
  // and heads against every symbol, including both senses on inclined planes.
  function segmentOverlapsLabel(a,b,box){
    const r={left:box.left-4,right:box.right+4,top:box.top-4,bottom:box.bottom+4},inside=p=>p[0]>=r.left&&p[0]<=r.right&&p[1]>=r.top&&p[1]<=r.bottom;
    if(inside(a)||inside(b))return true;
    const corners=[[r.left,r.top],[r.right,r.top],[r.right,r.bottom],[r.left,r.bottom]];
    for(let i=0;i<4;i++){
      const c=corners[i],d=corners[(i+1)%4],ux=b[0]-a[0],uy=b[1]-a[1],vx=d[0]-c[0],vy=d[1]-c[1],den=ux*vy-uy*vx;
      if(Math.abs(den)<1e-10)continue;
      const wx=c[0]-a[0],wy=c[1]-a[1],t=(wx*vy-wy*vx)/den,u=(wx*uy-wy*ux)/den;if(t>=0&&t<=1&&u>=0&&u<=1)return true;
    }
    return false;
  }
  for(const viewport of [280,700])for(const size of [15,22,30])for(const angle of [-60,-45,-20,0,20,45,60]){
    width=viewport;fontPixels=size;select(angle?'incline':'horizontal');if(angle)input('angle',angle);input('mass-1',5);input('mu-static',1);input('mu-kinetic',1);
    $('show-forces').checked=true;$('show-normal').checked=true;$('show-velocity').checked=true;
    for(const direction of [-1,1]){
      input('initial-speed',direction*3);input('force',direction*40);
      for(const factor of [.25,2,4]){
        input('vector-scale',factor);const current=bodyLabels();assert.equal(current.length,6);
        const vectors=plots.get('scene-canvas').strokes.filter(s=>s.width===2.5||s.width===2&&s.color==='#00869c');
        for(const el of current)for(const vector of vectors)for(let i=1;i<vector.points.length;i++)assert(!segmentOverlapsLabel(vector.points[i-1],vector.points[i],el.getBoundingClientRect()),'vector does not cross '+el.dataset.labelKey+' at angle '+angle+', scale '+factor);
      }
    }
  }
  fontPixels=15;width=700;
  // Display-only factor scales forces, velocities and both reference arrows,
  // with unchanged origins, bodies, physics, time, history and running state.
  const shafts=()=>plots.get('scene-canvas').strokes.filter(s=>s.points.length===2&&(s.width===2.5||s.width===1.6||s.color==='#00869c'&&[2,1.5].includes(s.width)));
  const bodies=()=>JSON.stringify(plots.get('scene-canvas').fills.filter(p=>p.color?.type==='linear'));
  for(const model of ['horizontal','incline','stack']){
    select(model);input('initial-speed',2);input('force',4);input('vector-scale',1);$('show-forces').checked=true;$('show-normal').checked=true;$('show-velocity').checked=true;$('show-velocity').fire('change');
    $('play').click();advance(.15);input('vector-scale',1);const physics=JSON.stringify(read()),body=bodies(),history=JSON.stringify(plots.get('history-canvas').strokes),baseline=shafts();assert(baseline.length>=6);
    const positions=()=>JSON.stringify(bodyLabels().map(el=>[el.dataset.labelKey,el.style.left,el.style.top,el.style.transform])),labelsBefore=positions();
    for(const factor of [.25,1,2,3,4]){
      input('vector-scale',factor);near(value('vector-scale-value'),factor);assert.equal($('vector-scale').getAttribute('aria-valuetext'),'Facteur '+factor.toFixed(2));
      assert.equal(JSON.stringify(read()),physics);assert.equal(bodies(),body);assert.equal(JSON.stringify(plots.get('history-canvas').strokes),history);assert.equal(frames.size,1);
      const scaled=shafts();assert.equal(scaled.length,baseline.length);
      for(let i=0;i<scaled.length;i++){const a=baseline[i].points,b=scaled[i].points;near(b[0][0],a[0][0]);near(b[0][1],a[0][1]);near(b[1][0]-b[0][0],factor*(a[1][0]-a[0][0]));near(b[1][1]-b[0][1],factor*(a[1][1]-a[0][1]));}
      if(model!=='stack')assert.equal(positions(),labelsBefore,'single-body symbol lanes stay fixed as vectors scale');
    }
    input('vector-scale',5);near(value('vector-scale-value'),4);
    const time=read().state.t;advance(.1);assert(read().state.t>time);$('play').click();$('restart').click();near(value('vector-scale-value'),4);select(model);near(value('vector-scale-value'),4);
  }
  input('vector-scale',1);
  // Direct launch preserves contact settings, resets history, and uses the
  // chosen signed initial velocity (2 m/s only when that setting is zero).
  select('horizontal');assert(!$('launch-control').hidden);near(read().state.v1,0);
  input('force',0);$('launch-block').click();assert(read().playing);near(read().state.t,0);near(read().state.v1,2);near(read().parameters.v0,2);near(read().state.F,0);
  advance(.25);assert(read().state.x1>0&&read().state.v1>0);near(value('balance-value'),0);$('play').click();
  input('initial-speed',-1.5);$('launch-block').click();near(read().state.v1,-1.5);near(read().state.t,0);advance(.1);assert(read().state.x1<0);$('play').click();
  $('launch-block').click();near(read().state.t,0);near(read().state.W1,0);near(Number($('history').getAttribute('aria-valuemax')),0);$('play').click();
  select('stack');assert($('launch-control').hidden);
  select('incline','launch');$('play').click();advance(3);$('play').click();assert.equal(read().state.mode,'static');near(value('velocity-value'),0);assert(value('work-1-value')<0);assert($('observation').textContent.includes('antérieur'));
  select('stack','slide');$('play').click();advance(2);assert(read().state.edge);assert.equal(frames.size,0);assert(!$('stop-note').hidden);assert($('stop-note').textContent.includes('support'));near(value('balance-value'),0);
  const adjust=tools.get('adjust_friction_live'),choose=tools.get('select_friction_example');choose.execute({model:'stack',example:'stick'});adjust.execute({force:8,muStatic:.6,muKinetic:.4,playback:'play'});assert.equal(read().state.F,8);assert(read().playing);advance(.3);adjust.execute({playback:'pause'});assert(!read().playing);near(value('force-value'),8);
  const old=JSON.stringify(read());assert.throws(()=>adjust.execute({force:12,muStatic:.2,muKinetic:.9}));assert.throws(()=>adjust.execute({force:NaN}));assert.throws(()=>adjust.execute({unknown:1}));assert.throws(()=>choose.execute({model:'incline',example:'stick'}));assert.equal(JSON.stringify(read()),old,'invalid command is atomic');
  assert.throws(()=>adjust.execute({force:12,angle:30,playback:'play'}));assert.equal(JSON.stringify(read()),old,'angle is not valid for stacked bodies');
  choose.execute({model:'incline',example:'rest'});adjust.execute({playback:'play'});advance(.25);
  const atTilt=read().state.t;adjust.execute({angle:-40});near(read().state.t,atTilt);near(read().state.angle,-40);assert(read().playing);advance(.2);assert(read().state.v1>0);
  const validTilt=JSON.stringify(read());for(const angle of [-61,61,NaN])assert.throws(()=>adjust.execute({force:10,angle,playback:'pause'}));assert.equal(JSON.stringify(read()),validTilt);
  adjust.execute({playback:'pause'});
  $('play').click();document.hidden=true;events.visibilitychange();assert.equal(frames.size,0);assert.equal($('play').textContent,'Lire');events.pagehide();assert.deepEqual(errors,[]);
  console.log('UI adapter passed: presets, live settings, synchronized coefficients, geometry stability, histories, stopping, numeric baselines, optional agent contracts'+(convertTex?' with real MathJax.':'.'));
}
main().catch(e=>{console.error(e);process.exitCode=1;});
