/* Coulomb contact with exact constant-acceleration segments and stop events.
 * No viscous regularization: sticking is a constraint, not a small sliding speed. */
const FrictionPhysics=(()=>{
  'use strict';
  const g=9.81,eps=1e-10,supportLimit=2.4;
  const presets={
    horizontal:{held:{angle:0,m1:2,m2:3,muS:.5,muK:.3,F:4,v0:0},pushed:{angle:0,m1:2,m2:3,muS:.5,muK:.3,F:15,v0:0},slowing:{angle:0,m1:2,m2:3,muS:.5,muK:.3,F:0,v0:2}},
    incline:{rest:{angle:20,m1:2,m2:3,muS:.5,muK:.3,F:0,v0:0},slide:{angle:35,m1:2,m2:3,muS:.5,muK:.3,F:0,v0:0},launch:{angle:20,m1:2,m2:3,muS:.5,muK:.3,F:0,v0:2},horizontal:{angle:0,m1:2,m2:3,muS:.5,muK:.3,F:4,v0:0}},
    stack:{stick:{angle:0,m1:1,m2:3,muS:.5,muK:.3,F:6,v0:0},slide:{angle:0,m1:1,m2:3,muS:.5,muK:.3,F:24,v0:0},brake:{angle:0,m1:1,m2:3,muS:.5,muK:.3,F:-6,v0:2}},
  };
  function forces(model,p,s){
    const single=model!=='stack',theta=model==='incline'?s.angle*Math.PI/180:0,N=p.m1*g*Math.cos(theta),limit=s.muS*N;
    const relative=single?s.v1:s.v1-s.v2;
    const drive=single?s.F-p.m1*g*Math.sin(theta):-s.F/p.m2;
    const required=single?-drive:p.m1*s.F/(p.m1+p.m2);
    const sticking=Math.abs(relative)<eps&&Math.abs(required)<=limit+1e-11;
    const f=sticking?required:-s.muK*N*Math.sign(Math.abs(relative)>=eps?relative:drive);
    const a1=single?(drive+f)/p.m1:f/p.m1;
    const a2=single?0:(s.F-f)/p.m2;
    return {N,limit,required,f,a1,a2,relative,mode:sticking?'static':'kinetic'};
  }
  // Earliest positive crossing of either full-support boundary, if any.
  function supportTime(d,u,a,maxTime){
    let best=Infinity;
    for(const target of [-supportLimit,supportLimit]){
      const c=d-target;
      if(Math.abs(a)<1e-12){if(Math.abs(u)>eps){const t=-c/u;if(t>1e-11&&t<=maxTime+1e-11)best=Math.min(best,t);}}
      else {const disc=u*u-2*a*c;if(disc>=0)for(const t of [(-u-Math.sqrt(disc))/a,(-u+Math.sqrt(disc))/a])if(t>1e-11&&t<=maxTime+1e-11)best=Math.min(best,t);}
    }
    return best;
  }
  class Simulation {
    constructor(model='incline',parameters={}){
      if(!Object.hasOwn(presets,model))throw new Error('Système inconnu.');
      this.model=model;this.p={...Object.values(presets[model])[0],duration:8,...parameters};
      const p=this.p;
      if(!Object.values(p).every(Number.isFinite)||p.m1<=0||p.m2<=0||p.duration<=0||Math.abs(p.angle)>60||p.muS<0||p.muK<0||p.muK>p.muS)throw new Error('Paramètres physiques non valides.');
      if(model==='horizontal')p.angle=0;
      this.s={t:0,x1:0,x2:0,v1:p.v0,v2:model==='stack'?p.v0:0,F:p.F,muS:p.muS,muK:p.muK,angle:p.angle,W1:0,W2:0,WA:0,WG:0,Q:0,edge:false};
      this.K0=.5*p.m1*this.s.v1**2+.5*p.m2*this.s.v2**2;
      this.history=[{...this.s}];this.started=false;
    }
    snapshot(s=this.s){const q=forces(this.model,this.p,s),K=.5*this.p.m1*s.v1**2+.5*this.p.m2*s.v2**2;return {...s,...q,K,balance:K-this.K0-s.WA-s.WG-s.W1-s.W2};}
    get end(){return this.history[this.history.length-1].t;}
    get done(){return this.s.edge||this.s.t>=this.p.duration-1e-9;}
    record(){if(Math.abs(this.end-this.s.t)<1e-10)this.history[this.history.length-1]={...this.s};else this.history.push({...this.s});}
    branch(){if(this.s.t<this.end-1e-10)this.history=this.history.filter(s=>s.t<this.s.t-1e-10);this.record();}
    setLive(key,value){
      if(!['F','muS','muK','angle'].includes(key)||!Number.isFinite(value)||
        ['muS','muK'].includes(key)&&value<0||
        key==='angle'&&(this.model!=='incline'||Math.abs(value)>60))throw new Error('Réglage non valide.');
      // Quasi-static slope setting: preserve tangential state; neglect the
      // support's rotational inertia effects and actuator work. Each recorded
      // angle belongs to its own segment, including when revisiting the past.
      this.branch();this.s[key]=value;
      if(key==='muS')this.s.muK=Math.min(this.s.muK,value);
      if(key==='muK')this.s.muK=Math.min(this.s.muK,this.s.muS);
      if(!this.started){this.p.F=this.s.F;this.p.muS=this.s.muS;this.p.muK=this.s.muK;this.p.angle=this.s.angle;}
      this.record();
    }
    advance(dt){
      if(!Number.isFinite(dt)||dt<0)throw new Error('Pas de temps non valide.');
      if(this.done||dt===0)return this.snapshot();
      this.branch();this.started=true;
      const end=Math.min(this.p.duration,this.s.t+dt);
      let guard=0;
      while(this.s.t<end-1e-12&&!this.s.edge){
        if(++guard>100000)throw new Error('Trop de segments de contact.');
        const s=this.s,p=this.p,q=forces(this.model,p,s),relativeA=q.a1-q.a2;
        let h=Math.min(1/120,end-s.t),stopTime=Infinity,edge=false;
        if(q.mode==='kinetic'&&q.relative*relativeA<0){stopTime=-q.relative/relativeA;h=Math.min(h,stopTime);}
        if(this.model==='stack'){
          const t=supportTime(s.x1-s.x2,q.relative,relativeA,h);
          if(t<=h+1e-12){h=Math.min(h,t);edge=true;}
        }
        const dx1=s.v1*h+.5*q.a1*h*h,dx2=s.v2*h+.5*q.a2*h*h;
        s.x1+=dx1;s.x2+=dx2;s.v1+=q.a1*h;s.v2+=q.a2*h;
        s.W1+=q.f*dx1;s.W2+=this.model==='stack'?-q.f*dx2:0;
        s.WA+=s.F*(this.model==='stack'?dx2:dx1);
        if(this.model==='incline')s.WG-=p.m1*g*Math.sin(s.angle*Math.PI/180)*dx1;
        s.Q+=q.mode==='kinetic'?Math.max(0,-q.f*(dx1-dx2)):0;
        s.t+=h;s.edge=edge;
        if(Math.abs(h-stopTime)<1e-12||q.mode==='static'){
          if(this.model!=='stack')s.v1=0;
          else {const v=(p.m1*s.v1+p.m2*s.v2)/(p.m1+p.m2);s.v1=v;s.v2=v;}
        }
        this.record();
      }
      if(!this.s.edge&&Math.abs(this.s.t-end)<1e-9){this.s.t=end;this.record();}
      return this.snapshot();
    }
    seek(t){
      if(!Number.isFinite(t))throw new Error('Instant non valide.');
      t=Math.max(0,Math.min(this.end,t));let lo=0,hi=this.history.length-1;
      while(hi-lo>1){const mid=(lo+hi)>>1;if(this.history[mid].t<=t)lo=mid;else hi=mid;}
      const a=this.history[lo],b=this.history[hi],u=b.t===a.t?0:(t-a.t)/(b.t-a.t),h=t-a.t,q=forces(this.model,this.p,a);
      if(u>=1-1e-10){this.s={...b,t};return this.snapshot();}
      // Reconstruct each constant-acceleration segment, including exact work.
      const dx1=a.v1*h+.5*q.a1*h*h,dx2=a.v2*h+.5*q.a2*h*h;
      this.s={...a,t,x1:a.x1+dx1,x2:a.x2+dx2,v1:a.v1+q.a1*h,v2:a.v2+q.a2*h,W1:a.W1+q.f*dx1,W2:a.W2+(this.model==='stack'?-q.f*dx2:0),WA:a.WA+a.F*(this.model==='stack'?dx2:dx1),WG:a.WG-(this.model==='incline'?this.p.m1*g*Math.sin(a.angle*Math.PI/180)*dx1:0),Q:a.Q+(q.mode==='kinetic'?Math.max(0,-q.f*(dx1-dx2)):0),edge:false};
      return this.snapshot();
    }
  }
  return {g,forces,Simulation,presets,supportLimit};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=FrictionPhysics;
