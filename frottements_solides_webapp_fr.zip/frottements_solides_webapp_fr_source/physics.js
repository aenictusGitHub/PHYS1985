var physTranslate = globalThis.PhysLang?.t || (value => value);
/* Coulomb contact with exact constant-acceleration segments and stop events.
 * No viscous regularization: sticking is a constraint, not a small sliding speed. */
const FrictionPhysics=(()=>{
  'use strict';
  const g=9.81,eps=1e-10,supportLimit=2.4;
  const presets={
    horizontal:{held:{angle:0,m1:2,m2:3,muS:.5,muK:.3,F:4,v0:0},pushed:{angle:0,m1:2,m2:3,muS:.5,muK:.3,F:15,v0:0},slowing:{angle:0,m1:2,m2:3,muS:.5,muK:.3,F:0,v0:2}},
    incline:{rest:{angle:20,m1:2,m2:3,muS:.5,muK:.3,F:0,v0:0},slide:{angle:35,m1:2,m2:3,muS:.5,muK:.3,F:0,v0:0},launch:{angle:20,m1:2,m2:3,muS:.5,muK:.3,F:0,v0:2},horizontal:{angle:0,m1:2,m2:3,muS:.5,muK:.3,F:4,v0:0}},
    stack:{stick:{angle:0,m1:1,m2:3,muS:.5,muK:.3,F:6,v0:0},slide:{angle:0,m1:1,m2:3,muS:.5,muK:.3,F:24,v0:0},brake:{angle:0,m1:1,m2:3,muS:.5,muK:.3,F:-6,v0:2}},
  };
  function forces(model,p,s){
    const single=model!=='stack',theta=model==='incline'?s.angle*Math.PI/180:0,N=p.m1*g*Math.cos(theta),limit=s.muS*N;
    const relative=single?s.v1:s.v1-s.v2;
    const drive=single?s.F-p.m1*g*Math.sin(theta):-s.F/p.m2;
    const required=single?-drive:p.m1*s.F/(p.m1+p.m2);
    const sticking=Math.abs(relative)<eps&&Math.abs(required)<=limit+1e-11;
    const f=sticking?required:-s.muK*N*Math.sign(Math.abs(relative)>=eps?relative:drive);
    const a1=single?(drive+f)/p.m1:f/p.m1;
    const a2=single?0:(s.F-f)/p.m2;
    return {N,limit,required,f,a1,a2,relative,mode:sticking?'static':'kinetic'};
  }
  // Earliest positive crossing of either full-support boundary, if any.
  function supportTime(d,u,a,maxTime){
    let best=Infinity;
    for(const target of [-supportLimit,supportLimit]){
      const c=d-target;
      if(Math.abs(a)<1e-12){if(Math.abs(u)>eps){const t=-c/u;if(t>1e-11&&t<=maxTime+1e-11)best=Math.min(best,t);}}
      else {const disc=u*u-2*a*c;if(disc>=0)for(const t of [(-u-Math.sqrt(disc))/a,(-u+Math.sqrt(disc))/a])if(t>1e-11&&t<=maxTime+1e-11)best=Math.min(best,t);}
    }
    return best;
  }
  class Simulation {
    constructor(model='incline',parameters={}){
      if(!Object.hasOwn(presets,model))throw new Error(physTranslate('Système inconnu.'));
      this.model=model;this.p={...Object.values(presets[model])[0],duration:8,...parameters};
      const p=this.p;
      if(!Object.values(p).every(Number.isFinite)||p.m1<=0||p.m2<=0||p.duration<=0||Math.abs(p.angle)>60||p.muS<0||p.muK<0||p.muK>p.muS)throw new Error(physTranslate('Paramètres physiques non valides.'));
      if(model==='horizontal')p.angle=0;
      this.s={t:0,x1:0,x2:0,v1:p.v0,v2:model==='stack'?p.v0:0,F:p.F,muS:p.muS,muK:p.muK,angle:p.angle,W1:0,W2:0,WA:0,WG:0,Q:0,edge:false};
      this.K0=.5*p.m1*this.s.v1**2+.5*p.m2*this.s.v2**2;
      this.history=[{...this.s}];this.started=false;
    }
    snapshot(s=this.s){const q=forces(this.model,this.p,s),K=.5*this.p.m1*s.v1**2+.5*this.p.m2*s.v2**2;return {...s,...q,K,balance:K-this.K0-s.WA-s.WG-s.W1-s.W2};}
    get end(){return this.history[this.history.length-1].t;}
    get done(){return this.s.edge||this.s.t>=this.p.duration-1e-9;}
    record(){if(this.history.length&&Math.abs(this.end-this.s.t)<1e-10)this.history[this.history.length-1]={...this.s};else this.history.push({...this.s});}
    branch(){if(this.s.t<this.end-1e-10)this.history=this.history.filter(s=>s.t<this.s.t-1e-10);this.record();}
    setLive(key,value){
      if(!['F','muS','muK','angle'].includes(key)||!Number.isFinite(value)||
        ['muS','muK'].includes(key)&&value<0||
        key==='angle'&&(this.model!=='incline'||Math.abs(value)>60))throw new Error(physTranslate('Réglage non valide.'));
      // Quasi-static slope setting: preserve tangential state; neglect the
      // support's rotational inertia effects and actuator work. Each recorded
      // angle belongs to its own segment, including when revisiting the past.
      this.branch();this.s[key]=value;
      if(key==='muS')this.s.muK=Math.min(this.s.muK,value);
      if(key==='muK')this.s.muK=Math.min(this.s.muK,this.s.muS);
      if(!this.started){this.p.F=this.s.F;this.p.muS=this.s.muS;this.p.muK=this.s.muK;this.p.angle=this.s.angle;}
      this.record();
    }
    advance(dt){
      if(!Number.isFinite(dt)||dt<0)throw new Error(physTranslate('Pas de temps non valide.'));
      if(this.done||dt===0)return this.snapshot();
      this.branch();this.started=true;
      const end=Math.min(this.p.duration,this.s.t+dt);
      let guard=0;
      while(this.s.t<end-1e-12&&!this.s.edge){
        if(++guard>100000)throw new Error(physTranslate('Trop de segments de contact.'));
        const s=this.s,p=this.p,q=forces(this.model,p,s),relativeA=q.a1-q.a2;
        let h=Math.min(1/120,end-s.t),stopTime=Infinity,edge=false;
        if(q.mode==='kinetic'&&q.relative*relativeA<0){stopTime=-q.relative/relativeA;h=Math.min(h,stopTime);}
        if(this.model==='stack'){
          const t=supportTime(s.x1-s.x2,q.relative,relativeA,h);
          if(t<=h+1e-12){h=Math.min(h,t);edge=true;}
        }
        const dx1=s.v1*h+.5*q.a1*h*h,dx2=s.v2*h+.5*q.a2*h*h;
        s.x1+=dx1;s.x2+=dx2;s.v1+=q.a1*h;s.v2+=q.a2*h;
        s.W1+=q.f*dx1;s.W2+=this.model==='stack'?-q.f*dx2:0;
        s.WA+=s.F*(this.model==='stack'?dx2:dx1);
        if(this.model==='incline')s.WG-=p.m1*g*Math.sin(s.angle*Math.PI/180)*dx1;
        s.Q+=q.mode==='kinetic'?Math.max(0,-q.f*(dx1-dx2)):0;
        s.t+=h;s.edge=edge;
        if(Math.abs(h-stopTime)<1e-12||q.mode==='static'){
          if(this.model!=='stack')s.v1=0;
          else {const v=(p.m1*s.v1+p.m2*s.v2)/(p.m1+p.m2);s.v1=v;s.v2=v;}
        }
        this.record();
      }
      if(!this.s.edge&&Math.abs(this.s.t-end)<1e-9){this.s.t=end;this.record();}
      return this.snapshot();
    }
    seek(t){
      if(!Number.isFinite(t))throw new Error(physTranslate('Instant non valide.'));
      t=Math.max(0,Math.min(this.end,t));let lo=0,hi=this.history.length-1;
      while(hi-lo>1){const mid=(lo+hi)>>1;if(this.history[mid].t<=t)lo=mid;else hi=mid;}
      const a=this.history[lo],b=this.history[hi],u=b.t===a.t?0:(t-a.t)/(b.t-a.t),h=t-a.t,q=forces(this.model,this.p,a);
      if(u>=1-1e-10){this.s={...b,t};return this.snapshot();}
      // Reconstruct each constant-acceleration segment, including exact work.
      const dx1=a.v1*h+.5*q.a1*h*h,dx2=a.v2*h+.5*q.a2*h*h;
      this.s={...a,t,x1:a.x1+dx1,x2:a.x2+dx2,v1:a.v1+q.a1*h,v2:a.v2+q.a2*h,W1:a.W1+q.f*dx1,W2:a.W2+(this.model==='stack'?-q.f*dx2:0),WA:a.WA+a.F*(this.model==='stack'?dx2:dx1),WG:a.WG-(this.model==='incline'?this.p.m1*g*Math.sin(a.angle*Math.PI/180)*dx1:0),Q:a.Q+(q.mode==='kinetic'?Math.max(0,-q.f*(dx1-dx2)):0),edge:false};
      return this.snapshot();
    }
  }
  // A reproducible experiment, deliberately restricted to a horizontal body
  // released from rest and a nonnegative monotone force ramp. The solution is
  // analytic: it does not depend on requestAnimationFrame or the playback rate.
  class RampSimulation extends Simulation {
    constructor(parameters={},peak=15,rise=5){
      super('horizontal',{...parameters,F:0,v0:0});
      if(!Number.isFinite(peak)||peak<0||peak>60||!Number.isFinite(rise)||rise<=0||rise>this.p.duration)throw new Error(physTranslate('Rampe non valide.'));
      this.ramp={peak,rise};
      this.thresholdTime=peak>this.p.muS*this.p.m1*g?this.p.muS*this.p.m1*g*rise/peak:Infinity;
      this.s=this.sampleAt(0);this.history=[{...this.s}];
    }
    sampleAt(time,side='right'){
      const t=Math.max(0,Math.min(this.p.duration,time)),p=this.p,{peak,rise}=this.ramp;
      const F=peak*Math.min(1,t/rise),tc=this.thresholdTime;
      const sliding=Number.isFinite(tc)&&(t>tc+1e-12||Math.abs(t-tc)<=1e-12&&side==='right');
      let x=0,v=0,WA=0;
      if(sliding){
        const rate=peak/rise,limit=p.muS*p.m1*g,a0=(p.muS-p.muK)*g,j=rate/p.m1;
        const q=Math.max(0,Math.min(t,rise)-tc);
        x=.5*a0*q*q+j*q**3/6;v=a0*q+.5*j*q*q;
        // Independent integral of (limit + rate*q) * v(q), not inferred
        // from kinetic energy, so the work-energy residual remains a check.
        WA=limit*a0*q*q/2+(limit*j/2+rate*a0)*q**3/3+rate*j*q**4/8;
        if(t>rise){const h=t-rise,a=(peak-p.muK*p.m1*g)/p.m1,dx=v*h+.5*a*h*h;x+=dx;v+=a*h;WA+=peak*dx;}
      }
      const W1=-p.muK*p.m1*g*x;
      return {t,x1:x,x2:0,v1:v,v2:0,F,muS:p.muS,muK:p.muK,angle:0,W1,W2:0,WA,WG:0,Q:-W1,edge:false,rampSliding:sliding};
    }
    snapshot(s=this.s){
      const result=super.snapshot(s);
      if(s.rampSliding){
        // The right-hand limit at release has kinetic friction even though
        // the velocity is still zero at that exact transition instant.
        result.f=-s.muK*result.N;result.a1=(s.F+result.f)/this.p.m1;result.mode='kinetic';
      }
      return result;
    }
    setLive(){throw new Error(physTranslate('La rampe est programmée : recommencez avec les nouveaux paramètres ou choisissez la commande manuelle.'));}
    advance(dt){
      if(!Number.isFinite(dt)||dt<0)throw new Error(physTranslate('Pas de temps non valide.'));
      if(this.done||dt===0)return this.snapshot();
      this.branch();this.started=true;
      const start=this.s.t,end=Math.min(this.p.duration,start+dt),tc=this.thresholdTime,times=[end];
      for(let i=Math.floor((start+1e-10)*120)+1;i/120<end-1e-10;i++)times.push(i/120);
      if(start<this.ramp.rise&&this.ramp.rise<end)times.push(this.ramp.rise);
      if(start<tc&&tc<=end)times.push(tc);
      const sorted=[...new Set(times)].filter(t=>t===tc||Math.abs(t-tc)>1e-10).sort((a,b)=>a-b);
      for(const t of sorted){
        if(t===tc&&start<tc)this.history.push(this.sampleAt(t,'left'));
        this.s=this.sampleAt(t);this.history.push({...this.s});
      }
      return this.snapshot();
    }
    seek(t){
      if(!Number.isFinite(t))throw new Error(physTranslate('Instant non valide.'));
      this.s=this.sampleAt(Math.max(0,Math.min(this.end,t)));return this.snapshot();
    }
  }
  return {g,forces,Simulation,RampSimulation,presets,supportLimit};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=FrictionPhysics;
