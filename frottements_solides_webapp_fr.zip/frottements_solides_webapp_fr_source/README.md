# Frottements solides — PHYS1985

Application intégrée au catalogue PHYS1985, publication autorisée le 8 septembre 2026.
[Ouvrir l’animation](https://aenictusgithub.github.io/PHYS1985/frottements_solides_webapp_fr.html).
Les QR codes PNG et SVG sont disponibles dans le dossier `qr-codes/` du dépôt.

Ouvrir `frottements_solides_webapp_fr.html` pour la version autonome, ou
`index.html` pour la version source. MathJax et le thème sont locaux : aucun
serveur ou accès Internet n’est nécessaire. La licence MathJax est conservée
dans `vendor/mathjax/LICENSE.txt`.

## Les trois expériences

### Surface horizontale immobile

- Cas affiché à l’ouverture : un corps sur une surface rugueuse, avec une
  force extérieure horizontale réglable en direct de -40 à +40 N.
- Axe positif vers la droite ; N = m g et m a = F_app,x + f.
- Au repos : f = -F_app,x tant que |F_app,x| <= mu_s m g. Au-delà,
  le glissement commence avec |f| = mu_k m g, opposé au mouvement.
- Retirer la force pendant le mouvement laisse le frottement freiner le
  corps jusqu’à l’arrêt ; il ne le fait pas repartir dans l’autre sens.
- Trois exemples : repos sous une force (4 N), mise en glissement (15 N)
  et freinage sans force appliquée (v_0 = 2 m/s), pour m = 2 kg,
  mu_s = 0.5 et mu_k = 0.3.
- La surface est infinie et le cadre suit le corps sans changer son échelle.
  Angle et deuxième masse sont masqués. W_g = 0, Q = -W_f et
  delta(K) = W_app + W_f.
- Le graphique f_x(t) est sélectionné automatiquement pour ce système,
  avec les limites +mu_s N et -mu_s N en pointillés. Le curseur de force
  permet de modifier l’expérience en cours sans réinitialiser l’historique.

### Plan incliné, angle réglable en direct

- Axe positif le long du plan vers la droite ; force appliquée parallèle et signée.
  Angle positif : le plan monte vers la droite ; angle négatif : il descend.
- Réaction normale N = m g cos(theta).
- Au repos : f = -(F_app,x - m g sin(theta)) si sa valeur absolue ne dépasse
  pas mu_s N. Le frottement statique n’est pas systématiquement maximal.
- En glissement : f = -mu_k N signe(v). Lors d’un arrêt, l’adhérence est
  réévaluée ; si elle n’est pas possible, le glissement reprend dans le sens
  de la force motrice. Le lancement vers le haut peut finir au repos.
- Le plan est supposé infini, sans roulement ni basculement. La vue suit le
  bloc lorsque nécessaire, sans changer son échelle.
- L’angle se règle de -60 à +60 degrés pendant la lecture, sans remise à zéro
  du temps, de la position sur le plan, de la vitesse tangentielle ou des travaux.
  Réaction normale, seuil statique et accélération s’adaptent immédiatement.
- Approximation quasi statique : chaque segment de mouvement est calculé
  comme sur un plan fixe à l’angle courant. Les effets inertiels de rotation
  du support, sa vitesse de rotation et son travail ne sont pas modélisés.
  La vitesse, l’énergie cinétique et les travaux ci-dessous décrivent le
  mouvement relatif au plan, pas le bilan complet dans le laboratoire
  lorsque le support tourne. Le pivot du dessin est un choix de présentation.
- W_f = intégrale(f dx), W_g = -m g intégrale(sin(theta) dx), W_app = intégrale(F dx).
  Q = -W_f et delta(K) = W_app + W_g + W_f.

### Deux blocs empilés

- m_1 désigne le bloc supérieur, m_2 le bloc inférieur. La force horizontale
  agit sur m_2. Le sol est **sans frottement** pour isoler le contact entre blocs.
- N = m_1 g et vitesse relative u = v_1 - v_2.
- Sans glissement : accélération commune a = F/(m_1+m_2), frottement sur m_1
  f = m_1 F/(m_1+m_2), sous la contrainte |f| <= mu_s m_1 g.
- En glissement : f = -mu_k m_1 g signe(u), a_1=f/m_1, a_2=(F-f)/m_2.
- W_f,1 = intégrale(f dx_1), W_f,2 = -intégrale(f dx_2). En adhérence,
  les travaux supplémentaires se compensent mais chacun peut être non nul.
  Le frottement peut accélérer le bloc supérieur dans le laboratoire.
- Q = -(W_f,1+W_f,2), delta(K_total) = W_app+W_f,1+W_f,2.
  Q ne croît que pendant un glissement relatif. Les travaux sont cumulés
  depuis le début, y compris lorsqu’on passe du glissement à l’adhérence.
- La plateforme mesure 6 m, le bloc supérieur 1.2 m. La simulation s’arrête
  à |x_1-x_2|=2.4 m, limite du support **complet**, avant de modéliser une chute
  ou un basculement. Ce n’est pas une loi de déclenchement du basculement.
- Modèle de translation guidée : la répartition de pression et la rotation
  des blocs ne sont pas calculées. Les positions des résultantes de contact
  dans le dessin sont schématiques.

## Commandes

Force, coefficients et angle du plan incliné réglables en direct, sans arrêter
ou recommencer. L’angle courant est enregistré dans chaque segment de
l’historique : revoir le passé restitue la pente et les forces de cet instant.
Le coefficient cinétique est borné par le coefficient statique ; abaisser
ce dernier abaisse aussi le coefficient cinétique si nécessaire.
Masses, vitesse initiale et durée recommencent l’expérience.
Pour les blocs empilés, la vitesse initiale est commune.

Lorsqu’un réglage fait passer le contact de l’adhérence au glissement,
la lecture démarre automatiquement, sans effacer l’historique des réglages
en direct. Modifier le coefficient statique, cinétique ou l’angle démarre également
la lecture, même sans changement de régime. Les exemples initialement en
glissement démarrent aussi dès leur sélection. Un simple rafraîchissement
de la scène, la consultation du passé ou un réglage de force restant
dans le même régime ne relancent pas une animation mise en pause.
Recommencer revient à zéro en pause. Si la durée est écoulée, un nouveau
réglage déclenchant la lecture recommence à zéro avec les paramètres actuels,
comme le bouton Lire ; sans nouveau réglage, la lecture ne boucle pas.
Une limite de support atteinte ou un onglet masqué restent en pause.

Pour un corps seul, « Lancer le bloc » sous l’animation recommence à t = 0
et démarre avec la vitesse initiale choisie, ou 2 m/s si elle est nulle.
Le sens peut être inversé avec une vitesse initiale négative. Les forces,
coefficients et masses restent inchangés. Il s’agit d’une nouvelle condition
initiale : aucun apport d’énergie non comptabilisé pendant une expérience.

« Recommencer » conserve les réglages actuels et remet à zéro temps,
positions et travaux. « Réinitialiser » restaure l’exemple par défaut.
Les exemples incluent l’équilibre, le glissement, le lancement vers le haut,
le plan horizontal, l’entraînement et le freinage puis inversion des blocs.

Le graphique présente les forces de frottement et les limites statiques,
les vitesses ou les travaux. L’historique commence à l’instant initial.
Le frottement et ses limites sont tracés par paliers : un changement
instantané de force ou de régime apparaît comme un saut vertical, pas
comme une rampe fictive entre deux échantillons.
Un clic, un glissement ou les touches gauche/droite, Début/Fin revoient cet
historique. Reprendre dans le passé remplace la suite. L’animation reste en
pause à l’ouverture et se met en pause lorsque l’onglet est masqué.

Les forces partagent une échelle linéaire fixe pour une configuration de
masses, avec une flèche de référence de 10 N. Les vitesses ont une échelle
commune adaptative, indépendante des corps et de la caméra, avec une
référence de 1 m/s. Aucun changement de visibilité ne déplace les corps.
Le curseur « Échelle des vecteurs » multiplie les longueurs des forces et
des vitesses de 0.25 à 4 (facteur initial : 2). Les flèches de référence
suivent le même facteur. Ce réglage visuel agit pendant la lecture, sans
modifier le temps, le mouvement, les travaux ou le graphique ; il est conservé
lorsqu’on recommence ou qu’on change d’exemple.
Tous les nombres et unités utilisent un même alignement LaTeX/SVG ; décimales
avec un point, vecteurs avec une flèche.

## Calcul et vérifications

Accélérations constantes entre événements : intégration analytique des
positions, vitesses et travaux par segments d’au plus 1/120 s. Détection
analytique des arrêts relatifs et de la limite du support. Pas de lissage
visqueux du frottement ni d’oscillations artificielles autour du repos.
Le bilan d’énergie est affiché à zéro sous 1e-7 J, sinon avec six décimales.

Reconstruction locale : `python3 build.py`.
Tests : `node check_physics.cjs` et `node check_ui.cjs`.
Pour les formules réelles : définir `PHYS1985_MATHJAX_ROOT` vers le dossier
`js` de mathjax-full avant le second test.

Les tests couvrent seuil critique, arrêt, inversion, récupération de
l’adhérence, travaux statiques, dissipation, bilan d’énergie, limite du
support, historique, réglages en direct, décimales et alignement numérique.
Le cas horizontal vérifie aussi le seuil statique dans les deux sens, le
freinage jusqu’au repos, la conservation de l’historique lors des changements
de force et la position temporelle des sauts dans f_x(t).
La vérification des commandes utilise un adaptateur DOM/canvas : aucune
vérification visuelle dans un navigateur n’est revendiquée.

Une interface WebMCP optionnelle expose lecture de l’état, choix d’un
exemple et réglages/lecture. Elle utilise les mêmes actions que l’interface,
sans réseau ni stockage. Contrats vérifiés sur l’adaptateur de test ; aucun
contexte WebMCP natif de validation n’était disponible. Les navigateurs non
compatibles conservent l’interface standard.

Références pédagogiques (dessins joints utilisés comme inspiration, non copiés) :

- [OpenStax — Friction](https://openstax.org/books/university-physics-volume-1/pages/6-2-friction)
- [OpenStax — Work](https://openstax.org/books/university-physics-volume-1/pages/7-1-work)
# Rendu des blocs

Les blocs ont un dégradé doux, des bords biseautés et un grain fin. La texture est déterministe et attachée au corps : elle suit sa translation et l’inclinaison, sans clignotement à chaque image. Ce relief reste à l’intérieur de la silhouette initiale ; les contacts, dimensions et coefficients de frottement ne changent pas. L’adaptateur de contrôle vérifie aussi les dégradés et la stabilité de la texture lorsque les options d’affichage changent.

Pour un corps seul, les symboles de masse, forces et vitesse occupent des
emplacements réservés autour du corps. Leur placement tient compte des
dimensions réelles des formules et de tous les sens possibles des vecteurs,
pas seulement de leur longueur courante : même agrandie, une flèche ne
traverse pas un symbole. De fins repères pointillés les
relient au milieu des flèches. Les symboles suivent le corps, sans changer de côté
avec le signe ou la longueur des vecteurs ni avec leur visibilité. Les
graduations masquées par une annotation ou une flèche de force sont omises.
Le plan d’annotations est conservé pendant la lecture et les réglages
visuels. La scène réserve davantage de hauteur lorsque le texte est agrandi.
Tests de séparation entre symboles, tiges et pointes des flèches, avec deux
largeurs, trois tailles de texte, les angles 0, ±20, ±45 et ±60 degrés et les
facteurs 0.25, 2 et 4 ; pas de validation visuelle navigateur revendiquée.
