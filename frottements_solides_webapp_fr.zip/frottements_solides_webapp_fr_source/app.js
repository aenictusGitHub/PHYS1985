if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',startFrictionApp);else startFrictionApp();
async function startFrictionApp(){
  'use strict';
  const $=id=>document.getElementById(id),tex=String.raw,FP=FrictionPhysics;
  try{
    await MathJax.startup.promise;
    const C={body:'#2775b6',body2:'#429b88',f:'#d9683b',F:'#268576',N:'#7758a6',P:'#2775b6',v:'#00869c',ink:'#233449',muted:'#607185',grid:'#dce4ec',heat:'#b5688b'};
    const state={sim:new FP.Simulation(),playing:false,frame:0,last:null,lastReadout:-Infinity,legend:'',vectorScale:2,labelPlan:null,rampPeak:15,rampRise:5},labels=new Map(),glyphs=new Map(),units=new Map();
    const isRamp=()=>state.sim instanceof FP.RampSimulation;
    function makeRamp(p){state.rampRise=Math.min(state.rampRise,p.duration);return new FP.RampSimulation(p,state.rampPeak,state.rampRise);}
    const presetNames={held:'Repos sous une force',pushed:'Mise en glissement',slowing:'Freinage sans force appliquée',rest:'Équilibre sur le plan',slide:'Glissement',launch:'Lancé vers le haut',horizontal:'Plan horizontal : immobile',stick:'Entraînement sans glissement',brake:'Freinage puis inversion sans glissement'};
    function math(el,value){if(el.dataset.math===value)return;el.replaceChildren(MathJax.tex2svg(value,{display:false}));el.dataset.math=value;}
    function part(value){const svg=MathJax.tex2svg(value,{display:false}).querySelector('svg'),[x,y,width,height]=svg.getAttribute('viewBox').split(/\s+/).map(Number);return {svg,x,y,width,height,ex:parseFloat(svg.getAttribute('width'))/width};}
    for(const el of document.querySelectorAll('[data-tex]'))math(el,el.dataset.tex);
    for(const c of '0123456789.-')glyphs.set(c,part(c));
    const top0=Math.min(...[...glyphs.values()].map(g=>g.y)),bottom0=Math.max(...[...glyphs.values()].map(g=>g.y+g.height));
    MathJax.startup.document.updateDocument();
    function number(el,value,digits=3,unit=''){
      if(!Number.isFinite(value))throw new Error('Valeur numérique non finie.');
      const string=(Math.abs(value)<.5*10**-digits?0:value).toFixed(digits),key=string+'|'+unit;if(el.dataset.number===key)return;
      const parts=[...string].map(c=>glyphs.get(c));if(unit){if(!units.has(unit))units.set(unit,part(unit));parts.push(units.get(unit));}
      const svg=parts[0].svg.cloneNode(false),ex=glyphs.get('0').ex;let width=0,top=top0,bottom=bottom0;
      for(const [i,p]of parts.entries()){if(i===string.length)width+=1000/6;const g=document.createElementNS('http://www.w3.org/2000/svg','g');g.setAttribute('transform',`translate(${width-p.x},0)`);g.append(...[...p.svg.children].map(c=>c.cloneNode(true)));svg.append(g);width+=p.width;top=Math.min(top,p.y);bottom=Math.max(bottom,p.y+p.height);}
      svg.setAttribute('viewBox',`0 ${top} ${width} ${bottom-top}`);svg.setAttribute('width',`${width*ex}ex`);svg.setAttribute('height',`${(bottom-top)*ex}ex`);svg.style.verticalAlign=`${-bottom*ex}ex`;svg.setAttribute('role','img');svg.setAttribute('aria-label',string+' '+unit.replace(/\\mathrm|[{}]/g,'').replace(/\\,/g,' '));
      el.classList.add('number');el.replaceChildren(svg);el.dataset.number=key;
    }
    function pause(){state.playing=false;state.last=null;if(state.frame)cancelAnimationFrame(state.frame);state.frame=0;$('play').textContent='Lire';$('play').setAttribute('aria-pressed','false');}
    function play(){if(state.sim.done)restart();state.playing=true;state.sim.started=true;state.last=null;$('play').textContent='Pause';$('play').setAttribute('aria-pressed','true');if(!state.frame)state.frame=requestAnimationFrame(frame);}
    function startAfterChange(previousMode,settingChanged=false){
      // Coefficient and angle edits resume playback without changing regime.
      // Rendering, seeking and explicit pause/restart never start it alone.
      // At the time limit, use Lire's normal restart with the current settings.
      // A physical support limit still requires an explicit restart.
      if((settingChanged||previousMode==='static'&&state.sim.snapshot().mode==='kinetic')&&!state.playing&&!state.sim.s.edge&&!document.hidden)play();
    }
    function changeLive(key,value){
      if(isRamp()){
        if(!['muS','muK'].includes(key))return;
        const p={...state.sim.p,[key]:value};p.muK=Math.min(p.muK,p.muS);
        if(p.muS===state.sim.p.muS&&p.muK===state.sim.p.muK)return;
        pause();state.sim=makeRamp(p);$('preset-select').value='custom';syncControls();render();startAfterChange('static',true);return;
      }
      const previous=state.sim.snapshot();state.sim.setLive(key,value);$('preset-select').value='custom';render();startAfterChange(previous.mode,previous.muS!==state.sim.s.muS||previous.muK!==state.sim.s.muK||previous.angle!==state.sim.s.angle);
    }
    function restart(){pause();const sim=state.sim;state.sim=isRamp()?makeRamp(sim.p):new FP.Simulation(sim.model,{...sim.p,F:sim.s.F,muS:sim.s.muS,muK:sim.s.muK,angle:sim.s.angle});syncControls();render();}
    function configure(model,preset=Object.keys(FP.presets[model])[0]){
      pause();state.sim=new FP.Simulation(model,FP.presets[model][preset]);$('model-select').value=model;
      const options=Object.keys(FP.presets[model]).map(key=>{const el=document.createElement('option');el.value=key;el.textContent=presetNames[key];return el;});
      const custom=document.createElement('option');custom.value='custom';custom.textContent='Réglage personnalisé';options.push(custom);$('preset-select').replaceChildren(...options);$('preset-select').value=preset;
      $('show-normal').checked=model!=='stack';if(model==='horizontal')$('chart-select').value='friction';syncControls();render();startAfterChange('static');
    }
    function syncControls(){
      const sim=state.sim,p=sim.p,stack=sim.model==='stack',horizontal=sim.model==='horizontal';
      const ramp=isRamp();
      $('drive-control').hidden=!horizontal;$('force-mode').value=ramp?'ramp':'manual';$('ramp-settings').hidden=!ramp;
      $('force').disabled=$('zero-force').disabled=$('initial-speed').disabled=ramp;
      $('force').min=ramp?0:-40;$('force').max=ramp?60:40;
      $('ramp-rise').max=p.duration;$('ramp-rise').value=state.rampRise;$('ramp-peak').value=state.rampPeak;
      number($('ramp-peak-value'),state.rampPeak,2,tex`\mathrm N`);number($('ramp-rise-value'),state.rampRise,2,tex`\mathrm s`);
      if(ramp)$('ramp-status').textContent=Number.isFinite(sim.thresholdTime)?'Seuil prévu : '+(p.muS*p.m1*FP.g).toFixed(2)+' N, atteint à '+sim.thresholdTime.toFixed(2)+' s.':'La force finale ne dépasse pas la limite statique : le bloc reste au repos.';
      for(const [id,value]of [['angle',p.angle],['mass-1',p.m1],['mass-2',p.m2],['initial-speed',p.v0],['duration',p.duration]])$(id).value=value;
      $('angle-control').hidden=sim.model!=='incline';$('mass-2-control').hidden=!stack;$('second-velocity').hidden=!stack;
      $('launch-control').hidden=stack||ramp;
      $('mass-1-name').textContent=stack?'Masse du corps supérieur':'Masse';math($('mass-1-symbol'),stack?'m_1':'m');$('speed-name').textContent=stack?'Vitesse initiale commune':'Vitesse initiale';
      $('scene-title').textContent=stack?'Deux corps empilés':horizontal?'Corps sur une surface horizontale':'Corps sur un plan incliné';
      $('model-note').textContent=stack?'La force agit sur le bloc inférieur. Le sol est sans frottement ; seul le contact entre les deux blocs est rugueux.':horizontal?'Un corps repose sur une surface rugueuse immobile. Faites varier la force extérieure pendant la lecture pour passer de l’adhérence au glissement.':'Faites varier l’angle pendant la lecture pour passer de l’équilibre au glissement. Le mouvement est mesuré parallèlement au plan.';
      $('force-note').textContent=stack?'Positive vers la droite, appliquée au corps inférieur.':horizontal?'Positive vers la droite, négative vers la gauche. Le curseur agit immédiatement, sans remettre le temps à zéro.':'Force parallèle au plan : positive dans le sens +x, vers la droite ; négative dans le sens opposé.';
      if(ramp)$('force-note').textContent='Force imposée par la rampe ; sa valeur instantanée est affichée ici. Pour la régler librement, choisissez la commande manuelle.';
      math($('model-equation'),stack?tex`N=m_1g,\quad v_{\mathrm{rel}}=v_1-v_2`:horizontal?tex`N=mg,\quad v_{\mathrm{rel}}=v`:tex`N=mg\cos\theta,\quad v_{\mathrm{rel}}=v`);
      math($('motion-equation'),stack?tex`m_1a_1=f,\quad m_2a_2=F_{\mathrm{app},x}-f`:horizontal?tex`ma=F_{\mathrm{app},x}+f`:tex`ma=F_{\mathrm{app},x}-mg\sin\theta+f`);
      math($('work-equation'),stack?tex`W_{f,1}=\int f\,\mathrm dx_1,\quad W_{f,2}=-\int f\,\mathrm dx_2`:tex`W_f=\int f\,\mathrm dx,\quad Q=-W_f`);
      math($('position-symbol'),stack?tex`x_2=`:tex`x=`);math($('velocity-symbol'),stack?tex`v_1=`:tex`v=`);
      math($('friction-symbol'),stack?tex`f_{2\to1,x}`:'f_x');math($('work-1-symbol'),stack?tex`W_{f,1}`:'W_f');math($('work-2-symbol'),stack?tex`W_{f,2}`:tex`W_{\mathrm{app}}`);
      $('friction-detail').textContent=stack?'frottement sur le corps supérieur':horizontal?'force de frottement suivant x':'frottement le long du plan';$('work-1-detail').textContent=stack?'travail sur le corps supérieur':'travail du frottement';$('work-2-detail').textContent=stack?'travail sur le corps inférieur':'travail de la force appliquée';
      $('scene-note').textContent=stack?'Le cadre suit le bloc inférieur quand il s’éloigne. Le modèle s’arrête à la limite du support complet, avant tout basculement.':horizontal?'Surface considérée comme infinie ; le cadre suit le corps quand il s’éloigne. Le sens positif est dirigé vers la droite.':'Plan infini, sens +x le long du plan vers la droite. Vitesses et travaux décrivent le mouvement relatif au plan ; la rotation du support et son travail ne sont pas modélisés.';
      state.legend='';
    }
    function surface(id){const canvas=$(id),r=canvas.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1),ctx=canvas.getContext('2d');if(canvas.width!==Math.round(r.width*dpr)||canvas.height!==Math.round(r.height*dpr)){canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,r.width,r.height);return {ctx,w:r.width,h:r.height};}
    function line(ctx,points,color,width=1,dash=[]){if(!points.length)return;ctx.beginPath();ctx.moveTo(...points[0]);for(const p of points.slice(1))ctx.lineTo(...p);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.setLineDash(dash);ctx.stroke();ctx.setLineDash([]);}
    function polygon(ctx,points,fill,stroke,width=1.5,dash=[]){ctx.beginPath();ctx.moveTo(...points[0]);for(const p of points.slice(1))ctx.lineTo(...p);ctx.closePath();if(fill){ctx.fillStyle=fill;ctx.fill();}ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.setLineDash(dash);ctx.stroke();ctx.setLineDash([]);}
    function dot(ctx,x,y,r,color){ctx.beginPath();ctx.arc(x,y,r,0,2*Math.PI);ctx.fillStyle=color;ctx.fill();}
    function arrow(ctx,a,b,color,width=2.5){const dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);if(length<1e-8)return;const ux=dx/length,uy=dy/length,head=Math.min(8,length*.4);line(ctx,[a,b],color,width);line(ctx,[[b[0]-head*ux-head*.48*uy,b[1]-head*uy+head*.48*ux],b,[b[0]-head*ux+head*.48*uy,b[1]-head*uy-head*.48*ux]],color,width);}
    function label(layer,key,value,x,y,color=C.ink,tick=false){let el=labels.get(layer+key);if(!el){el=document.createElement('span');$(layer).append(el);labels.set(layer+key,el);}el.hidden=false;el.dataset.labelKey=key;el.className='plot-label'+(tick?' tick':'');math(el,value);el.style.left=x+'px';el.style.top=y+'px';el.style.color=color;el.style.transform='translate(-50%,-50%)';return el;}
    function numericLabel(layer,key,value,x,y,digits=0,unit=''){
      let el=labels.get(layer+key);if(!el){el=document.createElement('span');$(layer).append(el);labels.set(layer+key,el);}
      el.hidden=false;el.className='plot-label tick';el.style.left=x+'px';el.style.top=y+'px';el.style.color=C.muted;number(el,value,digits,unit);
    }
    function segmentHitsBox(a,b,r){
      let lo=0,hi=1;
      for(const [axis,min,max]of [[0,r.left,r.right],[1,r.top,r.bottom]]){
        const d=b[axis]-a[axis];
        if(Math.abs(d)<1e-10){if(a[axis]<min||a[axis]>max)return false;}
        else {const t1=(min-a[axis])/d,t2=(max-a[axis])/d;lo=Math.max(lo,Math.min(t1,t2));hi=Math.min(hi,Math.max(t1,t2));if(lo>hi)return false;}
      }
      return true;
    }
    function planSingleLabels(w,h,scale,theta,font){
      const signature=[w,h,scale,theta,font].join('|');if(state.labelPlan?.signature===signature)return state.labelPlan.slots;
      const cx=w/2,cy=h*.61,c=Math.cos(theta),s=Math.sin(theta),O=(x,n)=>[cx+scale*(x*c-n*s),cy-scale*(x*s+n*c)];
      const specs={mass:'m',F:tex`\vec F_{\mathrm{app}}`,N:tex`\vec N`,P:tex`m\vec g`,f:tex`\vec f`,v1:tex`\vec v`},sizes={};
      for(const [key,value]of Object.entries(specs)){const el=label('scene-labels',key,value,0,0),r=el.getBoundingClientRect();sizes[key]={w:r.width,h:r.height};el.hidden=true;}
      const corners=[O(-.45,0),O(.45,0),O(.45,.8),O(-.45,.8)],body={left:Math.min(...corners.map(p=>p[0])),right:Math.max(...corners.map(p=>p[0])),top:Math.min(...corners.map(p=>p[1])),bottom:Math.max(...corners.map(p=>p[1]))};
      const row=Math.max(32,font*2.2),gap=Math.max(18,font),shiftX=.65*scale*Math.abs(c),shiftY=.65*scale*Math.abs(s),upper=Math.max(body.top-row*.7,font+shiftY+row*2);
      // Reserve full direction corridors, not just the current arrow lengths:
      // force reversal, speed changes and the scale slider cannot move labels.
      const reach=4*Math.hypot(w,h),corridors=[];
      for(const n of [0,.45,1.05]){const a=O(0,n);corridors.push([[a[0]-reach*c,a[1]+reach*s],[a[0]+reach*c,a[1]-reach*s]]);}
      const normal=O(0,0),weight=O(0,.4);corridors.push([normal,[normal[0]-reach*s,normal[1]-reach*c]],[weight,[weight[0],weight[1]+reach]]);
      const expand=(r,x,y=x)=>({left:r.left-x,right:r.right+x,top:r.top-y,bottom:r.bottom+y});
      const intersects=(a,b)=>a.left<b.right&&a.right>b.left&&a.top<b.bottom&&a.bottom>b.top;
      const occupied=[expand(body,8),
        expand({left:0,right:145,top:0,bottom:62},shiftX,shiftY),
        expand({left:w-140,right:w,top:0,bottom:75},shiftX,shiftY),
        expand({left:0,right:115,top:h-100,bottom:h},shiftX,shiftY),
        expand({left:w-135,right:w,top:h-68,bottom:h},shiftX,shiftY)];
      const desired={
        mass:[body.left-gap-sizes.mass.w/2,upper],
        N:[body.right+gap+sizes.N.w/2,upper],
        F:[body.right+gap+sizes.F.w/2,upper-row],
        v1:[body.left-gap-sizes.v1.w/2,upper-row],
        f:[body.left-gap-sizes.f.w/2,body.bottom+row*.7],
        P:[body.right+gap+sizes.P.w/2,body.bottom+row*.7]};
      const slots={};
      for(const key of ['F','v1','P','N','f','mass']){
        const size=sizes[key],wanted=desired[key],candidates=[wanted],step=8;
        for(let y=font+shiftY;y<=h-font-shiftY;y+=step)for(let x=8+shiftX+size.w/2;x<=w-8-shiftX-size.w/2;x+=step)candidates.push([x,y]);
        let best=null,score=Infinity;
        for(const [x,y]of candidates){
          const r={left:x-size.w/2,right:x+size.w/2,top:y-size.h/2,bottom:y+size.h/2},clear=expand(r,9);
          if(r.left<8+shiftX||r.right>w-8-shiftX||r.top<8+shiftY||r.bottom>h-8-shiftY||occupied.some(b=>intersects(expand(r,6),b))||corridors.some(([a,b])=>segmentHitsBox(a,b,clear)))continue;
          const cost=(x-wanted[0])**2+(y-wanted[1])**2;
          if(cost<score){score=cost;best={x,y,w:size.w,h:size.h};}
        }
        // Very small/custom-font surfaces may need a more distant label, but
        // never silently fall back onto an arrow.
        if(!best)throw new Error('Agrandissez la fenêtre pour afficher toutes les annotations.');
        slots[key]=best;occupied.push({left:best.x-size.w/2,right:best.x+size.w/2,top:best.y-size.h/2,bottom:best.y+size.h/2});
      }
      state.labelPlan={signature,slots};return slots;
    }
    function drawScene(s){
      const {ctx,w,h}=surface('scene-canvas'),sim=state.sim,p=sim.p,stack=sim.model==='stack',theta=sim.model==='incline'?s.angle*Math.PI/180:0;
      for(const el of $('scene-labels').children)el.hidden=true;
      const scale=Math.min(w/10.5,h/5.6),cx=w/2,cy=h*.61,follow=stack?s.x2:s.x1,camera=Math.sign(follow)*Math.max(0,Math.abs(follow)-.65);
      const P=(x,n=0)=>[cx+scale*((x-camera)*Math.cos(theta)-n*Math.sin(theta)),cy-scale*((x-camera)*Math.sin(theta)+n*Math.cos(theta))];
      const tag=(key,value,x,y,color=C.ink)=>label('scene-labels',key,value,Math.max(38,Math.min(w-38,x)),Math.max(17,Math.min(h-17,y)),color);
      const font=parseFloat(window.getComputedStyle($('scene-labels')).fontSize)||15;
      const slots=stack?null:planSingleLabels(w,h,scale,theta,font),shiftX=scale*(s.x1-camera)*Math.cos(theta),shiftY=-scale*(s.x1-camera)*Math.sin(theta);
      const singleArrows=[];
      // Keep the two contact-force captions off the blocks and in separate
      // rows. Reserve the entire upper row even when f=0 or forces are hidden:
      // changing force direction/scale must not swap or jump these symbols.
      let stackSlots;
      if(stack){
        const sizes={};
        for(const [key,value]of [['m1','m_1'],['f1',tex`\vec f_{2\to1}`],['f2',tex`\vec f_{1\to2}`],['F',tex`\vec F_{\mathrm{app}}`]]){
          const el=label('scene-labels',key,value,0,0),r=el.getBoundingClientRect();
          sizes[key]={w:r.width,h:r.height};el.hidden=true;
        }
        const gap=Math.max(14,font),top=P(s.x1,1.45),a=sizes.m1,b=sizes.f1;
        const total=a.w+gap+b.w,left=Math.max(8,Math.min(w-8-total,top[0]-a.w-gap/2));
        const row=top[1]-Math.max(a.h,b.h)/2-Math.max(12,font*.6);
        stackSlots={
          m1:{x:left+a.w/2,y:row,...a},
          f1:{x:left+a.w+gap+b.w/2,y:row,...b},
          f2:{x:Math.max(8+sizes.f2.w/2,Math.min(w-8-sizes.f2.w/2,P(s.x1,0)[0])),y:cy+.8*scale+sizes.f2.h/2+gap,...sizes.f2},
          // A separate upper lane also keeps the applied-force caption clear
          // of m2 when the arrow points left or has a very short shaft.
          F:{x:Math.max(8+sizes.F.w/2,Math.min(w-8-sizes.F.w/2,P(s.x2+2.4,0)[0])),y:row-Math.max(a.h,b.h)/2-gap-sizes.F.h/2,...sizes.F},
        };
      }
      function stackContactTag(key,value,color,target){
        const slot=stackSlots[key];label('scene-labels',key,value,slot.x,slot.y,color);
        if(target){
          const dx=target[0]-slot.x,dy=target[1]-slot.y,r=Math.max(Math.abs(dx)/(slot.w/2+6),Math.abs(dy)/(slot.h/2+6),1);
          ctx.save();ctx.globalAlpha=.32;line(ctx,[target,[slot.x+dx/r,slot.y+dy/r]],color,1,[2,3]);ctx.restore();
        }
      }
      function singleTag(key,value,color,target){
        const slot=slots[key],x=slot.x+shiftX,y=slot.y+shiftY;label('scene-labels',key,value,x,y,color);
        if(target){
          const dx=target[0]-x,dy=target[1]-y,r=Math.max(Math.abs(dx)/(slot.w/2+6),Math.abs(dy)/(slot.h/2+6),1),end=[x+dx/r,y+dy/r];
          ctx.save();ctx.globalAlpha=.32;line(ctx,[target,end],color,1,[2,3]);ctx.restore();
        }
      }
      const rect=(x,n,width,height,fill,stroke,dash=[])=>polygon(ctx,[P(x-width/2,n),P(x+width/2,n),P(x+width/2,n+height),P(x-width/2,n+height)],fill,stroke,1.5,dash);
      function texturedBlock(x,n,width,height,second=false){
        const left=x-width/2,right=x+width/2,top=n+height,edge=second?C.body2:C.body;
        const face=ctx.createLinearGradient(...P(left,top),...P(right,n));
        for(const [offset,color]of (second?[[0,'#def3ec'],[.4,'#b2dfd4'],[1,'#7eb7a7']]:[[0,'#b6d9ee'],[.4,'#75b4df'],[1,'#4b87b2']]))face.addColorStop(offset,color);
        rect(x,n,width,height,face,edge);
        // Fine, deterministic grain in body coordinates: it follows translation
        // and inclination instead of shimmering between animation frames.
        ctx.save();ctx.beginPath();ctx.moveTo(...P(left,n));ctx.lineTo(...P(right,n));ctx.lineTo(...P(right,top));ctx.lineTo(...P(left,top));ctx.closePath();ctx.clip();
        ctx.beginPath();
        for(let ix=0;ix<Math.ceil(width/.13);ix++)for(let iy=0;iy<Math.ceil(height/.13);iy++){
          const jitter=((ix*37+iy*61+ix*iy*7)%97)/97,grainX=left+.055+ix*.13+jitter*.025,grainY=n+.04+iy*.13+jitter*.03;
          if(grainX+.022<right-.03&&grainY+.01<top-.03){ctx.moveTo(...P(grainX,grainY));ctx.lineTo(...P(grainX+.016+jitter*.013,grainY+.008));}
        }
        ctx.strokeStyle='rgba(35,52,73,.14)';ctx.lineWidth=.8;ctx.stroke();
        const bevel=Math.min(.055,width*.1,height*.1);
        polygon(ctx,[P(left,n),P(left,top),P(right,top),P(right-bevel,top-bevel),P(left+bevel,top-bevel),P(left+bevel,n+bevel)],'rgba(255,255,255,.22)','transparent',0);
        polygon(ctx,[P(left,n),P(right,n),P(right,top),P(right-bevel,top-bevel),P(right-bevel,n+bevel),P(left+bevel,n+bevel)],'rgba(35,52,73,.13)','transparent',0);
        ctx.restore();
      }
      ctx.save();ctx.beginPath();ctx.rect(0,0,w,h);ctx.clip();
      const extent=Math.hypot(w,h)/scale;
      polygon(ctx,[P(camera-extent),P(camera+extent),[w,h],[0,h]],'#f0f3f7','#dce4ec',1);
      line(ctx,[P(camera-extent),P(camera+extent)],C.muted,2);
      let tickIndex=0;for(let x=Math.floor(camera-extent);x<=camera+extent;x++){
        const q=P(x),tick=P(x,-.1);line(ctx,[q,tick],C.muted,1);
        if(q[0]>30&&q[0]<w-30&&q[1]>65&&q[1]<h-40){const pos=P(x,-.32);numericLabel('scene-labels','tick'+tickIndex++,x,pos[0],pos[1],0,tex`\mathrm m`);}
      }
      if($('show-start').checked&&Math.abs(follow)>.015){
        if(stack){rect(0,0,6,.65,null,'#b7c6d3',[4,4]);rect(0,.65,1.2,.8,null,'#b7c6d3',[4,4]);}
        else rect(0,0,.9,.8,null,'#b7c6d3',[4,4]);
      }
      if(stack){texturedBlock(s.x2,0,6,.65,true);texturedBlock(s.x1,.65,1.2,.8);tag('m2','m_2',...P(s.x2-1.1,.31),C.body2);stackContactTag('m1','m_1',C.body);}
      else {texturedBlock(s.x1,0,.9,.8);singleTag('mass','m',C.ink);}
      // One fixed force scale per geometry/mass setting, independent of visibility.
      const forceScale=state.vectorScale*Math.min(85,w*.13)/Math.max(40,(stack?p.m1+p.m2:p.m1)*FP.g);
      const vector=(key,a,fx,fy,color,symbol,offset=16)=>{if(Math.hypot(fx,fy)<1e-9)return;const b=[a[0]+forceScale*fx,a[1]-forceScale*fy];arrow(ctx,a,b,color);if(!stack){singleArrows.push([a,b]);singleTag(key,symbol,color,[(a[0]+b[0])/2,(a[1]+b[1])/2]);return;}if(key==='f1'||key==='f2'||key==='F'){stackContactTag(key,symbol,color,[(a[0]+b[0])/2,(a[1]+b[1])/2]);return;}const norm=Math.hypot(fx,fy);tag(key,symbol,b[0]+offset*fy/norm,b[1]+offset*fx/norm,color);};
      if($('show-forces').checked){
        if(stack){vector('f1',P(s.x1,.72),s.f,0,C.f,tex`\vec f_{2\to1}`,-18);vector('f2',P(s.x1,.57),-s.f,0,C.f,tex`\vec f_{1\to2}`,18);vector('F',P(s.x2+Math.sign(s.F)*3,.3),s.F,0,C.F,tex`\vec F_{\mathrm{app}}`,-20);}
        else {vector('f',P(s.x1,0),s.f*Math.cos(theta),s.f*Math.sin(theta),C.f,tex`\vec f`,20);vector('F',P(s.x1,.45),s.F*Math.cos(theta),s.F*Math.sin(theta),C.F,tex`\vec F_{\mathrm{app}}`,-22);}
      }
      if($('show-normal').checked){
        if(stack){vector('P1',P(s.x1,1.05),0,-p.m1*FP.g,C.P,tex`m_1\vec g`,25);vector('N1',P(s.x1,.65),0,s.N,C.N,tex`\vec N_{2\to1}`,25);vector('P2',P(s.x2,.32),0,-p.m2*FP.g,C.P,tex`m_2\vec g`,-25);vector('N2',P(s.x1,.65),0,-s.N,C.N,tex`\vec N_{1\to2}`,25);vector('R',P(s.x2,0),0,(p.m1+p.m2)*FP.g,C.N,tex`\vec R`,25);}
        else {vector('P',P(s.x1,.4),0,-p.m1*FP.g,C.P,tex`m\vec g`,-22);vector('N',P(s.x1,0),-s.N*Math.sin(theta),s.N*Math.cos(theta),C.N,tex`\vec N`,22);}
      }
      if($('show-velocity').checked){
        const velocityScale=state.vectorScale*Math.min(12,w*.16/Math.max(1,Math.abs(s.v1),Math.abs(s.v2)));
        const velocity=(key,x,n,v,symbol)=>{if(Math.abs(v)<1e-9)return;const a=P(x,n),length=v*velocityScale,b=[a[0]+length*Math.cos(theta),a[1]-length*Math.sin(theta)];arrow(ctx,a,b,C.v,2);if(!stack)singleTag(key,symbol,C.v,[(a[0]+b[0])/2,(a[1]+b[1])/2]);else tag(key,symbol,b[0],b[1]-17,C.v);};
        velocity('v1',s.x1,stack?1.7:1.05,s.v1,stack?tex`\vec v_1` : tex`\vec v`);if(stack)velocity('v2',s.x2,-.8,s.v2,tex`\vec v_2`);
        const a=[w-115,h-28],b=[w-115+velocityScale,h-28];arrow(ctx,a,b,C.v,1.5);tag('velocity-key',tex`1\,\mathrm{m\,s^{-1}}`,w-72,h-50,C.v);
      }
      ctx.restore();
      if($('show-forces').checked||$('show-normal').checked){const a=[w-105,33],b=[w-105+10*forceScale,33];arrow(ctx,a,b,C.muted,1.6);tag('force-key',tex`10\,\mathrm N`,(a[0]+b[0])/2,53,C.muted);}
      const ax=[42,h-35],tip=[ax[0]+32*Math.cos(theta),ax[1]-32*Math.sin(theta)];arrow(ctx,ax,tip,C.muted,1.5);tag('axis','+x',tip[0]+16,tip[1]-8,C.muted);
      if(sim.model==='incline')tag('angle',tex`\theta=${s.angle.toFixed(1)}^\circ`,76,h-74,C.muted);
      if(!stack){
        // Keep the spatial ruler subordinate to the force annotations. Only
        // covered tick captions are omitted; force symbols never swap lanes.
        const visible=[...$('scene-labels').children].filter(el=>!el.hidden),occupied=visible.filter(el=>!el.className.includes('tick')).map(el=>el.getBoundingClientRect());
        const sceneRect=$('scene').getBoundingClientRect();
        for(const [a,b] of singleArrows)occupied.push({left:sceneRect.left+Math.min(a[0],b[0])-4,right:sceneRect.left+Math.max(a[0],b[0])+4,top:sceneRect.top+Math.min(a[1],b[1])-4,bottom:sceneRect.top+Math.max(a[1],b[1])+4});
        for(const el of visible.filter(el=>el.className.includes('tick'))){const r=el.getBoundingClientRect();if(occupied.some(b=>r.left<b.right+8&&r.right>b.left-8&&r.top<b.bottom+8&&r.bottom>b.top-8))el.hidden=true;}
      }
      $('scene').setAttribute('aria-label',$('scene-title').textContent+'. '+(s.mode==='static'?'Adhérence':'Glissement')+'. Instant '+s.t.toFixed(2)+' s ; frottement '+s.f.toFixed(2)+' N ; vitesse relative '+s.relative.toFixed(2)+' m/s.');
    }
    function chartGeometry(w,h){return {left:70,right:Math.max(95,w-25),top:32,bottom:h-44};}
    function chartSeries(){const stack=state.sim.model==='stack',key=$('chart-select').value;
      if(key==='friction')return {stepped:true,unit:isRamp()?tex`\mathrm{Forces}\,[\mathrm N]`:tex`f_x\,[\mathrm N]`,series:[{key:'f',tex:'f_x(t)',color:C.f},...(isRamp()?[{key:'F',tex:tex`F_{\mathrm{app},x}(t)`,color:C.F}]:[]),{key:'limit',tex:tex`+\mu_s N`,color:C.muted,dash:[5,4]},{get:s=>-s.limit,tex:tex`-\mu_s N`,color:C.muted,dash:[5,4]}]};
      if(key==='velocity')return {unit:tex`v_x\,[\mathrm{m\,s^{-1}}]`,series:stack?[{key:'v1',tex:'v_1',color:C.body},{key:'v2',tex:'v_2',color:C.body2}]:[{key:'v1',tex:'v',color:C.body}]};
      return {unit:tex`W\,[\mathrm J]`,series:stack?[{key:'W1',tex:'W_{f,1}',color:C.body},{key:'W2',tex:'W_{f,2}',color:C.body2}]:[{key:'W1',tex:'W_f',color:C.body}]};
    }
    function drawHistory(s){
      const {ctx,w,h}=surface('history-canvas'),g=chartGeometry(w,h),sim=state.sim,info=chartSeries(),data=sim.history.map(x=>sim.snapshot(x));
      for(const el of $('history-labels').children)el.hidden=true;
      const legendKey=sim.model+$('chart-select').value;
      $('chart-title').textContent=$('chart-select').value==='friction'?'Force de frottement en fonction du temps':$('chart-select').value==='velocity'?'Vitesses en fonction du temps':'Travaux du frottement en fonction du temps';
      $('chart-note').hidden=$('chart-select').value!=='friction';
      $('chart-note').textContent=sim.model==='horizontal'?'Pendant la lecture, faites varier la force appliquée : le frottement statique s’ajuste jusqu’à sa limite, puis le corps glisse. Les pointillés indiquent les limites statiques.':'Force de frottement signée au contact ; les pointillés indiquent les limites statiques. Les changements de force ou de régime restent visibles depuis l’instant initial.';
      if(isRamp())$('chart-note').textContent='La courbe verte montre la force appliquée programmée ; le frottement suit son opposé pendant l’adhérence, puis passe à sa valeur cinétique en glissement. Les pointillés marquent les limites statiques.';
      if(state.legend!==legendKey){$('chart-key').replaceChildren();for(const series of info.series){const row=document.createElement('span'),swatch=document.createElement('i'),symbol=document.createElement('span');swatch.style.borderColor=series.color;if(series.dash)swatch.style.borderTopStyle='dashed';math(symbol,series.tex);row.append(swatch,symbol);$('chart-key').append(row);}state.legend=legendKey;}
      const get=(series,s)=>series.get?series.get(s):s[series.key],values=info.series.flatMap(series=>data.map(s=>get(series,s))),min=Math.min(0,...values),max=Math.max(0,...values),span=Math.max(.2,max-min),low=min-.1*span,high=max+.12*span;
      const X=t=>g.left+t/sim.p.duration*(g.right-g.left),Y=v=>g.bottom-(v-low)/(high-low)*(g.bottom-g.top),ticks=w<450?4:5;
      for(let i=0;i<=ticks;i++){const t=i*sim.p.duration/ticks,x=X(t);line(ctx,[[x,g.top],[x,g.bottom]],C.grid);numericLabel('history-labels','x'+i,t,x,g.bottom+16,Number.isInteger(t)?0:1);}
      for(let i=0;i<=4;i++){const v=low+(high-low)*i/4,y=Y(v);line(ctx,[[g.left,y],[g.right,y]],C.grid);if(Math.abs(y-Y(0))>=22)numericLabel('history-labels','y'+i,v,g.left-30,y,high-low<10?2:1);}
      numericLabel('history-labels','y-zero',0,g.left-30,Y(0));
      label('history-labels','unitY',info.unit,g.left,12).style.transform='translate(0,-50%)';label('history-labels','unitX',tex`t\,[\mathrm s]`,(g.left+g.right)/2,h-9);
      line(ctx,[[g.left,Y(0)],[g.right,Y(0)]],C.muted,1,[3,5]);
      // The analytic ramp varies continuously in static contact; its two
      // samples at release retain the vertical Coulomb jump exactly.
      for(const series of info.series){const points=[];for(let i=0;i<data.length;i++){if(info.stepped&&!isRamp()&&i)points.push([X(data[i].t),Y(get(series,data[i-1]))]);points.push([X(data[i].t),Y(get(series,data[i]))]);}line(ctx,points,series.color,2,series.dash||[]);dot(ctx,X(s.t),Y(get(series,s)),3.5,series.color);}
      line(ctx,[[X(s.t),g.top],[X(s.t),g.bottom]],C.muted,1,[4,4]);$('history').setAttribute('aria-valuemax',sim.end);$('history').setAttribute('aria-valuenow',s.t);$('history').setAttribute('aria-valuetext',s.t.toFixed(2)+' s');
    }
    function drawForceHistory(s){
      const {ctx,w,h}=surface('force-history-canvas'),g={...chartGeometry(w,h),left:76,top:40,bottom:h-52},sim=state.sim;
      const data=sim.history.map(row=>sim.snapshot(row)),forceValues=data.map(row=>row.F);
      const minX=Math.min(0,...forceValues),maxX=Math.max(1,...forceValues,isRamp()?sim.ramp.peak:1.15*s.limit),spanX=Math.max(1,maxX-minX);
      const lowX=minX<0?minX-.08*spanX:0,highX=maxX+.08*spanX;
      const bound=1.2*Math.max(1,s.limit,...data.map(row=>Math.abs(row.f)));
      const X=F=>g.left+(F-lowX)/(highX-lowX)*(g.right-g.left),Y=f=>g.bottom-(f+bound)/(2*bound)*(g.bottom-g.top);
      for(const el of $('force-history-labels').children)el.hidden=true;
      for(let i=0;i<=4;i++){
        const f=-bound+2*bound*i/4,y=Y(f);line(ctx,[[g.left,y],[g.right,y]],C.grid);
        if(Math.abs(y-Y(0))>=22)numericLabel('force-history-labels','y'+i,f,g.left-32,y,1);
      }
      const ticks=w<450?3:5;
      for(let i=0;i<=ticks;i++){
        const F=lowX+(highX-lowX)*i/ticks,x=X(F);line(ctx,[[x,g.top],[x,g.bottom]],C.grid);
        if(Math.abs(x-X(0))>=32)numericLabel('force-history-labels','x'+i,F,x,g.bottom+17,1);
      }
      numericLabel('force-history-labels','y-zero',0,g.left-32,Y(0));
      numericLabel('force-history-labels','x-zero',0,X(0),g.bottom+17);
      label('force-history-labels','unitY',tex`f_x\,[\mathrm N]`,g.left,14).style.transform='translate(0,-50%)';
      label('force-history-labels','unitX',tex`F_{\mathrm{app},x}\,[\mathrm N]`,(g.left+g.right)/2,h-12);
      line(ctx,[[g.left,Y(0)],[g.right,Y(0)]],C.muted,1,[3,5]);
      for(const sign of [-1,1])line(ctx,[[g.left,Y(sign*s.limit)],[g.right,Y(sign*s.limit)]],C.muted,1.2,[5,4]);
      // Actual acquired contact states, not a single-valued constitutive law:
      // the same applied force can have different friction while sliding.
      for(let i=1;i<data.length;i++){
        const a=data[i-1],b=data[i];
        line(ctx,[[X(a.F),Y(a.f)],[X(b.F),Y(b.f)]],b.mode==='static'?C.F:C.f,2.5,a.mode!==b.mode?[2,3]:[]);
      }
      dot(ctx,X(s.F),Y(s.f),5,s.mode==='static'?C.F:C.f);
      $('force-history').setAttribute('aria-label','Instant '+s.t.toFixed(2)+' s ; force appliquée '+s.F.toFixed(2)+' N ; frottement '+s.f.toFixed(2)+' N ; '+(s.mode==='static'?'adhérence':'glissement')+'.');
      $('force-chart-note').textContent=sim.model==='horizontal'?'Composantes signées : au repos, le frottement est opposé à la force appliquée et de même module, jusqu’à la limite statique. En glissement, il dépend aussi du sens de la vitesse.':sim.model==='incline'?'Composantes suivant le plan : à l’arrêt, le frottement équilibre la force appliquée et la composante tangentielle du poids.':'Frottement sur le corps supérieur : en adhérence, il fournit son accélération, sans être systématiquement à la limite statique.';
    }
    function render(readouts=true){
      const sim=state.sim,s=sim.snapshot(),p=sim.p,stack=sim.model==='stack';
      for(const [id,value]of [['force',s.F],['mu-static',s.muS],['mu-kinetic',s.muK],['angle',s.angle]])$(id).value=value;$('mu-kinetic').max=s.muS;
      if(readouts){
        $('vector-scale').value=state.vectorScale;number($('vector-scale-value'),state.vectorScale,2);
        $('vector-scale').setAttribute('aria-valuetext','Facteur '+state.vectorScale.toFixed(2));
        for(const [id,value,digits,unit]of [
          ['time-value',s.t,2,tex`\mathrm s`],['force-value',s.F,2,tex`\mathrm N`],['mu-static-value',s.muS,2,''],['mu-kinetic-value',s.muK,2,''],['angle-value',s.angle,1,tex`{}^\circ`],['mass-1-value',p.m1,2,tex`\mathrm{kg}`],['mass-2-value',p.m2,2,tex`\mathrm{kg}`],['initial-speed-value',p.v0,2,tex`\mathrm{m\,s^{-1}}`],['duration-value',p.duration,0,tex`\mathrm s`],['position-value',stack?s.x2:s.x1,2,tex`\mathrm m`],['velocity-value',s.v1,2,tex`\mathrm{m\,s^{-1}}`],['velocity-2-value',s.v2,2,tex`\mathrm{m\,s^{-1}}`],['normal-value',s.N,2,tex`\mathrm N`],['relative-value',s.relative,3,tex`\mathrm{m\,s^{-1}}`],['required-value',Math.abs(s.required),2,tex`\mathrm N`],['limit-value',s.limit,2,tex`\mathrm N`],['friction-value',s.f,2,tex`\mathrm N`],['work-1-value',s.W1,3,tex`\mathrm J`],['work-2-value',stack?s.W2:s.WA,3,tex`\mathrm J`],['heat-value',s.Q,3,tex`\mathrm J`],['balance-value',s.balance,Math.abs(s.balance)<1e-7?0:6,tex`\mathrm J`]
        ])number($(id),value,digits,unit);
        for(const id of ['force','mu-static','mu-kinetic','angle','mass-1','mass-2','initial-speed','duration'])$(id).setAttribute('aria-valuetext',$(id+'-value').dataset.number.replace('|',' '));
        $('contact-badge').textContent=s.mode==='static'?'Adhérence · sans glissement':'Glissement';$('contact-badge').dataset.mode=s.mode;
        $('contact-explanation').textContent=s.mode==='static'?(stack?'Les deux blocs ont la même vitesse. Le frottement transmet au bloc supérieur l’accélération du bloc inférieur.':'Le bloc est immobile par rapport au plan. Le frottement équilibre les autres forces tangentielles.'):(Math.abs(s.relative)<1e-9?'La force requise dépasse la limite statique : le glissement commence.':'Les surfaces glissent l’une par rapport à l’autre. Le frottement cinétique est opposé à leur vitesse relative.');
        if(stack)$('observation').textContent=s.mode==='static'?(Math.abs(s.W1)>1e-6?'Sans glissement, les points de contact se déplacent ensemble : le frottement peut fournir un travail non nul à chaque bloc. Pendant cette phase, les travaux supplémentaires se compensent, sans dissipation supplémentaire.':'L’adhérence ne signifie pas nécessairement le repos. Lancez la lecture : le frottement peut entraîner le bloc supérieur.'):'En glissement, les deux travaux du frottement ne se compensent plus. Leur somme est négative ; l’énergie dissipée est son opposée.';
        else $('observation').textContent=s.mode==='static'?(Math.abs(s.W1)<1e-8?(sim.model==='incline'?'Sans déplacement relatif au plan, le travail du frottement dans ce modèle est nul.':'Le point de contact est fixe dans le laboratoire : le travail du frottement statique est nul.'):'Le bloc est maintenant arrêté par rapport au plan. Le travail affiché conserve la contribution du glissement antérieur ; il ne varie plus pendant l’adhérence.'):'Le frottement cinétique s’oppose au déplacement relatif au plan : son travail est négatif et l’énergie correspondante est dissipée au contact.';
        $('stop-note').hidden=!s.edge;$('stop-note').textContent='Limite du support complet atteinte. L’animation s’arrête avant la perte d’appui ou le basculement, qui ne font pas partie de ce modèle. Recommencez avec une force plus faible pour prolonger le contact.';
      }
      drawScene(s);if(readouts){drawHistory(s);drawForceHistory(s);}
    }
    function frame(now){state.frame=0;if(!state.playing)return;const dt=state.last===null?0:Math.min(.05,Math.max(0,(now-state.last)/1000))*Number($('speed').value);state.last=now;
      try{state.sim.advance(dt);const refresh=now-state.lastReadout>=80;if(refresh)state.lastReadout=now;render(refresh);if(state.sim.done){pause();render();return;}}
      catch(error){pause();$('loading').hidden=false;$('loading').textContent='Animation interrompue : '+error.message;console.error(error);return;}state.frame=requestAnimationFrame(frame);
    }
    $('model-select').addEventListener('change',()=>configure($('model-select').value));$('preset-select').addEventListener('change',()=>{const preset=$('preset-select').value;if(preset!=='custom')configure(state.sim.model,preset);});
    for(const [id,key]of [['force','F'],['mu-static','muS'],['mu-kinetic','muK'],['angle','angle']])$(id).addEventListener('input',()=>changeLive(key,Number($(id).value)));
    $('zero-force').addEventListener('click',()=>changeLive('F',0));
    $('force-mode').addEventListener('change',()=>{
      const sim=state.sim;if(sim.model!=='horizontal')return;
      const ramp=$('force-mode').value==='ramp',p={...sim.p,F:Math.max(-40,Math.min(40,sim.s.F)),muS:sim.s.muS,muK:sim.s.muK};
      pause();state.sim=ramp?makeRamp(p):new FP.Simulation('horizontal',p);$('preset-select').value='custom';syncControls();render();
    });
    for(const [id,key]of [['ramp-peak','rampPeak'],['ramp-rise','rampRise']])$(id).addEventListener('input',()=>{
      const wasPlaying=state.playing;state[key]=Number($(id).value);restart();if(wasPlaying)play();
    });
    $('replay-ramp').addEventListener('click',()=>{if(isRamp()){restart();play();}});
    for(const [id,key]of [['mass-1','m1'],['mass-2','m2'],['initial-speed','v0'],['duration','duration']])$(id).addEventListener('input',()=>{const previousMode=state.sim.snapshot().mode;state.sim.p[key]=Number($(id).value);$('preset-select').value='custom';restart();startAfterChange(previousMode);});
    $('play').addEventListener('click',()=>{if(state.playing){pause();render();}else play();});$('restart').addEventListener('click',restart);$('reset').addEventListener('click',()=>configure(state.sim.model));
    $('launch-block').addEventListener('click',()=>{
      if(state.sim.model==='stack')return;
      // A new initial condition, not an unaccounted impulse during a run.
      if(Math.abs(state.sim.p.v0)<1e-9)state.sim.p.v0=2;
      $('preset-select').value='custom';restart();play();
    });
    for(const id of ['show-forces','show-normal','show-velocity','show-start','chart-select'])$(id).addEventListener('change',()=>render());
    $('vector-scale').addEventListener('input',()=>{
      const value=Number($('vector-scale').value);
      if(Number.isFinite(value))state.vectorScale=Math.max(.25,Math.min(4,value));
      render();
    });
    const seek=t=>{pause();state.sim.seek(t);render();},plot=$('history'),seekPointer=e=>{const r=plot.getBoundingClientRect(),q=chartGeometry(r.width,r.height);seek((e.clientX-r.left-q.left)/(q.right-q.left)*state.sim.p.duration);};
    plot.addEventListener('pointerdown',e=>{if(e.button!==undefined&&e.button!==0)return;plot.setPointerCapture(e.pointerId);seekPointer(e);});plot.addEventListener('pointermove',e=>{if(plot.hasPointerCapture(e.pointerId))seekPointer(e);});for(const event of ['pointerup','pointercancel'])plot.addEventListener(event,e=>{if(plot.hasPointerCapture(e.pointerId))plot.releasePointerCapture(e.pointerId);});
    plot.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();seek(e.key==='Home'?0:e.key==='End'?state.sim.end:state.sim.s.t+(e.key==='ArrowLeft'?-.1:.1));}});
    document.addEventListener('keydown',e=>{if(e.target.closest('input,select,button,[role="slider"]')||e.ctrlKey||e.metaKey||e.altKey)return;if(e.code==='Space'){e.preventDefault();$('play').click();}if(e.key.toLowerCase()==='r')restart();});document.addEventListener('visibilitychange',()=>{if(document.hidden){pause();render();}});
    new ResizeObserver(()=>render()).observe($('scene'));configure('horizontal');$('loading').hidden=true;
    await window.PhysShare?.register({id:'friction',pause,
      capture:()=>({model:state.sim.model,p:{...state.sim.p},s:{...state.sim.s},history:state.sim.history,started:state.sim.started,ramp:isRamp(),rampPeak:state.rampPeak,rampRise:state.rampRise,vectorScale:state.vectorScale}),
      restore:(s,ui)=>{
        PhysShare.member(s.model,Object.keys(FP.presets));PhysShare.range(s.p.duration,.1,120);PhysShare.range(s.vectorScale,.1,4);
        PhysShare.range(s.rampPeak,0,60);PhysShare.range(s.rampRise,.01,s.ramp?s.p.duration:120);
        const sim=s.ramp?new FP.RampSimulation(s.p,s.rampPeak,s.rampRise):new FP.Simulation(s.model,s.p);
        PhysShare.range(s.s.t,0,s.p.duration);if(!Array.isArray(s.history)||!s.history.length)throw Error('Historique absent.');
        PhysShare.set(sim.s,s.s);sim.history=s.history;sim.started=s.started;
        configure(s.model);pause();state.sim=sim;state.rampPeak=s.rampPeak;state.rampRise=s.rampRise;state.vectorScale=s.vectorScale;state.labelPlan=null;syncControls();ui();render();
      }
    });
    // Optional, page-local agent controls use the same actions as the interface.
    // Unsupported browsers simply keep the standard mouse/keyboard interface.
    if(document.modelContext?.registerTool){
      const lifecycle=new AbortController(),read=()=>({model:state.sim.model,playing:state.playing,parameters:{...state.sim.p},state:state.sim.snapshot()});
      const object=(input,keys)=>{if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!keys.includes(k)))throw new Error('Paramètres de commande non valides.');};
      const commands=[
        {name:'read_friction_experiment',title:'Lire l’expérience de frottement',description:'Lire les paramètres, l’état du contact et les travaux dans les unités SI, sans modification.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true},execute(input){object(input,[]);return read();}},
        {name:'select_friction_example',title:'Choisir un exemple de frottement',description:'Choisir un système et un exemple ; remet le temps et les travaux à zéro et lance la lecture si le contact est en glissement.',inputSchema:{type:'object',properties:{model:{type:'string',enum:['horizontal','incline','stack']},example:{type:'string',enum:['held','pushed','slowing','rest','slide','launch','horizontal','stick','brake']}},required:['model','example'],additionalProperties:false},annotations:{readOnlyHint:false},execute(input){object(input,['model','example']);if(!Object.hasOwn(FP.presets,input.model)||!Object.hasOwn(FP.presets[input.model],input.example))throw new Error('Cet exemple ne correspond pas au système.');configure(input.model,input.example);return read();}},
        {name:'adjust_friction_live',title:'Régler le frottement en direct',description:'Modifier la force en newtons, les coefficients et/ou l’angle en degrés (plan incliné uniquement) sans recommencer ; éventuellement lire ou mettre en pause. Angle quasi statique : effets de rotation du support négligés. Les réglages sont validés avant toute modification.',inputSchema:{type:'object',properties:{force:{type:'number',minimum:-40,maximum:40},muStatic:{type:'number',minimum:0,maximum:1},muKinetic:{type:'number',minimum:0,maximum:1},angle:{type:'number',minimum:-60,maximum:60},playback:{type:'string',enum:['play','pause']}},additionalProperties:false},annotations:{readOnlyHint:false},execute(input){
          object(input,['force','muStatic','muKinetic','angle','playback']);
          for(const key of ['force','muStatic','muKinetic','angle'])if(Object.hasOwn(input,key)&&(!Number.isFinite(input[key])||input[key]<(key==='force'?-40:key==='angle'?-60:0)||input[key]>(key==='force'?40:key==='angle'?60:1)))throw new Error('Réglage hors limites.');
          if(Object.hasOwn(input,'angle')&&state.sim.model!=='incline')throw new Error('L’angle ne se règle que pour le plan incliné.');
          if(Object.hasOwn(input,'playback')&&!['play','pause'].includes(input.playback))throw new Error('Action de lecture inconnue.');
          const muS=input.muStatic??state.sim.s.muS,muK=input.muKinetic??Math.min(state.sim.s.muK,muS);if(muK>muS)throw new Error('Le coefficient cinétique doit rester inférieur ou égal au coefficient statique.');
          const previous=state.sim.snapshot();
          if(isRamp()&&['force','muStatic','muKinetic','angle'].some(key=>Object.hasOwn(input,key)))throw new Error('Choisissez la commande manuelle pour modifier les réglages en direct.');
          if(Object.hasOwn(input,'muStatic'))state.sim.setLive('muS',muS);if(Object.hasOwn(input,'muKinetic'))state.sim.setLive('muK',muK);if(Object.hasOwn(input,'force'))state.sim.setLive('F',input.force);
          if(Object.hasOwn(input,'angle'))state.sim.setLive('angle',input.angle);
          if(input.playback==='play')play();else if(input.playback==='pause')pause();else startAfterChange(previous.mode,previous.muS!==state.sim.s.muS||previous.muK!==state.sim.s.muK||previous.angle!==state.sim.s.angle);$('preset-select').value='custom';render();return read();
        }},
      ];
      for(const command of commands){try{void Promise.resolve(document.modelContext.registerTool(command,{signal:lifecycle.signal})).catch(error=>console.warn('Commandes agent indisponibles.',error));}catch(error){console.warn('Commandes agent indisponibles.',error);}}
      window.addEventListener('pagehide',()=>lifecycle.abort(),{once:true});
    }
  }catch(error){$('loading').hidden=false;$('loading').textContent='L’application n’a pas pu démarrer : '+error.message;console.error(error);}
}
