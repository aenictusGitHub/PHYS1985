globalThis.PhysLang?.translateTree(document.documentElement);
var physTranslate = globalThis.PhysLang?.t || (value => value);
/* Original instructional curves inspired by the supplied video, not digitized
 * frames. Pair force is the radial force on body 2, directed from body 1 to 2. */
const PotentialModels = (() => {
  'use strict';
  const definitions = {
    wells: {min: -1.65, max: 1.65, start: .55, coordinate: 'x', energy:1, length:1},
    // Argon: sigma = 0.3405 nm, epsilon/k_B = 119.8 K
    // (Heyes, Dini & Smith, 2020, doi:10.1002/pssb.202000344).
    pair: {min: .98, max: 2.8, start: 1.4, coordinate: 'r', energy:1.654e-21, length:.3405e-9},
    gravity: {min: 1, max: 3, start: 1.5, coordinate: 'r', energy:1, length:1},
  };
  function reduced(model, q) {
    if (model === 'wells') return {u: (q*q-1)**2-q/3, du: 4*q*(q*q-1)-1/3, d2u: 12*q*q-4};
    if (model === 'pair' && q > 0) return {u: 4*(q**-12-q**-6), du: 24*(q**-7-2*q**-13), d2u: 624*q**-14-168*q**-8};
    if (model === 'gravity' && q > 0) return {u: -1/q, du: 1/q**2, d2u: -2/q**3};
    throw new Error(physTranslate('Potentiel ou position non valide.'));
  }
  function evaluate(model, q, energy = definitions[model]?.energy, length = definitions[model]?.length) {
    if (![q,energy,length].every(Number.isFinite) || energy <= 0 || length <= 0) throw new Error(physTranslate('Paramètres non valides.'));
    const {u,du,d2u} = reduced(model,q);
    return {q, position:q*length, U:energy*u, slope:energy/length*du, F:-energy/length*du, curvature:energy/length**2*d2u};
  }
  function stability(curvature) {
    if (!Number.isFinite(curvature)) throw new Error(physTranslate('Dérivée seconde non valide.'));
    return curvature > 0 ? 'stable' : curvature < 0 ? 'unstable' : 'inconclusive';
  }
  function quadratic(equilibrium, position) {
    // Second-order Taylor approximation in the physical coordinate (metres).
    const delta=position-equilibrium.position;
    return equilibrium.U+.5*equilibrium.curvature*delta*delta;
  }
  function equilibria(model) {
    if (model === 'gravity') return [];
    const roots = model === 'pair' ? [2**(1/6)] : [[-1.65,-.6],[-.6,.6],[.6,1.65]].map(([lo,hi]) => {
      for (let i=0;i<60;i++) { const mid=(lo+hi)/2; if (reduced(model,lo).du*reduced(model,mid).du <= 0) hi=mid; else lo=mid; }
      return (lo+hi)/2;
    });
    return roots.map(q => {
      const kind=stability(reduced(model,q).d2u);
      return {q,stable:kind==='stable',stability:kind};
    });
  }
  function sweep(q, direction, delta, min, max) {
    const span=max-min, period=2*span;
    const phase=((direction > 0 ? q-min : period-(q-min))+delta)%period;
    return phase <= span ? {q:min+phase,direction:1} : {q:min+period-phase,direction:-1};
  }
  return {definitions,reduced,evaluate,stability,quadratic,equilibria,sweep};
})();

if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startPotentialApp);
  else startPotentialApp();
}
async function startPotentialApp() {
  'use strict';
  const $ = id => document.getElementById(id), tex = String.raw;
  try {
    await MathJax.startup.promise;
    const colors = {U:'#b5688b',energy:'#167e8b',forbidden:'#eef1f4',zero:'#8b97a6',tangent:'#174b73',velocity:'#d05a20',quadratic:'#2775b6',F:'#7758a6',stable:'#268576',unstable:'#b5687b',body:'#2775b6',body2:'#74c9b2',ink:'#233449',muted:'#607185',grid:'#dce4ec'};
    const state = {model:'wells',q:.55,energy:1,length:1,playing:false,frame:0,last:null,direction:1,lastReadout:-Infinity,drag:null};
    const glyphs=new Map(), units=new Map(), labels=new Map();
    let arrowScaleCache=null,motion=null;
    const displayUnits={
      wells:{length:1,energy:1,force:1,lengthTex:tex`\mathrm m`,lengthText:'m',energyTex:tex`\mathrm J`,energyAxis:tex`\mathrm J`,energyText:'J',forceTex:tex`\mathrm N`,forceText:'N',slopeTex:tex`\mathrm{J\,m^{-1}}`},
      pair:{length:1e-9,energy:1e-21,force:1e-12,lengthTex:tex`\mathrm{nm}`,lengthText:'nm',energyTex:tex`\times10^{-21}\,\mathrm J`,energyAxis:tex`10^{-21}\,\mathrm J`,energyText:'× 10^-21 J',forceTex:tex`\mathrm{pN}`,forceText:'pN',slopeTex:tex`\mathrm{pN}`},
    };
    displayUnits.gravity=displayUnits.wells;
    const isRadial=()=>state.model!=='wells';
    function display() { return displayUnits[state.model]; }
    function positionText(position) { const u=display();return (position/u.length).toFixed(3)+' '+u.lengthText; }
    function math(el,value) {
      if (el.dataset.math === value) return;
      el.replaceChildren(MathJax.tex2svg(value,{display:false})); el.dataset.math=value;
    }
    function numericPart(value) {
      const svg=MathJax.tex2svg(value,{display:false}).querySelector('svg');
      const [x,y,width,height]=svg.getAttribute('viewBox').split(/\s+/).map(Number);
      return {svg,x,y,width,height,exPerUnit:parseFloat(svg.getAttribute('width'))/width};
    }
    for (const el of document.querySelectorAll('[data-tex]')) math(el,el.dataset.tex);
    for (const c of '0123456789.-') glyphs.set(c,numericPart(c));
    const numericTop=Math.min(...[...glyphs.values()].map(g=>g.y));
    const numericBottom=Math.max(...[...glyphs.values()].map(g=>g.y+g.height));
    MathJax.startup.document.updateDocument();
    function number(el,value,digits=3,unit='') {
      if (!Number.isFinite(value)) throw new Error(physTranslate('Valeur non finie.'));
      const string=(Math.abs(value)<.5*10**-digits ? 0 : value).toFixed(digits), key=string+'|'+unit;
      if (el.dataset.number===key) return;
      const parts=[...string].map(c=>glyphs.get(c));
      if (unit) { if (!units.has(unit)) units.set(unit,numericPart(unit)); parts.push(units.get(unit)); }
      // One SVG, one TeX baseline for digits, decimal point, sign and unit.
      const svg=parts[0].svg.cloneNode(false), ex= glyphs.get('0').exPerUnit;
      let width=0,top=numericTop,bottom=numericBottom;
      for (const [i,p] of parts.entries()) {
        if (i===string.length) width+=1000/6;
        const g=document.createElementNS('http://www.w3.org/2000/svg','g');
        g.setAttribute('transform',`translate(${width-p.x},0)`);
        g.append(...[...p.svg.children].map(child=>child.cloneNode(true))); svg.append(g);
        width+=p.width; top=Math.min(top,p.y); bottom=Math.max(bottom,p.y+p.height);
      }
      svg.setAttribute('viewBox',`0 ${top} ${width} ${bottom-top}`);
      svg.setAttribute('width',`${width*ex}ex`); svg.setAttribute('height',`${(bottom-top)*ex}ex`);
      svg.style.verticalAlign=`${-bottom*ex}ex`;
      svg.setAttribute('role','img'); svg.setAttribute('aria-label',string+' '+unit.replace(/\\mathrm|[{}]/g,'').replace(/\\,/g,' ').trim());
      el.classList.add('number'); el.replaceChildren(svg); el.dataset.number=key;
    }
    function definition() { return PotentialModels.definitions[state.model]; }
    function sample(q=state.q) { return PotentialModels.evaluate(state.model,q,state.energy,state.length); }
    function curvatureMath(q) {
      const curvature=sample(q).curvature;
      return "U''("+definition().coordinate+'_e)='+curvature.toFixed(3)
        +tex`\,\mathrm{N\,m^{-1}}`+(curvature>0?' > 0':curvature<0?' < 0':'');
    }
    function setPlaying(on) {
      if(on)motion?.pause();
      state.playing=on; state.last=null;
      $('play').textContent=on?'Pause':physTranslate('Balayer'); $('play').setAttribute('aria-pressed',String(on));
      if (!on && state.frame) { cancelAnimationFrame(state.frame); state.frame=0; }
      if (on && !state.frame) state.frame=requestAnimationFrame(frame);
    }
    function setPosition(q) {
      if (!Number.isFinite(q)) throw new Error(physTranslate('Position non valide.'));
      setPlaying(false); state.q=Math.max(definition().min,Math.min(definition().max,q));motion?.resetAtPoint();render();
    }
    function configure(model=state.model, reset=false) {
      const changed=model!==state.model;
      setPlaying(false); state.drag=null; state.model=model; state.q=definition().start; state.direction=1;
      if (reset||changed) {state.energy=definition().energy;state.length=definition().length;}
      const pair=model==='pair', gravity=model==='gravity', radial=isRadial(), c=definition().coordinate, u=display();
      for (const [id,key,min,max,step] of [
        ['energy-scale','energy',pair ? .5 : .2,4,pair ? .001 : .1],
        ['length-scale','length',pair ? .25 : .5,pair ? .5 : 2,pair ? .0001 : .1],
      ]) {
        const input=$(id);input.min=min;input.max=max;input.step=step;
        input.value=Number((state[key]/u[key]).toPrecision(12));
      }
      $('position').min=definition().min; $('position').max=definition().max;
      $('model-note').textContent=gravity
        ? physTranslate('Deux masses s’attirent suivant la loi de gravitation universelle. Le potentiel est négatif et tend vers zéro à l’infini ; la force attractive décroît comme l’inverse du carré de la distance.')
        : pair
        ? physTranslate('Un modèle de deux atomes d’argon : répulsion à courte distance, attraction plus loin. Les réglages initiaux correspondent à l’argon ; les curseurs permettent d’explorer d’autres paramètres atomiques.')
        : physTranslate('Deux minima et un maximum : explorez comment le sens de la force change avec la pente du potentiel.');
      math($('coordinate-label'),c); math($('energy-symbol'),pair?tex`\epsilon`:'U_0'); math($('length-symbol'),pair?tex`\sigma`:'L_0');
      math($('potential-symbol'),`U(${c})`);
      const slope=tex`\frac{dU}{d`+c+'}';
      math($('slope-symbol'),slope); math($('force-symbol'),radial?'F_r':'F_x'); math($('force-relation'),(radial?'F_r':'F_x')+'=-'+slope);
      const equations=gravity ? [tex`U(r)=-\frac{Gm_1m_2}{r}=-U_0\frac{L_0}{r}`,
        tex`Gm_1m_2=U_0L_0,\quad r>0`, tex`F_r=-\frac{dU}{dr}=-\frac{Gm_1m_2}{r^2}`,
        tex`\vec F_2=F_r\vec e_r,\quad\vec F_1=-\vec F_2`, tex`U(\infty)=0`]
        : pair ? [tex`U(r)=4\epsilon\!\left[\left(\frac{\sigma}{r}\right)^{12}-\left(\frac{\sigma}{r}\right)^6\right]`,
        tex`F_r=-\frac{dU}{dr}`, tex`\vec F_2=F_r\vec e_r,\quad\vec F_1=-\vec F_2`,
        tex`r_{\mathrm{eq}}=2^{1/6}\sigma,\quad U_{\min}=-\epsilon`]
        : [tex`q=\frac{x}{L_0},\quad U(x)=U_0\!\left[(q^2-1)^2-\frac q3\right]`,
          tex`F_x=-\frac{dU}{dx}`,tex`\vec F=F_x\vec e_x`];
      $('relations').replaceChildren(...equations.map(value=>{ const el=document.createElement('div');el.className='equation';math(el,value);return el; }));
      const eqCoordinate=c+'_e';
      math($('quadratic-formula'),'U('+c+tex`)\simeq U(`+eqCoordinate
        +tex`)+\frac12 U''(`+eqCoordinate+')('+c+'-'+eqCoordinate+')^2');
      math($('equilibrium-condition'),"U'("+eqCoordinate+")=0");
      math($('stability-positive'),"U''("+eqCoordinate+")>0");
      math($('stability-negative'),"U''("+eqCoordinate+")<0");
      math($('stability-zero'),"U''("+eqCoordinate+")=0");
      math($('stability-linear-force'),(radial?'F_r':'F_x')+'('+eqCoordinate
        +tex`+\delta `+c+tex`)\simeq-U''(`+eqCoordinate+tex`)\,\delta `+c);
      $('reference-note').textContent=gravity
        ? physTranslate('Masses ponctuelles ; la distance est mesurée entre leurs centres. Les échelles U₀ et L₀ fixent le produit Gm₁m₂ = U₀L₀. Le potentiel appartient à la paire et n’est compté qu’une fois. La force est toujours attractive : il n’existe pas de position d’équilibre à distance finie. Le schéma est symbolique.')
        : pair
        ? physTranslate('Potentiel de Lennard–Jones non tronqué, nul à l’infini. La distance est mesurée entre les centres des atomes. Le vecteur unitaire radial va du premier atome vers le second. Le schéma est agrandi pour rendre les forces visibles.')
        : physTranslate('La force est dirigée vers les potentiels décroissants. Un minimum est stable ; un maximum est instable. La courbe représente une énergie, pas la forme d’une piste.');
      $('argon-reference').hidden=!pair;
      $('no-equilibrium').hidden=!gravity;
      $('equilibrium-help').hidden=gravity;
      $('stage-title').textContent=gravity?physTranslate('Attraction gravitationnelle'):pair?physTranslate('Attraction et répulsion'):physTranslate('Sens de la force dans l’espace');
      $('stage-note').textContent=radial
        ? physTranslate('Faites glisser l’une des particules pour régler leur séparation. Les forces sont égales et opposées. La longueur des flèches est proportionnelle à leur module ; l’échelle reste fixe pour les paramètres choisis.')
        : physTranslate('Le mouvement se fait sur l’axe horizontal, pas le long du dessin du potentiel. La longueur de la flèche est proportionnelle au module de la force ; l’échelle reste fixe pour les paramètres choisis.');
      $('body-1').hidden=!radial;
      $('body-0').setAttribute('aria-label',radial?physTranslate('Déplacer la première particule pour changer la séparation'):physTranslate('Déplacer la particule'));
      buildEquilibria();motion?.resetAtPoint(changed||reset);render();
    }
    function buildEquilibria() {
      $('equilibrium-buttons').replaceChildren(...PotentialModels.equilibria(state.model).map((eq,i)=>{
        const button=document.createElement('button'), name=document.createElement('span'), value=document.createElement('span'), curvature=document.createElement('span');
        button.type='button';button.dataset.q=String(eq.q); value.className='eq-position';
        curvature.className='eq-curvature';button.dataset.stability=eq.stability;
        name.textContent=state.model==='pair'?physTranslate('Distance stable'):i===1?physTranslate('Maximum — instable'):i===0?physTranslate('Minimum gauche — stable'):physTranslate('Minimum droit — stable');
        number(value,eq.q*state.length/display().length,3,display().lengthTex);
        math(curvature,curvatureMath(eq.q));button.append(name,value,curvature);
        button.addEventListener('click',()=>setPosition(eq.q));return button;
      }));
    }
    function surface(id) {
      const canvas=$(id), r=canvas.getBoundingClientRect(), dpr=Math.min(2,window.devicePixelRatio||1), ctx=canvas.getContext('2d');
      if (canvas.width!==Math.round(r.width*dpr)||canvas.height!==Math.round(r.height*dpr)) {canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);}
      ctx.setTransform(dpr,0,0,dpr,0,0); ctx.clearRect(0,0,r.width,r.height);
      return {ctx,w:r.width,h:r.height};
    }
    function line(ctx,points,color,width=1,dash=[]) {
      if (!points.length) return;
      ctx.beginPath();ctx.moveTo(...points[0]);for (const p of points.slice(1)) ctx.lineTo(...p);
      ctx.strokeStyle=color;ctx.lineWidth=width;ctx.setLineDash(dash);ctx.stroke();ctx.setLineDash([]);
    }
    function dot(ctx,x,y,r,color) {ctx.beginPath();ctx.arc(x,y,r,0,2*Math.PI);ctx.fillStyle=color;ctx.fill();}
    function label(layer,key,value,x,y,color=colors.ink,tick=false) {
      const id=layer+':'+key;let el=labels.get(id);
      if (!el) {el=document.createElement('span');$(layer).append(el);labels.set(id,el);}
      el.className='plot-label'+(tick?' tick':'');el.hidden=false;math(el,value);
      el.style.left=x+'px';el.style.top=y+'px';el.style.color=color;return el;
    }
    function geometry(w,h) {return {left:64,right:Math.max(80,w-24),top:32,bottom:h-46};}
    function energyState(){
      const e=motion?.energy();
      return e?.dimension===1&&e.model===state.model?e:{E:sample().U,q0:[state.q]};
    }
    let accessibilityCache=null;
    function accessibility(){
      const e=energyState(),key=[state.model,e.E/state.energy,e.q0[0]].join('|');
      if(accessibilityCache?.key!==key)accessibilityCache={key,...PotentialEnergy.analyse(state.model,e.E/state.energy,e.q0[0])};
      return {...accessibilityCache,E:e.E};
    }
    function energyReadout(){
      const visible=$('energy-accessibility').checked;$('energy-guide').hidden=!visible;if(!visible)return;
      const info=accessibility(),u=display(),d=definition();
      number($('energy-level-value'),info.E/u.energy,3,u.energyTex);
      $('energy-regime').textContent=info.status;$('energy-regime-note').textContent=info.note;
      const turns=info.roots.filter(r=>r.reachable&&!r.stationary);
      $('energy-turns').textContent=turns.length?physTranslate('Positions de rebroussement possibles : ')+turns.map(r=>positionText(r.q*state.length)+(r.q<d.min||r.q>d.max?physTranslate(' (hors cadre)'):'')).join(' ; ')+'.':physTranslate('Aucun rebroussement ordinaire pour ces conditions initiales.');
      $('energy-other-roots').hidden=!info.roots.some(r=>!r.stationary&&!r.reachable);
    }
    function drawCurve(kind,equilibrium=null) {
      const {ctx,w,h}=surface(kind+'-canvas'), r=geometry(w,h), {min,max,coordinate}=definition(), layer=kind+'-labels';
      for (const el of $(layer).children) el.hidden=true;
      const points=Array.from({length:501},(_,i)=>sample(min+(max-min)*i/500));
      const key=kind==='potential'?'U':'F', values=points.map(s=>s[key]);
      const info=kind==='potential'&&$('energy-accessibility').checked?accessibility():null;
      if(info)values.push(info.E);
      const u=display(), unitScale=kind==='potential'?u.energy:u.force;
      const rawMin=Math.min(0,...values),rawMax=Math.max(0,...values), span=Math.max(.01*unitScale,rawMax-rawMin);
      const ymin=rawMin-span*.12,ymax=rawMax+span*.12;
      const X=q=>r.left+(q-min)/(max-min)*(r.right-r.left),Y=v=>r.bottom-(v-ymin)/(ymax-ymin)*(r.bottom-r.top);
      const ticks=w<450?3:5;
      for (let i=0;i<=ticks;i++) {
        const q=min+(max-min)*i/ticks,x=X(q);
        line(ctx,[[x,r.top],[x,r.bottom]],colors.grid);
        label(layer,'x'+i,(q*state.length/u.length).toFixed(2),x,r.bottom+16,colors.muted,true);
      }
      for (let i=0;i<=4;i++) {
        const value=ymin+(ymax-ymin)*i/4,y=Y(value);
        line(ctx,[[r.left,y],[r.right,y]],colors.grid);
        const shown=value/unitScale;
        if (Math.abs(y-Y(0))>=22) label(layer,'y'+i,(Math.abs(shown)<.0005?0:shown).toFixed((ymax-ymin)/unitScale<5?2:1),r.left-28,y,colors.muted,true);
      }
      label(layer,'y-zero','0',r.left-28,Y(0),colors.muted,true);
      const unitY=kind==='potential'?'U'+tex`\,[${u.energyAxis}]`:(isRadial()?'F_r':'F_x')+tex`\,[${u.forceTex}]`;
      // The scientific energy unit is wider: align its left edge with the plot.
      label(layer,'unitY',unitY,r.left,12).style.transform='translate(0,-50%)';
      label(layer,'unitX',coordinate+tex`\,[${u.lengthTex}]`,(r.left+r.right)/2,h-9);
      ctx.save();ctx.beginPath();ctx.rect(r.left,r.top,r.right-r.left,r.bottom-r.top);ctx.clip();
      if(info){
        const cuts=[min,...info.roots.map(p=>p.q).filter(q=>q>min&&q<max),max];
        ctx.fillStyle=colors.forbidden;
        for(let i=1;i<cuts.length;i++)if(sample((cuts[i-1]+cuts[i])/2).U>info.E){
          ctx.fillRect(X(cuts[i-1]),r.top,X(cuts[i])-X(cuts[i-1]),r.bottom-r.top);
        }
      }
      // Draw the zero reference over the mask, across the entire plot. Only E
      // uses a dashed horizontal line; U = 0 is identified in the legend.
      line(ctx,[[r.left,Y(0)],[r.right,Y(0)]],colors.zero,.9);
      if(info){
        line(ctx,[[r.left,Y(info.E)],[r.right,Y(info.E)]],colors.energy,1.2,[6,4]);
        const caption=label(layer,'total-energy','E',r.right-4,Y(info.E)-13,colors.energy);
        caption.style.transform='translate(-100%,-50%)';
        let previous=-Infinity,index=0;
        for(const root of info.roots){
          if(root.q<min||root.q>max||root.stationary)continue;
          const x=X(root.q),y=Y(info.E);index++;
          line(ctx,[[x,y],[x,r.bottom]],colors.energy,1,[2,4]);
          dot(ctx,x,y,5,colors.energy);dot(ctx,x,y,2.8,root.reachable?colors.energy:'#fff');
          const height=x-previous<34?40:22;
          label(layer,'turn'+index,'R_'+index,Math.max(r.left+12,Math.min(r.right-28,x)),Math.max(r.top+10,y-height),colors.energy,true);previous=x;
        }
      }
      line(ctx,points.map(s=>[X(s.q),Y(s[key])]),kind==='potential'?colors.U:colors.F,2.2);
      if (kind==='potential' && equilibrium) {
        // Keep the approximation local and preserve the potential's axis range.
        const half=Math.min(.12*(max-min),isRadial() ? .12*equilibrium.q : Infinity);
        const left=Math.max(min,equilibrium.q-half),right=Math.min(max,equilibrium.q+half);
        const qs=Array.from({length:81},(_,i)=>i<=40
          ? left+(equilibrium.q-left)*i/40
          : equilibrium.q+(right-equilibrium.q)*(i-40)/40);
        const parabola=qs.map(q=>[X(q),Y(PotentialModels.quadratic(equilibrium,q*state.length))]);
        line(ctx,parabola,colors.quadratic,2.2,[6,4]);
      }
      const current=sample(), x=X(state.q), y=Y(current[key]);
      if ($('equilibria').checked) {
        for (const eq of PotentialModels.equilibria(state.model)) {
          line(ctx,[[X(eq.q),r.top],[X(eq.q),r.bottom]],colors.grid,1,[2,5]);
          dot(ctx,X(eq.q),Y(sample(eq.q)[key]),3.5,eq.stable?colors.stable:colors.unstable);
        }
      }
      if (kind==='potential' && $('tangent').checked) {
        const half=(max-min)*.105;
        line(ctx,[[X(state.q-half),Y(current.U-current.slope*half*state.length)],[X(state.q+half),Y(current.U+current.slope*half*state.length)]],colors.tangent,2);
      }
      line(ctx,[[x,r.top],[x,r.bottom]],colors.muted,1,[4,4]);dot(ctx,x,y,5.5,colors.body);
      ctx.restore();
      const plot=$(kind+'-plot');
      plot.setAttribute('aria-valuemin',min*state.length/u.length);plot.setAttribute('aria-valuemax',max*state.length/u.length);
      plot.setAttribute('aria-valuenow',current.position/u.length);plot.setAttribute('aria-valuetext',positionText(current.position)+' ; '+key+' = '+(current[key]/unitScale).toFixed(3)+' '+(key==='U'?u.energyText:u.forceText));
    }
    function forceArrowScale(w) {
      const key=[state.model,w,state.energy,state.length].join('|');
      if (arrowScaleCache?.key===key) return arrowScaleCache.factor;
      const {min,max}=definition(), pair=isRadial(), r=geometry(w,150);
      let factor=Infinity;
      // Fit the entire position range once, never normalize to the current
      // force. Both particles share this one linear pixels-per-newton scale.
      for (let i=0;i<=1000;i++) {
        const q=min+(max-min)*i/1000, F=sample(q).F;
        if (Math.abs(F)<1e-12*state.energy/state.length) continue;
        let room;
        if (pair) {
          const halfDistance=q*(w-90)/max/2;
          room=F>0 ? w/2-halfDistance-28 : halfDistance-24;
        } else {
          const x=r.left+(q-min)/(max-min)*(r.right-r.left);
          room=F>0 ? w-x-28 : x-28;
        }
        // Leave room at the edges and between opposing arrowheads. Do not
        // impose a minimum length or clip individual forces: length = k |F|.
        factor=Math.min(factor,.9*Math.min(160,Math.max(0,room))/Math.abs(F));
      }
      arrowScaleCache={key,factor};return factor;
    }
    function forceArrow(ctx,x,y,direction,length,name) {
      const end=x+direction*length,head=Math.min(7,length*.4);
      line(ctx,[[x,y],[end,y]],colors.F,2.5);
      line(ctx,[[end-direction*head,y-head*.55],[end,y],[end-direction*head,y+head*.55]],colors.F,2.5);
      label('stage-labels',name,name==='force'?tex`\vec F`:tex`\vec F_`+name.slice(-1),(x+end)/2,y-24,colors.F);
    }
    function drawStage(current,zero) {
      const {ctx,w,h}=surface('stage-canvas'), {min,max}=definition(), y=79;
      for (const el of $('stage-labels').children) el.hidden=true;
      const r=geometry(w,h), X=q=>r.left+(q-min)/(max-min)*(r.right-r.left), pair=isRadial();
      const bodyRadius=10, scale=(w-90)/max;
      const centers=pair?[[w/2-state.q*scale/2,y],[w/2+state.q*scale/2,y]]:[[X(state.q),y]];
      const forceScale=forceArrowScale(w);
      const u=display();
      state.stage={w,h,scale,centers};
      // A reference arrow makes rescaling after a parameter/viewport change
      // explicit. Its label and drawn length represent exactly the same force.
      const reference=Number((40/forceScale/u.force).toPrecision(2));
      $('force-scale-arrow').style.width=reference*u.force*forceScale+'px';
      number($('force-scale-value'),reference,reference<1?3:2,u.forceTex);
      $('force-scale-key').hidden=!$('forces').checked;
      if (!pair) {
        line(ctx,[[r.left,y],[r.right,y]],colors.grid,1.5);
        label('stage-labels','axis','x',r.right+9,y+20);
        for (const eq of PotentialModels.equilibria(state.model)) if ($('equilibria').checked) dot(ctx,X(eq.q),y,3,eq.stable?colors.stable:colors.unstable);
      } else {
        line(ctx,[[centers[0][0],y+34],[centers[1][0],y+34]],colors.muted,1);
        for (const [x] of centers) line(ctx,[[x,y+29],[x,y+39]],colors.muted,1);
        const distance=label('stage-labels','distance','r=',w/2,y+50);let value=distance.querySelector('output');
        if(!value){value=document.createElement('output');distance.append(value);}number(value,current.position/u.length,3,u.lengthTex);
      }
      for (const [i,[x,y]] of centers.entries()) {
        dot(ctx,x,y,bodyRadius,i?colors.body2:colors.body);
        label('stage-labels','mass'+i,pair?'m_'+(i+1):'m',x,y+22,i?'#237a68':colors.body);
        const handle=$('body-'+i);handle.style.left=x+'px';handle.style.top=y+'px';
        if ($('forces').checked) {
          if (zero) label('stage-labels','zero'+i,(pair?tex`\vec F_`+(i+1):tex`\vec F`)+tex`=\vec 0`,x,y-26,colors.F);
          else {
            const direction=Math.sign(current.F)*(pair&&i===0?-1:1);
            const length=forceScale*Math.abs(current.F);
            forceArrow(ctx,x+direction*(bodyRadius+2),y,direction,length,pair?'force'+(i+1):'force');
          }
        }
      }
      const forceText=(current.F/u.force).toFixed(3)+' '+u.forceText;
      $('stage').setAttribute('aria-label',pair?physTranslate('Séparation ')+positionText(current.position)+physTranslate('. Force sur le deuxième corps : ')+forceText+physTranslate(' ; force opposée sur le premier.'):'Position '+positionText(current.position)+'. Force : '+forceText+'.');
    }
    function render(readouts=true) {
      if($('dimension').value==='2')return;
      const current=sample(), pair=state.model==='pair', radial=isRadial();
      const selected=PotentialModels.equilibria(state.model).find(eq=>Math.abs(eq.q-state.q)<1e-7);
      const equilibrium=selected?sample(selected.q):null,zero=Boolean(equilibrium);
      $('quadratic-legend').hidden=!equilibrium;
      $('quadratic-note').hidden=!equilibrium;
      const u=display();
      $('position').value=state.q;
      $('position').setAttribute('aria-valuetext',positionText(current.position));
      for (const button of $('equilibrium-buttons').children) button.dataset.selected=String(Math.abs(Number(button.dataset.q)-state.q)<1e-7);
      if (readouts) {
        number($('position-value'),current.position/u.length,3,u.lengthTex);
        number($('energy-value'),state.energy/u.energy,pair?3:2,u.energyTex);number($('length-value'),state.length/u.length,pair?4:2,u.lengthTex);
        number($('potential-value'),current.U/u.energy,3,u.energyTex);number($('slope-value'),current.slope/u.force,3,u.slopeTex);number($('force-value'),current.F/u.force,3,u.forceTex);
        $('energy-scale').setAttribute('aria-valuetext',(state.energy/u.energy).toFixed(pair?3:2)+' '+u.energyText);
        $('length-scale').setAttribute('aria-valuetext',(state.length/u.length).toFixed(pair?4:2)+' '+u.lengthText);
      }
      $('force-sign').textContent=zero?physTranslate('Force nulle'):current.F>0?physTranslate('Force positive'):physTranslate('Force négative');
      $('force-sign').className='sign-badge '+(zero?'neutral':current.F>0?'positive':'negative');
      const stability=PotentialModels.stability(current.curvature);
      $('state-badge').textContent=zero?(stability==='stable'?physTranslate('Équilibre stable'):stability==='unstable'?physTranslate('Équilibre instable'):physTranslate('Équilibre — critère insuffisant')):radial?(current.F>0?physTranslate('Répulsion'):'Attraction'):(current.F>0?physTranslate('Vers la droite'):physTranslate('Vers la gauche'));
      $('equilibrium-curvature').hidden=!zero;
      if (zero) math($('equilibrium-curvature'),curvatureMath(state.q));
      $('observation-text').textContent=zero
        ? (stability==='stable'?physTranslate('La dérivée seconde est positive : le potentiel présente un minimum local. Un petit déplacement fait apparaître une force de rappel vers l’équilibre.')
          :stability==='unstable'?physTranslate('La dérivée seconde est négative : le potentiel présente un maximum local. Un petit déplacement fait apparaître une force qui éloigne de l’équilibre.')
          :physTranslate('La dérivée seconde est nulle : ce critère ne permet pas de conclure. Il faut examiner le potentiel au voisinage de l’équilibre.'))
        : radial?(current.F>0?physTranslate('La pente est négative : la force radiale est positive. Les deux particules se repoussent.'):physTranslate('La pente est positive : la force radiale est négative. Les deux particules s’attirent.'))
        : current.F>0?physTranslate('Le potentiel décroît vers la droite : sa pente est négative et la force est dirigée vers la droite.'):physTranslate('Le potentiel croît vers la droite : sa pente est positive et la force est dirigée vers la gauche.');
      energyReadout();drawCurve('potential',equilibrium);drawCurve('force');drawStage(current,zero);
    }
    function frame(now) {
      state.frame=0;if (!state.playing) return;
      const dt=state.last===null?0:Math.max(0,Math.min(.1,(now-state.last)/1000));state.last=now;
      const d=definition();Object.assign(state,PotentialModels.sweep(state.q,state.direction,dt*(d.max-d.min)/12*Number($('speed').value),d.min,d.max));
      const update=now-state.lastReadout>=65;if(update)state.lastReadout=now;
      if(update)motion?.resetAtPoint(false,false);
      try { render(update); } catch(error) {setPlaying(false);$('loading').hidden=false;$('loading').textContent=physTranslate('Le balayage a été interrompu. ')+error.message;console.error(error);return;}
      state.frame=requestAnimationFrame(frame);
    }
    $('model-select').addEventListener('change',()=>configure($('model-select').value));
    $('position').addEventListener('input',()=>setPosition(Number($('position').value)));
    for (const [id,key] of [['energy-scale','energy'],['length-scale','length']]) $(id).addEventListener('input',()=>{setPlaying(false);state[key]=Number($(id).value)*display()[key];buildEquilibria();motion?.resetAtPoint();render();});
    $('reset').addEventListener('click',()=>configure(state.model,true));
    $('restart').addEventListener('click',()=>{state.direction=1;setPosition(definition().start);});
    $('play').addEventListener('click',()=>{setPlaying(!state.playing);if(!state.playing){motion?.resetAtPoint();render();}});
    for (const id of ['tangent','equilibria','forces']) $(id).addEventListener('change',()=>render());
    function keyboard(event,sign=1) {
      const delta={ArrowRight:.02,ArrowLeft:-.02,ArrowUp:.02,ArrowDown:-.02};
      if(event.key in delta){event.preventDefault();setPosition(state.q+sign*delta[event.key]*(event.shiftKey?5:1));}
      if(event.key==='Home'||event.key==='End'){event.preventDefault();setPosition(definition()[event.key==='Home'?'min':'max']);}
    }
    for (const name of ['potential','force']) {
      const plot=$(name+'-plot');
      const seek=event=>{const rect=plot.getBoundingClientRect(),r=geometry(rect.width,rect.height),d=definition();setPosition(d.min+(event.clientX-rect.left-r.left)/(r.right-r.left)*(d.max-d.min));};
      plot.addEventListener('pointerdown',event=>{if(event.button!==undefined&&event.button!==0)return;plot.setPointerCapture(event.pointerId);seek(event);});
      plot.addEventListener('pointermove',event=>{if(plot.hasPointerCapture(event.pointerId))seek(event);});
      const release=event=>{if(plot.hasPointerCapture(event.pointerId))plot.releasePointerCapture(event.pointerId);};
      plot.addEventListener('pointerup',release);plot.addEventListener('pointercancel',release);plot.addEventListener('keydown',event=>keyboard(event));
    }
    for (const index of [0,1]) {
      const body=$('body-'+index);
      body.addEventListener('pointerdown',event=>{
        if((event.button!==undefined&&event.button!==0)||event.isPrimary===false)return;
        event.preventDefault();setPlaying(false);const rect=$('stage-canvas').getBoundingClientRect();
        state.drag={index,pointerId:event.pointerId,offset:event.clientX-rect.left-state.stage.centers[index][0]};body.setPointerCapture(event.pointerId);
      });
      body.addEventListener('pointermove',event=>{
        if(state.drag?.index!==index||state.drag.pointerId!==event.pointerId)return;
        const rect=$('stage-canvas').getBoundingClientRect(),x=event.clientX-rect.left-state.drag.offset;
        if(isRadial())setPosition((index?1:-1)*2*(x-state.stage.w/2)/state.stage.scale);
        else {const r=geometry(rect.width,rect.height),d=definition();setPosition(d.min+(x-r.left)/(r.right-r.left)*(d.max-d.min));}
      });
      for (const type of ['pointerup','pointercancel','lostpointercapture']) body.addEventListener(type,event=>{if(state.drag?.pointerId===event.pointerId){state.drag=null;if(body.hasPointerCapture(event.pointerId))body.releasePointerCapture(event.pointerId);}});
      body.addEventListener('keydown',event=>keyboard(event,isRadial()&&index===0?-1:1));
    }
    document.addEventListener('keydown',event=>{
      if(event.target.closest('input,select,button,summary,[role="slider"]')||event.ctrlKey||event.metaKey||event.altKey)return;
      if(event.code==='Space'){event.preventDefault();motion?.toggle();}
      if(event.key.toLowerCase()==='r')motion?.restart();
    });
    document.addEventListener('visibilitychange',()=>{if(document.hidden){setPlaying(false);motion?.pause();render();}});
    new ResizeObserver(()=>render()).observe($('potential-plot'));
    const plane=createPotentialPlane({$,math,number,label,surface,line,dot,colors,onChange:reset=>motion?.resetAtPoint(reset),getEnergy:()=>motion?.energy(),getInitialVelocity:()=>motion?.initialVelocity()});
    motion=createPotentialMotion({$,math,number,stopSweep:()=>setPlaying(false),
      read:()=>$('dimension').value==='2'?plane.configuration():{dimension:1,model:state.model,energy:state.energy,length:state.length,q:[state.q],bounds:[[definition().min,definition().max]]},
      apply:(q,trail)=>{if($('dimension').value==='2')plane.move(q,trail);else{state.q=q[0];render();}}
    });
    $('energy-accessibility').addEventListener('change',()=>{render();plane.render();});
    let activeDimension='1';
    function closeDimensionMenu(){
      $('dimension-options').hidden=true;$('dimension-toggle').setAttribute('aria-expanded','false');
      $('dimension-toggle').removeAttribute('aria-activedescendant');
    }
    function highlightDimension(value){
      activeDimension=value;
      for(const option of ['1','2'])$('dimension-'+option).dataset.active=String(option===value);
      $('dimension-toggle').setAttribute('aria-activedescendant','dimension-'+value);
    }
    function openDimensionMenu(){
      $('dimension-options').hidden=false;$('dimension-toggle').setAttribute('aria-expanded','true');
      highlightDimension($('dimension').value);
    }
    function chooseDimension(value){
      if($('dimension').value!==value){$('dimension').value=value;$('dimension').dispatchEvent(new Event('change'));}
      closeDimensionMenu();$('dimension-toggle').focus();
    }
    for(const dimension of ['1','2'])$('dimension-'+dimension).addEventListener('click',()=>chooseDimension(dimension));
    $('dimension-toggle').addEventListener('click',()=>{$('dimension-options').hidden?openDimensionMenu():closeDimensionMenu();});
    $('dimension-toggle').addEventListener('keydown',event=>{
      const open=!$('dimension-options').hidden;
      if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)){
        event.preventDefault();if(!open)openDimensionMenu();
        if(event.key==='Home')highlightDimension('1');else if(event.key==='End')highlightDimension('2');
        else if(open)highlightDimension(event.key==='ArrowDown'?'2':'1');
      }else if(event.key==='Enter'||event.key===' '){event.preventDefault();open?chooseDimension(activeDimension):openDimensionMenu();}
      else if(event.key==='Escape'){event.preventDefault();closeDimensionMenu();}
      else if(event.key==='Tab')closeDimensionMenu();
    });
    document.addEventListener('pointerdown',event=>{if(!$('dimension-menu').contains(event.target))closeDimensionMenu();});
    $('dimension').addEventListener('change',()=>{
      setPlaying(false);motion.pause();state.drag=null;const two=$('dimension').value==='2';
      $('dimension-current-1').hidden=two;$('dimension-current-2').hidden=!two;
      $('dimension-1').setAttribute('aria-selected',String(!two));$('dimension-2').setAttribute('aria-selected',String(two));
      $('dimension-toggle').setAttribute('aria-labelledby','dimension-label dimension-current-'+(two?'2':'1'));closeDimensionMenu();
      $('controls-1d').hidden=two;$('view-1d').hidden=two;$('controls-2d').hidden=!two;$('view-2d').hidden=!two;
      $('motion-position-1d').hidden=two;$('motion-position-2d').hidden=!two;
      $('keyboard-note').textContent=two?physTranslate('Espace : lire · Flèches : position'):physTranslate('Espace : lire · R : recommencer');
      plane.activate(two);motion.resetAtPoint(true);if(!two)render();
    });
    configure();$('loading').hidden=true;
    await window.PhysShare?.register({id:'potential',pause:()=>{setPlaying(false);motion.pause();},
      capture:()=>({state:PhysShare.pick(state,'model q energy length direction'),plane:plane.capture(),motion:motion.capture()}),
      restore:(s,ui)=>{
        PhysShare.member(s.state.model,Object.keys(PotentialModels.definitions));PhysShare.range(s.state.energy,1e-30,1e20);PhysShare.range(s.state.length,1e-30,1e20);
        setPlaying(false);motion.pause();configure(s.state.model);PhysShare.set(state,s.state);buildEquilibria();
        plane.restore(s.plane);ui();$('dimension').dispatchEvent(new Event('change'));motion.restore(s.motion);ui();render();plane.render();
      }
    });
  } catch(error) {$('loading').hidden=false;$('loading').textContent=physTranslate('L’animation n’a pas pu démarrer. ')+error.message;console.error(error);}
}
