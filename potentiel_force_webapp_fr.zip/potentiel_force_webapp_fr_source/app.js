/* Original instructional curves inspired by the supplied video, not digitized
 * frames. Pair force is the radial force on body 2, directed from body 1 to 2. */
const PotentialModels = (() => {
  'use strict';
  const definitions = {
    wells: {min: -1.65, max: 1.65, start: .55, coordinate: 'x'},
    pair: {min: .98, max: 2.8, start: 1.4, coordinate: 'r'},
  };
  function reduced(model, q) {
    if (model === 'wells') return {u: (q*q-1)**2-q/3, du: 4*q*(q*q-1)-1/3, d2u: 12*q*q-4};
    if (model === 'pair' && q > 0) return {u: 4*(q**-12-q**-6), du: 24*(q**-7-2*q**-13), d2u: 624*q**-14-168*q**-8};
    throw new Error('Potentiel ou position non valide.');
  }
  function evaluate(model, q, energy = 1, length = 1) {
    if (![q,energy,length].every(Number.isFinite) || energy <= 0 || length <= 0) throw new Error('Paramètres non valides.');
    const {u,du,d2u} = reduced(model,q);
    return {q, position:q*length, U:energy*u, slope:energy/length*du, F:-energy/length*du, curvature:energy/length**2*d2u};
  }
  function equilibria(model) {
    const roots = model === 'pair' ? [2**(1/6)] : [[-1.65,-.6],[-.6,.6],[.6,1.65]].map(([lo,hi]) => {
      for (let i=0;i<60;i++) { const mid=(lo+hi)/2; if (reduced(model,lo).du*reduced(model,mid).du <= 0) hi=mid; else lo=mid; }
      return (lo+hi)/2;
    });
    return roots.map(q => ({q,stable:reduced(model,q).d2u > 0}));
  }
  function sweep(q, direction, delta, min, max) {
    const span=max-min, period=2*span;
    const phase=((direction > 0 ? q-min : period-(q-min))+delta)%period;
    return phase <= span ? {q:min+phase,direction:1} : {q:min+period-phase,direction:-1};
  }
  return {definitions,reduced,evaluate,equilibria,sweep};
})();

if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startPotentialApp);
  else startPotentialApp();
}
async function startPotentialApp() {
  'use strict';
  const $ = id => document.getElementById(id), tex = String.raw;
  try {
    await MathJax.startup.promise;
    const colors = {U:'#b5688b',tangent:'#bc8b3b',F:'#7758a6',stable:'#268576',unstable:'#b5687b',body:'#2775b6',body2:'#74c9b2',ink:'#233449',muted:'#607185',grid:'#dce4ec'};
    const state = {model:'wells',q:.55,energy:1,length:1,playing:false,frame:0,last:null,direction:1,lastReadout:-Infinity,drag:null};
    const glyphs=new Map(), units=new Map(), labels=new Map();
    let arrowScaleCache=null;
    function math(el,value) {
      if (el.dataset.math === value) return;
      el.replaceChildren(MathJax.tex2svg(value,{display:false})); el.dataset.math=value;
    }
    function numericPart(value) {
      const svg=MathJax.tex2svg(value,{display:false}).querySelector('svg');
      const [x,y,width,height]=svg.getAttribute('viewBox').split(/\s+/).map(Number);
      return {svg,x,y,width,height,exPerUnit:parseFloat(svg.getAttribute('width'))/width};
    }
    for (const el of document.querySelectorAll('[data-tex]')) math(el,el.dataset.tex);
    for (const c of '0123456789.-') glyphs.set(c,numericPart(c));
    const numericTop=Math.min(...[...glyphs.values()].map(g=>g.y));
    const numericBottom=Math.max(...[...glyphs.values()].map(g=>g.y+g.height));
    MathJax.startup.document.updateDocument();
    function number(el,value,digits=3,unit='') {
      if (!Number.isFinite(value)) throw new Error('Valeur non finie.');
      const string=(Math.abs(value)<.5*10**-digits ? 0 : value).toFixed(digits), key=string+'|'+unit;
      if (el.dataset.number===key) return;
      const parts=[...string].map(c=>glyphs.get(c));
      if (unit) { if (!units.has(unit)) units.set(unit,numericPart(unit)); parts.push(units.get(unit)); }
      // One SVG, one TeX baseline for digits, decimal point, sign and unit.
      const svg=parts[0].svg.cloneNode(false), ex= glyphs.get('0').exPerUnit;
      let width=0,top=numericTop,bottom=numericBottom;
      for (const [i,p] of parts.entries()) {
        if (i===string.length) width+=1000/6;
        const g=document.createElementNS('http://www.w3.org/2000/svg','g');
        g.setAttribute('transform',`translate(${width-p.x},0)`);
        g.append(...[...p.svg.children].map(child=>child.cloneNode(true))); svg.append(g);
        width+=p.width; top=Math.min(top,p.y); bottom=Math.max(bottom,p.y+p.height);
      }
      svg.setAttribute('viewBox',`0 ${top} ${width} ${bottom-top}`);
      svg.setAttribute('width',`${width*ex}ex`); svg.setAttribute('height',`${(bottom-top)*ex}ex`);
      svg.style.verticalAlign=`${-bottom*ex}ex`;
      svg.setAttribute('role','img'); svg.setAttribute('aria-label',string+' '+unit.replace(/\\mathrm|[{}]/g,'').replace(/\\,/g,' ').trim());
      el.classList.add('number'); el.replaceChildren(svg); el.dataset.number=key;
    }
    function definition() { return PotentialModels.definitions[state.model]; }
    function sample(q=state.q) { return PotentialModels.evaluate(state.model,q,state.energy,state.length); }
    function setPlaying(on) {
      state.playing=on; state.last=null;
      $('play').textContent=on?'Pause':'Balayer'; $('play').setAttribute('aria-pressed',String(on));
      if (!on && state.frame) { cancelAnimationFrame(state.frame); state.frame=0; }
      if (on && !state.frame) state.frame=requestAnimationFrame(frame);
    }
    function setPosition(q) {
      if (!Number.isFinite(q)) throw new Error('Position non valide.');
      setPlaying(false); state.q=Math.max(definition().min,Math.min(definition().max,q)); render();
    }
    function configure(model=state.model, reset=false) {
      setPlaying(false); state.drag=null; state.model=model; state.q=definition().start; state.direction=1;
      if (reset) { state.energy=1;state.length=1; $('energy-scale').value='1'; $('length-scale').value='1'; }
      $('position').min=definition().min; $('position').max=definition().max;
      const pair=model==='pair', c=definition().coordinate;
      $('model-note').textContent=pair
        ? 'À courte distance, les particules se repoussent ; plus loin, elles s’attirent. Au minimum du potentiel, la force s’annule.'
        : 'Deux minima et un maximum : explorez comment le sens de la force change avec la pente du potentiel.';
      math($('coordinate-label'),c); math($('energy-symbol'),pair?tex`\epsilon`:'U_0'); math($('length-symbol'),pair?tex`\sigma`:'L_0');
      math($('potential-symbol'),`U(${c})`);
      const slope=tex`\frac{\mathrm dU}{\mathrm d`+c+'}';
      math($('slope-symbol'),slope); math($('force-symbol'),pair?'F_r':'F_x'); math($('force-relation'),(pair?'F_r':'F_x')+'=-'+slope);
      const equations=pair ? [tex`U(r)=4\epsilon\!\left[\left(\frac{\sigma}{r}\right)^{12}-\left(\frac{\sigma}{r}\right)^6\right]`,
        tex`F_r=-\frac{\mathrm dU}{\mathrm dr}`, tex`\vec F_2=F_r\vec e_r,\quad\vec F_1=-\vec F_2`,
        tex`r_{\mathrm{eq}}=2^{1/6}\sigma,\quad U_{\min}=-\epsilon`]
        : [tex`q=\frac{x}{L_0},\quad U(x)=U_0\!\left[(q^2-1)^2-\frac q3\right]`,
          tex`F_x=-\frac{\mathrm dU}{\mathrm dx}`,tex`\vec F=F_x\vec e_x`,tex`U'(x_e)=0,\quad U''(x_e)>0\;\Rightarrow\;\text{stable}`];
      $('relations').replaceChildren(...equations.map(value=>{ const el=document.createElement('div');el.className='equation';math(el,value);return el; }));
      $('reference-note').textContent=pair
        ? 'Potentiel de Lennard–Jones non tronqué, nul à l’infini. Les échelles sont pédagogiques, pas celles d’un atome particulier. Le vecteur unitaire radial va de la première particule vers la seconde.'
        : 'La force est dirigée vers les potentiels décroissants. Un minimum est stable ; un maximum est instable. La courbe représente une énergie, pas la forme d’une piste.';
      $('stage-title').textContent=pair?'Attraction et répulsion':'Sens de la force dans l’espace';
      $('stage-note').textContent=pair
        ? 'Faites glisser l’une des particules pour régler leur séparation. Les forces sont égales et opposées. La longueur des flèches est proportionnelle à leur module ; l’échelle reste fixe pour les paramètres choisis.'
        : 'Le mouvement se fait sur l’axe horizontal, pas le long du dessin du potentiel. La longueur de la flèche est proportionnelle au module de la force ; l’échelle reste fixe pour les paramètres choisis.';
      $('body-1').hidden=!pair;
      $('body-0').setAttribute('aria-label',pair?'Déplacer la première particule pour changer la séparation':'Déplacer la particule');
      buildEquilibria(); render();
    }
    function buildEquilibria() {
      $('equilibrium-buttons').replaceChildren(...PotentialModels.equilibria(state.model).map((eq,i)=>{
        const button=document.createElement('button'), name=document.createElement('span'), value=document.createElement('span');
        button.type='button';button.dataset.q=String(eq.q); value.className='eq-position';
        name.textContent=state.model==='pair'?'Distance stable':i===1?'Maximum — instable':i===0?'Minimum gauche — stable':'Minimum droit — stable';
        number(value,eq.q*state.length,3,tex`\mathrm m`); button.append(name,value);
        button.addEventListener('click',()=>setPosition(eq.q));return button;
      }));
    }
    function surface(id) {
      const canvas=$(id), r=canvas.getBoundingClientRect(), dpr=Math.min(2,window.devicePixelRatio||1), ctx=canvas.getContext('2d');
      if (canvas.width!==Math.round(r.width*dpr)||canvas.height!==Math.round(r.height*dpr)) {canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);}
      ctx.setTransform(dpr,0,0,dpr,0,0); ctx.clearRect(0,0,r.width,r.height);
      return {ctx,w:r.width,h:r.height};
    }
    function line(ctx,points,color,width=1,dash=[]) {
      if (!points.length) return;
      ctx.beginPath();ctx.moveTo(...points[0]);for (const p of points.slice(1)) ctx.lineTo(...p);
      ctx.strokeStyle=color;ctx.lineWidth=width;ctx.setLineDash(dash);ctx.stroke();ctx.setLineDash([]);
    }
    function dot(ctx,x,y,r,color) {ctx.beginPath();ctx.arc(x,y,r,0,2*Math.PI);ctx.fillStyle=color;ctx.fill();}
    function label(layer,key,value,x,y,color=colors.ink,tick=false) {
      const id=layer+':'+key;let el=labels.get(id);
      if (!el) {el=document.createElement('span');$(layer).append(el);labels.set(id,el);}
      el.className='plot-label'+(tick?' tick':'');el.hidden=false;math(el,value);
      el.style.left=x+'px';el.style.top=y+'px';el.style.color=color;return el;
    }
    function geometry(w,h) {return {left:64,right:Math.max(80,w-24),top:32,bottom:h-46};}
    function drawCurve(kind) {
      const {ctx,w,h}=surface(kind+'-canvas'), r=geometry(w,h), {min,max,coordinate}=definition(), layer=kind+'-labels';
      for (const el of $(layer).children) el.hidden=true;
      const points=Array.from({length:501},(_,i)=>sample(min+(max-min)*i/500));
      const key=kind==='potential'?'U':'F', values=points.map(s=>s[key]);
      const rawMin=Math.min(0,...values),rawMax=Math.max(0,...values), span=Math.max(.01,rawMax-rawMin);
      const ymin=rawMin-span*.12,ymax=rawMax+span*.12;
      const X=q=>r.left+(q-min)/(max-min)*(r.right-r.left),Y=v=>r.bottom-(v-ymin)/(ymax-ymin)*(r.bottom-r.top);
      const ticks=w<450?3:5;
      for (let i=0;i<=ticks;i++) {
        const q=min+(max-min)*i/ticks,x=X(q);
        line(ctx,[[x,r.top],[x,r.bottom]],colors.grid);
        label(layer,'x'+i,(q*state.length).toFixed(2),x,r.bottom+16,colors.muted,true);
      }
      for (let i=0;i<=4;i++) {
        const value=ymin+(ymax-ymin)*i/4,y=Y(value);
        line(ctx,[[r.left,y],[r.right,y]],colors.grid);
        label(layer,'y'+i,(Math.abs(value)<.0005?0:value).toFixed(Math.abs(ymax-ymin)<5?2:1),r.left-28,y,colors.muted,true);
      }
      line(ctx,[[r.left,Y(0)],[r.right,Y(0)]],colors.muted,1,[4,4]);
      label(layer,'unitY',kind==='potential'?tex`U\,[\mathrm J]`:(state.model==='pair'?'F_r':'F_x')+tex`\,[\mathrm N]`,r.left,12);
      label(layer,'unitX',coordinate+tex`\,[\mathrm m]`,(r.left+r.right)/2,h-9);
      ctx.save();ctx.beginPath();ctx.rect(r.left,r.top,r.right-r.left,r.bottom-r.top);ctx.clip();
      line(ctx,points.map(s=>[X(s.q),Y(s[key])]),kind==='potential'?colors.U:colors.F,2.2);
      const current=sample(), x=X(state.q), y=Y(current[key]);
      if ($('equilibria').checked) {
        for (const eq of PotentialModels.equilibria(state.model)) {
          line(ctx,[[X(eq.q),r.top],[X(eq.q),r.bottom]],colors.grid,1,[2,5]);
          dot(ctx,X(eq.q),Y(sample(eq.q)[key]),3.5,eq.stable?colors.stable:colors.unstable);
        }
      }
      if (kind==='potential' && $('tangent').checked) {
        const half=(max-min)*.105;
        line(ctx,[[X(state.q-half),Y(current.U-current.slope*half*state.length)],[X(state.q+half),Y(current.U+current.slope*half*state.length)]],colors.tangent,2);
      }
      line(ctx,[[x,r.top],[x,r.bottom]],colors.muted,1,[4,4]);dot(ctx,x,y,5.5,colors.body);
      ctx.restore();
      const plot=$(kind+'-plot');
      plot.setAttribute('aria-valuemin',min*state.length);plot.setAttribute('aria-valuemax',max*state.length);
      plot.setAttribute('aria-valuenow',current.position);plot.setAttribute('aria-valuetext',current.position.toFixed(3)+' m ; '+key+' = '+current[key].toFixed(3)+(key==='U'?' J':' N'));
    }
    function forceArrowScale(w) {
      const key=[state.model,w,state.energy,state.length].join('|');
      if (arrowScaleCache?.key===key) return arrowScaleCache.factor;
      const {min,max}=definition(), pair=state.model==='pair', r=geometry(w,150);
      let factor=Infinity;
      // Fit the entire position range once, never normalize to the current
      // force. Both particles share this one linear pixels-per-newton scale.
      for (let i=0;i<=1000;i++) {
        const q=min+(max-min)*i/1000, F=sample(q).F;
        if (Math.abs(F)<1e-12) continue;
        let room;
        if (pair) {
          const halfDistance=q*(w-90)/max/2;
          room=F>0 ? w/2-halfDistance-28 : halfDistance-24;
        } else {
          const x=r.left+(q-min)/(max-min)*(r.right-r.left);
          room=F>0 ? w-x-28 : x-28;
        }
        // Leave room at the edges and between opposing arrowheads. Do not
        // impose a minimum length or clip individual forces: length = k |F|.
        factor=Math.min(factor,.9*Math.min(160,Math.max(0,room))/Math.abs(F));
      }
      arrowScaleCache={key,factor};return factor;
    }
    function forceArrow(ctx,x,y,direction,length,name) {
      const end=x+direction*length,head=Math.min(7,length*.4);
      line(ctx,[[x,y],[end,y]],colors.F,2.5);
      line(ctx,[[end-direction*head,y-head*.55],[end,y],[end-direction*head,y+head*.55]],colors.F,2.5);
      label('stage-labels',name,name==='force'?tex`\vec F`:tex`\vec F_`+name.slice(-1),(x+end)/2,y-24,colors.F);
    }
    function drawStage(current,zero) {
      const {ctx,w,h}=surface('stage-canvas'), {min,max}=definition(), y=79;
      for (const el of $('stage-labels').children) el.hidden=true;
      const r=geometry(w,h), X=q=>r.left+(q-min)/(max-min)*(r.right-r.left), pair=state.model==='pair';
      const bodyRadius=10, scale=(w-90)/max;
      const centers=pair?[[w/2-state.q*scale/2,y],[w/2+state.q*scale/2,y]]:[[X(state.q),y]];
      const forceScale=forceArrowScale(w);
      state.stage={w,h,scale,centers};
      // A reference arrow makes rescaling after a parameter/viewport change
      // explicit. Its label and drawn length represent exactly the same force.
      const reference=Number((40/forceScale).toPrecision(2));
      $('force-scale-arrow').style.width=reference*forceScale+'px';
      number($('force-scale-value'),reference,reference<1?3:2,tex`\mathrm N`);
      $('force-scale-key').hidden=!$('forces').checked;
      if (!pair) {
        line(ctx,[[r.left,y],[r.right,y]],colors.grid,1.5);
        label('stage-labels','axis','x',r.right+9,y+20);
        for (const eq of PotentialModels.equilibria(state.model)) if ($('equilibria').checked) dot(ctx,X(eq.q),y,3,eq.stable?colors.stable:colors.unstable);
      } else {
        line(ctx,[[centers[0][0],y+34],[centers[1][0],y+34]],colors.muted,1);
        for (const [x] of centers) line(ctx,[[x,y+29],[x,y+39]],colors.muted,1);
        label('stage-labels','distance',tex`r=${current.position.toFixed(3)}\,\mathrm m`,w/2,y+50);
      }
      for (const [i,[x,y]] of centers.entries()) {
        dot(ctx,x,y,bodyRadius,i?colors.body2:colors.body);
        label('stage-labels','mass'+i,pair?'m_'+(i+1):'m',x,y+22,i?'#237a68':colors.body);
        const handle=$('body-'+i);handle.style.left=x+'px';handle.style.top=y+'px';
        if ($('forces').checked) {
          if (zero) label('stage-labels','zero'+i,(pair?tex`\vec F_`+(i+1):tex`\vec F`)+tex`=\vec 0`,x,y-26,colors.F);
          else {
            const direction=Math.sign(current.F)*(pair&&i===0?-1:1);
            const length=forceScale*Math.abs(current.F);
            forceArrow(ctx,x+direction*(bodyRadius+2),y,direction,length,pair?'force'+(i+1):'force');
          }
        }
      }
      $('stage').setAttribute('aria-label',pair?'Séparation '+current.position.toFixed(3)+' m. Force sur la deuxième particule : '+current.F.toFixed(3)+' N ; force opposée sur la première.':'Position '+current.position.toFixed(3)+' m. Force : '+current.F.toFixed(3)+' N.');
    }
    function render(readouts=true) {
      const current=sample(), pair=state.model==='pair', zero=Math.abs(current.F)<1e-7*state.energy/state.length;
      $('position').value=state.q;
      $('position').setAttribute('aria-valuetext',current.position.toFixed(3)+' m');
      for (const button of $('equilibrium-buttons').children) button.dataset.selected=String(Math.abs(Number(button.dataset.q)-state.q)<1e-7);
      if (readouts) {
        number($('position-value'),current.position,3,tex`\mathrm m`);
        number($('energy-value'),state.energy,2,tex`\mathrm J`);number($('length-value'),state.length,2,tex`\mathrm m`);
        number($('potential-value'),current.U,3,tex`\mathrm J`);number($('slope-value'),current.slope,3,tex`\mathrm{J\,m^{-1}}`);number($('force-value'),current.F,3,tex`\mathrm N`);
      }
      $('force-sign').textContent=zero?'Force nulle':current.F>0?'Force positive':'Force négative';
      $('force-sign').className='sign-badge '+(zero?'neutral':current.F>0?'positive':'negative');
      $('state-badge').textContent=zero?(current.curvature>0?'Équilibre stable':'Équilibre instable'):pair?(current.F>0?'Répulsion':'Attraction'):(current.F>0?'Vers la droite':'Vers la gauche');
      $('observation').textContent=zero
        ? (current.curvature>0?'Au minimum du potentiel, la force est nulle. Un petit déplacement fait apparaître une force qui ramène vers l’équilibre.':'Au maximum du potentiel, la force est nulle. Un petit déplacement fait apparaître une force qui éloigne de l’équilibre.')
        : pair?(current.F>0?'La pente est négative : la force radiale est positive. Les deux particules se repoussent.':'La pente est positive : la force radiale est négative. Les deux particules s’attirent.')
        : current.F>0?'Le potentiel décroît vers la droite : sa pente est négative et la force est dirigée vers la droite.':'Le potentiel croît vers la droite : sa pente est positive et la force est dirigée vers la gauche.';
      drawCurve('potential');drawCurve('force');drawStage(current,zero);
    }
    function frame(now) {
      state.frame=0;if (!state.playing) return;
      const dt=state.last===null?0:Math.max(0,Math.min(.1,(now-state.last)/1000));state.last=now;
      const d=definition();Object.assign(state,PotentialModels.sweep(state.q,state.direction,dt*(d.max-d.min)/12*Number($('speed').value),d.min,d.max));
      const update=now-state.lastReadout>=65;if(update)state.lastReadout=now;
      try { render(update); } catch(error) {setPlaying(false);$('loading').hidden=false;$('loading').textContent='Le balayage a été interrompu. '+error.message;console.error(error);return;}
      state.frame=requestAnimationFrame(frame);
    }
    $('model-select').addEventListener('change',()=>configure($('model-select').value));
    $('position').addEventListener('input',()=>setPosition(Number($('position').value)));
    for (const [id,key] of [['energy-scale','energy'],['length-scale','length']]) $(id).addEventListener('input',()=>{setPlaying(false);state[key]=Number($(id).value);buildEquilibria();render();});
    $('reset').addEventListener('click',()=>configure(state.model,true));
    $('restart').addEventListener('click',()=>{state.direction=1;setPosition(definition().start);});
    $('play').addEventListener('click',()=>{setPlaying(!state.playing);if(!state.playing)render();});
    for (const id of ['tangent','equilibria','forces']) $(id).addEventListener('change',()=>render());
    function keyboard(event,sign=1) {
      const delta={ArrowRight:.02,ArrowLeft:-.02,ArrowUp:.02,ArrowDown:-.02};
      if(event.key in delta){event.preventDefault();setPosition(state.q+sign*delta[event.key]*(event.shiftKey?5:1));}
      if(event.key==='Home'||event.key==='End'){event.preventDefault();setPosition(definition()[event.key==='Home'?'min':'max']);}
    }
    for (const name of ['potential','force']) {
      const plot=$(name+'-plot');
      const seek=event=>{const rect=plot.getBoundingClientRect(),r=geometry(rect.width,rect.height),d=definition();setPosition(d.min+(event.clientX-rect.left-r.left)/(r.right-r.left)*(d.max-d.min));};
      plot.addEventListener('pointerdown',event=>{if(event.button!==undefined&&event.button!==0)return;plot.setPointerCapture(event.pointerId);seek(event);});
      plot.addEventListener('pointermove',event=>{if(plot.hasPointerCapture(event.pointerId))seek(event);});
      const release=event=>{if(plot.hasPointerCapture(event.pointerId))plot.releasePointerCapture(event.pointerId);};
      plot.addEventListener('pointerup',release);plot.addEventListener('pointercancel',release);plot.addEventListener('keydown',event=>keyboard(event));
    }
    for (const index of [0,1]) {
      const body=$('body-'+index);
      body.addEventListener('pointerdown',event=>{
        if((event.button!==undefined&&event.button!==0)||event.isPrimary===false)return;
        event.preventDefault();setPlaying(false);const rect=$('stage-canvas').getBoundingClientRect();
        state.drag={index,pointerId:event.pointerId,offset:event.clientX-rect.left-state.stage.centers[index][0]};body.setPointerCapture(event.pointerId);
      });
      body.addEventListener('pointermove',event=>{
        if(state.drag?.index!==index||state.drag.pointerId!==event.pointerId)return;
        const rect=$('stage-canvas').getBoundingClientRect(),x=event.clientX-rect.left-state.drag.offset;
        if(state.model==='pair')setPosition((index?1:-1)*2*(x-state.stage.w/2)/state.stage.scale);
        else {const r=geometry(rect.width,rect.height),d=definition();setPosition(d.min+(x-r.left)/(r.right-r.left)*(d.max-d.min));}
      });
      for (const type of ['pointerup','pointercancel','lostpointercapture']) body.addEventListener(type,event=>{if(state.drag?.pointerId===event.pointerId){state.drag=null;if(body.hasPointerCapture(event.pointerId))body.releasePointerCapture(event.pointerId);}});
      body.addEventListener('keydown',event=>keyboard(event,state.model==='pair'&&index===0?-1:1));
    }
    document.addEventListener('keydown',event=>{
      if(event.target.closest('input,select,button,[role="slider"]')||event.ctrlKey||event.metaKey||event.altKey)return;
      if(event.code==='Space'){event.preventDefault();$('play').click();}
      if(event.key.toLowerCase()==='r')$('restart').click();
    });
    document.addEventListener('visibilitychange',()=>{if(document.hidden){setPlaying(false);render();}});
    new ResizeObserver(()=>render()).observe($('potential-plot'));
    configure();$('loading').hidden=true;
  } catch(error) {$('loading').hidden=false;$('loading').textContent='L’animation n’a pas pu démarrer. '+error.message;console.error(error);}
}
