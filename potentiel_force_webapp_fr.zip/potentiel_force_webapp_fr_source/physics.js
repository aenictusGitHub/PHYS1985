var physTranslate = globalThis.PhysLang?.t || (value => value);
/* Two-dimensional instructional potentials; q = (x/L0, y/L0).
 * Conservative force and Hessian are analytical, not raster derivatives. */
const PotentialPlane=(()=>{
  'use strict';
  const bound=1.6;
  const definitions={
    bowl:{name:physTranslate('Puits elliptique incliné'),start:[.85,.5],equilibria:[[0,0]],note:physTranslate('Un minimum stable. Les équipotentielles sont des ellipses inclinées : la force ne pointe pas toujours directement vers l’origine.'),formula:String.raw`U=\frac{U_0}{2}(q_x^2+q_xq_y+2q_y^2)`},
    saddle:{name:physTranslate('Col — point selle'),start:[.7,.65],equilibria:[[0,0]],note:physTranslate('Un équilibre instable : le potentiel augmente dans une direction mais diminue dans l’autre.'),formula:String.raw`U=\frac{U_0}{2}(q_x^2-q_y^2)`},
    double:{name:physTranslate('Double puits couplé'),start:[.45,.8],equilibria:[[-1,-.5],[0,0],[1,.5]],note:physTranslate('Deux minima stables séparés par un col. Les coordonnées sont couplées : déplacer y modifie aussi la composante Fx.'),formula:String.raw`U=U_0\!\left[(q_x^2-1)^2+\frac12\left(q_y-\frac{q_x}{2}\right)^2\right]`},
  };
  function reduced(model,x,y){
    if(![x,y].every(Number.isFinite))throw new Error(physTranslate('Position 2D non valide.'));
    if(model==='bowl')return {u:.5*(x*x+x*y+2*y*y),gx:x+.5*y,gy:2*y+.5*x,hxx:1,hxy:.5,hyy:2};
    if(model==='saddle')return {u:.5*(x*x-y*y),gx:x,gy:-y,hxx:1,hxy:0,hyy:-1};
    if(model==='double'){const d=y-.5*x;return {u:(x*x-1)**2+.5*d*d,gx:4*x*(x*x-1)-.5*d,gy:d,hxx:12*x*x-3.75,hxy:-.5,hyy:1};}
    throw new Error(physTranslate('Potentiel 2D inconnu.'));
  }
  function evaluate(model,qx,qy,energy=1,length=1){
    if(![energy,length].every(Number.isFinite)||energy<=0||length<=0)throw new Error(physTranslate('Échelles 2D non valides.'));
    const r=reduced(model,qx,qy),k=energy/length,kk=k/length;
    return {x:qx*length,y:qy*length,U:energy*r.u,Fx:-k*r.gx,Fy:-k*r.gy,Hxx:kk*r.hxx,Hxy:kk*r.hxy,Hyy:kk*r.hyy};
  }
  function eigenvalues(s){const mean=(s.Hxx+s.Hyy)/2,delta=Math.hypot((s.Hxx-s.Hyy)/2,s.Hxy);return [mean-delta,mean+delta];}
  function equilibria(model,energy=1,length=1){
    if(!Object.hasOwn(definitions,model))throw new Error(physTranslate('Potentiel 2D inconnu.'));
    return definitions[model].equilibria.map(([qx,qy])=>{const s=evaluate(model,qx,qy,energy,length),eigen=eigenvalues(s);return {qx,qy,...s,eigen,stable:eigen[0]>0,saddle:eigen[0]<0&&eigen[1]>0};});
  }
  function geometry(w,h,vectorRoom=0){const side=Math.max(10,Math.min(w-88,h-78-2*vectorRoom)),left=(w-side)/2+12,top=30+vectorRoom;return {side,left,top,vectorRoom,right:left+side,bottom:top+side,X:q=>left+(q+bound)*side/(2*bound),Y:q=>top+(bound-q)*side/(2*bound)};}
  // Marching triangles: each contour segment lies on a piecewise-linear
  // interpolant. Splitting cells removes saddle-cell connectivity ambiguity.
  function contours(values,level){
    const n=values.length-1,segments=[];
    for(let j=0;j<n;j++)for(let i=0;i<n;i++){
      const corners=[[i,j],[i+1,j],[i+1,j+1],[i,j+1]];
      for(const triangle of [[0,1,2],[0,2,3]]){
        const hits=[];
        for(let k=0;k<3;k++){
          const a=corners[triangle[k]],b=corners[triangle[(k+1)%3]],va=values[a[1]][a[0]],vb=values[b[1]][b[0]];
          if((va<level)!==(vb<level)){const t=(level-va)/(vb-va);hits.push([a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])]);}
        }
        if(hits.length===2)segments.push(hits);
      }
    }return segments;
  }
  return {bound,definitions,reduced,evaluate,eigenvalues,equilibria,geometry,contours};
})();

// Orthographic height-field rendering. Energy has its own vertical scale;
// x and y always share one metric scale. The camera never changes the physics.
const PotentialSurface=(()=>{
  'use strict';
  const B=PotentialPlane.bound,initial={azimuth:.65,elevation:.6};
  function color(u,low,high,shade=1){
    const rgb=[[211,230,243],[244,245,247],[203,142,170]],t=Math.max(0,Math.min(1,(u-low)/(high-low)))*2,i=Math.min(1,Math.floor(t)),f=t-i;
    return 'rgb('+rgb[i].map((a,k)=>Math.round(Math.min(255,(a+(rgb[i+1][k]-a)*f)*shade))).join(',')+')';
  }
  function mesh(model,energy,n=40){
    const vertices=Array.from({length:n+1},(_,j)=>Array.from({length:n+1},(_,i)=>{
      const x=-B+2*B*i/n,y=-B+2*B*j/n;return {x,y,u:PotentialPlane.evaluate(model,x,y,energy).U};
    }));
    const values=vertices.flat().map(v=>v.u).concat(PotentialPlane.equilibria(model,energy).map(v=>v.U));
    const low=Math.min(...values),high=Math.max(...values),triangles=[];
    for(let j=0;j<n;j++)for(let i=0;i<n;i++){
      const quad=[vertices[j][i],vertices[j][i+1],vertices[j+1][i+1],vertices[j+1][i]];
      for(const indices of [[0,1,2],[0,2,3]]){
        const v=indices.map(k=>quad[k]),x=v.reduce((a,b)=>a+b.x,0)/3,y=v.reduce((a,b)=>a+b.y,0)/3,r=PotentialPlane.reduced(model,x,y);
        const nx=-2.1*energy*r.gx/(high-low),ny=-2.1*energy*r.gy/(high-low),light=(-.35*nx-.45*ny+.82)/Math.hypot(nx,ny,1);
        triangles.push({v,color:color(v.reduce((a,b)=>a+b.u,0)/3,low,high,.9+.12*Math.max(0,light))});
      }
    }
    return {vertices,triangles,low,high};
  }
  function projection(w,h,low,high,camera=initial){
    const ca=Math.cos(camera.azimuth),sa=Math.sin(camera.azimuth),ce=Math.cos(camera.elevation),se=Math.sin(camera.elevation),span=high-low,base=low-.12*span,top=high+.06*span;
    const raw=(x,y,u)=>{const z=2.1*(u-base)/span;return [ca*x-sa*y,se*(sa*x+ca*y)-ce*z,ce*(sa*x+ca*y)+se*z];};
    const corners=[];for(const x of [-B,B])for(const y of [-B,B])for(const u of [base,top])corners.push(raw(x,y,u));
    const xmin=Math.min(...corners.map(p=>p[0])),xmax=Math.max(...corners.map(p=>p[0])),ymin=Math.min(...corners.map(p=>p[1])),ymax=Math.max(...corners.map(p=>p[1]));
    const scale=Math.max(1,Math.min((w-110)/(xmax-xmin),(h-110)/(ymax-ymin))),cx=w/2+12,cy=h/2-5;
    const project=(x,y,u)=>{const p=raw(x,y,u);return [cx+scale*(p[0]-(xmin+xmax)/2),cy+scale*(p[1]-(ymin+ymax)/2),p[2]];};
    return {project,base,top,scale};
  }
  function barycentric(p,v){
    const [a,b,c]=v,det=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1]);if(Math.abs(det)<1e-10)return null;
    const u=((b[1]-c[1])*(p[0]-c[0])+(c[0]-b[0])*(p[1]-c[1]))/det,vv=((c[1]-a[1])*(p[0]-c[0])+(a[0]-c[0])*(p[1]-c[1]))/det;
    return u>=-1e-7&&vv>=-1e-7&&u+vv<=1+1e-7?[u,vv,1-u-vv]:null;
  }
  // Screen buckets keep point picking and visible surface cuts inexpensive.
  function scene(mesh,projection){
    const cells=new Map(),size=24,faces=mesh.triangles.map(t=>({...t,screen:t.v.map(v=>projection.project(v.x,v.y,v.u))}));
    faces.sort((a,b)=>a.screen.reduce((s,v)=>s+v[2],0)-b.screen.reduce((s,v)=>s+v[2],0));
    for(const f of faces){
      const xs=f.screen.map(v=>v[0]),ys=f.screen.map(v=>v[1]);
      for(let j=Math.floor(Math.min(...ys)/size);j<=Math.floor(Math.max(...ys)/size);j++)for(let i=Math.floor(Math.min(...xs)/size);i<=Math.floor(Math.max(...xs)/size);i++){
        const key=i+','+j;if(!cells.has(key))cells.set(key,[]);cells.get(key).push(f);
      }
    }
    function pick(x,y){
      let hit=null;
      for(const f of cells.get(Math.floor(x/size)+','+Math.floor(y/size))||[]){
        const b=barycentric([x,y],f.screen);if(!b)continue;const depth=b.reduce((s,k,i)=>s+k*f.screen[i][2],0);
        if(!hit||depth>hit.depth)hit={depth,x:b.reduce((s,k,i)=>s+k*f.v[i].x,0),y:b.reduce((s,k,i)=>s+k*f.v[i].y,0)};
      }return hit;
    }
    return {faces,pick,visible:p=>{const hit=pick(p[0],p[1]);return !hit||p[2]>=hit.depth-.035;}};
  }
  function forceFactor(mesh,model,energy,length,projection,w,h){
    const samples=mesh.vertices.flat().map(v=>({...v,...PotentialPlane.evaluate(model,v.x,v.y,energy,length),qx:v.x,qy:v.y}));
    const maxForce=Math.max(...samples.map(s=>Math.hypot(s.Fx,s.Fy)));
    let factor=Math.min(1.5,110/projection.scale)/maxForce;
    // One scale for the entire domain, independent of the selected point and
    // shared by both components. Fit endpoints, never normalize each arrow.
    for(const s of samples){
      const a=projection.project(s.qx,s.qy,s.U),b=projection.project(s.qx+s.Fx,s.qy+s.Fy,s.U),d=[b[0]-a[0],b[1]-a[1]];
      for(let i=0;i<2;i++)if(Math.abs(d[i])>1e-12)factor=Math.min(factor,.9*(d[i]>0?(i===0?w:h)-28-a[i]:a[i]-28)/Math.abs(d[i]));
    }
    return Math.max(0,factor);
  }
  return {initial,color,mesh,projection,barycentric,scene,forceFactor};
})();

// Integrate dimensionless Newton equations, q'' = -grad(u), with velocity
// Verlet. Physical time is restored with L0*sqrt(m_eff/U0), including atomic
// scales. Domain exits are events, not artificial reflecting walls.
const PotentialDynamics=(()=>{
  'use strict';
  function create(q,w,sample){
    if(q.length!==w.length||!q.concat(w).every(Number.isFinite))throw new Error(physTranslate('État initial non valide.'));
    const r=sample(q);return {q:[...q],w:[...w],t:0,E0:r.u+.5*w.reduce((s,v)=>s+v*v,0),ended:false};
  }
  function advance(s,dt,sample,bounds){
    if(!Number.isFinite(dt)||dt<0||dt>4)throw new Error(physTranslate('Pas de temps non valide.'));
    let remaining=dt,steps=0;
    const inside=q=>q.every((v,i)=>Number.isFinite(v)&&v>=bounds[i][0]&&v<=bounds[i][1]);
    if(!inside(s.q))throw new Error(physTranslate('Position hors du domaine.'));
    while(remaining>1e-13&&!s.ended){
      if(++steps>10000)throw new Error(physTranslate('Trop de sous-pas.'));
      let h=Math.min(.001,remaining);const r=sample(s.q),position=t=>s.q.map((v,i)=>v+t*s.w[i]+.5*t*t*r.a[i]);let next=position(h);
      if(!inside(next)){
        let lo=0,hi=h;for(let i=0;i<45;i++){const mid=(lo+hi)/2;if(inside(position(mid)))lo=mid;else hi=mid;}h=lo;next=position(h);s.ended=true;
      }
      const end=sample(next);s.w=s.w.map((v,i)=>v+.5*h*(r.a[i]+end.a[i]));s.q=next;s.t+=h;remaining-=h;
      if(!s.q.concat(s.w,s.t).every(Number.isFinite))throw new Error(physTranslate('Évolution non finie.'));
    }
    return s;
  }
  function energy(s,sample){return sample(s.q).u+.5*s.w.reduce((sum,v)=>sum+v*v,0);}
  return {create,advance,energy};
})();

// Accessibility is computed in reduced units, including for atomic energies.
// Roots are found on the whole physical domain, not just inside the viewport.
const PotentialEnergy=(()=>{
  function analyse(model,E,q0){
    if(!Number.isFinite(E)||!Number.isFinite(q0))throw new Error(physTranslate('Énergie ou position initiale non valide.'));
    const M=PotentialModels,u=q=>M.reduced(model,q).u,tol=1e-10*Math.max(1,Math.abs(E));
    let qs=[];
    if(model==='gravity'){if(E<0)qs=[-1/E];}
    else if(model==='pair'){
      if(E>=-1-tol){
        const d=Math.sqrt(Math.max(0,1+E));qs.push(((1+d)/2)**(-1/6));
        if(E<0&&d>1e-8)qs.push((-E/(2*(1+d)))**(-1/6));
      }
    }else{
      let extent=2;while(u(-extent)<E||u(extent)<E)extent*=2;
      const cuts=[-extent,...M.equilibria(model).map(e=>e.q),extent];
      for(const q of cuts)if(Math.abs(u(q)-E)<=tol)qs.push(q);
      for(let i=1;i<cuts.length;i++){
        let lo=cuts[i-1],hi=cuts[i],f=u(lo)-E,g=u(hi)-E;
        if(Math.abs(f)<=tol||Math.abs(g)<=tol||f*g>=0)continue;
        for(let j=0;j<65;j++){const mid=(lo+hi)/2;if((u(mid)-E)*f>0)lo=mid;else hi=mid;}
        qs.push((lo+hi)/2);
      }
    }
    qs.sort((a,b)=>a-b);qs=qs.filter((q,i)=>i===0||Math.abs(q-qs[i-1])>1e-8);
    const roots=qs.map(q=>({q,stationary:Math.abs(M.reduced(model,q).du)<1e-7}));
    const edges=[model==='wells'?-Infinity:0,...qs,Infinity],intervals=[];
    for(let i=1;i<edges.length;i++){
      const lo=edges[i-1],hi=edges[i],mid=!Number.isFinite(lo)?hi-1:!Number.isFinite(hi)?lo+Math.max(1,Math.abs(lo)):(lo+hi)/2;
      if(u(mid)<=E+tol)intervals.push([lo,hi]);
    }
    const region=intervals.find(([lo,hi])=>q0>=lo-1e-8&&q0<=hi+1e-8);
    const resting=roots.some(r=>r.stationary&&Math.abs(r.q-q0)<1e-7);
    for(const root of roots)root.reachable=!resting&&Boolean(region)&&region.some(end=>Math.abs(end-root.q)<1e-7);
    let status,note;
    if(resting){status=physTranslate('Au repos à l’équilibre');note=physTranslate('Ici U = E et la force est nulle : ce point n’est pas un rebroussement. Une perturbation peut changer le mouvement.');}
    else if(model==='wells'){
      const barrier=u(M.equilibria(model)[1].q);
      if(Math.abs(E-barrier)<=tol){status=physTranslate('Au seuil de la barrière');note=physTranslate('Le sommet peut être approché asymptotiquement : il n’est pas franchi en un temps fini à cette énergie.');}
      else if(E<barrier){status=physTranslate('Confinement dans un puits');note=physTranslate('La barrière est plus haute que E. L’autre puits peut être énergétiquement accessible, mais il reste séparé du point de départ par une zone interdite.');}
      else {status=physTranslate('Barrière franchissable');note=physTranslate('E dépasse le maximum central : le mouvement relie les deux puits, mais reste confiné entre les deux rebroussements extérieurs.');}
    }else if(E<0){
      status=model==='pair'?physTranslate('Paire liée — mouvement confiné'):physTranslate('Séparation maximale finie');
      note=model==='pair'?physTranslate('E est négative : les atomes ne peuvent pas se séparer à l’infini.'):physTranslate('E est négative : un mouvement vers l’extérieur rebrousse chemin. Vers r = 0, ce modèle ponctuel est singulier ; il ne décrit pas une collision.');
    }else{
      status=E===0?physTranslate('Seuil d’échappement'):physTranslate('Échappement possible');
      note=physTranslate('U tend vers zéro à l’infini. Avec E ≥ 0, un mouvement vers l’extérieur n’a pas de rebroussement à grande distance.')+(model==='gravity'?physTranslate(' Un départ vers l’intérieur mène au contraire vers la singularité r = 0.'):'');
    }
    return {roots,intervals,region,status,note};
  }
  // Clip a sampled triangle/polygon on the forbidden side of the energy level.
  // x/y/u are interpolated only for drawing; the dynamics stays analytic.
  function forbidden(vertices,E){
    const out=[];
    for(let i=0;i<vertices.length;i++){
      const a=vertices[i],b=vertices[(i+1)%vertices.length],inside=a.u>E,next=b.u>E;
      if(inside)out.push(a);
      if(inside!==next){const t=(E-a.u)/(b.u-a.u);out.push({x:a.x+t*(b.x-a.x),y:a.y+t*(b.y-a.y),u:E});}
    }
    return out;
  }
  return {analyse,forbidden};
})();

function createPotentialMotion(helpers){
  'use strict';
  const {$,math,number,read,apply,stopSweep}=helpers,tex=String.raw,D=PotentialDynamics;
  const settings={mass:1,v0:0,angle:0};let config=null,system=null,run=null,initial=null,trail=[],playing=false,frameId=0,last=null;
  $('motion-rate').value='1';
  function setup(c){
    const pair=c.dimension===1&&c.model==='pair',gravity=c.dimension===1&&c.model==='gravity',radial=pair||gravity;
    // Equal masses and a stationary centre of mass in the radial examples.
    // U0*L0 = G*m_body^2 fixes the equal gravitational masses, not inertia
    // chosen independently from the gravitational potential.
    const bodyMass=pair?6.63e-26:gravity?Math.sqrt(c.energy*c.length/6.67430e-11):settings.mass,mass=radial?bodyMass/2:bodyMass;
    const timeScale=c.length*Math.sqrt(mass/c.energy),timeUnit=pair?1e-12:1,timeRate=pair?1e-12:gravity?100:1;
    const sample=q=>{
      if(c.dimension===2){const s=PotentialPlane.reduced(c.model,q[0],q[1]);return {u:s.u,a:[-s.gx,-s.gy]};}
      const s=PotentialModels.reduced(c.model,q[0]);return {u:s.u,a:[-s.du]};
    };
    return {sample,mass,bodyMass,pair,gravity,radial,timeScale,timeUnit,timeRate,vScale:Math.sqrt(c.energy/mass),energyUnit:pair?1e-21:1,energyTex:pair?tex`\times10^{-21}\,\mathrm J`:tex`\mathrm J`};
  }
  function pause(){if(playing)$('motion-status').textContent=physTranslate('En pause — Lire reprend le mouvement.');playing=false;last=null;if(frameId)cancelAnimationFrame(frameId);frameId=0;$('motion-play').textContent=physTranslate('Lire');$('motion-play').setAttribute('aria-pressed','false');}
  function readouts(){
    if(!run)return;const K=.5*run.w.reduce((s,v)=>s+v*v,0)*config.energy,E=D.energy(run,system.sample)*config.energy,drift=Math.abs(E/config.energy-run.E0)/Math.max(1,Math.abs(run.E0));
    number($('motion-time'),run.t*system.timeScale/system.timeUnit,2,system.pair?tex`\mathrm{ps}`:tex`\mathrm s`);
    number($('motion-kinetic'),K/system.energyUnit,3,system.energyTex);number($('motion-energy'),E/system.energyUnit,3,system.energyTex);
    $('motion-energy-check').textContent=run.t>0?physTranslate('Écart énergétique : ')+(100*drift).toFixed(4)+' %':physTranslate('Sans frottement');$('motion-energy-check').dataset.warning=String(drift>1e-3);
    number($('motion-v0-value'),settings.v0,system.gravity?4:system.pair?0:2,tex`\mathrm{m\,s^{-1}}`);number($('motion-angle-value'),settings.angle,0,tex`{}^\circ`);
    if(system.pair)math($('motion-mass-value'),tex`6.63\times10^{-26}\,\mathrm{kg}`);else number($('motion-mass-value'),system.bodyMass,2,tex`\mathrm{kg}`);
  }
  function seed(q){
    const speed=settings.v0/system.vScale,angle=settings.angle*Math.PI/180,w=config.dimension===2?[speed*Math.cos(angle),speed*Math.sin(angle)]:[speed];
    run=D.create(q,w,system.sample);trail=[[...q]];initial=[...q];
  }
  function resetAtPoint(resetSettings=false,repaint=true){
    pause();const next=read(),changed=!config||config.dimension!==next.dimension||config.model!==next.model;config=next;
    if(changed||resetSettings){settings.mass=1;settings.v0=0;settings.angle=0;}
    system=setup(config);seed(config.q);
    const max=system.pair?400:system.gravity?.02:3;
    $('motion-mass').hidden=system.radial;$('motion-mass').disabled=system.radial;$('motion-mass').value=settings.mass;
    math($('motion-mass-symbol'),system.radial?'m_1=m_2':'m');
    $('motion-v0').min=config.dimension===2?0:-max;$('motion-v0').max=max;$('motion-v0').step=system.gravity?.0001:system.pair?1:.01;$('motion-v0').value=settings.v0;
    $('motion-angle').value=settings.angle;$('motion-angle-row').hidden=config.dimension!==2;
    $('motion-v0-label').textContent=config.dimension===2?physTranslate('Module de la vitesse initiale'):system.radial?physTranslate('Vitesse relative initiale'):physTranslate('Vitesse initiale');
    math($('motion-v0-symbol'),config.dimension===2?tex`|\vec v_0|`:system.radial?tex`\dot r_0`:tex`v_{x0}`);
    $('motion-mass-note').textContent=system.radial?(system.gravity?physTranslate('Deux masses égales, fixées par les échelles du potentiel. '):physTranslate('Deux atomes de même masse. '))+physTranslate('Le centre de masse reste au repos ; le mouvement relatif utilise la moitié de la masse d’un corps. Une vitesse relative positive les éloigne.'):physTranslate('Modifier une position ou un paramètre redéfinit les conditions initiales.')+(config.dimension===2?physTranslate(' L’angle est mesuré depuis +x vers +y.'):'');
    $('motion-clock-note').textContent=system.pair?physTranslate('Lecture normale : 1 ps simulée par seconde à l’écran.'):system.gravity?physTranslate('Lecture normale : 100 s simulées par seconde à l’écran.'):physTranslate('Lecture normale : 1 s simulée par seconde à l’écran.');
    $('motion-status').textContent=physTranslate('Choisissez la position initiale, puis appuyez sur Lire.');
    readouts();if(repaint)apply(run.q,trail);
  }
  function frame(now){
    frameId=0;if(!playing)return;const elapsed=last===null?0:Math.max(0,Math.min(.05,(now-last)/1000));last=now;
    try{
      const dt=elapsed*Number($('motion-rate').value)*system.timeRate/system.timeScale;
      D.advance(run,dt,system.sample,config.bounds);
      if(elapsed>0){trail.push([...run.q]);if(trail.length>1800)trail=trail.filter((_,i)=>i===0||i%2===0||i===trail.length-1);}
      readouts();apply(run.q,trail);
      if(run.ended){pause();$('motion-status').textContent=physTranslate('La particule a atteint le bord du domaine représenté. Recommencez ou choisissez une autre position initiale.');return;}
      const drift=Math.abs(D.energy(run,system.sample)-run.E0)/Math.max(1,Math.abs(run.E0));
      if(drift>.01)throw new Error(physTranslate('précision énergétique insuffisante'));
    }catch(error){pause();readouts();$('motion-status').textContent=physTranslate('Simulation arrêtée : ')+error.message+'.';return;}
    frameId=requestAnimationFrame(frame);
  }
  function toggle(){
    if(playing){pause();readouts();$('motion-status').textContent=physTranslate('En pause — Lire reprend le mouvement.');return;}
    stopSweep();const position=read().q;if(!run||position.some((q,i)=>Math.abs(q-run.q[i])>1e-10))resetAtPoint();
    if(run.ended){$('motion-status').textContent=physTranslate('Bord du domaine atteint. Appuyez sur Recommencer ou déplacez le point.');return;}
    playing=true;last=null;$('motion-play').textContent='Pause';$('motion-play').setAttribute('aria-pressed','true');$('motion-status').textContent=physTranslate('Mouvement sous l’action de la force, sans frottement.');frameId=requestAnimationFrame(frame);
  }
  function restart(){pause();stopSweep();seed(initial||read().q);readouts();apply(run.q,trail);$('motion-status').textContent=physTranslate('Retour aux conditions initiales.');}
  $('motion-play').addEventListener('click',toggle);$('motion-restart').addEventListener('click',restart);
  for(const key of ['mass','v0','angle'])$('motion-'+key).addEventListener('input',()=>{
    const el=$('motion-'+key),v=Number(el.value);if(!Number.isFinite(v))return;settings[key]=Math.max(Number(el.min),Math.min(Number(el.max),v));stopSweep();resetAtPoint();
  });
  resetAtPoint();return {pause,toggle,restart,resetAtPoint,
    initialVelocity:()=>{
      if(!run||config.dimension!==2||settings.v0===0)return null;
      const angle=settings.angle*Math.PI/180;
      return {model:config.model,q:[...initial],v:[settings.v0*Math.cos(angle),settings.v0*Math.sin(angle)],speed:settings.v0};
    },
    capture:()=>({settings:{...settings},run,initial,trail}),
    restore:s=>{
      pause();resetAtPoint();PhysShare.set(settings,s.settings);PhysShare.range(settings.mass,.01,1e6);resetAtPoint();
      if(!s.run||s.run.q.length!==config.dimension||s.run.w.length!==config.dimension)throw Error(physTranslate('Dimension mécanique incohérente.'));
      PhysShare.range(s.run.t,0,1e12);run=PhysShare.clone(s.run);initial=[...s.initial];trail=PhysShare.clone(s.trail);
      readouts();apply(run.q,trail);$('motion-status').textContent=physTranslate('Configuration restaurée — en pause.');
    },
    energy:()=>run?{E:run.E0*config.energy,q0:[...initial],dimension:config.dimension,model:config.model}:null};
}

function createPotentialPlane(helpers){
  'use strict';
  const {$,math,number,label,surface,line,dot,colors,onChange=()=>{},getEnergy=()=>null,getInitialVelocity=()=>null}=helpers;
  const P=PotentialPlane,B=P.bound,tex=String.raw;
  const state={model:'bowl',qx:.85,qy:.5,energy:1,length:1,active:false};
  let cache=null,surfaceMesh=null,surfaceCache=null,trajectory=[];
  const camera={...PotentialSurface.initial};
  const sample=(x=state.qx,y=state.qy)=>P.evaluate(state.model,x,y,state.energy,state.length);
  function energyLevel(){
    if(!$('energy-accessibility').checked)return null;
    const e=getEnergy();return e?.dimension===2&&e.model===state.model?e.E:sample().U;
  }
  const clear=layer=>{for(const el of $(layer).children)el.hidden=true;};
  const clip=q=>Math.max(-B,Math.min(B,q));
  const mapGeometry=(w,h)=>P.geometry(w,h,state.model==='saddle'?48:0);
  function choose(x,y){if(![x,y].every(Number.isFinite))return;state.qx=clip(x);state.qy=clip(y);onChange(false);render();}
  function configure(reset=false){
    if(reset){state.energy=1;state.length=1;[state.qx,state.qy]=P.definitions[state.model].start;}
    $('plane-model-note').textContent=P.definitions[state.model].note;math($('plane-formula'),P.definitions[state.model].formula);
    for(const key of ['energy','length'])$('plane-'+key).value=state[key];
    $('plane-equilibria').replaceChildren(...P.equilibria(state.model,state.energy,state.length).map((eq,i)=>{
      const button=document.createElement('button'),name=document.createElement('span'),value=document.createElement('span');button.type='button';button.dataset.qx=eq.qx;button.dataset.qy=eq.qy;button.dataset.stability=eq.stable?'stable':'unstable';
      name.textContent=eq.stable?'Minimum — stable':physTranslate('Col — instable');value.className='eq-position';math(value,tex`(${eq.x.toFixed(2)},\,${eq.y.toFixed(2)})\,\mathrm m`);button.append(name,value);button.addEventListener('click',()=>choose(eq.qx,eq.qy));return button;
    }));onChange(reset);render();
  }
  function arrow(ctx,a,b,color,width=2.5,dash=[]){
    const dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);if(length<.05)return;
    const ux=dx/length,uy=dy/length,head=Math.min(9,length*.4),base=[b[0]-head*ux,b[1]-head*uy];
    line(ctx,[a,[b[0]-.5*head*ux,b[1]-.5*head*uy]],color,width,dash);
    ctx.beginPath();ctx.moveTo(...b);ctx.lineTo(base[0]-.45*head*uy,base[1]+.45*head*ux);ctx.lineTo(b[0]-.72*head*ux,b[1]-.72*head*uy);ctx.lineTo(base[0]+.45*head*uy,base[1]-.45*head*ux);ctx.closePath();ctx.fillStyle=color;ctx.fill();
  }
  function initialVelocity(){const v=getInitialVelocity();return v?.model===state.model?v:null;}
  function drawInitialVelocity(ctx,layer,w,h,project){
    const initial=initialVelocity();if(!initial)return;
    const [qx,qy]=initial.q,U=sample(qx,qy).U,a=project(qx,qy,U),vx=project(qx+1,qy,U),vy=project(qx,qy+1,U);
    // One scale for every direction and speed at this starting point. Reduce
    // it near the viewport edges, using the slider maximum (3 m/s), not v0.
    // Holding U fixed projects a physical xy vector, not a slope of U(x,y).
    let k=Math.min(85,.24*Math.min(w,h))/(3*Math.max(Math.hypot(vx[0]-a[0],vx[1]-a[1]),Math.hypot(vy[0]-a[0],vy[1]-a[1])));
    for(let i=0;i<2;i++){
      const component=Math.hypot(vx[i]-a[i],vy[i]-a[i]);
      if(component>1e-12)k=Math.min(k,Math.max(0,Math.min(a[i]-12,(i===0?w:h)-12-a[i]))/(3*component));
    }
    const b=project(qx+k*initial.v[0],qy+k*initial.v[1],U),dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);
    arrow(ctx,a,b,colors.velocity,2.6,[5,3]);
    // The ring stays at the launch point even after the particle moves away.
    dot(ctx,a[0],a[1],5.5,colors.velocity);dot(ctx,a[0],a[1],3.2,'#fff');
    const nx=length>1e-8?-dy/length:0,ny=length>1e-8?dx/length:-1;
    label(layer,'initial-velocity',tex`\vec v_0`,Math.max(28,Math.min(w-28,a[0]+.62*dx+18*nx)),Math.max(20,Math.min(h-20,a[1]+.62*dy+18*ny)),colors.velocity);
  }
  function background(w,h){
    const E=energyLevel(),key=[state.model,state.energy,state.length,w,h,$('plane-contours').checked,E].join('|');if(cache?.key===key)return cache;
    const g=mapGeometry(w,h),canvas=document.createElement('canvas'),dpr=Math.min(2,window.devicePixelRatio||1);canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);
    const n=88,values=Array.from({length:n+1},(_,j)=>Array.from({length:n+1},(_,i)=>sample(-B+2*B*i/n,B-2*B*j/n).U));
    const all=values.flat().concat(P.equilibria(state.model,state.energy,state.length).map(s=>s.U)),low=Math.min(...all),high=Math.max(...all),span=high-low;
    const color=v=>PotentialSurface.color(v,low,high);
    for(let j=0;j<n;j++)for(let i=0;i<n;i++){ctx.fillStyle=color((values[j][i]+values[j+1][i]+values[j][i+1]+values[j+1][i+1])/4);ctx.fillRect(g.left+i*g.side/n,g.top+j*g.side/n,g.side/n+.5,g.side/n+.5);}
    if($('plane-contours').checked){
      const levels=Array.from({length:10},(_,i)=>low+(i+1)*span/11);if(low<0&&high>0)levels.push(0);
      for(const level of levels){ctx.beginPath();for(const [a,b]of P.contours(values,level)){ctx.moveTo(g.left+a[0]*g.side/n,g.top+a[1]*g.side/n);ctx.lineTo(g.left+b[0]*g.side/n,g.top+b[1]*g.side/n);}ctx.strokeStyle='rgba(83,102,123,.44)';ctx.lineWidth=level===0?1.4:1;ctx.stroke();}
    }
    if(E!==null){
      for(let j=0;j<n;j++)for(let i=0;i<n;i++){
        const quad=[[i,j],[i+1,j],[i+1,j+1],[i,j+1]].map(([x,y])=>({x,y,u:values[y][x]}));
        for(const indices of [[0,1,2],[0,2,3]]){
          const polygon=PotentialEnergy.forbidden(indices.map(k=>quad[k]),E);if(polygon.length<3)continue;
          ctx.beginPath();polygon.forEach((v,k)=>ctx[k?'lineTo':'moveTo'](g.left+v.x*g.side/n,g.top+v.y*g.side/n));ctx.closePath();ctx.fillStyle=colors.forbidden;ctx.fill();ctx.strokeStyle=colors.forbidden;ctx.lineWidth=.5;ctx.stroke();
        }
      }
      for(const [a,b]of P.contours(values,E))line(ctx,[[g.left+a[0]*g.side/n,g.top+a[1]*g.side/n],[g.left+b[0]*g.side/n,g.top+b[1]*g.side/n]],colors.energy,1.2);
    }
    // One linear scale fitted across the WHOLE domain, never to the current
    // point. It is shared by the force and both component arrows.
    let factor=Infinity;
    for(let j=0;j<=40;j++)for(let i=0;i<=40;i++){
      const x=-B+2*B*i/40,y=-B+2*B*j/40,s=sample(x,y),sx=g.X(x),sy=g.Y(y),f=Math.hypot(s.Fx,s.Fy);
      if(f>1e-12)factor=Math.min(factor,(state.model==='saddle'?Math.min(110,g.side*.48):Math.min(90,g.side*.27))/f);
      if(Math.abs(s.Fx)>1e-12)factor=Math.min(factor,.85*(s.Fx>0?w-16-sx:sx-16)/Math.abs(s.Fx));
      if(Math.abs(s.Fy)>1e-12)factor=Math.min(factor,.85*(s.Fy>0?sy-14:h-18-sy)/Math.abs(s.Fy));
    }
    cache={key,canvas,g,low,high,factor};return cache;
  }
  function drawMap(s){
    const {ctx,w,h}=surface('plane-canvas');if(w<100||h<100)return;
    const bg=background(w,h),g=bg.g,k=bg.factor,layer='plane-labels';clear(layer);ctx.drawImage(bg.canvas,0,0,w,h);
    const count=w<450?1:2;
    for(let i=-count;i<=count;i++){const q=B*i/count,x=g.X(q),y=g.Y(q),value=q===0?'0':(q*state.length).toFixed(2);label(layer,'x'+i,value,x,g.bottom+g.vectorRoom+17,colors.muted,true);label(layer,'y'+i,value,g.left-27,y,colors.muted,true);}
    label(layer,'x-unit',tex`x\,[\mathrm m]`,(g.left+g.right)/2,g.bottom+g.vectorRoom+40);label(layer,'y-unit',tex`y\,[\mathrm m]`,g.left,12).style.transform='translate(0,-50%)';
    line(ctx,[[g.X(0),g.top],[g.X(0),g.bottom]],colors.muted,1,[2,5]);line(ctx,[[g.left,g.Y(0)],[g.right,g.Y(0)]],colors.muted,1,[2,5]);
    const a=[g.X(state.qx),g.Y(state.qy)],b=[a[0]+k*s.Fx,a[1]-k*s.Fy];
    line(ctx,[[g.left,a[1]],[g.right,a[1]]],colors.body,1,[5,5]);line(ctx,[[a[0],g.top],[a[0],g.bottom]],colors.stable,1,[5,5]);
    for(const eq of P.equilibria(state.model,state.energy,state.length)){dot(ctx,g.X(eq.qx),g.Y(eq.qy),4,eq.stable?colors.stable:colors.unstable);}
    if(trajectory.length>1)line(ctx,trajectory.map(q=>[g.X(q[0]),g.Y(q[1])]),'#8495a7',2);
    if($('plane-force').checked){
      if($('plane-components').checked){arrow(ctx,a,[b[0],a[1]],colors.body,1.8);arrow(ctx,a,[a[0],b[1]],colors.stable,1.8);line(ctx,[[b[0],a[1]],b,[a[0],b[1]]],colors.muted,1,[2,4]);}
      arrow(ctx,a,b,colors.F,3);
    }
    drawInitialVelocity(ctx,layer,w,h,(x,y)=>[g.X(x),g.Y(y)]);
    dot(ctx,...a,5,colors.body);
    const reference=Number((40/k).toPrecision(2));$('plane-scale-arrow').style.width=reference*k+'px';number($('plane-scale-value'),reference,2,tex`\mathrm N`);$('plane-scale-key').hidden=!$('plane-force').checked;
    number($('plane-color-low'),bg.low,2,tex`\mathrm J`);number($('plane-color-high'),bg.high,2,tex`\mathrm J`);
    const v0=initialVelocity(),velocityText=v0?physTranslate(` Vitesse initiale : vx = ${v0.v[0].toFixed(3)} m/s, vy = ${v0.v[1].toFixed(3)} m/s, flèche fixée au point de départ.`):'';
    $('plane-map').setAttribute('aria-label',physTranslate(`Point x = ${s.x.toFixed(3)} m, y = ${s.y.toFixed(3)} m. Potentiel ${s.U.toFixed(3)} J. Fx = ${s.Fx.toFixed(3)} N, Fy = ${s.Fy.toFixed(3)} N.${velocityText} Utilisez les flèches pour déplacer le point.`));
  }
  function surfaceBackground(w,h){
    const meshKey=state.model+'|'+state.energy;
    if(surfaceMesh?.key!==meshKey)surfaceMesh={key:meshKey,...PotentialSurface.mesh(state.model,state.energy)};
    const E=energyLevel(),key=[meshKey,state.length,w,h,camera.azimuth,camera.elevation,$('plane-contours').checked,E].join('|');
    if(surfaceCache?.key===key)return surfaceCache;
    const projection=PotentialSurface.projection(w,h,surfaceMesh.low,surfaceMesh.high,camera),scene=PotentialSurface.scene(surfaceMesh,projection),project=projection.project;
    const canvas=document.createElement('canvas'),dpr=Math.min(2,window.devicePixelRatio||1);canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);
    const path=(points,fill)=>{ctx.beginPath();ctx.moveTo(...points[0].slice(0,2));for(const p of points.slice(1))ctx.lineTo(...p.slice(0,2));ctx.closePath();ctx.fillStyle=fill;ctx.fill();};
    const floor=[[-B,-B],[B,-B],[B,B],[-B,B]].map(([x,y])=>project(x,y,projection.base));path(floor,'#f1f4f8');
    for(const q of [-B,-B/2,0,B/2,B])for(const axis of ['x','y'])line(ctx,(axis==='x'?[[-B,q],[B,q]]:[[q,-B],[q,B]]).map(([x,y])=>project(x,y,projection.base).slice(0,2)),colors.grid,1);
    for(const f of scene.faces){
      path(f.screen,f.color);ctx.strokeStyle=f.color;ctx.lineWidth=.55;ctx.setLineDash([]);ctx.stroke();
      if(E!==null){const polygon=PotentialEnergy.forbidden(f.v,E);if(polygon.length>2){path(polygon.map(v=>project(v.x,v.y,v.u)),colors.forbidden);ctx.strokeStyle=colors.forbidden;ctx.lineWidth=.55;ctx.stroke();}}
    }
    if($('plane-contours').checked){
      const values=surfaceMesh.vertices.map(row=>row.map(v=>v.u)),n=values.length-1,levels=Array.from({length:10},(_,i)=>surfaceMesh.low+(i+1)*(surfaceMesh.high-surfaceMesh.low)/11);
      if(surfaceMesh.low<0&&surfaceMesh.high>0)levels.push(0);
      ctx.beginPath();
      for(const u of levels)for(const segment of P.contours(values,u)){
        const a=project(-B+2*B*segment[0][0]/n,-B+2*B*segment[0][1]/n,u),b=project(-B+2*B*segment[1][0]/n,-B+2*B*segment[1][1]/n,u);
        if(scene.visible(a)&&scene.visible(b)){ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);}
      }
      ctx.strokeStyle='rgba(83,102,123,.48)';ctx.lineWidth=.85;ctx.stroke();
    }
    if(E!==null){
      const values=surfaceMesh.vertices.map(row=>row.map(v=>v.u)),n=values.length-1;
      for(const [a,b]of P.contours(values,E)){
        const pa=project(-B+2*B*a[0]/n,-B+2*B*a[1]/n,E),pb=project(-B+2*B*b[0]/n,-B+2*B*b[1]/n,E);
        if(scene.visible(pa)&&scene.visible(pb))line(ctx,[pa.slice(0,2),pb.slice(0,2)],colors.energy,1.3);
      }
    }
    const forceFactor=PotentialSurface.forceFactor(surfaceMesh,state.model,state.energy,state.length,projection,w,h);
    surfaceCache={key,canvas,projection,scene,forceFactor};return surfaceCache;
  }
  function drawSurface(s=sample()){
    if(!state.active||!$('plane-show-surface').checked)return;
    const {ctx,w,h}=surface('surface-canvas');if(w<100||h<100)return;
    const bg=surfaceBackground(w,h),{project,base,top}=bg.projection,layer='surface-labels';clear(layer);ctx.drawImage(bg.canvas,0,0,w,h);
    // The two physical coordinates share the same scale; the energy axis is
    // separate and labelled in joules, including its zero.
    const cx=Math.sin(camera.azimuth)>=0?B:-B,cy=Math.cos(camera.azimuth)>=0?B:-B,center=project(0,0,base);
    for(const axis of ['x','y']){
      const at=q=>axis==='x'?project(q,cy,base):project(cx,q,base),a=at(-B),b=at(B),mid=at(0),dx=mid[0]-center[0],dy=mid[1]-center[1],d=Math.hypot(dx,dy)||1,out=[dx/d,dy/d];
      line(ctx,[a.slice(0,2),b.slice(0,2)],colors.muted,1.2);
      const ticks=Math.hypot(b[0]-a[0],b[1]-a[1])<100?[0]:[-B,0,B];
      for(const q of ticks){const p=at(q);line(ctx,[p.slice(0,2),[p[0]+out[0]*4,p[1]+out[1]*4]],colors.muted,1);label(layer,axis+q,q===0?'0':(q*state.length).toFixed(2),p[0]+out[0]*18,p[1]+out[1]*18,colors.muted,true);}
      label(layer,'unit-'+axis,axis+tex`\,[\mathrm m]`,mid[0]+out[0]*42,mid[1]+out[1]*42);
    }
    const corners=[[-B,-B],[-B,B],[B,-B],[B,B]],left=corners.reduce((a,b)=>project(...a,base)[0]<project(...b,base)[0]?a:b),bottom=project(...left,base),tip=project(...left,top),zHeight=bottom[1]-tip[1];
    if(zHeight>30){
      line(ctx,[bottom.slice(0,2),tip.slice(0,2)],colors.muted,1.2);
      const values=[0];for(const v of [surfaceMesh.low,surfaceMesh.high])if(!values.some(u=>Math.abs(project(...left,u)[1]-project(...left,v)[1])<26))values.push(v);
      for(const u of values){const p=project(...left,u);line(ctx,[[p[0]-4,p[1]],[p[0],p[1]]],colors.muted,1);label(layer,'u'+u,u===0?'0':u.toFixed(2),p[0]-8,p[1],colors.muted,true).style.transform='translate(-100%,-50%)';}
      label(layer,'unit-u',tex`U\,[\mathrm J]`,tip[0],tip[1]-19);
    }else label(layer,'unit-u',tex`U\,[\mathrm J]`,w/2,16);
    for(const axis of ['x','y']){
      let segment=[];const flush=()=>{line(ctx,segment,axis==='x'?colors.body:colors.stable,2.5);segment=[];};
      for(let i=0;i<=180;i++){
        const q=-B+2*B*i/180,x=axis==='x'?q:state.qx,y=axis==='y'?q:state.qy,p=project(x,y,sample(x,y).U);
        if(bg.scene.visible(p))segment.push(p.slice(0,2));else flush();
      }flush();
    }
    for(const eq of P.equilibria(state.model,state.energy,state.length)){const p=project(eq.qx,eq.qy,eq.U);if(bg.scene.visible(p))dot(ctx,p[0],p[1],3.5,eq.stable?colors.stable:colors.unstable);}
    if(trajectory.length>1){
      let segment=[];const flush=()=>{line(ctx,segment,'#8495a7',2);segment=[];};
      for(const q of trajectory){const p=project(q[0],q[1],sample(q[0],q[1]).U);if(bg.scene.visible(p))segment.push(p.slice(0,2));else flush();}flush();
    }
    const point=project(state.qx,state.qy,s.U),visible=bg.scene.visible(point),showForce=$('plane-force').checked,norm=Math.hypot(s.Fx,s.Fy);
    $('surface-force-key').hidden=!showForce;$('surface-point-note').hidden=visible;
    $('surface-point-note').textContent=showForce?physTranslate('Le point choisi est derrière le relief ; le point et la force sont montrés au premier plan.'):physTranslate('Le point choisi est masqué par le relief. Faites pivoter la vue pour le retrouver.');
    math($('surface-force-caption'),norm<1e-10?tex`\vec F=\vec 0`:tex`\vec F=-\nabla U`);
    if(showForce&&norm>=1e-10){
      // U is unchanged along the drawn vector: it represents a force in the
      // physical x/y plane, NOT a spatial vertical force or a surface tangent.
      const k=bg.forceFactor,a=point.slice(0,2),tip=project(state.qx+k*s.Fx,state.qy+k*s.Fy,s.U).slice(0,2);
      if($('plane-components').checked){
        const xTip=project(state.qx+k*s.Fx,state.qy,s.U).slice(0,2),yTip=project(state.qx,state.qy+k*s.Fy,s.U).slice(0,2);
        line(ctx,[xTip,tip,yTip],colors.muted,1,[2,4]);arrow(ctx,a,xTip,colors.body,1.8);arrow(ctx,a,yTip,colors.stable,1.8);
      }
      arrow(ctx,a,tip,colors.F,3.5);
      const dx=tip[0]-a[0],dy=tip[1]-a[1],d=Math.hypot(dx,dy);
      if(d>1){const lx=a[0]+.65*dx-18*dy/d,ly=a[1]+.65*dy+18*dx/d;label(layer,'force',tex`\vec F`,Math.max(24,Math.min(w-24,lx)),Math.max(20,Math.min(h-20,ly)),colors.F);}
    }
    drawInitialVelocity(ctx,layer,w,h,project);
    if(visible||showForce){dot(ctx,point[0],point[1],7,'#fff');dot(ctx,point[0],point[1],5,colors.body);}
    $('plane-surface').setAttribute('aria-label',physTranslate(`Surface du potentiel. Point x = ${s.x.toFixed(3)} m, y = ${s.y.toFixed(3)} m, U = ${s.U.toFixed(3)} J. Fx = ${s.Fx.toFixed(3)} N, Fy = ${s.Fy.toFixed(3)} N. Faites glisser ou utilisez les touches fléchées pour tourner la vue. Cliquez pour choisir un point.`));
  }
  function drawSlice(axis,s,eq){
    const {ctx,w,h}=surface('plane-'+axis+'-canvas'),layer='plane-'+axis+'-labels';if(w<100)return;clear(layer);
    const r={left:64,right:Math.max(90,w-22),top:30,bottom:h-44},read=q=>axis==='x'?sample(q,state.qy):sample(state.qx,q),points=Array.from({length:201},(_,i)=>({q:-B+2*B*i/200,s:read(-B+2*B*i/200)}));
    const E=energyLevel(),values=points.map(p=>p.s.U);if(E!==null)values.push(E);
    const min=Math.min(0,...values),max=Math.max(0,...values),span=Math.max(.1*state.energy,max-min),low=min-.12*span,high=max+.12*span;
    const X=q=>r.left+(q+B)*(r.right-r.left)/(2*B),Y=u=>r.bottom-(u-low)*(r.bottom-r.top)/(high-low);
    const count=w<450?1:2;
    for(let i=-count;i<=count;i++){const q=B*i/count,x=X(q);line(ctx,[[x,r.top],[x,r.bottom]],colors.grid);label(layer,'x'+i,q===0?'0':(q*state.length).toFixed(2),x,r.bottom+15,colors.muted,true);}
    for(let i=0;i<=4;i++){const v=low+(high-low)*i/4,y=Y(v);line(ctx,[[r.left,y],[r.right,y]],colors.grid);if(Math.abs(y-Y(0))>=22)label(layer,'y'+i,v.toFixed(1),r.left-27,y,colors.muted,true);}
    label(layer,'y-zero','0',r.left-27,Y(0),colors.muted,true);
    label(layer,'unit-y',tex`U\,[\mathrm J]`,r.left,12).style.transform='translate(0,-50%)';label(layer,'unit-x',axis+tex`\,[\mathrm m]`,(r.left+r.right)/2,h-9);
    ctx.save();ctx.beginPath();ctx.rect(r.left,r.top,r.right-r.left,r.bottom-r.top);ctx.clip();
    if(E!==null){
      ctx.fillStyle=colors.forbidden;
      for(let i=1;i<points.length;i++){
        const a=points[i-1],b=points[i];let lo=a.q,hi=b.q;
        if(a.s.U<=E&&b.s.U<=E)continue;
        if((a.s.U>E)!==(b.s.U>E)){const q=a.q+(E-a.s.U)/(b.s.U-a.s.U)*(b.q-a.q);if(a.s.U>E)hi=q;else lo=q;}
        ctx.fillRect(X(lo),r.top,X(hi)-X(lo),r.bottom-r.top);
      }
    }
    line(ctx,[[r.left,Y(0)],[r.right,Y(0)]],colors.zero,.9);
    if(E!==null){
      line(ctx,[[r.left,Y(E)],[r.right,Y(E)]],colors.energy,1.2,[6,4]);
      label(layer,'total-energy','E',r.right-9,Y(E)-13,colors.energy);
    }
    line(ctx,points.map(p=>[X(p.q),Y(p.s.U)]),colors.U,2.2);
    const q=state[axis==='x'?'qx':'qy'],slope=axis==='x'?-s.Fx:-s.Fy,half=.28;
    line(ctx,[[X(q-half),Y(s.U-slope*half*state.length)],[X(q+half),Y(s.U+slope*half*state.length)]],colors.tangent,2);
    if(eq){const H=axis==='x'?eq.Hxx:eq.Hyy;line(ctx,Array.from({length:61},(_,i)=>{const delta=(i-30)*.012;return [X(q+delta),Y(eq.U+.5*H*(delta*state.length)**2)];}),colors.quadratic,2.2,[6,4]);}
    dot(ctx,X(q),Y(s.U),5,colors.body);ctx.restore();
    const heading=$('plane-cut-'+axis);let value=heading.querySelector('output');
    if(!value){const prefix=document.createElement('span');math(prefix,(axis==='x'?'y':'x')+'=');value=document.createElement('output');heading.replaceChildren(prefix,value);}
    number(value,s[axis==='x'?'y':'x'],2,tex`\mathrm m`);
    const plot=$('plane-'+axis+'-plot');plot.setAttribute('aria-valuemin',-B*state.length);plot.setAttribute('aria-valuemax',B*state.length);plot.setAttribute('aria-valuenow',s[axis]);plot.setAttribute('aria-valuetext',axis+' = '+s[axis].toFixed(3)+' m');
  }
  function render(){
    if(!state.active)return;
    const v0=initialVelocity();
    for(const prefix of ['plane','surface']){
      $(prefix+'-velocity-key').hidden=!v0;
      if(v0)number($(prefix+'-velocity-value'),v0.speed,2,tex`\mathrm{m\,s^{-1}}`);
    }
    const E=energyLevel();$('plane-energy-guide').hidden=E===null;if(E!==null)number($('plane-energy-level'),E,3,tex`\mathrm J`);
    const s=sample(),eq=P.equilibria(state.model,state.energy,state.length).find(e=>Math.hypot(e.qx-state.qx,e.qy-state.qy)<1e-6);
    for(const [axis,key]of [['x','qx'],['y','qy']]){$('plane-'+axis).value=state[key];number($('plane-'+axis+'-value'),s[axis],3,tex`\mathrm m`);$('plane-'+axis).setAttribute('aria-valuetext',s[axis].toFixed(3)+' m');}
    number($('plane-energy-value'),state.energy,2,tex`\mathrm J`);number($('plane-length-value'),state.length,2,tex`\mathrm m`);
    number($('plane-U'),s.U,3,tex`\mathrm J`);number($('plane-Fx'),s.Fx,3,tex`\mathrm N`);number($('plane-Fy'),s.Fy,3,tex`\mathrm N`);number($('plane-norm'),Math.hypot(s.Fx,s.Fy),3,tex`\mathrm N`);
    for(const button of $('plane-equilibria').children)button.dataset.selected=String(Math.hypot(Number(button.dataset.qx)-state.qx,Number(button.dataset.qy)-state.qy)<1e-6);
    $('plane-status').textContent=eq?(eq.stable?physTranslate('Minimum stable'):physTranslate('Col — instable')):physTranslate('Force vers les potentiels décroissants');
    $('plane-observation-text').textContent=eq?(eq.stable?physTranslate('Les deux courbures principales sont positives : tout petit déplacement augmente le potentiel. L’équilibre est stable.'):physTranslate('Une courbure principale est négative et l’autre positive : la force rappelle dans une direction et éloigne dans l’autre. Ce col est un équilibre instable.')):physTranslate('La force totale combine les deux composantes. Chaque coupe conserve l’autre coordonnée fixe ;');
    $('plane-slope-explanation').hidden=Boolean(eq);
    $('plane-hessian').hidden=!eq;if(eq)math($('plane-eigenvalues'),tex`\lambda_1=${eq.eigen[0].toFixed(3)}\,\mathrm{N\,m^{-1}},\quad\lambda_2=${eq.eigen[1].toFixed(3)}\,\mathrm{N\,m^{-1}}`);
    $('plane-surface-card').hidden=!$('plane-show-surface').checked;
    drawSurface(s);drawMap(s);drawSlice('x',s,eq);drawSlice('y',s,eq);
  }
  for(const [id,key]of [['plane-x','qx'],['plane-y','qy']])$(id).addEventListener('input',()=>choose(key==='qx'?Number($(id).value):state.qx,key==='qy'?Number($(id).value):state.qy));
  for(const key of ['energy','length'])$('plane-'+key).addEventListener('input',()=>{const value=Number($('plane-'+key).value);if(Number.isFinite(value)&&value>0){state[key]=value;configure();}});
  $('plane-model').addEventListener('change',()=>{const model=$('plane-model').value;if(Object.hasOwn(P.definitions,model)){state.model=model;configure(true);}});
  $('plane-reset').addEventListener('click',()=>configure(true));
  for(const id of ['plane-contours','plane-force','plane-components','plane-show-surface'])$(id).addEventListener('change',render);
  function keyboard(e,axis=null){
    if(e.ctrlKey||e.metaKey||e.altKey)return;const step=.02*(e.shiftKey?5:1);let x=state.qx,y=state.qy;
    if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();if(axis)x+=axis==='x'?(e.key==='ArrowLeft'||e.key==='ArrowDown'?-step:step):0;else x+=e.key==='ArrowLeft'?-step:e.key==='ArrowRight'?step:0;if(axis)y+=axis==='y'?(e.key==='ArrowLeft'||e.key==='ArrowDown'?-step:step):0;else y+=e.key==='ArrowDown'?-step:e.key==='ArrowUp'?step:0;choose(x,y);}
    if(e.key==='Home'){e.preventDefault();if(axis)choose(axis==='x'?-B:x,axis==='y'?-B:y);else choose(0,0);}
    if(e.key==='End'&&axis){e.preventDefault();choose(axis==='x'?B:x,axis==='y'?B:y);}
  }
  for(const axis of [null,'x','y']){
    const el=$(axis?'plane-'+axis+'-plot':'plane-map');
    const seek=e=>{const r=el.getBoundingClientRect();if(axis){const q=-B+2*B*(e.clientX-r.left-64)/(Math.max(90,r.width-22)-64);choose(axis==='x'?q:state.qx,axis==='y'?q:state.qy);}else{const g=mapGeometry(r.width,r.height);choose(-B+2*B*(e.clientX-r.left-g.left)/g.side,B-2*B*(e.clientY-r.top-g.top)/g.side);}};
    el.addEventListener('pointerdown',e=>{if((e.button!==undefined&&e.button!==0)||e.isPrimary===false)return;e.preventDefault();el.setPointerCapture(e.pointerId);seek(e);});
    el.addEventListener('pointermove',e=>{if(el.hasPointerCapture(e.pointerId))seek(e);});
    for(const event of ['pointerup','pointercancel','lostpointercapture'])el.addEventListener(event,e=>{if(el.hasPointerCapture(e.pointerId))el.releasePointerCapture(e.pointerId);});
    el.addEventListener('keydown',e=>keyboard(e,axis));
  }
  new ResizeObserver(render).observe($('plane-map'));
  new ResizeObserver(()=>drawSurface()).observe($('plane-surface'));
  const surfaceEl=$('plane-surface');let surfaceDrag=null;
  const turn=(azimuth,elevation)=>{camera.azimuth=Math.atan2(Math.sin(azimuth),Math.cos(azimuth));camera.elevation=Math.max(.18,Math.min(Math.PI/2,elevation));drawSurface();};
  $('surface-reset').addEventListener('click',()=>turn(PotentialSurface.initial.azimuth,PotentialSurface.initial.elevation));
  $('surface-top').addEventListener('click',()=>turn(0,Math.PI/2));
  surfaceEl.addEventListener('pointerdown',e=>{
    if((e.button!==undefined&&e.button!==0)||e.isPrimary===false)return;e.preventDefault();surfaceEl.setPointerCapture(e.pointerId);surfaceEl.dataset.dragging='true';surfaceDrag={id:e.pointerId,x:e.clientX,y:e.clientY,azimuth:camera.azimuth,elevation:camera.elevation,moved:false};
  });
  surfaceEl.addEventListener('pointermove',e=>{
    if(!surfaceDrag||surfaceDrag.id!==e.pointerId)return;const dx=e.clientX-surfaceDrag.x,dy=e.clientY-surfaceDrag.y;
    if(Math.hypot(dx,dy)>4)surfaceDrag.moved=true;
    if(surfaceDrag.moved)turn(surfaceDrag.azimuth-dx*.008,surfaceDrag.elevation+dy*.008);
  });
  for(const event of ['pointerup','pointercancel','lostpointercapture'])surfaceEl.addEventListener(event,e=>{
    if(!surfaceDrag||surfaceDrag.id!==e.pointerId)return;
    const select=event==='pointerup'&&!surfaceDrag.moved;surfaceDrag=null;surfaceEl.dataset.dragging='false';if(surfaceEl.hasPointerCapture(e.pointerId))surfaceEl.releasePointerCapture(e.pointerId);
    if(select&&surfaceCache){const r=surfaceEl.getBoundingClientRect(),hit=surfaceCache.scene.pick(e.clientX-r.left,e.clientY-r.top);if(hit)choose(hit.x,hit.y);}
  });
  surfaceEl.addEventListener('keydown',e=>{
    if(e.ctrlKey||e.metaKey||e.altKey)return;
    if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home'].includes(e.key)){
      e.preventDefault();if(e.key==='Home')turn(PotentialSurface.initial.azimuth,PotentialSurface.initial.elevation);
      else turn(camera.azimuth+(e.key==='ArrowLeft'?-.1:e.key==='ArrowRight'?.1:0),camera.elevation+(e.key==='ArrowUp'?.08:e.key==='ArrowDown'?-.08:0));
    }
  });
  configure();
  return {activate:on=>{state.active=on;render();},render,
    capture:()=>({state:{...state},camera:{...camera},trajectory}),
    restore:s=>{PhysShare.member(s.state.model,Object.keys(P.definitions));PhysShare.range(s.state.energy,.01,100);PhysShare.range(s.state.length,.01,100);PhysShare.set(state,s.state);PhysShare.set(camera,s.camera);trajectory=PhysShare.clone(s.trajectory);configure();},
    configuration:()=>({dimension:2,model:state.model,energy:state.energy,length:state.length,q:[state.qx,state.qy],bounds:[[-B,B],[-B,B]]}),
    move:(q,trail)=>{[state.qx,state.qy]=q;trajectory=trail;render();}
  };
}
