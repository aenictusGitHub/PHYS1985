# Énergie potentielle et force — PHYS1985

Ouvrir `index.html` sans serveur ni connexion. MathJax et le thème commun sont
fournis localement. Les tracés sont originaux ; la vidéo « Potential Energy Force »
sert de référence pédagogique et n’est pas redistribuée.

## Une dimension

Trois exemples, dont les deux premiers reprennent les parties de la vidéo :

- Double puits asymétrique : U(x) = U0 [(q² − 1)² − q/3], avec q = x/L0.
  Cette fonction reproduit qualitativement deux minima séparés par un maximum,
  sans prétendre être la fonction exacte de la vidéo. Les trois équilibres sont
  calculés par recherche des zéros de la dérivée.
- Paire attractive–répulsive : potentiel de Lennard–Jones à exposants 12 et 6,
  U(r) = 4 epsilon [(sigma/r)^12 − (sigma/r)^6], sans troncature. Le minimum
  est à r = 2^(1/6) sigma et vaut −epsilon. Source de la formule :
  https://docs.lammps.org/pair_lj.html (la présente app ne tronque pas le potentiel).

- Gravitation universelle : U(r) = −Gm₁m₂/r = −U₀L₀/r et F_r = −Gm₁m₂/r².
  Les échelles U₀ et L₀ fixent Gm₁m₂ ; les masses sont ponctuelles et le potentiel
  de la paire est compté une seule fois, avec zéro à l’infini. Il n’existe pas
  d’équilibre à distance finie. Le schéma montre deux forces égales et opposées.

Le double puits et la gravitation utilisent des échelles pédagogiques en mètres et joules.
Les axes verticaux du potentiel et de la force affichent explicitement « 0 » ;
les graduations voisines trop proches ne sont pas superposées à ce repère.
La paire utilise par défaut les paramètres usuels de l’argon : sigma = 0.3405 nm,
epsilon/k_B = 119.8 K, soit epsilon ≈ 1.654 × 10^-21 J (valeur arrondie).
La distance d’équilibre entre centres vaut 2^(1/6) sigma ≈ 0.382 nm.
Source : Heyes, Dini et Smith (2020), https://doi.org/10.1002/pssb.202000344,
section 2.1 ; https://d-nb.info/1260679276/34. Le potentiel reste ici non tronqué.
Les calculs restent en SI. Pour la paire, l’affichage utilise nm, 10^-21 J et pN
(1 pN = 10^-12 N = 10^-12 J/m) pour ne pas arrondir les valeurs atomiques à zéro.
Chaque exemple permet de régler l’échelle d’énergie et de longueur ; les plages
de la paire sont 0.25–0.50 nm et (0.5–4) × 10^-21 J. Changer les paramètres explore
un modèle atomique générique ; « Réinitialiser » restaure les valeurs de l’argon.
Changer d’exemple restaure les échelles propres à celui-ci.
La dérivée analytique donne la force, sans différences finies dans l’application.
Le graphe du potentiel est un graphe d’énergie, pas une piste matérielle.

Déplacer le curseur, cliquer ou faire glisser sur l’un des graphiques, ou déplacer
les corps règle le même point de lecture. Les deux graphiques ont le même axe
horizontal. Les touches fléchées, Début et Fin offrent le même contrôle au clavier.
Les boutons d’équilibre placent le point exactement sur les minima ou le maximum.
Ils affichent la dérivée seconde analytique au point d’équilibre, sa valeur en
N/m et son signe. Le critère s’applique après U′ = 0 : U″ > 0 correspond à un
minimum local stable ; U″ < 0 à un maximum local instable. Si U″ = 0, la dérivée
seconde seule ne conclut pas : il faut examiner le potentiel au voisinage du point.
La relation locale F_x(x_e + δx) ≃ −U″(x_e) δx explique la force de rappel ou
d’éloignement ; la même relation s’applique à F_r et à la séparation radiale r.
La valeur et l’explication sont aussi affichées lorsque l’on sélectionne un équilibre.
Le critère radial concerne la séparation des corps, sans imposer leur orientation.
Lorsqu’un équilibre est sélectionné, le graphe du potentiel superpose une parabole
bleue en pointillés : U(x) ≃ U(x_e) + ½ U″(x_e)(x − x_e)² (avec r pour la paire).
Le terme linéaire est nul à l’équilibre. La parabole est limitée à un voisinage
du point ; elle a la même valeur, la même pente nulle et la même dérivée seconde
que le potentiel. Elle ne modifie ni les axes ni la courbe de force et disparaît
dès que l’on quitte l’équilibre. Aucun tracé parabolique n’est ajouté pour la
gravitation universelle, qui n’a pas d’équilibre à distance finie.
La tangente et les points de force s’actualisent ensemble. Les chiffres, le point
décimal et les unités partagent une seule ligne de base SVG issue de LaTeX.

Le balayage automatique explore les positions aller-retour, sans résoudre une
équation du mouvement. Il est arrêté lorsqu’on manipule le point et lorsque la
page est masquée. Aucune animation ne démarre automatiquement. La longueur des
flèches vaut un facteur d’échelle commun multiplié par le module de la force.
Ce facteur est choisi sur toute la plage de positions pour garder les flèches
dans le schéma, puis reste fixe pendant les déplacements et le balayage.
Il est recalculé seulement si l’exemple, les paramètres ou la largeur changent ;
une flèche de référence avec sa valeur en N ou pN indique l’échelle utilisée.
Aucune longueur minimale ni saturation n’est appliquée aux forces non nulles.
Dans la paire, F_r est la composante de la force sur le deuxième corps suivant
la direction allant du premier vers le second ; les forces sont égales et opposées.

Les commandes, couleurs et dimensions typographiques reprennent les autres apps
du site existant PHYS1985. Aucune bibliothèque réseau ni service externe n’est
nécessaire au fonctionnement. Le projet conserve la publication GitHub Pages.

## Deux dimensions — version du 11 septembre 2026

Le sélecteur « Dimensions du potentiel » conserve les trois exemples 1D et ajoute
un mode U(x, y). Trois potentiels pédagogiques, avec qx = x/L0 et qy = y/L0 :

- Puits elliptique incliné : U/U0 = (qx² + qx qy + 2 qy²)/2.
  Un minimum stable en (0, 0), avec des directions principales inclinées.
- Col : U/U0 = (qx² − qy²)/2. L’origine est un point selle instable.
- Double puits couplé : U/U0 = (qx² − 1)² + (qy − qx/2)²/2.
  Deux minima stables en (−L0, −L0/2) et (L0, L0/2), un col en (0, 0).

Une carte en couleurs et des équipotentielles montrent le potentiel sur le plan.
Le point de lecture est déplaçable dans les deux directions, par curseurs, clic,
glissement souris/tactile ou flèches du clavier (Maj augmente le pas ; Début
revient à l’origine). « Lire » lance maintenant le mouvement réel depuis ce point.
Les coupes U(x, y fixé) et U(x fixé, y) sont synchronisées avec le même point.
Leurs tangentes donnent les dérivées partielles, opposées à Fx et Fy.

L’option « Surface d’énergie potentielle en 3D » ajoute une surface au-dessus de
la carte, avec les mêmes couleurs et deux coupes tracées sur le relief. La hauteur
est l’énergie en joules, pas une coordonnée spatiale supplémentaire. Faire glisser
tourne la vue (également les flèches du clavier), cliquer sans glisser choisit un
point sur la face visible. « Vue du dessus » et « Vue initiale » règlent la caméra.
La force est aussi dessinée au point choisi sur la vue en surface, parallèlement
au plan physique (x, y), donc à hauteur U constante dans cette représentation.
Le vecteur violet et ses composantes obéissent aux cases d’affichage communes.
Les annotations restent au premier plan, même si le relief masque leur origine,
avec une mention explicite dans ce cas. La longueur est proportionnelle au module
avant projection, avec une échelle ajustée globalement au domaine et à la caméra,
jamais au point courant. Les valeurs et les coupes
restent synchronisées, y compris lorsque le point est masqué par le relief ; une
indication invite alors à tourner la vue. L’échelle verticale s’ajuste au potentiel
et inclut zéro ; les deux axes spatiaux partagent une même échelle. Le dessin est
une triangulation, mais les valeurs et dérivées restent analytiques. Le fond 3D
est mis en cache et la sélection tient compte de l’occultation par la surface.

La force F = −grad U et la Hessienne sont calculées analytiquement dans physics.js.
Les équilibres sont classés par les deux valeurs propres de la Hessienne :
positives pour un minimum stable, de signes contraires pour un col instable.
Une seule coupe ne suffit pas à établir la stabilité. Aux équilibres seulement,
les deux coupes montrent l’approximation quadratique locale en pointillés bleus.

Les flèches du vecteur force et de ses composantes partagent un facteur linéaire
fixé sur l’ensemble du domaine ; il ne change pas lorsque le point bouge ou
que l’on masque les annotations. Une flèche étalon indique ce facteur. Les
composantes horizontale et verticale sont bleue et verte, la résultante violette.
L’échelle est recalculée si le potentiel, les échelles physiques ou le cadre
changent. Les équipotentielles sont obtenues par interpolation linéaire sur
triangles ; cette approximation de dessin ne sert pas au calcul de la force.
La carte de fond est mise en cache pendant le déplacement du point.
Pour le col, des marges supplémentaires accueillent les flèches dirigées vers
l’extérieur et permettent une échelle plus grande, sans normaliser les vecteurs
point par point. Les graduations sont décalées hors de cette zone.

Les deux modes gardent leurs réglages séparés ; passer en 2D arrête le balayage 1D.
Les valeurs restent en SI, avec LaTeX et séparateurs décimaux à point. Les axes
des deux coupes incluent un zéro explicite. Les tests vérifient les gradients,
la Hessienne, les unités, les contours, les flèches, les contrôles et le retour 1D.

## Mouvement réel — 14 septembre 2026

- Le bouton « Lire » résout la deuxième loi de Newton dans chacun des six
  potentiels 1D/2D. Pause/reprise conserve l’état dynamique ; « Recommencer »
  restitue la position et la vitesse initiales choisies. Le balayage exploratoire
  1D est conservé séparément et les deux lectures ne peuvent pas être simultanées.
- La masse et la vitesse initiale sont réglables dans les exemples de particule
  seule (en 2D, module et angle). Modifier un paramètre ou déplacer le point
  interrompt le mouvement et définit de nouvelles conditions initiales.
- Dans les modèles à deux corps, le centre de masse reste fixe et les masses sont
  égales : l’équation relative est `µ r̈ = F_r`, avec `µ = m/2`. La vitesse initiale
  affichée est `ṙ`, les vitesses individuelles étant `−ṙ/2` et `ṙ/2`.
  Pour l’argon, on utilise `m = 6.63 × 10⁻²⁶ kg`. En gravitation, les masses sont
  déduites du potentiel : `m = sqrt(U0 L0/G)`, `G = 6.67430 × 10⁻¹¹ SI`.
- Temps physique et vitesses sont en SI ; le temps atomique est affiché en ps.
  En lecture normale, une seconde à l’écran correspond à 1 s (particule seule),
  1 ps (argon) ou 100 s (gravitation). Lent/Rapide modifie seulement cette lecture.
- Intégration de Verlet en variables réduites `q = x/L0`, `τ = t/[L0 sqrt(µ/U0)]`
  (masse m au lieu de µ pour une particule), avec pas au plus 0.001 en τ.
  La sortie du domaine est localisée par bissection et interrompt explicitement
  la lecture : aucun rebond artificiel et aucun passage par une singularité.
- Les valeurs `t`, `K`, `U` et `E = K + U` suivent le même instant. L’écart
  énergétique affiché est `|E − E_initial| / max(U0, |E_initial|)` en pour cent.
  Une dérive supérieure à 1 % provoque un arrêt explicite de sécurité numérique.
- La trajectoire 2D est visible sur la carte et sur la surface du potentiel,
  depuis la position initiale. Une décimation progressive conserve l’intégralité
  temporelle du tracé tout en bornant sa taille ; la caméra et les cases
  d’affichage ne réinitialisent pas le mouvement. Changer de dimension ou masquer
  l’onglet met en pause. Les nombres animés utilisent les glyphes LaTeX préchargés.

Tests : mouvement harmonique analytique à plusieurs cadences, énergie sur les six
potentiels, stabilité au repos, événement de sortie et temps de chute radial
analytique, commandes, horloges atomique/gravitationnelle et trajectoire partagée.

Reconstruction depuis le dépôt : `python3 tools/build_apps.py --app potentiel_force_webapp_fr`.
Vérification : `node tools/check_potential.cjs` (modèles et commandes sans navigateur).
Pour vérifier aussi toutes les formules avec le moteur MathJax réel, définir
`PHYS1985_MATHJAX_ROOT` vers le dossier `js` d’une installation de mathjax-full.
