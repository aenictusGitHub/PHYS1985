# Énergie potentielle et force — PHYS1985

Ouvrir `index.html` sans serveur ni connexion. MathJax et le thème commun sont
fournis localement. Les tracés sont originaux ; la vidéo « Potential Energy Force »
sert de référence pédagogique et n’est pas redistribuée.

Deux exemples reprennent les deux parties de la vidéo :

- Double puits asymétrique : U(x) = U0 [(q² − 1)² − q/3], avec q = x/L0.
  Cette fonction reproduit qualitativement deux minima séparés par un maximum,
  sans prétendre être la fonction exacte de la vidéo. Les trois équilibres sont
  calculés par recherche des zéros de la dérivée.
- Paire attractive–répulsive : potentiel de Lennard–Jones à exposants 12 et 6,
  U(r) = 4 epsilon [(sigma/r)^12 − (sigma/r)^6], sans troncature. Le minimum
  est à r = 2^(1/6) sigma et vaut −epsilon. Source de la formule :
  https://docs.lammps.org/pair_lj.html (la présente app ne tronque pas le potentiel).

Le double puits conserve ses échelles pédagogiques en mètres et joules.
La paire utilise par défaut les paramètres usuels de l’argon : sigma = 0.3405 nm,
epsilon/k_B = 119.8 K, soit epsilon ≈ 1.654 × 10^-21 J (valeur arrondie).
La distance d’équilibre entre centres vaut 2^(1/6) sigma ≈ 0.382 nm.
Source : Heyes, Dini et Smith (2020), https://doi.org/10.1002/pssb.202000344,
section 2.1 ; https://d-nb.info/1260679276/34. Le potentiel reste ici non tronqué.
Les calculs restent en SI. Pour la paire, l’affichage utilise nm, 10^-21 J et pN
(1 pN = 10^-12 N = 10^-12 J/m) pour ne pas arrondir les valeurs atomiques à zéro.
Chaque exemple permet de régler l’échelle d’énergie et de longueur ; les plages
de la paire sont 0.25–0.50 nm et (0.5–4) × 10^-21 J. Changer les paramètres explore
un modèle atomique générique ; « Réinitialiser » restaure les valeurs de l’argon.
Changer d’exemple restaure les échelles propres à celui-ci.
La dérivée analytique donne la force, sans différences finies dans l’application.
Le graphe du potentiel est un graphe d’énergie, pas une piste matérielle.

Déplacer le curseur, cliquer ou faire glisser sur l’un des graphiques, ou déplacer
les corps règle le même point de lecture. Les deux graphiques ont le même axe
horizontal. Les touches fléchées, Début et Fin offrent le même contrôle au clavier.
Les boutons d’équilibre placent le point exactement sur les minima ou le maximum.
La tangente et les points de force s’actualisent ensemble. Les chiffres, le point
décimal et les unités partagent une seule ligne de base SVG issue de LaTeX.

Le balayage automatique explore les positions aller-retour, sans résoudre une
équation du mouvement. Il est arrêté lorsqu’on manipule le point et lorsque la
page est masquée. Aucune animation ne démarre automatiquement. La longueur des
flèches vaut un facteur d’échelle commun multiplié par le module de la force.
Ce facteur est choisi sur toute la plage de positions pour garder les flèches
dans le schéma, puis reste fixe pendant les déplacements et le balayage.
Il est recalculé seulement si l’exemple, les paramètres ou la largeur changent ;
une flèche de référence avec sa valeur en N ou pN indique l’échelle utilisée.
Aucune longueur minimale ni saturation n’est appliquée aux forces non nulles.
Dans la paire, F_r est la composante de la force sur le deuxième corps suivant
la direction allant du premier vers le second ; les forces sont égales et opposées.

Les commandes, couleurs et dimensions typographiques reprennent les autres apps
du site existant PHYS1985. Aucune bibliothèque réseau ni service externe n’est
nécessaire au fonctionnement. Le projet conserve la publication GitHub Pages.

Reconstruction depuis le dépôt : `python3 tools/build_apps.py --app potentiel_force_webapp_fr`.
Vérification : `node tools/check_potential.cjs` (modèles et commandes sans navigateur).
Pour vérifier aussi toutes les formules avec le moteur MathJax réel, définir
`PHYS1985_MATHJAX_ROOT` vers le dossier `js` d’une installation de mathjax-full.
