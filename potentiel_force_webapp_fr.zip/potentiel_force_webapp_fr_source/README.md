# Énergie potentielle et force — PHYS1985

Ouvrir `index.html` sans serveur ni connexion. MathJax et le thème commun sont
fournis localement. Les tracés sont originaux ; la vidéo « Potential Energy Force »
sert de référence pédagogique et n’est pas redistribuée.

Deux exemples reprennent les deux parties de la vidéo :

- Double puits asymétrique : U(x) = U0 [(q² − 1)² − q/3], avec q = x/L0.
  Cette fonction reproduit qualitativement deux minima séparés par un maximum,
  sans prétendre être la fonction exacte de la vidéo. Les trois équilibres sont
  calculés par recherche des zéros de la dérivée.
- Paire attractive–répulsive : potentiel de Lennard–Jones à exposants 12 et 6,
  U(r) = 4 epsilon [(sigma/r)^12 − (sigma/r)^6], sans troncature. Le minimum
  est à r = 2^(1/6) sigma et vaut −epsilon. Source de la formule :
  https://docs.lammps.org/pair_lj.html (la présente app ne tronque pas le potentiel).

Les valeurs sont pédagogiques, en unités SI ; elles ne décrivent pas un atome
particulier. Chaque exemple permet de régler l’échelle d’énergie et de longueur.
La dérivée analytique donne la force, sans différences finies dans l’application.
Le graphe du potentiel est un graphe d’énergie, pas une piste matérielle.

Déplacer le curseur, cliquer ou faire glisser sur l’un des graphiques, ou déplacer
les corps règle le même point de lecture. Les deux graphiques ont le même axe
horizontal. Les touches fléchées, Début et Fin offrent le même contrôle au clavier.
Les boutons d’équilibre placent le point exactement sur les minima ou le maximum.
La tangente et les points de force s’actualisent ensemble. Les chiffres, le point
décimal et les unités partagent une seule ligne de base SVG issue de LaTeX.

Le balayage automatique explore les positions aller-retour, sans résoudre une
équation du mouvement. Il est arrêté lorsqu’on manipule le point et lorsque la
page est masquée. Aucune animation ne démarre automatiquement. Les flèches du
schéma indiquent uniquement le sens des forces, pas leur intensité par leur longueur.
Dans la paire, F_r est la composante de la force sur le deuxième corps suivant
la direction allant du premier vers le second ; les forces sont égales et opposées.

Les commandes, couleurs et dimensions typographiques reprennent les autres apps
du site existant PHYS1985. Aucune bibliothèque réseau ni service externe n’est
nécessaire au fonctionnement. Le projet conserve la publication GitHub Pages.

Reconstruction depuis le dépôt : `python3 tools/build_apps.py --app potentiel_force_webapp_fr`.
Vérification : `node tools/check_potential.cjs` (modèles et commandes sans navigateur).
Pour vérifier aussi toutes les formules avec le moteur MathJax réel, définir
`PHYS1985_MATHJAX_ROOT` vers le dossier `js` d’une installation de mathjax-full.
