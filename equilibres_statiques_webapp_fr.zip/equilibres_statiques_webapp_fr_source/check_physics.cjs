const assert=require('node:assert/strict'),P=require('./physics.js');
const near=(a,b,tol=1e-8)=>assert(Math.abs(a-b)<tol,a+' != '+b);
for(const key of ['balanced','unequal']){
 const p=P.preset(key),s=P.advance(p,P.initial(),60);near(s.theta,0);near(s.omega,0);assert(P.solve(p,s).equilibrium);
}
for(const [key,sign]of [['clockwise',-1],['counterclockwise',1]]){
 const p=P.preset(key),s=P.advance(p,P.initial(),.1);assert(sign*s.theta>0);assert(sign*s.omega>0);near(P.solve(p).alpha,sign*1.5);
}
let seed=154;const rand=()=>((seed=(1664525*seed+1013904223)>>>0)/2**32);
for(let i=0;i<2000;i++){
 const p={F1:20*rand(),F2:20*rand(),d1:.2+1.6*rand(),d2:.2+1.6*rand()},s={theta:(rand()-.5)*20,omega:(rand()-.5)*6,t:0},r=P.solve(p,s);
 near(r.torque,r.M1+r.M2);near(r.torque,4*r.alpha);near(r.reaction-r.weight-p.F1-p.F2,0);
 near(r.forces.reduce((v,f)=>v+f.x*f.Fy,0),r.torque);for(const f of r.forces)near(Math.hypot(f.x,f.y),p['d'+f.id]);
 const next=P.advance(p,s,.1);near(P.solve(p,next).energy,r.energy,1e-6);
}
for(const p of [P.preset('clockwise'),{F1:20,F2:0,d1:1.8,d2:.2}]){
 const s=P.advance(p,P.initial(),60);near(P.solve(p,s).energy,0,2e-5);assert(Number.isFinite(s.theta));
}
const moving=P.advance(P.preset('clockwise'),P.initial(),.8),constant=P.advance(P.defaults,moving,10);
near(constant.omega,moving.omega);near(constant.theta,moving.theta+10*moving.omega);assert(!P.solve(P.defaults,constant).equilibrium);
// A zero moment at vertical does not stop motion.
const vertical=P.solve(P.preset('clockwise'),{theta:Math.PI/2,omega:2,t:1});near(vertical.torque,0);assert(!vertical.equilibrium);
for(const bad of [null,[],{F1:NaN},{F2:-1},{d1:5},{fake:1}])assert.throws(()=>P.parameters(bad));
for(const dt of [-1,NaN,Infinity,61])assert.throws(()=>P.advance(P.defaults,P.initial(),dt));
for(const w of [280,500,1000])for(const h of [430,768])for(let i=0;i<500;i++){
 const g=P.geometry(w,h),theta=rand()*2*Math.PI;
 for(const d of [-2,-1.8,1.8,2]){const q=g.point(d*Math.cos(theta),d*Math.sin(theta));assert(q[0]>=20&&q[0]<=w-20);assert(q[1]>=0&&q[1]+100<=h);}
}
console.log('Physique : équilibre, sens de rotation, conservation de l’énergie et 2 000 bilans vérifiés.');

