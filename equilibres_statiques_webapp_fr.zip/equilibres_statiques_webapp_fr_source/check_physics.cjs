const assert=require('node:assert/strict'),P=require('./physics.js');
const near=(a,b,tol=1e-8)=>assert(Math.abs(a-b)<tol,a+' != '+b);
for(const key of ['balanced','unequal']){
 const p=P.preset(key),s=P.advance(p,P.initial(),60);near(s.theta,0);near(s.omega,0);assert(P.solve(p,s).equilibrium);
}
for(const [key,sign]of [['clockwise',-1],['counterclockwise',1]]){
 const p=P.preset(key),s=P.advance(p,P.initial(),.1);assert(sign*s.theta>0);assert(sign*s.omega>0);near(P.solve(p).alpha,sign*1.5);
}
let seed=154;const rand=()=>((seed=(1664525*seed+1013904223)>>>0)/2**32);
for(let i=0;i<2000;i++){
 const p={F1:20*rand(),F2:20*rand(),d1:.2+1.6*rand(),d2:.2+1.6*rand()},s={theta:(rand()-.5)*20,omega:(rand()-.5)*6,t:0},r=P.solve(p,s);
 near(r.torque,r.M1+r.M2);near(r.torque,4*r.alpha);near(r.reaction-r.weight-p.F1-p.F2,0);
 assert.equal(r.allForces.length,4);near(r.allForces.reduce((sum,f)=>sum+f.Fy,0),r.sumFy);near(r.sumFy,0);near(r.sumFx,0);assert(r.forceBalanced);
 near(r.allForces.reduce((sum,f)=>sum+f.x*f.Fy-f.y*f.Fx,0),r.torque);
 for(const f of r.allForces.slice(2)){near(f.x,0);near(f.y,0);near(f.torque,0);}
 near(r.forces.reduce((v,f)=>v+f.x*f.Fy,0),r.torque);for(const f of r.forces)near(Math.hypot(f.x,f.y),p['d'+f.id]);
 const next=P.advance(p,s,.1);near(P.solve(p,next).energy,r.energy,1e-6);
}
for(const p of [P.preset('clockwise'),{F1:20,F2:0,d1:1.8,d2:.2}]){
 const s=P.advance(p,P.initial(),60);near(P.solve(p,s).energy,0,2e-5);assert(Number.isFinite(s.theta));
}
const moving=P.advance(P.preset('clockwise'),P.initial(),.8),constant=P.advance(P.defaults,moving,10);
near(constant.omega,moving.omega);near(constant.theta,moving.theta+10*moving.omega);assert(!P.solve(P.defaults,constant).equilibrium);
// A zero moment at vertical does not stop motion.
const vertical=P.solve(P.preset('clockwise'),{theta:Math.PI/2,omega:2,t:1});near(vertical.torque,0);assert(!vertical.equilibrium);
assert(vertical.forceBalanced&&vertical.momentBalanced);assert(!vertical.equilibrium);
// Viscous pivot: no static threshold, torque opposes omega, exact free decay.
for(const b of [.25,2,8])for(const omega of [-2,2]){
 const p={...P.defaults,friction:true,b},start={theta:.3,omega,t:0},t=3,next=P.advance(p,start,t),decay=Math.exp(-b*t/P.INERTIA),r=P.solve(p,start);
 near(next.omega,omega*decay,1e-8);near(next.theta,start.theta+omega*P.INERTIA/b*(1-decay),1e-8);
 near(r.frictionTorque,-b*omega);near(r.torque,r.M1+r.M2+r.frictionTorque);near(r.alpha*P.INERTIA,r.torque);near(r.frictionPower,-b*omega**2);
 assert(P.solve(p).equilibrium);near(P.solve({...P.preset('clockwise'),friction:true,b}).alpha,-1.5);
}
for(const key of ['clockwise','counterclockwise']){
 const p={...P.preset(key),friction:true,b:2};let motion=P.initial(),energy=P.solve(p,motion).energy;
 for(let i=0;i<600;i++){motion=P.advance(p,motion,.1);const next=P.solve(p,motion);assert(next.energy<=energy+1e-9);assert(next.frictionPower<=0);energy=next.energy;}
 near(motion.omega,0,1e-5);near(motion.theta,key==='clockwise'?-Math.PI/2:Math.PI/2,2e-5);
 const free=P.advance({...p,friction:false},moving,1),zero=P.advance({...p,b:0},moving,1);near(free.theta,zero.theta);near(free.omega,zero.omega);
}
for(const bad of [{b:-1},{b:9},{b:NaN},{friction:1},{friction:'true'}])assert.throws(()=>P.parameters(bad));
for(const bad of [null,[],{F1:NaN},{F2:-1},{d1:5},{fake:1}])assert.throws(()=>P.parameters(bad));
for(const dt of [-1,NaN,Infinity,61])assert.throws(()=>P.advance(P.defaults,P.initial(),dt));
for(const w of [280,500,1000])for(const h of [430,768])for(let i=0;i<500;i++){
 const g=P.geometry(w,h),theta=rand()*2*Math.PI;
 for(const d of [-2,-1.8,1.8,2]){const q=g.point(d*Math.cos(theta),d*Math.sin(theta));assert(q[0]>=20&&q[0]<=w-20);assert(q[1]>=0&&q[1]+100<=h);}
}
console.log('Physique : 2 000 bilans, équilibre, rotation, conservation sans frottement et amortissement visqueux vérifiés.');

// General orientations: r × F, shortest distance to the line, reaction in 2D.
for(let i=0;i<2000;i++){
 const p={...P.defaults,F1:20*rand(),F2:20*rand(),d1:.2+1.6*rand(),d2:.2+1.6*rand(),phi1:-180+360*rand(),phi2:-180+360*rand()};
 const motion={theta:(rand()-.5)*20,omega:(rand()-.5)*6,t:0},s=P.solve(p,motion);
 near(s.sumFx,0);near(s.sumFy,0);near(s.reaction,Math.hypot(s.Rx,s.Ry));
 for(const f of s.forces){
  near(f.torque,f.x*f.Fy-f.y*f.Fx);near(Math.abs(f.torque),f.r*f.F*Math.sin(f.beta));near(Math.abs(f.torque),f.F*f.lever);
  near(f.lever,Math.hypot(f.foot.x,f.foot.y));near(f.foot.x*f.ux+f.foot.y*f.uy,0);
  near((f.foot.x-f.x)*f.uy-(f.foot.y-f.y)*f.ux,0);assert(f.beta>=0&&f.beta<=Math.PI);assert(f.lever<=f.r+1e-10);
 }
 const h=1e-5,up=P.solve(p,{...motion,theta:motion.theta+h}),down=P.solve(p,{...motion,theta:motion.theta-h});
 near(s.torque,-(up.energy-down.energy)/(2*h),1e-7);
 const next=P.advance(p,motion,.1);near(P.solve(p,next).energy,s.energy,2e-6);
 const damp={...p,friction:true,b:2},end=P.advance(damp,motion,.1);assert(P.solve(damp,end).energy<=P.solve(damp,motion).energy+1e-8);
}
const oblique=P.solve(P.preset('oblique'));near(oblique.forces[0].r,1.2);near(oblique.forces[0].lever,.6);near(oblique.forces[0].beta,150*Math.PI/180);near(oblique.M1,6);near(oblique.M2,-12);
assert(P.solve(P.preset('radial')).equilibrium);near(P.solve(P.preset('radial')).forces[0].lever,0);
const horizontal=P.solve({...P.defaults,phi1:0,phi2:0}),up=P.solve({...P.defaults,phi1:90,phi2:90,F1:20,F2:20});near(horizontal.Rx,-20);near(horizontal.Ry,29.43);near(up.Ry,-10.57);
for(const bad of [{phi1:181},{phi2:-181},{phi1:NaN}])assert.throws(()=>P.parameters(bad));
console.log('Orientations : 2 000 bilans vectoriels, bras perpendiculaires, angle bêta, réaction 2D et conservation/dissipation vérifiés.');
