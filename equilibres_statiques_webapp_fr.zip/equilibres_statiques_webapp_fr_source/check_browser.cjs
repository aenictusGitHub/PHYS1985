'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),{pathToFileURL}=require('node:url');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'/Users/jmartin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const near=(a,b,tol=1e-7)=>assert(Math.abs(a-b)<tol,a+' != '+b);
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROME_PATH||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
 try{
  const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  await page.addInitScript(()=>{
   Object.defineProperty(document,'modelContext',{value:{registerTool(tool){(window.__staticsTools??={})[tool.name]=tool;}}});
   const p=CanvasRenderingContext2D.prototype;
   for(const key of ['clearRect','beginPath','moveTo','lineTo','stroke']){const original=p[key];p[key]=function(...args){if(this.canvas.id==='scene-canvas'){
    if(key==='clearRect')window.__strokes=[];if(key==='beginPath')this.__points=[];if(key==='moveTo'||key==='lineTo')(this.__points??=[]).push(args);
    if(key==='stroke')(window.__strokes??=[]).push({points:this.__points.map(p=>[...p]),color:this.strokeStyle,width:this.lineWidth});
   }return original.apply(this,args);};}
  });
  await page.goto(process.env.STATICS_APP_URL||pathToFileURL(path.join(__dirname,'index.html')).href);
  await page.waitForFunction(()=>document.getElementById('loading').hidden);
  const read=()=>page.evaluate(()=>window.__staticsTools.read_static_equilibrium.execute({}));
  const input=(id,value)=>page.locator('#'+id).evaluate((el,value)=>{el.value=value;el.dispatchEvent(new Event('input',{bubbles:true}));},String(value));
  const bar=()=>page.evaluate(()=>window.__strokes.find(s=>s.color==='#8da2b6'&&s.width===11));
  const forceTag=()=>page.locator('#force-condition').getAttribute('data-satisfied'),momentTag=()=>page.locator('#moment-condition').getAttribute('data-satisfied');
  assert(!(await page.locator('#full-forces').isChecked()));assert(!(await page.locator('#complete-balance').isVisible()));
  for(const width of [1440,900,390]){
   await page.setViewportSize({width,height:1000});
   for(const preset of ['balanced','unequal','clockwise','counterclockwise']){
    await page.selectOption('#preset',preset);await page.locator('#full-forces').uncheck();
    const before=await read(),shape=await bar();await page.locator('#full-forces').check();
    assert.deepEqual((await read()).motion,before.motion);assert.deepEqual(await bar(),shape);assert(!(await read()).playing);
    assert(await page.locator('#complete-balance').isVisible());assert.equal(await forceTag(),'true');assert.equal(await momentTag(),String(['balanced','unequal'].includes(preset)));
    const result=(await read()).result;near(result.reaction,result.weight+(await read()).parameters.F1+(await read()).parameters.F2);near(result.sumFy,0);
    assert.equal(result.allForces.length,4);
    assert(await page.evaluate(()=>window.__strokes.some(s=>s.color==='#268576'&&Math.abs(s.width-3.4)<1e-5)));
    const clipped=await page.locator('#scene-labels').evaluate(layer=>{const b=layer.getBoundingClientRect();return [...layer.children].filter(el=>!el.hidden).filter(el=>{const r=el.getBoundingClientRect();return r.left<b.left||r.right>b.right||r.top<b.top||r.bottom>b.bottom;}).map(el=>el.dataset.labelKey);});
    assert.deepEqual(clipped,[]);assert.equal(await page.locator('[data-mml-node="merror"]').count(),0);
    assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));
   }
  }
  await page.setViewportSize({width:1440,height:1000});await page.selectOption('#preset','clockwise');
  await page.locator('#play').click();await page.waitForTimeout(600);await page.locator('#play').click();let s=await read();assert(Math.abs(s.motion.omega)>.1);assert.equal(await forceTag(),'true');assert.equal(await momentTag(),'false');
  await input('F2',10);s=await read();assert(Math.abs(s.motion.omega)>.1);near(s.result.torque,0);assert(!s.result.equilibrium);assert.equal(await momentTag(),'true');assert((await page.locator('#rest-condition').innerText()).includes('tourne déjà'));
  await page.locator('#friction').check();assert.equal(await momentTag(),'false');assert.equal(await forceTag(),'true');assert(await page.locator('#couple-note').isVisible());
  const paused=(await read()).motion;await page.locator('#full-forces').uncheck();assert.deepEqual((await read()).motion,paused);assert(!(await page.locator('#complete-balance').isVisible()));
  await page.locator('#full-forces').check();await page.locator('#friction').uncheck();await page.selectOption('#preset','unequal');
  await input('F1',20);await input('F2',20);near((await read()).result.reaction,69.43);
  const outside=await page.evaluate(()=>{const h=document.getElementById('scene').getBoundingClientRect().height;return window.__strokes.filter(s=>s.color==='#268576'&&Math.abs(s.width-3.4)<1e-5).flatMap(s=>s.points).some(p=>p[1]<0||p[1]>h);});assert(!outside);
  // Full view stays on across a restart, and remains a purely visual option.
  await page.locator('#restart').click();near((await read()).motion.t,0);assert(await page.locator('#full-forces').isChecked());
  await page.selectOption('#preset','clockwise');
  if(process.env.QA_OUTPUT){await page.locator('#scene').screenshot({path:path.join(process.env.QA_OUTPUT,'statics-complete-scene.png')});await page.locator('#complete-balance').screenshot({path:path.join(process.env.QA_OUTPUT,'statics-complete-balance.png')});
   await page.setViewportSize({width:390,height:1000});await page.locator('#complete-balance').screenshot({path:path.join(process.env.QA_OUTPUT,'statics-mobile-balance.png')});}
  for(const width of [1440,900,390,320]){
   await page.setViewportSize({width,height:1100});await page.selectOption('#preset','oblique');await page.locator('#full-forces').uncheck();await page.locator('#lever-geometry').check();await page.selectOption('#lever-force','1');
   const r=await read();near(r.result.M1,6);near(r.result.M2,-12);near(r.result.forces[0].lever,.6);
   near(parseFloat(await page.locator('#lever-beta-value').getAttribute('data-number')),150);
   assert(await page.locator('#lever-guide').isVisible());
   const strokes=await page.evaluate(()=>window.__strokes),force=strokes.find(s=>s.color==='#2775b6'&&Math.abs(s.width-3.4)<1e-5);
   assert(force);near((force.points[1][1]-force.points[0][1])/(force.points[1][0]-force.points[0][0]),Math.tan(Math.PI/6));
   const geometry=await page.evaluate(()=>{const el=document.querySelector('#scene-canvas'),r=el.getBoundingClientRect();return {width:r.width,height:r.height};});
   for(const s of strokes.filter(s=>Math.abs(s.width-3.4)<1e-5))for(const [x,y]of s.points){assert(x>=0&&x<=geometry.width);assert(y>=0&&y<=geometry.height-80);}
   const shape=await bar(),before=(await read()).motion;await page.locator('#lever-geometry').uncheck();assert.deepEqual(await bar(),shape);assert.deepEqual((await read()).motion,before);assert(!(await page.locator('#lever-guide').isVisible()));
   await page.locator('#lever-geometry').check();
   if(process.env.QA_OUTPUT)await page.locator('.visual-card').screenshot({path:path.join(process.env.QA_OUTPUT,`statics-oblique-${width}.png`)});
   await page.selectOption('#lever-force','2');near(parseFloat(await page.locator('#lever-d-value').getAttribute('data-number')),1.2);near(parseFloat(await page.locator('#lever-beta-value').getAttribute('data-number')),90);
   await page.selectOption('#preset','radial');near((await read()).result.torque,0);assert((await page.locator('#lever-note').innerText()).includes('passe par O'));
   await input('F2',0);assert(!(await page.locator('#lever-metrics').isVisible()));assert((await page.locator('#lever-note').innerText()).includes('Force nulle'));
   await page.selectOption('#preset','oblique');await page.locator('#full-forces').check();await input('phi1',90);await input('phi2',90);await input('F1',20);await input('F2',20);near((await read()).result.Ry,-10.57);
   await input('phi1',0);await input('phi2',0);near((await read()).result.Rx,-40);near((await read()).result.Ry,29.43);
   await page.selectOption('#preset','oblique');await page.selectOption('#lever-force','1');
   await page.locator('#play').click();await page.waitForTimeout(200);
   const change=await page.evaluate(()=>{const tool=window.__staticsTools,before=tool.read_static_equilibrium.execute({});tool.configure_static_equilibrium.execute({parameters:{phi1:35}});return {before,after:tool.read_static_equilibrium.execute({})};});
   assert(change.after.playing);assert.deepEqual(change.after.motion,change.before.motion);near(change.after.parameters.phi1,35);
   await page.locator('#play').click();assert.equal(await page.locator('[data-mml-node="merror"]').count(),0);
   assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));
  }
  assert.deepEqual(errors,[]);console.log('PASS browser: complete forces, orientations and live changes, r vs lever arm, beta, radial/zero forces, two-component reaction, view toggles, four viewport sizes and MathJax.');
 }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
