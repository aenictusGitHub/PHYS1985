/* Uniform bar, central pivot, two downward forces and optional viscous friction. */
const StaticsPhysics=(()=>{
  'use strict';
  const LENGTH=4,MASS=3,G=9.81,INERTIA=MASS*LENGTH*LENGTH/12,STEP=1/240;
  const defaults={F1:10,F2:10,d1:1.2,d2:1.2,friction:false,b:2},bounds={F1:[0,20],F2:[0,20],d1:[.2,1.8],d2:[.2,1.8],b:[0,8]};
  const presets={balanced:{title:'Équilibre — forces égales',values:{...defaults}},unequal:{title:'Équilibre — forces différentes',values:{F1:8,F2:16,d1:1.6,d2:.8}},clockwise:{title:'Rotation horaire',values:{...defaults,F2:15}},counterclockwise:{title:'Rotation antihoraire',values:{...defaults,F1:15}}};
  function parameters(input={}){
    if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>k!=='friction'&&!Object.hasOwn(bounds,k)))throw new Error('Paramètres non valides.');
    const p={...defaults,...input};if(typeof p.friction!=='boolean')throw new Error('Option de frottement non valide.');for(const [key,[lo,hi]]of Object.entries(bounds))if(typeof p[key]!=='number'||!Number.isFinite(p[key])||p[key]<lo||p[key]>hi)throw new Error('Valeur hors limites : '+key);return p;
  }
  function preset(key){if(!Object.hasOwn(presets,key))throw new Error('Exemple inconnu.');return {...defaults,...presets[key].values};}
  function initial(){return {theta:0,omega:0,t:0};}
  function validateMotion(s){if(!s||['theta','omega','t'].some(k=>!Number.isFinite(s[k]))||s.t<0)throw new Error('État mécanique non valide.');}
  function solve(input,motion=initial()){
    const p=parameters(input);validateMotion(motion);const c=Math.cos(motion.theta),s=Math.sin(motion.theta),M1=p.d1*p.F1*c,M2=-p.d2*p.F2*c,frictionTorque=p.friction?-p.b*motion.omega:0,torque=M1+M2+frictionTorque;
    return {forces:[{id:1,x:-p.d1*c,y:-p.d1*s,Fy:-p.F1,torque:M1},{id:2,x:p.d2*c,y:p.d2*s,Fy:-p.F2,torque:M2}],M1,M2,frictionTorque,torque,alpha:torque/INERTIA,omega:motion.omega,theta:motion.theta,t:motion.t,reaction:MASS*G+p.F1+p.F2,weight:MASS*G,sumFy:0,equilibrium:Math.abs(torque)<1e-8&&Math.abs(motion.omega)<1e-8,energy:.5*INERTIA*motion.omega**2+(p.d2*p.F2-p.d1*p.F1)*s,frictionPower:frictionTorque*motion.omega};
  }
  // RK4 with substeps <= 1/240 s; viscous torque is evaluated at each stage.
  function advance(input,motion,dt){
    const p=parameters(input);validateMotion(motion);if(!Number.isFinite(dt)||dt<0||dt>60)throw new Error('Pas de temps non valide.');
    const a=(p.d1*p.F1-p.d2*p.F2)/INERTIA,damping=p.friction?p.b/INERTIA:0,acc=(q,v)=>a*Math.cos(q)-damping*v,n=Math.max(1,Math.ceil(dt/STEP)),h=dt/n;let {theta:q,omega:v}=motion;
    for(let i=0;i<n;i++){
      const k1q=v,k1v=acc(q,v),k2q=v+h*k1v/2,k2v=acc(q+h*k1q/2,k2q),k3q=v+h*k2v/2,k3v=acc(q+h*k2q/2,k3q),k4q=v+h*k3v,k4v=acc(q+h*k3q,k4q);
      q+=h*(k1q+2*k2q+2*k3q+k4q)/6;v+=h*(k1v+2*k2v+2*k3v+k4v)/6;
    }return {theta:q,omega:v,t:motion.t+dt};
  }
  // Keep a bottom annotation lane clear of the bar and both force arrows.
  function geometry(w,h){const scale=Math.max(1,Math.min((w-90)/4.6,(h-215)/4.6));return {cx:w/2,cy:(h-120)/2,scale,point(x,y){return [w/2+x*scale,(h-120)/2-y*scale];}};}
  return {LENGTH,MASS,G,INERTIA,STEP,defaults,bounds,presets,parameters,preset,initial,solve,advance,geometry};
})();
if(typeof module!=='undefined')module.exports=StaticsPhysics;
