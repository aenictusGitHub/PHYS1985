/* Uniform bar, central pivot, two lab-fixed force directions and viscous friction. */
const StaticsPhysics=(()=>{
  'use strict';
  const LENGTH=4,MASS=3,G=9.81,INERTIA=MASS*LENGTH*LENGTH/12,STEP=1/240;
  const defaults={F1:10,F2:10,d1:1.2,d2:1.2,phi1:-90,phi2:-90,friction:false,b:2},bounds={F1:[0,20],F2:[0,20],d1:[.2,1.8],d2:[.2,1.8],phi1:[-180,180],phi2:[-180,180],b:[0,8]};
  const presets={balanced:{title:'Équilibre — forces égales',values:{...defaults}},unequal:{title:'Équilibre — forces différentes',values:{F1:8,F2:16,d1:1.6,d2:.8}},clockwise:{title:'Rotation horaire',values:{...defaults,F2:15}},counterclockwise:{title:'Rotation antihoraire',values:{...defaults,F1:15}},oblique:{title:'Même distance, moments différents',values:{...defaults,phi1:-30}},radial:{title:'Forces passant par le pivot',values:{...defaults,phi1:180,phi2:0}}};
  function parameters(input={}){
    if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>k!=='friction'&&!Object.hasOwn(bounds,k)))throw new Error('Paramètres non valides.');
    const p={...defaults,...input};if(typeof p.friction!=='boolean')throw new Error('Option de frottement non valide.');for(const [key,[lo,hi]]of Object.entries(bounds))if(typeof p[key]!=='number'||!Number.isFinite(p[key])||p[key]<lo||p[key]>hi)throw new Error('Valeur hors limites : '+key);return p;
  }
  function preset(key){if(!Object.hasOwn(presets,key))throw new Error('Exemple inconnu.');return {...defaults,...presets[key].values};}
  function initial(){return {theta:0,omega:0,t:0};}
  function validateMotion(s){if(!s||['theta','omega','t'].some(k=>!Number.isFinite(s[k]))||s.t<0)throw new Error('État mécanique non valide.');}
  function direction(degrees){const a=degrees*Math.PI/180,clean=v=>Math.abs(v)<1e-14?0:v;return [clean(Math.cos(a)),clean(Math.sin(a))];}
  function appliedForces(p,theta){
    const c=Math.cos(theta),s=Math.sin(theta);
    return [1,2].map(id=>{
      const r=p['d'+id],sign=id===1?-1:1,x=sign*r*c,y=sign*r*s,[ux,uy]=direction(p['phi'+id]),F=p['F'+id],Fx=F*ux,Fy=F*uy;
      const signedLever=x*uy-y*ux,along=x*ux+y*uy,dot=(x*ux+y*uy)/r;
      return {id,x,y,r,F,Fx,Fy,ux,uy,torque:F*signedLever,lever:Math.abs(signedLever),beta:Math.acos(Math.max(-1,Math.min(1,dot))),foot:{x:x-along*ux,y:y-along*uy}};
    });
  }
  function solve(input,motion=initial()){
    const p=parameters(input);validateMotion(motion);const forces=appliedForces(p,motion.theta),[M1,M2]=forces.map(f=>f.torque),frictionTorque=p.friction?-p.b*motion.omega:0,torque=M1+M2+frictionTorque;
    const weight=MASS*G,Rx=-forces.reduce((sum,f)=>sum+f.Fx,0),Ry=weight-forces.reduce((sum,f)=>sum+f.Fy,0),reaction=Math.hypot(Rx,Ry);
    // G coincides with the fixed pivot: a_G=0 even during rotation. The
    // viscous bearing is an external couple, not an extra resultant force.
    const allForces=[...forces,{id:'weight',x:0,y:0,Fx:0,Fy:-weight,torque:0},{id:'reaction',x:0,y:0,Fx:Rx,Fy:Ry,torque:0}];
    const sumFx=allForces.reduce((sum,f)=>sum+f.Fx,0),sumFy=allForces.reduce((sum,f)=>sum+f.Fy,0),forceBalanced=Math.hypot(sumFx,sumFy)<1e-8,momentBalanced=Math.abs(torque)<1e-8;
    return {forces,allForces,M1,M2,frictionTorque,torque,alpha:torque/INERTIA,omega:motion.omega,theta:motion.theta,t:motion.t,reaction,Rx,Ry,weight,sumFx,sumFy,forceBalanced,momentBalanced,equilibrium:forceBalanced&&momentBalanced&&Math.abs(motion.omega)<1e-8,energy:.5*INERTIA*motion.omega**2-forces.reduce((sum,f)=>sum+f.x*f.Fx+f.y*f.Fy,0),frictionPower:frictionTorque*motion.omega};
  }
  // RK4 with substeps <= 1/240 s; viscous torque is evaluated at each stage.
  function advance(input,motion,dt){
    const p=parameters(input);validateMotion(motion);if(!Number.isFinite(dt)||dt<0||dt>60)throw new Error('Pas de temps non valide.');
    const horizontal=appliedForces(p,0),a=horizontal.reduce((sum,f)=>sum+f.x*f.Fy,0)/INERTIA,b=-horizontal.reduce((sum,f)=>sum+f.x*f.Fx,0)/INERTIA,damping=p.friction?p.b/INERTIA:0,acc=(q,v)=>a*Math.cos(q)+b*Math.sin(q)-damping*v,n=Math.max(1,Math.ceil(dt/STEP)),h=dt/n;let {theta:q,omega:v}=motion;
    for(let i=0;i<n;i++){
      const k1q=v,k1v=acc(q,v),k2q=v+h*k1v/2,k2v=acc(q+h*k1q/2,k2q),k3q=v+h*k2v/2,k3v=acc(q+h*k2q/2,k3q),k4q=v+h*k3v,k4v=acc(q+h*k3q,k4q);
      q+=h*(k1q+2*k2q+2*k3q+k4q)/6;v+=h*(k1v+2*k2v+2*k3v+k4v)/6;
    }return {theta:q,omega:v,t:motion.t+dt};
  }
  // Keep a bottom annotation lane clear of the bar and both force arrows.
  function geometry(w,h){const scale=Math.max(1,Math.min((w-90)/4.6,(h-215)/4.6)),cy=(h-52)/2;return {cx:w/2,cy,scale,point(x,y){return [w/2+x*scale,cy-y*scale];}};}
  return {LENGTH,MASS,G,INERTIA,STEP,defaults,bounds,presets,parameters,preset,initial,solve,advance,geometry};
})();
if(typeof module!=='undefined')module.exports=StaticsPhysics;
