# Équilibre et rotation — PHYS1985

Refonte simplifiée du 8 septembre 2026, publiée le 9 septembre 2026.
Mise à jour du 9 septembre : moment total avec ⊙/⊗, frottement visqueux optionnel au pivot et points d’application plus discrets, sans réduire leur zone de saisie.
Extension locale du 15 septembre : option « Bilan complet des forces »,
poids et réaction au pivot, et deux conditions d’équilibre simultanées.
Extension locale du 17 septembre : forces orientables, lignes d’action,
bras de levier perpendiculaires et angles β.

Ouvrir index.html (sources locales), ou equilibres_statiques_webapp_fr.html
(fichier autonome incluant MathJax, CSS et code). Aucune dépendance réseau.

## Expérience

Une barre homogène est articulée en son centre O. Deux forces orientables
sont appliquées à des points de la barre (verticales descendantes par défaut). Exemples :
équilibre avec forces égales, équilibre avec forces différentes, départ
horaire et départ antihoraire, même distance avec moments différents, forces
passant par le pivot. Six curseurs règlent F1, F2, r1, r2, φ1, φ2.
Les noms internes d1/d2 restent utilisés pour les distances, afin de conserver
le contrat de configuration ; leur affichage est désormais r1/r2 pour bien les
distinguer des bras perpendiculaires d⊥.
Les points d’application bleu et orangé peuvent être glissés directement
sur la barre, à la souris ou au toucher, même pendant la lecture. Le déplacement
est projeté sur la direction actuelle de la barre, avec une plage de 0.20 à
1.80 m et un pas de 0.01 m, synchronisé avec les curseurs et les valeurs LaTeX.
La prise en main conserve le décalage initial du pointeur pour éviter un saut.
Chaque point reste sur sa demi-barre. Un changement d’exemple, une remise au
repos, une annulation du geste ou le masquage de l’onglet termine le glissement.
Pas de champ de saisie au clavier : les curseurs restent accessibles au clavier.

Lire / Pause contrôle le temps, Recommencer rétablit la barre horizontale
au repos sans modifier les forces. Un changement d’exemple remet aussi au repos.
Les paramètres peuvent être modifiés pendant la lecture sans changer
instantanément l’angle ni la vitesse angulaire. Les orientations φ des forces
restent fixes dans l’espace et ne tournent pas avec la barre. Elles sont mesurées
depuis +x, antihoraire positif, entre −180° et 180°.

Le schéma conserve la même échelle pendant tout le mouvement. Les marqueurs
colorés ne sont pas des masses ajoutées. Les flèches sont proportionnelles
aux intensités (même facteur pour les deux forces), et jointives.
Les distances r1 et r2 sont mesurées le long de la barre, pas les bras
de levier perpendiculaires instantanés. O utilise une annotation fixe ; aucune
permutation des étiquettes pendant la rotation.

## Construction du bras de levier

L’option « Ligne d’action et bras de levier » est active au départ. Le choix
« Construction pour » sélectionne une force à la fois. Saisir son point
d’application la sélectionne également. Désactiver la construction restitue
la vue simple avec l’option des distances au pivot ; cela ne change ni le
cadrage ni l’état mécanique. Le bilan complet reste désactivé par défaut.

La ligne d’action est en tirets de la couleur de la force ; OH, perpendiculaire
à cette ligne, est violet et porte une marque d’angle droit en H. La distance r
est cotée en gris juste à côté de la barre, avec extrémités projetées sur O et A.
L’arc doré β (entre 0 et 180°) est situé en A entre le prolongement de OA et la
force. Une légende fixe donne r, d⊥, β et |τ| = F d⊥, sans étiquettes flottantes.
La relation d⊥ = r sin β distingue la distance au pivot du vrai bras de levier.

Pour une direction unitaire u de la force et le vecteur position r,
H = r − (r·u)u et d⊥ = |r × u|. Le signe du moment vient de r × F, et non de
sin β (toujours positif sur 0…π). Le cas radial donne d⊥ = 0 ; le cas
perpendiculaire donne d⊥ = r. Si F = 0, la construction de la ligne d’action et
de l’angle est masquée et un texte explique qu’ils ne sont pas définis.

## Modèle

Barre de longueur 4 m et de masse 3 kg ; I_O = m l² / 12 = 4 kg m².
Angle theta positif antihoraire, zéro horizontal. Positions matérielles
s1 = -r1 et s2 = r2 ; chaque force est Fi (cos φi, sin φi).

τi = xi Fiy − yi Fix = si Fi sin(φi − theta)
I_O theta'' = τ1 + τ2
Pour φ1 = φ2 = −90°, on retrouve (r1 F1 − r2 F2) cos(theta).

Avec l’option « Avec frottement », le bilan devient
I_O theta'' = τ1 + τ2 − b omega.
Le coefficient b varie de 0 à 8 N m s (2 par défaut), en direct sans remettre
le mouvement à zéro. L’option est désactivée au départ ; le choix d’un autre
exemple conserve ce réglage. Le bilan affiche séparément τ_f = −bω.
Il s’agit d’un frottement visqueux, pas d’un frottement sec : aucun seuil
statique n’est ajouté et le moment de frottement est nul au repos.

Un indicateur fixe dans la scène donne le moment total et sa valeur signée :
⊙ sort du plan (antihoraire, positif), ⊗ entre dans le plan (horaire, négatif).
Ce symbole suit le moment total, frottement compris, et non la vitesse angulaire.
À la précision d’affichage, un moment inférieur à 0.005 N m est affiché comme nul.

Le centre de masse est fixe en O. Le poids et la réaction du pivot ne
créent aucun moment autour de O. La réaction est
Rx = −F1x − F2x, Ry = mg − F1y − F2y ; la résultante de toutes les forces est nulle même
pendant la rotation. Les deux forces seules ne forment pas ce bilan complet.
Poids et réaction ne sont pas dessinés par défaut pour garder l’expérience lisible.

## Option « Bilan complet des forces »

La case, décochée au démarrage, ajoute le poids mg (gris, vers le bas)
et la réaction R (verte, de direction calculée) au point O. Une légende fixe donne
leurs modules en newtons. Les quatre flèches partagent une même échelle
de force, réduite dans cette vue pour que la réaction maximale reste visible.
Cette échelle est fixée par la taille du cadre et les bornes des réglages,
pas par les forces courantes. La géométrie de la barre ne change pas.
L’option ne réinitialise ni le temps, ni l’angle, ni la vitesse ; elle peut
être modifiée pendant la lecture et est conservée au changement d’exemple.

Le panneau « Deux conditions à vérifier ensemble » affiche simultanément :

- ΣFx = F1x + F2x + Rx = 0 et ΣFy = F1y + F2y + Ry − mg = 0 ;
- Στ_(O,z) = τ1 + τ2 + τf, nul ou non nul suivant l’état courant.

Les contributions du poids et de la réaction au moment sont nulles,
car elles s’appliquent en O. Le centre de masse est précisément ce pivot
fixe, donc la résultante des forces est nulle **même en rotation**.
Le modèle de frottement ajoute un couple visqueux au bilan des moments,
et aucune résultante supplémentaire de forces.

Un troisième message distingue les bilans nuls d’un véritable équilibre
statique : une barre déjà en rotation ne s’immobilise pas simplement parce
que le moment devient nul. Un moment très petit mais non nul est signalé
comme tel même si la valeur affichée est arrondie à 0.00.

Les tests incluent le bilan vectoriel des quatre forces, leurs moments,
le cas moment nul/vitesse non nulle, les options en cours de lecture et
la conservation du cadrage. `check_browser.cjs` vérifie aussi Chrome réel,
MathJax et les largeurs 1440, 900, 390 et 320 pixels. Variables facultatives :
`PLAYWRIGHT_MODULE`, `CHROME_PATH`, `STATICS_APP_URL` et `QA_OUTPUT`.

Par défaut, le pivot est idéal : ni frottement ni amortissement. Le moment non nul
produit une accélération angulaire, pas une vitesse prescrite. À moment nul,
une barre déjà en mouvement n’est pas en équilibre statique. Une force
verticale à un point solidaire de la barre engendre généralement une
oscillation, et non une accélération de signe constant sur tout un tour.

Les paramètres sont des commandes externes ; leur modification peut apporter
ou retirer de l’énergie. On ne modélise ni les actionneurs ni leur inertie.
À paramètres constants, E = I omega²/2 − Σ Fi·ri est conservée.
Avec frottement, dE/dt = −b omega² ≤ 0, et les oscillations sont amorties.

Intégration RK4, sous-pas <= 1/240 s. La lecture démarre seulement sur demande.
Les longues interruptions sont bornées à 0.1 s par image ; le temps d’un onglet
masqué n’est pas rattrapé. Raccourcis : Espace lire/pause, R recommencer,
hors champs de saisie et boutons.

## Vérifications

- check_physics.cjs : 2 000 configurations, somme des moments, réaction,
  mise en rotation dans les deux sens, équilibres au repos pendant 60 s,
  conservation d’énergie, moment nul et vitesse conservée.
  2 000 configurations orientées supplémentaires vérifient la perpendicularité
  de OH, le pied H sur la ligne d’action, rF sin β, le gradient de l’énergie,
  les deux composantes de réaction et l’amortissement.
- check_ui.cjs : adaptateur Node du contrôleur (pas un navigateur).
  Lecture/pause, reprise, ralentissement, onglet masqué, paramètres en direct,
  changements d’exemple, décimales avec point et ligne de base des chiffres.
  Géométrie et séparation des annotations à 280 et 700 px, formules
  de 16, 24 et 32 px, pendant le mouvement et aux limites des curseurs.
- MathJax réel utilisé pour vérifier les formules et leurs métriques.
- Frottement : décroissance exponentielle de la rotation libre, monotonie
  de l’énergie, sens opposé à la vitesse, limite b = 0 et activation en direct.
- Indicateur du moment total : deux sens et valeur nulle, y compris pendant
  le freinage lorsque le signe du moment est opposé à celui de la vitesse.
- build.py inclut tous les fichiers dans le HTML autonome.

Commandes :
node check_physics.cjs
PHYS1985_MATHJAX_ROOT=/chemin/vers/mathjax/package/js node check_ui.cjs
python3 build.py

## Outils facultatifs WebMCP

- read_static_equilibrium : paramètres, état mécanique et bilan.
- configure_static_equilibrium : paramètres en direct ; exemple = remise au repos.
- control_static_rotation : play, pause, restart.

Mêmes fonctions que les commandes visibles, validation atomique des entrées,
détection de disponibilité, désinscription à la sortie.
Contrat testé dans l’adaptateur Node ; pas de validation native WebMCP
pour cette modification. La vue et les contrôles sont également vérifiés
dans un navigateur réel pour l’extension du bilan complet.
L’app fonctionne sans WebMCP.

## Sauvegarde de la version précédente

Une copie complète avant refonte est conservée localement, hors de cette archive.

Elle contient notamment les anciennes expériences « Posture et base d’appui »
et « Levier à deux masses », leur fichier autonome, les sources et les tests.

## Références physiques

- OpenStax, University Physics Vol. 1, 12.1 :
  https://openstax.org/books/university-physics-volume-1/pages/12-1-conditions-for-static-equilibrium
- OpenStax, University Physics Vol. 1, 10.7 :
  https://openstax.org/books/university-physics-volume-1/pages/10-7-newtons-second-law-for-rotation

Équations usuelles vérifiées sur ces références ; explications rédigées pour l’app.
