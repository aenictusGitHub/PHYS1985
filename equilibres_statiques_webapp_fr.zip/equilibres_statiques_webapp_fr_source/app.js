if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',startStaticsApp);else startStaticsApp();
async function startStaticsApp(){
  'use strict';
  const $=id=>document.getElementById(id),P=StaticsPhysics;
  try{
    await MathJax.startup.promise;
    const colors=['#2775b6','#cf693c'],ink='#233449',muted='#607185';
    const state={p:P.preset('balanced'),motion:P.initial(),example:'balanced',playing:false,speed:1,last:null,frame:null,disposed:false,drag:null,hover:null,fullForces:false},labels=new Map(),glyphs=new Map(),units=new Map();
    function math(el,value){if(el.dataset.math===value)return;el.replaceChildren(MathJax.tex2svg(value,{display:false}));el.dataset.math=value;}
    function part(value){const svg=MathJax.tex2svg(value,{display:false}).querySelector('svg'),[x,y,width,height]=svg.getAttribute('viewBox').split(/\s+/).map(Number);return {svg,x,y,width,height,ex:parseFloat(svg.getAttribute('width'))/width};}
    for(const el of document.querySelectorAll('[data-tex]'))math(el,el.dataset.tex);
    for(const c of '0123456789.-')glyphs.set(c,part(c));
    const top0=Math.min(...[...glyphs.values()].map(g=>g.y)),bottom0=Math.max(...[...glyphs.values()].map(g=>g.y+g.height));MathJax.startup.document.updateDocument();
    // Cached SVG glyphs share a single baseline. No per-frame MathJax typesetting.
    function number(el,value,digits=2,unit=''){
      if(!Number.isFinite(value))throw new Error('Valeur non finie.');
      const string=(Math.abs(value)<.5*10**-digits?0:value).toFixed(digits),key=string+'|'+unit;if(el.dataset.number===key)return;
      const parts=[...string].map(c=>glyphs.get(c));if(unit){if(!units.has(unit))units.set(unit,part(unit));parts.push(units.get(unit));}
      const svg=parts[0].svg.cloneNode(false),ex=glyphs.get('0').ex;let width=0,top=top0,bottom=bottom0;
      for(const [i,p]of parts.entries()){
        if(i===string.length)width+=1000/6;
        const g=document.createElementNS('http://www.w3.org/2000/svg','g');g.setAttribute('transform','translate('+(width-p.x)+',0)');
        g.append(...[...p.svg.children].map(c=>c.cloneNode(true)));svg.append(g);width+=p.width;top=Math.min(top,p.y);bottom=Math.max(bottom,p.y+p.height);
      }
      svg.setAttribute('viewBox','0 '+top+' '+width+' '+(bottom-top));svg.setAttribute('width',width*ex+'ex');svg.setAttribute('height',(bottom-top)*ex+'ex');svg.style.verticalAlign=-bottom*ex+'ex';svg.setAttribute('role','img');svg.setAttribute('aria-label',string+' '+unit.replace(/\\mathrm|[{}]/g,'').replace(/\\,/g,' '));
      el.classList.add('number');el.replaceChildren(svg);el.dataset.number=key;
    }
    const scene=$('scene');
    function sync(){
      $('preset').value=state.example;
      for(const key of Object.keys(P.bounds)){$(key).value=state.p[key];number($(key+'-value'),state.p[key],key.startsWith('phi')?0:key[0]==='F'?1:2,key.startsWith('phi')?'{}^\\circ':key==='b'?'\\mathrm{N\\,m\\,s}':key[0]==='F'?'\\mathrm N':'\\mathrm m');}
      $('friction').checked=state.p.friction;$('friction-controls').hidden=!state.p.friction;$('b').disabled=!state.p.friction;
      $('friction-plus').hidden=!state.p.friction;$('friction-moment').hidden=!state.p.friction;
      $('moment-equation').className='moment-equation'+(state.p.friction?' friction-active':'');
      $('full-forces').checked=state.fullForces;
      $('play').textContent=state.playing?'Pause':'Lire';$('play').setAttribute('aria-pressed',String(state.playing));
    }
    function configure(change){state.p=P.parameters({...state.p,...change});state.example='custom';sync();render();}
    function finishDrag(){
      const drag=state.drag;state.drag=null;state.hover=null;scene.style.cursor='default';
      if(drag&&scene.hasPointerCapture(drag.pointerId))scene.releasePointerCapture(drag.pointerId);
    }
    function cancelFrame(){if(state.frame!==null)cancelAnimationFrame(state.frame);state.frame=null;state.last=null;}
    function play(playing){cancelFrame();state.playing=playing;sync();render();if(playing&&!state.disposed)state.frame=requestAnimationFrame(frame);}
    function restart(){finishDrag();play(false);state.motion=P.initial();render();}
    function chooseExample(key){const p={...P.preset(key),friction:state.p.friction,b:state.p.b};finishDrag();play(false);state.p=p;state.example=key;state.motion=P.initial();sync();render();}
    function frame(now){
      state.frame=null;if(!state.playing||state.disposed)return;
      // Ignore time spent in a hidden tab; cap long stalls to avoid a catch-up jump.
      const dt=state.last===null?0:Math.min(.1,Math.max(0,(now-state.last)/1000))*state.speed;state.last=now;
      if(!document.hidden)state.motion=P.advance(state.p,state.motion,dt);
      render();state.frame=requestAnimationFrame(frame);
    }
    function line(ctx,points,color,width=1,dash=[]){ctx.beginPath();ctx.moveTo(...points[0]);for(const q of points.slice(1))ctx.lineTo(...q);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineCap='round';ctx.lineJoin='round';ctx.setLineDash(dash);ctx.stroke();ctx.setLineDash([]);}
    function circle(ctx,x,y,r,fill){ctx.beginPath();ctx.arc(x,y,r,0,2*Math.PI);ctx.fillStyle=fill;ctx.fill();}
    function arrow(ctx,a,b,color,width=3.4){
      const dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);if(length<.2)return;
      const ux=dx/length,uy=dy/length,head=Math.min(width<3?7:11,length*.55),base=[b[0]-head*ux,b[1]-head*uy];
      line(ctx,[a,[b[0]-head*.45*ux,b[1]-head*.45*uy]],color,width);
      ctx.beginPath();ctx.moveTo(...b);ctx.lineTo(base[0]-head*.43*uy,base[1]+head*.43*ux);ctx.lineTo(b[0]-head*.72*ux,b[1]-head*.72*uy);ctx.lineTo(base[0]+head*.43*uy,base[1]-head*.43*ux);ctx.closePath();ctx.fillStyle=color;ctx.fill();
    }
    function label(key,value,x,y,color=ink,kind=''){
      let el=labels.get(key);if(!el){el=document.createElement('span');$('scene-labels').append(el);labels.set(key,el);}
      el.hidden=false;el.dataset.labelKey=key;el.className='plot-label '+kind;el.style.left=x+'px';el.style.top=y+'px';el.style.color=color;math(el,value);
    }
    function actionLine(ctx,f,g,w,h){
      if(!f.F)return;
      const A=g.point(f.x,f.y),u=[f.ux,-f.uy];let lo=-Infinity,hi=Infinity;
      for(const [axis,min,max]of [[0,18,w-18],[1,28,h-82]]){
        if(Math.abs(u[axis])<1e-12)continue;
        const ends=[(min-A[axis])/u[axis],(max-A[axis])/u[axis]].sort((a,b)=>a-b);lo=Math.max(lo,ends[0]);hi=Math.min(hi,ends[1]);
      }
      if(lo<hi)line(ctx,[[A[0]+lo*u[0],A[1]+lo*u[1]],[A[0]+hi*u[0],A[1]+hi*u[1]]],colors[f.id-1],1.25,[6,5]);
    }
    function construction(ctx,f,g){
      const O=g.point(0,0),A=g.point(f.x,f.y),H=g.point(f.foot.x,f.foot.y),arm='#7758a6',angle='#ac792c';
      // A dimension line outside the bar makes r readable; its ends project
      // onto O and A. Its side follows the bar, never an angle-dependent switch.
      const side=f.id===1?1:-1,n=[side*f.y/f.r,side*f.x/f.r],a=[O[0]+18*n[0],O[1]+18*n[1]],b=[A[0]+18*n[0],A[1]+18*n[1]];
      line(ctx,[a,b],muted,1.5);
      for(const [point,end]of [[O,a],[A,b]]){line(ctx,[point,[end[0]+4*n[0],end[1]+4*n[1]]],'#a9b6c4',1,[2,3]);line(ctx,[[end[0]-4*n[0],end[1]-4*n[1]],[end[0]+4*n[0],end[1]+4*n[1]]],muted,1.5);}
      if(!f.F)return;
      line(ctx,[O,H],arm,2.6);
      const d=Math.hypot(H[0]-O[0],H[1]-O[1]);
      if(d>1){circle(ctx,...H,3,arm);circle(ctx,...H,1.5,'#fbfcfe');}
      if(d>14){
        const toward=[(O[0]-H[0])/d,(O[1]-H[1])/d],side=(A[0]-H[0])*f.ux-(A[1]-H[1])*f.uy>=0?1:-1,v=[side*f.ux*7,-side*f.uy*7];
        line(ctx,[[H[0]+v[0],H[1]+v[1]],[H[0]+v[0]+toward[0]*7,H[1]+v[1]+toward[1]*7],[H[0]+toward[0]*7,H[1]+toward[1]*7]],arm,1.25);
      }
      const ux=f.x/f.r,uy=f.y/f.r,radius=Math.max(14,Math.min(27,f.r*g.scale*.35)),startAngle=Math.atan2(-uy,ux),delta=Math.atan2(ux*f.uy-uy*f.ux,ux*f.ux+uy*f.uy);
      line(ctx,[A,[A[0]+ux*(radius+10),A[1]-uy*(radius+10)]],muted,1.1,[3,4]);
      if(Math.abs(delta)>.025)line(ctx,Array.from({length:41},(_,i)=>[A[0]+radius*Math.cos(startAngle-delta*i/40),A[1]+radius*Math.sin(startAngle-delta*i/40)]),angle,2);
    }
    function leverReadout(s){
      const on=$('lever-geometry').checked,f=s.forces[Number($('lever-force').value||1)-1];
      $('lever-toolbar').hidden=$('lever-guide').hidden=!on;$('distance-display').hidden=on;
      if(!on)return;
      number($('lever-r-value'),f.r,2,'\\mathrm m');number($('lever-d-value'),f.lever,2,'\\mathrm m');number($('lever-beta-value'),f.beta*180/Math.PI,1,'{}^\\circ');number($('lever-torque-value'),Math.abs(f.torque),2,'\\mathrm{N\\,m}');
      $('lever-action-key').style.color=colors[f.id-1];$('lever-metrics').hidden=!f.F;
      math($('lever-relation'),f.F?'|\\tau_'+f.id+'|=F_'+f.id+'d_\\perp=':'|\\tau_'+f.id+'|=');
      $('lever-action-key').hidden=!f.F;
      $('lever-note').textContent=!f.F?'Force nulle : moment nul. La ligne d’action et l’angle β d’une force nulle ne sont pas définis.':f.lever<1e-7?'La ligne d’action passe par O : le bras de levier est nul, même si la distance au point d’application ne l’est pas.':Math.abs(f.lever-f.r)<1e-7?'La force est perpendiculaire au vecteur position : β = 90° et le bras de levier est égal à la distance au pivot.':'Le segment violet est perpendiculaire à la ligne d’action : il est plus court que la distance au pivot. L’arc doré mesure β entre le prolongement du vecteur position et la force.';
    }
    function draw(s){
      const canvas=$('scene-canvas'),r=canvas.getBoundingClientRect(),w=r.width,h=r.height,dpr=Math.min(2,window.devicePixelRatio||1);
      if(w<200||h<300)return;
      if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
      const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
      for(const el of labels.values())el.hidden=true;
      const g=P.geometry(w,h),pt=g.point,c=Math.cos(s.theta),sn=Math.sin(s.theta),u=[c,-sn],n=[-sn,-c],O=pt(0,0),font=parseFloat(window.getComputedStyle($('scene-labels')).fontSize)||16;
      // Fixed view; toggles, forces and elapsed time never change its spatial scale.
      ctx.beginPath();ctx.arc(...O,2*g.scale,0,2*Math.PI);ctx.strokeStyle='#edf1f5';ctx.lineWidth=1;ctx.stroke();
      line(ctx,[[20,O[1]],[w-20,O[1]]],'#dce4ec',1,[4,6]);
      const selected=s.forces[Number($('lever-force').value||1)-1],showGeometry=$('lever-geometry').checked;
      if(showGeometry)actionLine(ctx,selected,g,w,h);
      const a=pt(-2*c,-2*sn),b=pt(2*c,2*sn);line(ctx,[a,b],'#8da2b6',11);
      line(ctx,[[a[0]+n[0]*3,a[1]+n[1]*3],[b[0]+n[0]*3,b[1]+n[1]*3]],'#c9d7e3',2);
      // Only the force scale changes in the complete view, never the bar's
      // geometry. Use a fixed scale for the maximum allowed reaction, not
      // one that fluctuates with the forces or the rotation.
      const simpleScale=Math.max(.1,Math.min(5,(O[1]-1.8*g.scale-28)/20,(w/2-1.8*g.scale-24)/20,(h-82-O[1]-1.8*g.scale)/20));
      const forceScale=state.fullForces?Math.min(simpleScale,2,(O[1]-Math.max(24,font*1.1)-font-18)/(P.MASS*P.G+40),(w/2-24)/(P.MASS*P.G+40)):simpleScale;
      if(showGeometry)construction(ctx,selected,g);
      if(state.fullForces){arrow(ctx,O,[O[0]+s.Rx*forceScale,O[1]-s.Ry*forceScale],'#268576');arrow(ctx,O,[O[0],O[1]+s.weight*forceScale],muted);}
      // Colour identifies the attached application point throughout a full turn.
      for(const f of s.forces){
        const q=pt(f.x,f.y),color=colors[f.id-1];circle(ctx,...q,5,color);arrow(ctx,q,[q[0]+forceScale*f.Fx,q[1]-forceScale*f.Fy],color);
        if(state.drag?.id===f.id||state.hover===f.id){ctx.beginPath();ctx.arc(...q,9,0,2*Math.PI);ctx.strokeStyle=color;ctx.lineWidth=1.5;ctx.stroke();}
        if($('arms').checked&&!showGeometry){
          const side=f.id===1?1:-1,offset=side*Math.max(34,font*1.7),start=[O[0]+n[0]*offset,O[1]+n[1]*offset],end=[q[0]+n[0]*offset,q[1]+n[1]*offset];
          line(ctx,[start,end],color,1.2);
          for(const v of [start,end])line(ctx,[[v[0]-n[0]*4,v[1]-n[1]*4],[v[0]+n[0]*4,v[1]+n[1]*4]],color,1.2);
          const lx=(start[0]+end[0])/2+n[0]*side*16,ly=(start[1]+end[1])/2+n[1]*side*16;
          label('d'+f.id,'r_'+f.id,lx,ly,color);
        }
      }
      circle(ctx,...O,9,'#233449');circle(ctx,...O,3,'#fff');
      // A fixed caption lane keeps O clear of the rotating distance labels.
      const originY=Math.max(24,font*1.1);
      const leaderEnd=state.fullForces&&Math.abs(s.Rx)<1e-7&&s.Ry>0?O[1]-s.Ry*forceScale-8:O[1]-12;
      line(ctx,[[O[0],originY+font],[O[0],leaderEnd]],'#c3cfdb',1,[2,5]);
      label('O','O',O[0],originY,ink,'pivot');
      $('scene').setAttribute('aria-label','Barre sur pivot fixe O. Moment total '+s.torque.toFixed(2)+' N m. Vitesse angulaire '+s.omega.toFixed(2)+' rad/s. '+(s.equilibrium?'Équilibre statique.':'Hors équilibre statique.')+(showGeometry?(selected.F?' Force '+selected.id+' : distance '+selected.r.toFixed(2)+' m, bras de levier '+selected.lever.toFixed(2)+' m.':' Force '+selected.id+' nulle : moment nul, pas de ligne d’action définie.'):'')+(state.fullForces?' Bilan complet : poids '+s.weight.toFixed(2)+' N vers le bas ; réaction Rx = '+s.Rx.toFixed(2)+' N, Ry = '+s.Ry.toFixed(2)+' N ; résultante nulle.':''));
    }
    function render(){
      const s=P.solve(state.p,state.motion),rest=Math.abs(s.omega)<1e-8,zero=Math.abs(s.torque)<1e-8;
      number($('time-value'),s.t,2,'\\mathrm s');number($('M1-value'),s.M1,2,'\\mathrm{N\\,m}');number($('M2-value'),s.M2,2,'\\mathrm{N\\,m}');number($('Mf-value'),s.frictionTorque,2,'\\mathrm{N\\,m}');number($('torque-value'),s.torque,2,'\\mathrm{N\\,m}');number($('alpha-value'),s.alpha,2,'\\mathrm{rad\\,s^{-2}}');number($('omega-value'),s.omega,2,'\\mathrm{rad\\,s^{-1}}');
      number($('scene-torque-value'),s.torque,2,'\\mathrm{N\\,m}');
      $('complete-force-key').hidden=$('complete-balance').hidden=!state.fullForces;
      $('couple-note').hidden=!state.p.friction;
      for(const [id,key]of [['weight-value','weight'],['reaction-value','reaction'],['sumFx-value','sumFx'],['sumFy-value','sumFy']])number($(id),s[key],2,'\\mathrm N');
      number($('moment-condition-value'),s.torque,2,'\\mathrm{N\\,m}');
      $('force-condition').textContent=s.forceBalanced?'Résultante nulle':'Résultante non nulle';$('force-condition').dataset.satisfied=String(s.forceBalanced);
      $('moment-condition').textContent=zero?'Moment nul':Math.abs(s.torque)<.005?'Moment non nul (arrondi à 0.00)':'Moment non nul';$('moment-condition').dataset.satisfied=String(zero);
      $('rest-condition').textContent=s.equilibrium?'Les deux conditions sont satisfaites et la barre est au repos : équilibre statique.':zero?'Les deux bilans sont nuls, mais la barre tourne déjà : ce n’est pas un équilibre statique.':rest?'La résultante est nulle, mais pas le moment : la barre peut se mettre en rotation autour du pivot.':'La résultante est nulle, mais le moment modifie la vitesse de rotation : pas d’équilibre statique.';
      $('force-scene-note').textContent=state.fullForces?'Le poids agit au centre de masse O et la réaction au pivot O : leurs moments sont nuls. Les quatre flèches utilisent une même échelle de force. La légende reste fixe pendant la rotation.':'Les forces gardent leur orientation dans l’espace lorsque la barre tourne. Poids et réaction du pivot ne sont pas représentés ; leur moment autour de O est nul.';
      const direction=Math.abs(s.torque)<.005?0:Math.sign(s.torque);
      math($('torque-direction-symbol'),direction>0?'\\odot':direction<0?'\\otimes':'0');
      $('scene-torque').dataset.direction=String(direction);
      $('torque-direction-text').textContent=direction>0?'Sort du plan · antihoraire':direction<0?'Entre dans le plan · horaire':zero?'Moment total nul':'Moment total ≈ 0 à cette précision';
      let title,explanation,badge,kind;
      if(s.equilibrium){badge='Équilibre statique';kind='positive';title='La barre reste au repos.';explanation='Les deux moments se compensent. La réaction du pivot assure aussi l’équilibre des forces. Vous pouvez lancer la lecture : la barre ne tourne pas.';}
      else if(zero){badge='Moment nul · rotation en cours';kind='neutral';title='Moment nul ne signifie pas vitesse nulle.';explanation='La vitesse angulaire acquise est conservée lorsque le moment total reste nul. Pour retrouver le repos initial, appuyez sur « Recommencer ».';}
      else if(rest){badge=state.playing?'Mise en rotation':'Prête à tourner';kind='negative';title='Un moment total subsiste.';explanation='Au lâcher, la barre part dans le sens '+(s.torque>0?'antihoraire (positif).':'horaire (négatif).')+' '+(state.playing?'':'Appuyez sur « Lire » pour observer le mouvement.');}
      else {const speeding=s.torque*s.omega>0;badge=state.playing?'En rotation':'Animation en pause';kind='negative';title=speeding?'Le moment accélère la rotation.':'Le moment freine la rotation.';explanation='Le moment total et la vitesse angulaire sont '+(speeding?'de même signe.':'de signes opposés.')+' La barre peut donc ralentir avant de repartir dans l’autre sens.';if(speeding)explanation='Le moment total et la vitesse angulaire sont de même signe : le module de la vitesse augmente. Les orientations des forces restant fixes, les bras de levier évoluent avec l’inclinaison.';}
      if(state.p.friction&&state.p.b>0)explanation+=' Le frottement visqueux s’oppose à la vitesse angulaire et dissipe de l’énergie dès que la barre tourne.';
      if($('status').textContent!==badge)$('status').textContent=badge;$('status').className='sign-badge '+kind;
      $('explanation-title').textContent=title;$('explanation').textContent=explanation;leverReadout(s);draw(s);
    }
    $('preset').addEventListener('change',()=>chooseExample($('preset').value));
    $('friction').addEventListener('change',()=>configure({friction:$('friction').checked}));
    for(const key of Object.keys(P.bounds))$(key).addEventListener('input',()=>configure({[key]:Number($(key).value)}));
    function pointerGeometry(e){
      const r=scene.getBoundingClientRect(),g=P.geometry(r.width,r.height),theta=state.motion.theta;
      return {g,x:e.clientX-r.left,y:e.clientY-r.top,ux:Math.cos(theta),uy:-Math.sin(theta)};
    }
    function hitPoint(e){
      const q=pointerGeometry(e);
      const hits=P.solve(state.p,state.motion).forces.map(f=>{const p=q.g.point(f.x,f.y);return {id:f.id,distance:Math.hypot(q.x-p[0],q.y-p[1])};}).sort((a,b)=>a.distance-b.distance);
      return hits[0].distance<=24?hits[0].id:null;
    }
    scene.addEventListener('pointerdown',e=>{
      if(e.button!==0||e.isPrimary===false||state.drag)return;
      const id=hitPoint(e);if(id===null)return;
      $('lever-force').value=String(id);
      e.preventDefault();scene.focus({preventScroll:true});
      const q=pointerGeometry(e),sign=id===1?-1:1,projection=((q.x-q.g.cx)*q.ux+(q.y-q.g.cy)*q.uy)/q.g.scale;
      // Keep the initial grab offset: selecting near a point must not move it.
      state.drag={id,pointerId:e.pointerId,offset:sign*state.p['d'+id]-projection};
      state.hover=id;scene.setPointerCapture(e.pointerId);scene.style.cursor='grabbing';render();
    });
    scene.addEventListener('pointermove',e=>{
      if(state.drag){
        const drag=state.drag;if(e.pointerId!==drag.pointerId)return;
        e.preventDefault();const q=pointerGeometry(e),key='d'+drag.id,sign=drag.id===1?-1:1;
        // Project onto the bar's CURRENT direction, including during playback.
        const raw=sign*(((q.x-q.g.cx)*q.ux+(q.y-q.g.cy)*q.uy)/q.g.scale+drag.offset),[lo,hi]=P.bounds[key];
        if(!Number.isFinite(raw))return;
        configure({[key]:Math.round(Math.max(lo,Math.min(hi,raw))*100)/100});
      }else{
        const hit=hitPoint(e);scene.style.cursor=hit===null?'default':'grab';
        if(hit!==state.hover){state.hover=hit;render();}
      }
    });
    for(const name of ['pointerup','pointercancel','lostpointercapture'])scene.addEventListener(name,e=>{
      if(e.pointerId!==state.drag?.pointerId)return;finishDrag();render();
    });
    scene.addEventListener('pointerleave',()=>{if(!state.drag){state.hover=null;scene.style.cursor='default';render();}});
    $('play').addEventListener('click',()=>play(!state.playing));$('restart').addEventListener('click',restart);
    $('speed').addEventListener('change',()=>{const v=Number($('speed').value);if([.25,.5,1].includes(v))state.speed=v;});
    $('arms').addEventListener('change',render);
    $('lever-geometry').addEventListener('change',render);$('lever-force').addEventListener('change',render);
    $('full-forces').addEventListener('change',()=>{state.fullForces=$('full-forces').checked;render();});
    document.addEventListener('visibilitychange',()=>{state.last=null;if(document.hidden){finishDrag();render();}});
    document.addEventListener('keydown',e=>{if(e.target.closest?.('input,select,button,summary,textarea')||e.ctrlKey||e.metaKey||e.altKey)return;if(e.code==='Space'){e.preventDefault();play(!state.playing);}else if(e.key?.toLowerCase()==='r')restart();});
    const observer=new ResizeObserver(render);observer.observe($('scene'));window.addEventListener('pagehide',()=>{state.disposed=true;state.playing=false;finishDrag();cancelFrame();observer.disconnect();});
    sync();render();$('loading').hidden=true;
    await window.PhysShare?.register({id:'statics',pause:()=>play(false),
      capture:()=>({p:{...state.p},motion:{...state.motion},example:state.example,speed:state.speed,fullForces:state.fullForces}),
      restore:(s,ui)=>{const p=P.parameters(s.p);P.solve(p,s.motion);PhysShare.range(s.speed,.1,4);finishDrag();play(false);state.p=p;PhysShare.set(state.motion,s.motion);state.example=s.example;state.speed=s.speed;state.fullForces=s.fullForces;sync();ui();render();}
    });
    // Optional WebMCP integration is installed after the visible experience is ready.
    if(typeof installStaticsTools==='function')installStaticsTools({state,configure,chooseExample,play,restart,P});
  }catch(error){console.error(error);$('loading').hidden=false;$('loading').textContent='L’application n’a pas pu démarrer. Rechargez la page ; les formules sont incluses localement.';}
}

function installStaticsTools({state,configure,chooseExample,play,restart,P}){
  if(!document.modelContext?.registerTool)return;
  const lifecycle=new AbortController(),object=input=>{if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('Objet attendu.');},empty=input=>{object(input);if(Object.keys(input).length)throw new Error('Aucun paramètre attendu.');};
  const read=()=>({parameters:{...state.p},motion:{...state.motion},playing:state.playing,speed:state.speed,display:{fullForces:state.fullForces},result:P.solve(state.p,state.motion)});
  const register=tool=>{try{Promise.resolve(document.modelContext.registerTool(tool,{signal:lifecycle.signal})).catch(error=>console.warn('Outil facultatif indisponible.',error));}catch(error){console.warn('Outil facultatif indisponible.',error);}};
  register({name:'read_static_equilibrium',description:'Lire les forces, leurs orientations, distances au pivot, bras de levier, angles bêta, mouvement et moments de la barre.',annotations:{readOnlyHint:true},inputSchema:{type:'object',properties:{},additionalProperties:false},execute:input=>{empty(input);return read();}});
  const properties={...Object.fromEntries(Object.entries(P.bounds).map(([key,[minimum,maximum]])=>[key,{type:'number',minimum,maximum}])),friction:{type:'boolean'}};
  register({name:'configure_static_equilibrium',description:'Modifier les forces, leurs orientations phi1/phi2 en degrés depuis +x, les distances et le frottement visqueux au pivot sans remettre le mouvement à zéro. Choisir un exemple remet la barre horizontale au repos et met la lecture en pause, en conservant le réglage du frottement.',inputSchema:{type:'object',properties:{preset:{type:'string',enum:Object.keys(P.presets)},parameters:{type:'object',properties,additionalProperties:false}},additionalProperties:false},execute:input=>{
    object(input);if(!Object.keys(input).length||Object.keys(input).some(k=>!['preset','parameters'].includes(k)))throw new Error('Configuration non valide.');
    const changes=input.parameters===undefined?{}:input.parameters;object(changes);
    const p=P.parameters({...((input.preset===undefined)?state.p:{...P.preset(input.preset),friction:state.p.friction,b:state.p.b}),...changes});
    // Validate every field before changing the visible state or playback.
    if(input.preset!==undefined)chooseExample(input.preset);
    if(input.parameters!==undefined)configure(p);
    return read();
  }});
  register({name:'control_static_rotation',description:'Lire, mettre en pause ou recommencer la rotation, comme les boutons visibles. Recommencer conserve les forces mais remet la barre horizontale au repos.',inputSchema:{type:'object',properties:{action:{type:'string',enum:['play','pause','restart']}},required:['action'],additionalProperties:false},execute:input=>{
    object(input);if(Object.keys(input).length!==1||!['play','pause','restart'].includes(input.action))throw new Error('Action non valide.');
    if(input.action==='restart')restart();else play(input.action==='play');return read();
  }});
  window.addEventListener('pagehide',()=>lifecycle.abort());
}
