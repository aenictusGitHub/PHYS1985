/* Node controller adapter, not browser visual QA. Supports real MathJax metrics. */
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'index.html'),'utf8'),source=fs.readFileSync(path.join(__dirname,'physics.js'),'utf8')+'\n'+fs.readFileSync(path.join(__dirname,'app.js'),'utf8');
assert(!html.includes('M_{O,z}'),'all displayed torques use tau');
assert.equal(html.split('\\tau_{O,z}').length-1,7,'tau in all torque relations and labels');
const near=(a,b,tol=1e-8)=>assert(Math.abs(a-b)<tol,`${a} != ${b}`);
let width=700,fontPixels=16,clock=0,frameId=0;const nodes=new Map(),plots=new Map(),frames=new Map(),events={},tools=new Map(),errors=[];
function canvasContext(id){let points=[];const strokes=[],bodies=[];const context=new Proxy({}, {get(target,key){if(key in target)return target[key];return (...args)=>{for(const n of args.flat())if(typeof n==='number')assert(Number.isFinite(n),'finite geometry');if(key==='clearRect'){strokes.length=0;bodies.length=0;}if(key==='beginPath')points=[];if(key==='moveTo'||key==='lineTo')points.push([...args]);if(key==='createLinearGradient'||key==='createRadialGradient')return {type:'linear',args,stops:[],addColorStop(offset,color){this.stops.push([offset,color]);}};if(key==='arc')points.push(args.slice(0,3));if(key==='fill'&&target.fillStyle?.type==='linear')bodies.push({points,fill:target.fillStyle});if(key==='stroke')strokes.push({points,color:target.strokeStyle,width:target.lineWidth});if(key==='fillRect')bodies.push({rect:args,fill:target.fillStyle});};}});plots.set(id,{context,strokes,bodies});return context;}
class Element{
  constructor(tag='span'){this.tag=tag;this.children=[];this.dataset={};this.style={};this.attrs={};this.events={};this.classList={add(){}};this.value='';this.hidden=false;this.checked=false;}
  set id(id){this._id=id;nodes.set(id,this);}get id(){return this._id;}
  append(...children){this.children.push(...children);}replaceChildren(...children){this.children=children;}
  setAttribute(k,v){this.attrs[k]=String(v);}getAttribute(k){return this.attrs[k];}querySelector(tag){return this.children.find(el=>el.tag===tag);}
  cloneNode(deep){const el=new Element(this.tag);el.attrs={...this.attrs};el.style={...this.style};el.dataset={...this.dataset};if(deep)el.children=this.children.map(c=>c.cloneNode(true));return el;}
  addEventListener(k,fn){this.events[k]=fn;}fire(k,args={}){this.events[k]?.({target:this,preventDefault(){},...args});}click(){this.fire('click');}closest(){return null;}
  focus(){this.focused=true;}
  setPointerCapture(id){this.capture=id;}hasPointerCapture(id){return this.capture===id;}releasePointerCapture(){this.capture=undefined;}
  getBoundingClientRect(){
    if(this.className?.includes('plot-label')){const first=this.children[0],svg=first?.tag==='svg'?first:first?.querySelector('svg'),factor=fontPixels*.52,w=parseFloat(svg?.getAttribute('width')||'1.131')*factor,h=Math.max(fontPixels*1.4,parseFloat(svg?.getAttribute('height')||'2')*factor),left=parseFloat(this.style.left)-w/2,top=parseFloat(this.style.top)-h/2;return {left,top,right:left+w,bottom:top+h,width:w,height:h};}
    const height=this.id?.startsWith('scene')?Math.max(430,fontPixels*24):Math.max(280,fontPixels*18);return {left:0,top:0,right:width,bottom:height,width,height};
  }
  getContext(){return plots.get(this.id)?.context||canvasContext(this.id);}
}
for(const m of html.matchAll(/<([\w-]+)\b([^>]*\bid="([^"]+)"[^>]*)>/g)){const el=new Element(m[1]);el.id=m[3];el.value=/\bvalue="([^"]*)"/.exec(m[2])?.[1]||'';el.checked=/\bchecked\b/.test(m[2]);}
const $=id=>{assert(nodes.has(id),'missing '+id);return nodes.get(id);};$('preset').value='balanced';$('speed').value='1';
const staticMath=[...html.matchAll(/\bdata-tex="([^"]*)"/g)].map(m=>{const el=new Element();el.dataset.tex=m[1];return el;});
let convertTex;
if(process.env.PHYS1985_MATHJAX_ROOT){
  const root=process.env.PHYS1985_MATHJAX_ROOT,{mathjax}=require(path.join(root,'mathjax.js')),{TeX}=require(path.join(root,'input/tex.js')),{SVG}=require(path.join(root,'output/svg.js')),adaptor=require(path.join(root,'adaptors/liteAdaptor.js')).liteAdaptor();require(path.join(root,'handlers/html.js')).RegisterHTMLHandler(adaptor);require(path.join(root,'input/tex/ams/AmsConfiguration.js'));require(path.join(root,'input/tex/newcommand/NewcommandConfiguration.js'));
  const doc=mathjax.document('',{InputJax:new TeX({packages:['base','ams','newcommand']}),OutputJax:new SVG({fontCache:'none'})});
  function convert(n){const el=new Element(n.kind);for(const {name,value}of adaptor.allAttributes(n))el.setAttribute(name,value);el.append(...adaptor.childNodes(n).filter(c=>c.kind!=='#text').map(convert));return el;}
  convertTex=text=>{const out=doc.convert(text,{display:false});assert(!adaptor.outerHTML(out).includes('data-mml-node="merror"'),'valid TeX: '+text);return convert(out);};
}
function typeset(text){assert(!/[\x00-\x1f]/.test(text));assert(!text.includes('NaN'));if(convertTex)return convertTex(text);const out=new Element('mjx-container'),svg=new Element('svg');svg.setAttribute('viewBox','0 -700 500 722');svg.setAttribute('width','1.131ex');svg.setAttribute('height','1.6ex');svg.append(new Element('g'));out.append(svg);return out;}
function listen(name,fn){const old=events[name];events[name]=e=>{old?.(e);fn(e);};}
const document={readyState:'complete',getElementById:$,createElement:t=>new Element(t),createElementNS:(_,t)=>new Element(t),querySelectorAll:()=>staticMath,addEventListener:listen,modelContext:{registerTool(tool,options){assert(!tools.has(tool.name));tools.set(tool.name,tool);options.signal.addEventListener('abort',()=>tools.delete(tool.name));}}};
const context={document,window:{devicePixelRatio:1,getComputedStyle:()=>({fontSize:fontPixels+'px'}),addEventListener:listen},AbortController,console:{error:e=>errors.push(e),warn:e=>errors.push(e)},ResizeObserver:class{observe(){}disconnect(){}},requestAnimationFrame:fn=>{frames.set(++frameId,fn);return frameId;},cancelAnimationFrame:id=>frames.delete(id),MathJax:{startup:{promise:Promise.resolve(),document:{updateDocument(){}}},tex2svg:typeset}};
const P=require('./physics.js'),value=id=>parseFloat($(id).dataset.number),input=(id,v)=>{$(id).value=v;$(id).fire('input');};
const read=()=>tools.get('read_static_equilibrium').execute({}),configure=p=>tools.get('configure_static_equilibrium').execute(p);

const control=action=>tools.get('control_static_rotation').execute({action});
const overlap=(a,b)=>a.left<b.right+1&&a.right>b.left-1&&a.top<b.bottom+1&&a.bottom>b.top-1;
function selectExample(key){$('preset').value=key;$('preset').fire('change');}
function tick(ms=1000/60){clock+=ms;const current=[...frames.entries()];frames.clear();for(const [,fn]of current)fn(clock);}
function advanceSeconds(seconds){tick(0);for(let i=0;i<Math.round(seconds*60);i++)tick();}
function inspectLabels(){
 const visible=$('scene-labels').children.filter(el=>!el.hidden),h=$('scene').getBoundingClientRect().height;
 for(const el of visible){const r=el.getBoundingClientRect();assert(r.left>=0&&r.right<=width&&r.top>=0&&r.bottom<=h,'label inside '+fontPixels+'/'+width+'/'+el.dataset.labelKey+': '+JSON.stringify(r));}
 for(let i=0;i<visible.length;i++)for(const other of visible.slice(i+1))assert(!overlap(visible[i].getBoundingClientRect(),other.getBoundingClientRect()),'separate '+fontPixels+'/'+width+'/'+visible[i].dataset.labelKey+'/'+other.dataset.labelKey);
}
async function main(){
 vm.runInNewContext(source,context);await new Promise(r=>setImmediate(r));assert.deepEqual(errors,[]);assert($('loading').hidden);assert.equal(tools.size,3);assert.equal(frames.size,0);assert(read().result.equilibrium);
 for(const key of Object.keys(P.presets)){
  selectExample(key);assert(!read().playing);near(read().motion.t,0);near(value('torque-value'),P.solve(P.preset(key)).torque,.005);
  $('play').click();assert(read().playing);assert.equal(frames.size,1);advanceSeconds(1);
  near(read().motion.t,1);if(['balanced','unequal'].includes(key)){near(read().motion.theta,0);assert(read().result.equilibrium);}else assert(Math.abs(read().motion.theta)>.1);
  $('play').click();assert(!read().playing);assert.equal(frames.size,0);const paused=JSON.stringify(read().motion);tick(3000);assert.equal(JSON.stringify(read().motion),paused);
  for(const id of ['F1-value','F2-value','d1-value','d2-value','time-value','M1-value','M2-value','torque-value','alpha-value','omega-value']){
   assert.equal($(id).children.length,1);assert.equal($(id).children[0].tag,'svg');assert(!$(id).dataset.number.split('|')[0].includes(','));for(const g of $(id).children[0].children)assert(/,0\)$/.test(g.getAttribute('transform')));
  }
 }
 // Direct manipulation: both points, both signs of rotation, touch and mouse.
 const scene=$('scene');
 function location(id,d){
  const s=read(),g=P.geometry(width,scene.getBoundingClientRect().height),u=[Math.cos(s.motion.theta),-Math.sin(s.motion.theta)],sign=id===1?-1:1;
  return {g,u,p:g.point(sign*d*Math.cos(s.motion.theta),sign*d*Math.sin(s.motion.theta))};
 }
 const emit=(type,q,extra={})=>scene.fire(type,{pointerId:21,button:0,isPrimary:true,clientX:q[0],clientY:q[1],...extra});
 for(const viewport of [280,700])for(const id of [1,2])for(const running of [false,true]){
  width=viewport;selectExample(id===1?'counterclockwise':'clockwise');
  if(running){control('play');advanceSeconds(.8);}
  const key='d'+id,other='d'+(3-id),oldOther=read().parameters[other],initial={...read().motion};
  let at=location(id,read().parameters[key]);
  const nearPoint=[at.p[0]+4*at.u[0]-6*at.u[1],at.p[1]+4*at.u[1]+6*at.u[0]];
  emit('pointermove',nearPoint);assert.equal(scene.style.cursor,'grab');
  emit('pointerdown',nearPoint,{pointerType:running?'touch':'mouse'});assert.equal(scene.capture,21);assert.equal(scene.style.cursor,'grabbing');
  assert.equal(JSON.stringify(read().motion),JSON.stringify(initial));near(read().parameters[key],1.2);
  // A secondary contact cannot steal the active point.
  emit('pointerdown',location(3-id,oldOther).p,{pointerId:22,isPrimary:false});assert.equal(scene.capture,21);
  const snapshot=JSON.stringify(read().parameters);emit('pointermove',[0,0],{pointerId:22});assert.equal(JSON.stringify(read().parameters),snapshot);
  if(running){advanceSeconds(.2);assert(read().motion.t>initial.t);assert(read().playing);}
  for(const [distance,expected]of [[.65,.65],[4,1.8],[-.4,.2],[1.4,1.4]]){
   at=location(id,distance);const unchanged={...read().motion};
   // Same along-bar grab offset; arbitrary perpendicular displacement ignored.
   emit('pointermove',[at.p[0]+4*at.u[0]-30*at.u[1],at.p[1]+4*at.u[1]+30*at.u[0]]);
   near(read().parameters[key],expected);near(Number($(key).value),expected);near(value(key+'-value'),expected);
   near(read().parameters[other],oldOther);assert.equal(JSON.stringify(read().motion),JSON.stringify(unchanged));assert.equal(read().playing,running);
  }
  emit('pointerup',at.p);assert.equal(scene.capture,undefined);const finished=JSON.stringify(read().parameters);emit('pointermove',[0,0]);assert.equal(JSON.stringify(read().parameters),finished);
  at=location(id,read().parameters[key]);emit('pointerdown',at.p);assert.equal(scene.capture,21);emit('pointercancel',at.p);assert.equal(scene.capture,undefined);
  emit('pointerdown',at.p);assert.equal(scene.capture,21);$('restart').click();assert.equal(scene.capture,undefined);assert(!read().playing);
  emit('pointerdown',[0,0]);assert.equal(scene.capture,undefined);
  // Zero forces still leave a draggable application point.
  input('F'+id,0);at=location(id,read().parameters[key]);emit('pointerdown',at.p);assert.equal(scene.capture,21);emit('lostpointercapture',at.p);assert.equal(scene.capture,undefined);
  at=location(id,read().parameters[key]);emit('pointerdown',at.p);selectExample('balanced');assert.equal(scene.capture,undefined);
  at=location(id,read().parameters[key]);emit('pointerdown',at.p);document.hidden=true;events.visibilitychange();assert.equal(scene.capture,undefined);document.hidden=false;
 }
 width=700;
 assert(!nodes.has('d1-input')&&!nodes.has('d2-input'),'no numeric-entry fields');
 selectExample('clockwise');control('play');advanceSeconds(.7);
 const before={...read().motion};input('F2',10);assert(read().playing);assert.equal(JSON.stringify(read().motion),JSON.stringify(before));near(read().result.torque,0);advanceSeconds(1);near(read().motion.omega,before.omega);near(read().motion.theta,before.theta+before.omega);
 assert($('explanation-title').textContent.includes('vitesse nulle'));assert(!read().result.equilibrium);
 $('restart').click();assert(!read().playing);near(read().motion.theta,0);near(read().motion.omega,0);near(read().motion.t,0);near(read().parameters.F2,10);
 selectExample('clockwise');$('speed').value='.25';$('speed').fire('change');control('play');advanceSeconds(1);near(read().motion.t,.25);
 document.hidden=true;events.visibilitychange();advanceSeconds(5);near(read().motion.t,.25);document.hidden=false;events.visibilitychange();tick(30000);near(read().motion.t,.25);tick(1000/60);near(read().motion.t,.25+.25/60);
 control('pause');$('speed').value='1';$('speed').fire('change');
 // Geometry/label checks use real MathJax metrics, not browser screenshots.
 for(const viewport of [280,700])for(const font of [16,24,32])for(const distance of [.2,1.8]){
  width=viewport;fontPixels=font;configure({preset:'counterclockwise',parameters:{d1:distance,d2:distance,F1:20,F2:0}});
  control('play');
  for(let i=0;i<150;i++){tick(1000/30);inspectLabels();}
  control('pause');
  const stationary=JSON.stringify(read().motion);$('arms').checked=false;$('arms').fire('change');assert.equal(JSON.stringify(read().motion),stationary);assert($('scene-labels').children.filter(e=>/^d/.test(e.dataset.labelKey)).every(e=>e.hidden));$('arms').checked=true;$('arms').fire('change');
 }
 configure({preset:'clockwise'});control('play');advanceSeconds(.2);const original=JSON.stringify(read());
 for(const bad of [null,[],{}, {unknown:1},{preset:'bad'},{preset:'balanced',parameters:{F1:-1}},{parameters:{F1:NaN}},{parameters:{fake:1}},{parameters:null},{parameters:[]}]){
  assert.throws(()=>configure(bad));assert.equal(JSON.stringify(read()),original);
 }
 for(const bad of [null,{}, {action:'bad'},{action:'restart',extra:1}]){assert.throws(()=>tools.get('control_static_rotation').execute(bad));assert.equal(JSON.stringify(read()),original);}
 assert.throws(()=>tools.get('read_static_equilibrium').execute({foo:1}));
 events.pagehide();assert.equal(tools.size,0);assert.equal(frames.size,0);assert.deepEqual(errors,[]);
 document.modelContext=undefined;vm.runInNewContext(source,{...context});await new Promise(r=>setImmediate(r));assert($('loading').hidden);assert.deepEqual(errors,[]);events.pagehide();
 document.modelContext={registerTool(){throw new Error('unsupported');}};vm.runInNewContext(source,{...context});await new Promise(r=>setImmediate(r));assert($('loading').hidden);assert.equal(errors.length,3);events.pagehide();
 console.log('Interface : lecture/pause, réglages en direct, reprise, chiffres et géométrie vérifiés'+(convertTex?' avec MathJax réel.':'.'));
}
main().catch(error=>{console.error(error);process.exit(1);});
