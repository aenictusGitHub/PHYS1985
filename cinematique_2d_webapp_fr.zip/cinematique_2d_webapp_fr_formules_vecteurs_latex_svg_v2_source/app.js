(() => {
  'use strict';

  const COLORS = Object.freeze({
    position: '#d9683b',
    velocity: '#2775b6',
    acceleration: '#7758a6',
    tangential: '#b5688b',
    centripetal: '#268576',
    jerk: '#987125',
    trail: [137, 147, 157],
    projection: [217, 104, 59],
  });

  // Rescale the former 500 m squares to physical 1 m squares.
  const LENGTH_SCALE = 500;
  const BALLISTIC_TIME_SCALE = 1 / Math.sqrt(LENGTH_SCALE);
  const GRID_STEP_METRES = 1;

  const PARAMETERS = Object.freeze({
    R: 2,
    x0: 4,
    y0: 4,
    omega: 0.5,
    alpha: 0.02,
    theta0Deg: 0,
    v0: Math.sqrt(80),
    launchAngleDeg: 60,
    g: 9.81,
  });

  const DEFAULT_VIEW = Object.freeze({ xmin: 0, xmax: 8, ymin: 0, ymax: 8 });
  const CLOSED_PERIOD = 2 * Math.PI / PARAMETERS.omega;
  const MCUA_TURN_DURATION = (Math.sqrt(PARAMETERS.omega ** 2 + 4 * Math.PI * PARAMETERS.alpha) - PARAMETERS.omega) / PARAMETERS.alpha;
  const MCUA_DURATION = 2 * MCUA_TURN_DURATION;
  const BALLISTIC_DURATION = 2 * PARAMETERS.v0 * Math.sin(PARAMETERS.launchAngleDeg * Math.PI / 180) / PARAMETERS.g;
  const AXIS_TICK_STEP = GRID_STEP_METRES;

  const ARROW = Object.freeze({
    shaftWidthPx: 3.2,
    headLengthPx: 18,
    headHalfWidthPx: 7,
    minimumLengthPx: 3,
  });

  const V = (x = 0, y = 0) => ({ x, y });
  const add = (a, b) => V(a.x + b.x, a.y + b.y);
  const sub = (a, b) => V(a.x - b.x, a.y - b.y);
  const scale = (a, s) => V(a.x * s, a.y * s);
  const dot = (a, b) => a.x * b.x + a.y * b.y;
  const norm = (a) => Math.hypot(a.x, a.y);
  const normalize = (a) => {
    const n = norm(a);
    return n > 1e-14 ? scale(a, 1 / n) : V(0, 0);
  };
  const deg2rad = (angle) => angle * Math.PI / 180;
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const wrap = (value, period) => ((value % period) + period) % period;

  const TRAJECTORIES = Object.freeze({
    lissajous2: {
      label: 'Lissajous (𝑛=2)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.50,
      scaleA: 0.50,
      equations: [
        String.raw`x(t)=x_0+R\cos\!\bigl(\omega t+\theta_0\bigr)`,
        String.raw`y(t)=y_0+R\sin(2\omega t)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}},\qquad \theta_0=0`,
        String.raw`T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, R, omega, theta0Deg } = PARAMETERS;
        return V(
          x0 + R * Math.cos(omega * t + deg2rad(theta0Deg)),
          y0 + R * Math.sin(2 * omega * t),
        );
      },
    },

    lissajous3: {
      label: 'Lissajous (𝑛=3)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.40,
      scaleA: 0.50,
      equations: [
        String.raw`x(t)=x_0+R\cos\!\bigl(\omega t+\theta_0\bigr)`,
        String.raw`y(t)=y_0+R\sin(3\omega t)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}},\qquad \theta_0=0`,
        String.raw`n=3,\qquad T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, R, omega, theta0Deg } = PARAMETERS;
        return V(
          x0 + R * Math.cos(omega * t + deg2rad(theta0Deg)),
          y0 + R * Math.sin(3 * omega * t),
        );
      },
    },

    mcua: {
      label: 'Mouvement circulaire uniformément accéléré',
      duration: MCUA_DURATION,
      closed: false,
      scaleV: 0.50,
      scaleA: 0.50,
      equations: [
        String.raw`\varphi(t)=\frac{1}{2}\alpha t^2+\omega_0t+\theta_0`,
        String.raw`x(t)=x_0+R\cos\!\bigl(\varphi(t)\bigr)`,
        String.raw`y(t)=y_0+R\sin\!\bigl(\varphi(t)\bigr)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2\,\mathrm m`,
        String.raw`\omega_0=0.5\,\mathrm{rad\,s^{-1}},\qquad \alpha=0.02\,\mathrm{rad\,s^{-2}}`,
        String.raw`\theta_0=0,\qquad \omega(t)=\omega_0+\alpha t`,
        String.raw`T_{\mathrm{tour}}\simeq 10.40\,\mathrm s,\qquad t_{\max}=2T_{\mathrm{tour}}\simeq 20.80\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, R, omega, alpha, theta0Deg } = PARAMETERS;
        const phi = 0.5 * alpha * t * t + omega * t + deg2rad(theta0Deg);
        return V(x0 + R * Math.cos(phi), y0 + R * Math.sin(phi));
      },
    },

    fish: {
      label: 'Courbe poisson',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.50,
      scaleA: 0.65,
      equations: [
        String.raw`x(t)=x_0+R\left[\cos(\omega t)-\frac{\sin^2(\omega t)}{\sqrt2}\right]`,
        String.raw`y(t)=y_0+R\cos(\omega t)\sin(\omega t)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, R, omega } = PARAMETERS;
        const q = omega * t;
        const s = Math.sin(q);
        const c = Math.cos(q);
        return V(x0 + R * (c - s * s / Math.sqrt(2)), y0 + R * c * s);
      },
    },

    astroid: {
      label: 'Astroïde',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.50,
      scaleA: 0.50,
      equations: [
        String.raw`x(t)=x_0+R\cos^3(\omega t)`,
        String.raw`y(t)=y_0+R\sin^3(\omega t)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, R, omega } = PARAMETERS;
        const q = omega * t;
        return V(x0 + R * Math.cos(q) ** 3, y0 + R * Math.sin(q) ** 3);
      },
    },

    quadrifolium: {
      label: 'Quadrifolium',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.35,
      scaleA: 0.35,
      equations: [
        String.raw`x(t)=x_0+R\cos(2\omega t)\cos(\omega t)`,
        String.raw`y(t)=y_0+R\cos(2\omega t)\sin(\omega t)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, R, omega } = PARAMETERS;
        const q = omega * t;
        return V(
          x0 + R * Math.cos(2 * q) * Math.cos(q),
          y0 + R * Math.cos(2 * q) * Math.sin(q),
        );
      },
    },

    ballistic: {
      label: 'Mouvement balistique',
      duration: BALLISTIC_DURATION,
      closed: false,
      scaleV: 3 * BALLISTIC_TIME_SCALE,
      scaleA: 25 / LENGTH_SCALE,
      jerk() { return V(0, 0); },
      equations: [
        String.raw`x(t)=x_0+v_0\cos(\theta_0)\,t`,
        String.raw`y(t)=y_0+v_0\sin(\theta_0)\,t-\frac{1}{2}gt^2`,
      ],
      parameters: [
        String.raw`x_0=y_0=0,\qquad v_0=\sqrt{80}\simeq 8.94\,\mathrm{m\,s^{-1}}`,
        String.raw`\theta_0=60^\circ,\qquad g=9.81\,\mathrm{m\,s^{-2}}`,
        String.raw`T=\frac{2v_0\sin\theta_0}{g}\simeq 1.58\,\mathrm s`,
      ],
      position(t) {
        const { v0, launchAngleDeg, g } = PARAMETERS;
        const angle = deg2rad(launchAngleDeg);
        return V(v0 * Math.cos(angle) * t, v0 * Math.sin(angle) * t - 0.5 * g * t * t);
      },
    },

    cardioid: {
      label: 'Cardioïde',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.55,
      scaleA: 0.50,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+a\bigl(2\cos\tau-\cos2\tau\bigr)`,
        String.raw`y(t)=y_0+a\bigl(2\sin\tau-\sin2\tau\bigr)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad a=1\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, omega } = PARAMETERS;
        const a = 1;
        const q = omega * t;
        return V(x0 + a * (2 * Math.cos(q) - Math.cos(2 * q)), y0 + a * (2 * Math.sin(q) - Math.sin(2 * q)));
      },
    },

    lemniscate: {
      label: 'Lemniscate de Bernoulli',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.65,
      scaleA: 0.55,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+\frac{a\cos\tau}{1+\sin^2\tau}`,
        String.raw`y(t)=y_0+\frac{a\sin\tau\cos\tau}{1+\sin^2\tau}`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad a=2.8\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, omega } = PARAMETERS;
        const a = 2.8;
        const q = omega * t;
        const s = Math.sin(q);
        const c = Math.cos(q);
        const denominator = 1 + s * s;
        return V(x0 + a * c / denominator, y0 + a * s * c / denominator);
      },
    },

    rose5: {
      label: 'Rose à cinq pétales',
      duration: CLOSED_PERIOD / 2,
      closed: true,
      scaleV: 0.28,
      scaleA: 0.12,
      equations: [
        String.raw`\tau=\omega t,\qquad \rho(\tau)=R\cos(5\tau)`,
        String.raw`x(t)=x_0+\rho(\tau)\cos\tau`,
        String.raw`y(t)=y_0+\rho(\tau)\sin\tau`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2.8\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}},\qquad T=\frac{\pi}{\omega}=2\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, omega } = PARAMETERS;
        const R = 2.8;
        const q = omega * t;
        const rho = R * Math.cos(5 * q);
        return V(x0 + rho * Math.cos(q), y0 + rho * Math.sin(q));
      },
    },

    spiral: {
      label: 'Spirale d’Archimède',
      duration: 24,
      closed: false,
      scaleV: 0.95,
      scaleA: 0.85,
      equations: [
        String.raw`\tau=\frac{6\pi}{T}t,\qquad \rho(\tau)=\rho_0+b\tau`,
        String.raw`x(t)=x_0+\rho(\tau)\cos\tau`,
        String.raw`y(t)=y_0+\rho(\tau)\sin\tau`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad \rho_0=0.16\,\mathrm m`,
        String.raw`b=0.16\,\mathrm m,\qquad T=24\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0 } = PARAMETERS;
        const T = 24;
        const tau = 6 * Math.PI * t / T;
        const rho = 0.16 + 0.16 * tau;
        return V(x0 + rho * Math.cos(tau), y0 + rho * Math.sin(tau));
      },
    },

    cycloid: {
      label: 'Cycloïde',
      duration: 12,
      closed: false,
      scaleV: 1.25,
      scaleA: 1.0,
      equations: [
        String.raw`\tau=\frac{2\pi}{T}t`,
        String.raw`x(t)=x_\mathrm i+a\bigl(\tau-\sin\tau\bigr)`,
        String.raw`y(t)=y_\mathrm i+a\bigl(1-\cos\tau\bigr)`,
      ],
      parameters: [
        String.raw`x_\mathrm i=0.8\,\mathrm m,\qquad y_\mathrm i=1.3\,\mathrm m`,
        String.raw`a=1\,\mathrm m,\qquad T=12\,\mathrm s`,
      ],
      position(t) {
        const T = 12;
        const a = 1;
        const tau = 2 * Math.PI * t / T;
        return V(0.8 + a * (tau - Math.sin(tau)), 1.3 + a * (1 - Math.cos(tau)));
      },
    },

    deltoid: {
      label: 'Deltoïde',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.55,
      scaleA: 0.38,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+a\bigl(2\cos\tau+\cos2\tau\bigr)`,
        String.raw`y(t)=y_0+a\bigl(2\sin\tau-\sin2\tau\bigr)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad a=0.86\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, omega } = PARAMETERS;
        const a = 0.86;
        const q = omega * t;
        return V(x0 + a * (2 * Math.cos(q) + Math.cos(2 * q)), y0 + a * (2 * Math.sin(q) - Math.sin(2 * q)));
      },
    },

    nephroid: {
      label: 'Néphroïde',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.45,
      scaleA: 0.30,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+a\bigl(3\cos\tau-\cos3\tau\bigr)`,
        String.raw`y(t)=y_0+a\bigl(3\sin\tau-\sin3\tau\bigr)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad a=0.7\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, omega } = PARAMETERS;
        const a = 0.7;
        const q = omega * t;
        return V(x0 + a * (3 * Math.cos(q) - Math.cos(3 * q)), y0 + a * (3 * Math.sin(q) - Math.sin(3 * q)));
      },
    },

    hypotrochoid: {
      label: 'Hypotrochoïde',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.42,
      scaleA: 0.24,
      equations: [
        String.raw`\tau=\omega t,\qquad k=\frac{R-r}{r}`, 
        String.raw`x(t)=x_0+(R-r)\cos\tau+d\cos(k\tau)`,
        String.raw`y(t)=y_0+(R-r)\sin\tau-d\sin(k\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2.4\,\mathrm m`,
        String.raw`r=0.8\,\mathrm m,\qquad d=1.3\,\mathrm m,\qquad k=2`,
      ],
      position(t) {
        const { x0, y0, omega } = PARAMETERS;
        const R = 2.4;
        const r = 0.8;
        const d = 1.3;
        const q = omega * t;
        const k = (R - r) / r;
        return V(x0 + (R - r) * Math.cos(q) + d * Math.cos(k * q), y0 + (R - r) * Math.sin(q) - d * Math.sin(k * q));
      },
    },

    heart: {
      label: 'Cœur',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.32,
      scaleA: 0.16,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+16a\sin^3\tau`,
        String.raw`y(t)=y_0+a\bigl(13\cos\tau-5\cos2\tau-2\cos3\tau-\cos4\tau\bigr)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad a=0.13\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, omega } = PARAMETERS;
        const a = 0.13;
        const q = omega * t;
        return V(
          x0 + 16 * a * Math.sin(q) ** 3,
          y0 + a * (13 * Math.cos(q) - 5 * Math.cos(2 * q) - 2 * Math.cos(3 * q) - Math.cos(4 * q)),
        );
      },
    },

    butterfly: {
      label: 'Papillon',
      duration: 24,
      closed: true,
      scaleV: 0.72,
      scaleA: 0.32,
      equations: [
        String.raw`\tau=\frac{12\pi}{T}t`,
        String.raw`f(\tau)=e^{\cos\tau}-2\cos4\tau-\sin^5\!\left(\frac{\tau}{12}\right)`,
        String.raw`x(t)=x_0+A\sin\tau\,f(\tau)`,
        String.raw`y(t)=y_0+A\cos\tau\,f(\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad A=0.6\,\mathrm m`,
        String.raw`T=24\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0 } = PARAMETERS;
        const T = 24;
        const A = 0.6;
        const tau = 12 * Math.PI * t / T;
        const f = Math.exp(Math.cos(tau)) - 2 * Math.cos(4 * tau) - Math.sin(tau / 12) ** 5;
        return V(x0 + A * Math.sin(tau) * f, y0 + A * Math.cos(tau) * f);
      },
    },
  });

  // Differentiate the smooth position law, not the playback wrap/clamp.
  // A symmetric seven-point stencil gives fourth-order accuracy without
  // differentiating the noise in the displayed acceleration.
  function jerkAt(item, t) {
    if (item.jerk) return item.jerk(t);
    const h = 0.004;
    const pm1 = item.position(t - h);
    const pp1 = item.position(t + h);
    const pm2 = item.position(t - 2 * h);
    const pp2 = item.position(t + 2 * h);
    const pm3 = item.position(t - 3 * h);
    const pp3 = item.position(t + 3 * h);
    const numerator = add(
      add(scale(sub(pm1, pp1), 13), scale(sub(pp2, pm2), 8)),
      sub(pm3, pp3),
    );
    const result = scale(numerator, 1 / (8 * h ** 3));
    for (const axis of Object.keys(result)) {
      if (Math.abs(result[axis]) < 1e-4 / LENGTH_SCALE) result[axis] = 0;
    }
    return result;
  }

  const jerkScales = new WeakMap();
  function jerkDisplayScale(item) {
    if (!jerkScales.has(item)) {
      let maximum = 0;
      for (let i = 0; i <= 384; i += 1) {
        maximum = Math.max(maximum, norm(jerkAt(item, item.duration * i / 384)));
      }
      // Fixed for each trajectory: arrow length still follows |j(t)|.
      jerkScales.set(item, maximum > 1e-4 / LENGTH_SCALE ? 0.65 * PARAMETERS.R / maximum : 1);
    }
    return jerkScales.get(item);
  }

  // Physical geometry only: independent of camera and vector display scales.
  function osculatingGeometry(data) {
    const speed = norm(data.velocity);
    if (!Number.isFinite(speed) || speed <= 1e-2 / LENGTH_SCALE) {
      return { defined: false, reason: 'stationary' };
    }
    const tangent = scale(data.velocity, 1 / speed);
    const normalAcceleration = sub(data.acceleration, scale(tangent, dot(data.acceleration, tangent)));
    const normalMagnitude = norm(normalAcceleration);
    // Suppress finite-difference roundoff at straight segments and inflections.
    const tolerance = Math.max(1e-5 / LENGTH_SCALE, norm(data.acceleration) * 1e-7);
    if (!Number.isFinite(normalMagnitude) || normalMagnitude <= tolerance) {
      return { defined: false, reason: 'straight' };
    }
    const normal = scale(normalAcceleration, 1 / normalMagnitude);
    const radius = speed * speed / normalMagnitude;
    const center = add(data.position, scale(normal, radius));
    if (!Number.isFinite(radius) || !Object.values(center).every(Number.isFinite)) {
      return { defined: false, reason: 'unresolved' };
    }
    return { defined: true, radius, center, tangent, normal, position: data.position };
  }

  function osculatingPoint(circle, angle) {
    // Anchored at the mobile: avoids center - radius cancellation for large radii.
    return add(circle.position, add(
      scale(circle.tangent, circle.radius * Math.sin(angle)),
      scale(circle.normal, 2 * circle.radius * Math.sin(angle / 2) ** 2),
    ));
  }

  function clipScreenSegment(a, b, bounds) {
    if (![a?.x, a?.y, b?.x, b?.y].every(Number.isFinite)) return null;
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    let first = 0;
    let last = 1;
    const edges = [
      [-dx, a.x - bounds.left], [dx, bounds.right - a.x],
      [-dy, a.y - bounds.top], [dy, bounds.bottom - a.y],
    ];
    for (const [p, q] of edges) {
      if (p === 0) {
        if (q < 0) return null;
      } else {
        const t = q / p;
        if (p < 0) first = Math.max(first, t);
        else last = Math.min(last, t);
        if (first > last) return null;
      }
    }
    return [
      { x: a.x + first * dx, y: a.y + first * dy },
      { x: a.x + last * dx, y: a.y + last * dy },
    ];
  }

  const viewport = document.getElementById('viewport');
  const canvas = document.getElementById('scene-canvas');
  const ctx = canvas.getContext('2d', { alpha: true });
  const loadingMessage = document.getElementById('loading-message');

  const dom = {
    trajectory: document.getElementById('trajectory-select'),
    equations: document.getElementById('trajectory-equations'),
    play: document.getElementById('play-button'),
    reset: document.getElementById('reset-button'),
    resetView: document.getElementById('reset-view'),
    speed: document.getElementById('speed-select'),
    timeSlider: document.getElementById('time-slider'),
    timeOutputDigits: document.getElementById('time-output-digits'),
    timeBadgeDigits: document.getElementById('time-badge-digits'),
    loop: document.getElementById('loop-toggle'),
    vectorScale: document.getElementById('vector-scale'),
    vectorScaleOutputDigits: document.getElementById('vector-scale-output-digits'),
    trailDuration: document.getElementById('trail-duration'),
    trailDurationOutputDigits: document.getElementById('trail-duration-output-digits'),
    fullTrail: document.getElementById('full-trail'),
    projections: document.getElementById('projection-toggle'),
    osculating: document.getElementById('osculating-toggle'),
    curvatureDetails: document.getElementById('curvature-details'),
    curvatureValue: document.getElementById('curvature-value'),
    curvatureDigits: document.getElementById('curvature-digits'),
    curvatureScientific: document.getElementById('curvature-scientific'),
    curvatureExponent: document.getElementById('curvature-exponent'),
    curvatureStatus: document.getElementById('curvature-status'),
    radiusLabel: document.getElementById('radius-label'),
    grid: document.getElementById('grid-toggle'),
    warning: document.getElementById('warning-badge'),
    clearVectors: document.getElementById('clear-vectors'),
    vectorReadouts: document.getElementById('vector-readouts'),
    axisLabels: {
      x: document.getElementById('axis-label-x'),
      y: document.getElementById('axis-label-y'),
    },
    axisTickLayers: {
      x: document.getElementById('axis-ticks-x'),
      y: document.getElementById('axis-ticks-y'),
    },
    toggles: {
      position: document.getElementById('toggle-position'),
      velocity: document.getElementById('toggle-velocity'),
      acceleration: document.getElementById('toggle-acceleration'),
      tangential: document.getElementById('toggle-tangential'),
      centripetal: document.getElementById('toggle-centripetal'),
      jerk: document.getElementById('toggle-jerk'),
    },
  };

  const VECTOR_META = Object.freeze({
    position: {
      symbolTeX: String.raw`\vec r`,
      unitTeX: String.raw`\mathrm m`,
      plainName: 'position',
      color: COLORS.position,
    },
    velocity: {
      symbolTeX: String.raw`\vec v`,
      unitTeX: String.raw`\mathrm{m\,s^{-1}}`,
      plainName: 'vitesse',
      color: COLORS.velocity,
    },
    acceleration: {
      symbolTeX: String.raw`\vec a`,
      unitTeX: String.raw`\mathrm{m\,s^{-2}}`,
      plainName: 'accélération',
      color: COLORS.acceleration,
    },
    tangential: {
      symbolTeX: String.raw`\vec a_{\mathrm t}`,
      unitTeX: String.raw`\mathrm{m\,s^{-2}}`,
      plainName: 'accélération tangentielle',
      color: COLORS.tangential,
    },
    centripetal: {
      symbolTeX: String.raw`\vec a_{\mathrm c}`,
      unitTeX: String.raw`\mathrm{m\,s^{-2}}`,
      plainName: 'accélération centripète',
      color: COLORS.centripetal,
    },
    jerk: {
      symbolTeX: String.raw`\vec{\jmath}`,
      unitTeX: String.raw`\mathrm{m\,s^{-3}}`,
      plainName: 'à-coup',
      color: COLORS.jerk,
    },
  });

  const readoutElements = {};
  for (const [key, meta] of Object.entries(VECTOR_META)) {
    const element = document.createElement('div');
    element.className = 'vector-readout';
    element.style.setProperty('--readout-color', meta.color);
    element.innerHTML = `
      <div class="vector-readout-line vector-readout-magnitude">
        <span class="tex-math">\\(\\lvert${meta.symbolTeX}\\rvert=\\)</span>
        <span class="math-digits magnitude-digits">0.00</span>
        <span class="tex-math">\\(\\,${meta.unitTeX}\\)</span>
      </div>
      <div class="vector-readout-line vector-readout-components">
        <span class="tex-math">\\(${meta.symbolTeX}=(\\)</span>
        <span class="math-digits component-x-digits">0.0</span>
        <span class="tex-math">\\(,\\,\\)</span>
        <span class="math-digits component-y-digits">0.0</span>
        <span class="tex-math">\\()\\)</span>
      </div>`;
    dom.vectorReadouts.append(element);
    readoutElements[key] = {
      root: element,
      meta,
      magnitude: element.querySelector('.magnitude-digits'),
      componentX: element.querySelector('.component-x-digits'),
      componentY: element.querySelector('.component-y-digits'),
    };
  }

  const state = {
    trajectoryKey: 'lissajous2',
    time: 0,
    playing: true,
    playbackSpeed: 1,
    loop: true,
    vectorScale: 1,
    trailDuration: 10,
    fullTrail: true,
    projections: true,
    grid: true,
  };

  const view = { ...DEFAULT_VIEW };
  let viewportWidth = 1;
  let viewportHeight = 1;
  let devicePixelRatio = 1;
  let plotRect = { left: 80, top: 40, width: 400, height: 400, right: 480, bottom: 440 };
  let dragging = false;
  let dragX = 0;
  let dragY = 0;

  let mathIsReady = false;
  let mathTypesetQueue = Promise.resolve();
  const mathGlyphTemplates = new Map();
  const axisTickElements = { x: new Map(), y: new Map() };

  const currentTrajectory = () => TRAJECTORIES[state.trajectoryKey];
  const trajectoryTimeMax = (item) => item.closed ? 2 * item.duration : item.duration;
  const axisTickValues = (minimum, maximum) => {
    // Keep every grid square at 1 m; only thin the numbers when space is tight.
    const pixelsPerMetre = plotRect.width / (view.xmax - view.xmin);
    const step = AXIS_TICK_STEP * Math.max(1, Math.ceil(38 / pixelsPerMetre));
    const first = Math.ceil((minimum - 1e-9) / step) * step;
    const values = [];
    for (let value = first; value <= maximum + 1e-9; value += step) {
      values.push(Math.abs(value) < 1e-9 ? 0 : value);
    }
    return values;
  };
  const vectorSelection = () => Object.fromEntries(
    Object.entries(dom.toggles).map(([key, input]) => [key, input.checked]),
  );

  function queueTypeset(elements) {
    if (!mathIsReady || !window.MathJax?.typesetPromise) return Promise.resolve();
    mathTypesetQueue = mathTypesetQueue
      .then(() => window.MathJax.typesetPromise(elements))
      .catch((error) => console.error('Échec de la composition MathJax :', error));
    return mathTypesetQueue;
  }

  async function initializeMathGlyphs() {
    const characters = '0123456789.-+';
    for (const character of characters) {
      const tex = character === '-' ? '{-}' : character === '+' ? '{+}' : character;
      const rendered = await window.MathJax.tex2svgPromise(tex, { display: false });
      rendered.setAttribute('aria-hidden', 'true');
      mathGlyphTemplates.set(character, rendered);
    }
  }

  function setMathDigits(element, text) {
    if (!element) return;
    const value = String(text);
    if (!mathIsReady || mathGlyphTemplates.size === 0) {
      element.textContent = value;
      element.dataset.value = value;
      return;
    }
    if (element.dataset.value === value && element.classList.contains('typeset')) return;

    const fragment = document.createDocumentFragment();
    for (const character of value) {
      const wrapper = document.createElement('span');
      wrapper.className = 'math-glyph';
      wrapper.setAttribute('aria-hidden', 'true');
      const template = mathGlyphTemplates.get(character);
      if (template) wrapper.append(template.cloneNode(true));
      else wrapper.textContent = character;
      fragment.append(wrapper);
    }
    element.replaceChildren(fragment);
    element.classList.add('typeset');
    element.dataset.value = value;
  }

  function synchronizeAxisTickElements(axis, ticks) {
    const elements = axisTickElements[axis];
    const visible = new Set(ticks);

    for (const [tick, record] of elements) {
      if (!visible.has(tick)) {
        record.root.remove();
        elements.delete(tick);
      }
    }

    for (const tick of ticks) {
      if (elements.has(tick)) continue;
      const root = document.createElement('div');
      root.className = 'axis-math-label axis-tick-label';
      root.setAttribute('aria-hidden', 'true');
      const digits = document.createElement('span');
      digits.className = 'math-digits';
      root.append(digits);
      dom.axisTickLayers[axis].append(root);
      setMathDigits(digits, String(tick));
      elements.set(tick, { root, digits });
    }
  }

  function updateDynamicMathOutputs() {
    setMathDigits(dom.timeOutputDigits, state.time.toFixed(2));
    setMathDigits(dom.timeBadgeDigits, state.time.toFixed(2));
    setMathDigits(dom.vectorScaleOutputDigits, state.vectorScale.toFixed(2));
    setMathDigits(dom.trailDurationOutputDigits, state.trailDuration.toFixed(1));
  }

  function resetView() {
    Object.assign(view, DEFAULT_VIEW);
  }

  function computePlotRect() {
    const margins = { left: 112, right: 54, top: 42, bottom: 90 };
    const availableWidth = Math.max(120, viewportWidth - margins.left - margins.right);
    const availableHeight = Math.max(120, viewportHeight - margins.top - margins.bottom);
    const viewAspect = (view.xmax - view.xmin) / (view.ymax - view.ymin);

    let width = availableWidth;
    let height = width / viewAspect;
    if (height > availableHeight) {
      height = availableHeight;
      width = height * viewAspect;
    }

    const left = margins.left + 0.5 * (availableWidth - width);
    const top = margins.top + 0.5 * (availableHeight - height);
    plotRect = { left, top, width, height, right: left + width, bottom: top + height };
  }

  function worldToScreen(point) {
    const x = plotRect.left + (point.x - view.xmin) * plotRect.width / (view.xmax - view.xmin);
    const y = plotRect.bottom - (point.y - view.ymin) * plotRect.height / (view.ymax - view.ymin);
    return V(x, y);
  }

  function screenToWorld(point) {
    const x = view.xmin + (point.x - plotRect.left) * (view.xmax - view.xmin) / plotRect.width;
    const y = view.ymin + (plotRect.bottom - point.y) * (view.ymax - view.ymin) / plotRect.height;
    return V(x, y);
  }

  function resizeCanvas() {
    const rect = viewport.getBoundingClientRect();
    viewportWidth = Math.max(1, rect.width);
    viewportHeight = Math.max(1, rect.height);
    devicePixelRatio = Math.min(2.5, Math.max(1, window.devicePixelRatio || 1));
    canvas.width = Math.max(1, Math.round(viewportWidth * devicePixelRatio));
    canvas.height = Math.max(1, Math.round(viewportHeight * devicePixelRatio));
    canvas.style.width = `${viewportWidth}px`;
    canvas.style.height = `${viewportHeight}px`;
    ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
    computePlotRect();
    updateAxisLabelPositions();
    updateAndDraw();
  }

  function positionAt(item, time) {
    if (item.closed) return item.position(wrap(time, item.duration));
    return item.position(clamp(time, 0, item.duration));
  }

  function derivatives(item, time) {
    const t = item.closed ? time : clamp(time, 0, item.duration);
    const h = Math.max(1e-3, Math.min(0.01, item.duration / 3000));
    const p = positionAt(item, t);
    let velocity;
    let acceleration;

    if (item.closed) {
      const pm = positionAt(item, t - h);
      const pp = positionAt(item, t + h);
      velocity = scale(sub(pp, pm), 1 / (2 * h));
      acceleration = scale(add(sub(pp, scale(p, 2)), pm), 1 / (h * h));
    } else if (t <= h) {
      const p1 = positionAt(item, t + h);
      const p2 = positionAt(item, t + 2 * h);
      velocity = scale(add(add(scale(p, -3), scale(p1, 4)), scale(p2, -1)), 1 / (2 * h));
      acceleration = scale(add(add(p, scale(p1, -2)), p2), 1 / (h * h));
    } else if (t >= item.duration - h) {
      const p1 = positionAt(item, t - h);
      const p2 = positionAt(item, t - 2 * h);
      velocity = scale(add(add(scale(p, 3), scale(p1, -4)), p2), 1 / (2 * h));
      acceleration = scale(add(add(p, scale(p1, -2)), p2), 1 / (h * h));
    } else {
      const pm = positionAt(item, t - h);
      const pp = positionAt(item, t + h);
      velocity = scale(sub(pp, pm), 1 / (2 * h));
      acceleration = scale(add(sub(pp, scale(p, 2)), pm), 1 / (h * h));
    }

    const speed = norm(velocity);
    const decompositionDefined = speed > 1e-2 / LENGTH_SCALE;
    let tangential = V(0, 0);
    let centripetal = V(0, 0);
    if (decompositionDefined) {
      const tangentUnit = scale(velocity, 1 / speed);
      tangential = scale(tangentUnit, dot(acceleration, tangentUnit));
      centripetal = sub(acceleration, tangential);
    }

    const jerk = jerkAt(item, item.closed ? wrap(t, item.duration) : t);
    return { position: p, velocity, acceleration, jerk, tangential, centripetal, speed, decompositionDefined };
  }

  function clipToPlot(callback) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(plotRect.left, plotRect.top, plotRect.width, plotRect.height);
    ctx.clip();
    callback();
    ctx.restore();
  }

  function drawLineScreen(a, b, color, width = 1, alpha = 1, dash = []) {
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = 'round';
    ctx.setLineDash(dash);
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
    ctx.restore();
  }

  function drawAxes() {
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,0.88)';
    ctx.fillRect(plotRect.left, plotRect.top, plotRect.width, plotRect.height);
    ctx.restore();

    clipToPlot(() => {
      if (state.grid) {
        const step = GRID_STEP_METRES;
        const xStart = Math.ceil(view.xmin / step) * step;
        const yStart = Math.ceil(view.ymin / step) * step;
        ctx.save();
        ctx.lineWidth = 1;
        ctx.strokeStyle = 'rgba(148,168,186,0.20)';
        for (let x = xStart; x <= view.xmax + 1e-9; x += step) {
          const s = worldToScreen(V(x, 0));
          ctx.beginPath();
          ctx.moveTo(s.x, plotRect.top);
          ctx.lineTo(s.x, plotRect.bottom);
          ctx.stroke();
        }
        for (let y = yStart; y <= view.ymax + 1e-9; y += step) {
          const s = worldToScreen(V(0, y));
          ctx.beginPath();
          ctx.moveTo(plotRect.left, s.y);
          ctx.lineTo(plotRect.right, s.y);
          ctx.stroke();
        }
        ctx.restore();
      }

      if (view.xmin <= 0 && view.xmax >= 0) {
        const x0 = worldToScreen(V(0, 0)).x;
        drawLineScreen(V(x0, plotRect.top), V(x0, plotRect.bottom), '#8190a5', 1.7, 0.85);
      }
      if (view.ymin <= 0 && view.ymax >= 0) {
        const y0 = worldToScreen(V(0, 0)).y;
        drawLineScreen(V(plotRect.left, y0), V(plotRect.right, y0), '#8190a5', 1.7, 0.85);
      }
    });

    ctx.save();
    ctx.strokeStyle = '#bbcbd9';
    ctx.lineWidth = 1;
    ctx.strokeRect(plotRect.left, plotRect.top, plotRect.width, plotRect.height);
    ctx.restore();

    const xTickValues = axisTickValues(view.xmin, view.xmax);
    const yTickValues = axisTickValues(view.ymin, view.ymax);
    ctx.save();
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 1.2;
    for (const tick of xTickValues) {
      const s = worldToScreen(V(tick, view.ymin));
      ctx.beginPath();
      ctx.moveTo(s.x, plotRect.bottom);
      ctx.lineTo(s.x, plotRect.bottom + 7);
      ctx.stroke();
    }
    for (const tick of yTickValues) {
      const s = worldToScreen(V(view.xmin, tick));
      ctx.beginPath();
      ctx.moveTo(plotRect.left - 7, s.y);
      ctx.lineTo(plotRect.left, s.y);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawTrail(item) {
    if (state.time <= 0) return;
    const startTime = state.fullTrail ? 0 : Math.max(0, state.time - state.trailDuration);
    const timeSpan = Math.max(0, state.time - startTime);
    const segments = clamp(Math.ceil(timeSpan * 30), 2, 500);
    const [r, g, b] = COLORS.trail;

    clipToPlot(() => {
      let previous = worldToScreen(positionAt(item, startTime));
      for (let index = 1; index <= segments; index += 1) {
        const u = index / segments;
        const time = startTime + timeSpan * u;
        const current = worldToScreen(positionAt(item, time));
        const alpha = state.fullTrail ? 1 : 0.025 + 0.86 * u ** 1.65;
        drawLineScreen(previous, current, `rgb(${r},${g},${b})`, 2.7, alpha);
        previous = current;
      }
    });
  }

  function drawProjectionSystem(position) {
    if (!state.projections) return;
    const p = worldToScreen(position);
    const px = worldToScreen(V(position.x, 0));
    const py = worldToScreen(V(0, position.y));

    clipToPlot(() => {
      drawLineScreen(p, px, COLORS.position, 1.15, 0.38, [6, 6]);
      drawLineScreen(p, py, COLORS.position, 1.15, 0.38, [6, 6]);

      for (const point of [px, py]) {
        ctx.save();
        ctx.fillStyle = 'rgba(217,104,59,0.68)';
        ctx.strokeStyle = 'rgba(255,255,255,0.92)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(point.x, point.y, 4.8, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      }
    });
  }

  function drawArrow(startWorld, vectorWorld, lengthScale, color) {
    const start = worldToScreen(startWorld);
    const end = worldToScreen(add(startWorld, scale(vectorWorld, lengthScale)));
    const dx = end.x - start.x;
    const dy = end.y - start.y;
    const length = Math.hypot(dx, dy);
    if (!Number.isFinite(length) || length < ARROW.minimumLengthPx) return;

    const direction = V(dx / length, dy / length);
    const perpendicular = V(-direction.y, direction.x);
    const headLength = Math.min(ARROW.headLengthPx, length * 0.65);
    const headHalfWidth = Math.min(ARROW.headHalfWidthPx, headLength * 0.38);
    const shaftHalfWidth = Math.min(ARROW.shaftWidthPx / 2, headHalfWidth * 0.55);
    const headBase = sub(end, scale(direction, headLength));
    const neck = sub(end, scale(direction, headLength * 0.72));
    // One continuous silhouette: swept-back wings and a seamless shaft,
    // without a white outline crossing their junction.
    const outline = [
      add(start, scale(perpendicular, shaftHalfWidth)),
      add(neck, scale(perpendicular, shaftHalfWidth)),
      add(headBase, scale(perpendicular, headHalfWidth)),
      end,
      sub(headBase, scale(perpendicular, headHalfWidth)),
      sub(neck, scale(perpendicular, shaftHalfWidth)),
      sub(start, scale(perpendicular, shaftHalfWidth)),
    ];
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(outline[0].x, outline[0].y);
    for (const point of outline.slice(1)) ctx.lineTo(point.x, point.y);
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
    ctx.restore();
  }

  function drawDecompositionParallelogram(item, data, selected) {
    if (!data.decompositionDefined || !(selected.tangential && selected.centripetal)) return;
    const factor = item.scaleA * state.vectorScale;
    const pTangential = add(data.position, scale(data.tangential, factor));
    const pCentripetal = add(data.position, scale(data.centripetal, factor));
    const pTotal = add(data.position, scale(data.acceleration, factor));
    drawLineScreen(worldToScreen(pTangential), worldToScreen(pTotal), '#667085', 1.25, 0.72, [7, 6]);
    drawLineScreen(worldToScreen(pCentripetal), worldToScreen(pTotal), '#667085', 1.25, 0.72, [7, 6]);
  }

  function drawSelectedVectors(item, data) {
    const selected = vectorSelection();
    drawDecompositionParallelogram(item, data, selected);

    if (selected.position) drawArrow(V(0, 0), data.position, 1, COLORS.position);
    if (selected.acceleration) drawArrow(data.position, data.acceleration, item.scaleA * state.vectorScale, COLORS.acceleration);
    if (selected.centripetal && data.decompositionDefined) drawArrow(data.position, data.centripetal, item.scaleA * state.vectorScale, COLORS.centripetal);
    if (selected.tangential && data.decompositionDefined) drawArrow(data.position, data.tangential, item.scaleA * state.vectorScale, COLORS.tangential);
    if (selected.velocity) drawArrow(data.position, data.velocity, item.scaleV * state.vectorScale, COLORS.velocity);
    if (selected.jerk) drawArrow(data.position, data.jerk, jerkDisplayScale(item) * state.vectorScale, COLORS.jerk);
  }

  function drawParticle(position) {
    const point = worldToScreen(position);
    ctx.save();
    ctx.shadowColor = 'rgba(15,23,42,0.22)';
    ctx.shadowBlur = 3;
    ctx.fillStyle = COLORS.position;
    ctx.strokeStyle = 'rgba(255,255,255,0.96)';
    ctx.lineWidth = 2.7;
    ctx.beginPath();
    ctx.arc(point.x, point.y, 7.2, 0, 2 * Math.PI);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  function drawOsculatingCircle(circle) {
    if (!circle) return;
    const center = worldToScreen(circle.center);
    const radius = circle.radius * plotRect.width / (view.xmax - view.xmin);
    let last = null;
    let nodes = 0;
    const trace = (a, b, p, q, level) => {
      const sagitta = 2 * radius * Math.sin((b - a) / 4) ** 2;
      if (Math.max(p.x, q.x) + sagitta < plotRect.left || Math.min(p.x, q.x) - sagitta > plotRect.right
        || Math.max(p.y, q.y) + sagitta < plotRect.top || Math.min(p.y, q.y) - sagitta > plotRect.bottom) {
        last = null;
        return;
      }
      if (++nodes > 8192) { last = null; return; }
      if (sagitta <= 0.35) {
        const segment = clipScreenSegment(p, q, plotRect);
        if (!segment) { last = null; return; }
        const [start, end] = segment;
        if (!last || Math.hypot(start.x - last.x, start.y - last.y) > 0.01) ctx.moveTo(start.x, start.y);
        ctx.lineTo(end.x, end.y);
        last = end;
      } else if (level < 36) {
        const middle = (a + b) / 2;
        const m = worldToScreen(osculatingPoint(circle, middle));
        trace(a, middle, p, m, level + 1);
        trace(middle, b, m, q, level + 1);
      } else last = null;
    };
    clipToPlot(() => {
      ctx.save();
      ctx.strokeStyle = '#268576';
      ctx.lineWidth = 1.5;
      ctx.globalAlpha = 0.8;
      ctx.setLineDash([6, 5]);
      ctx.beginPath();
      // Tessellation anchored at the mobile also keeps very large circles
      // accurate on canvas implementations that store paths as 32-bit floats.
      for (let i = 0; i < 8; i += 1) {
        const a = i * Math.PI / 4;
        const b = (i + 1) * Math.PI / 4;
        trace(a, b, worldToScreen(osculatingPoint(circle, a)), worldToScreen(osculatingPoint(circle, b)), 0);
      }
      ctx.stroke();
      ctx.restore();
      drawRadiusAnnotation(worldToScreen(circle.position), center, plotRect);
    });
  }

  function drawScene(item, data) {
    ctx.clearRect(0, 0, viewportWidth, viewportHeight);
    drawAxes();
    drawOsculatingCircle(updateCurvatureReadout(data));
    drawTrail(item);
    drawProjectionSystem(data.position);
    drawSelectedVectors(item, data);
    drawParticle(data.position);
  }

  function updateCurvatureReadout(data) {
    dom.radiusLabel.hidden = true;
    dom.curvatureDetails.hidden = !dom.osculating.checked;
    if (!dom.osculating.checked) return null;
    const circle = osculatingGeometry(data);
    dom.curvatureValue.hidden = !circle.defined;
    dom.curvatureStatus.hidden = circle.defined;
    if (!circle.defined) {
      const messages = {
        stationary: 'Vitesse quasi nulle : le cercle osculateur et son rayon sont indéfinis.',
        straight: 'Courbure quasi nulle : le rayon tend vers l’infini ; aucun cercle fini n’est tracé.',
        unresolved: 'Le rayon de courbure ne peut pas être résolu à cet instant.',
      };
      dom.curvatureStatus.textContent = messages[circle.reason];
      return null;
    }
    const scientific = circle.radius >= 1e5 || circle.radius < 0.01;
    dom.curvatureScientific.hidden = !scientific;
    if (scientific) {
      const [mantissa, exponent] = circle.radius.toExponential(2).split('e');
      setMathDigits(dom.curvatureDigits, mantissa);
      setMathDigits(dom.curvatureExponent, String(Number(exponent)));
    } else {
      setMathDigits(dom.curvatureDigits, circle.radius.toFixed(2));
    }
    dom.curvatureValue.setAttribute('aria-label', 'Rayon de courbure : ' + circle.radius.toPrecision(5) + ' mètres');
    return circle;
  }

  function drawRadiusAnnotation(start, center, bounds) {
    const segment = clipScreenSegment(start, center, bounds);
    if (!segment) return;
    const [a, b] = segment;
    ctx.save();
    ctx.strokeStyle = '#268576';
    ctx.lineWidth = 1.6;
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
    // A small cross marks the actual center, never an artificially clipped endpoint.
    if (center.x > bounds.left + 5 && center.x < bounds.right - 5
      && center.y > bounds.top + 5 && center.y < bounds.bottom - 5) {
      ctx.beginPath();
      ctx.moveTo(center.x - 4, center.y);
      ctx.lineTo(center.x + 4, center.y);
      ctx.moveTo(center.x, center.y - 4);
      ctx.lineTo(center.x, center.y + 4);
      ctx.stroke();
    }
    ctx.restore();
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const length = Math.hypot(dx, dy);
    if (length < 36) return;
    const x = (a.x + b.x) / 2 - 14 * dy / length;
    const y = (a.y + b.y) / 2 + 14 * dx / length;
    if (x < bounds.left + 20 || x > bounds.right - 20 || y < bounds.top + 20 || y > bounds.bottom - 20) return;
    dom.radiusLabel.hidden = false;
    dom.radiusLabel.style.left = x + 'px';
    dom.radiusLabel.style.top = y + 'px';
  }

  function updateReadouts(data) {
    const vectors = {
      position: data.position,
      velocity: data.velocity,
      acceleration: data.acceleration,
      tangential: data.tangential,
      centripetal: data.centripetal,
      jerk: data.jerk,
    };
    const selected = vectorSelection();

    for (const [key, vector] of Object.entries(vectors)) {
      const elements = readoutElements[key];
      const magnitude = norm(vector).toFixed(2);
      const componentX = vector.x.toFixed(2);
      const componentY = vector.y.toFixed(2);

      elements.root.classList.toggle('visible', selected[key]);
      setMathDigits(elements.magnitude, magnitude);
      setMathDigits(elements.componentX, componentX);
      setMathDigits(elements.componentY, componentY);
      elements.root.setAttribute(
        'aria-label',
        `${elements.meta.plainName} : norme ${magnitude} ; composantes (${componentX}, ${componentY})`,
      );
    }
  }

  function updateEquationPanel() {
    const item = currentTrajectory();
    if (mathIsReady && window.MathJax?.typesetClear) window.MathJax.typesetClear([dom.equations]);
    dom.equations.innerHTML = [
      ...item.equations.map((equation) => `<div class="equation"><span class="tex-math">\\(\\displaystyle ${equation}\\)</span></div>`),
      ...item.parameters.map((parameter) => `<div class="equation parameters parameter-line"><span class="tex-math">\\(${parameter}\\)</span></div>`),
    ].join('');
    if (mathIsReady) void queueTypeset([dom.equations]);
  }

  function updateAxisLabelPositions() {
    computePlotRect();
    if (!mathIsReady) return;

    const place = (element, x, y, visible = true) => {
      element.hidden = !visible;
      if (!visible) return;
      element.style.left = `${x}px`;
      element.style.top = `${y}px`;
    };

    place(dom.axisLabels.x, plotRect.left + 0.5 * plotRect.width, plotRect.bottom + 54);
    place(dom.axisLabels.y, plotRect.left - 50, plotRect.top - 18);

    const xTicks = axisTickValues(view.xmin, view.xmax);
    const yTicks = axisTickValues(view.ymin, view.ymax);
    synchronizeAxisTickElements('x', xTicks);
    synchronizeAxisTickElements('y', yTicks);

    for (const tick of xTicks) {
      const sx = worldToScreen(V(tick, view.ymin)).x;
      place(axisTickElements.x.get(tick).root, sx, plotRect.bottom + 29);
    }
    for (const tick of yTicks) {
      const sy = worldToScreen(V(view.xmin, tick)).y;
      place(axisTickElements.y.get(tick).root, plotRect.left - 42, sy);
    }
  }

  function applyVectorPreset(name) {
    const selected = {
      position: false,
      velocity: false,
      acceleration: false,
      tangential: false,
      centripetal: false,
      jerk: false,
    };
    if (name === 'velocity') selected.velocity = true;
    if (name === 'acceleration') selected.acceleration = true;
    if (name === 'decomposition') {
      selected.acceleration = true;
      selected.tangential = true;
      selected.centripetal = true;
    }
    if (name === 'all') Object.keys(selected).forEach((key) => { selected[key] = true; });
    for (const [key, checked] of Object.entries(selected)) dom.toggles[key].checked = checked;
  }

  function setPlaying(playing) {
    state.playing = playing;
    dom.play.textContent = playing ? 'Pause' : 'Lire';
    dom.play.setAttribute('aria-label', playing ? 'Mettre l’animation en pause' : 'Lire l’animation');
  }

  function updateAndDraw() {
    if (!ctx) return;
    computePlotRect();
    const item = currentTrajectory();
    const data = derivatives(item, state.time);
    const selected = vectorSelection();

    dom.timeSlider.value = String(state.time);
    setMathDigits(dom.timeOutputDigits, state.time.toFixed(2));
    setMathDigits(dom.timeBadgeDigits, state.time.toFixed(2));
    updateReadouts(data);
    updateAxisLabelPositions();

    const decompositionRequested = selected.tangential || selected.centripetal;
    dom.warning.hidden = !(decompositionRequested && !data.decompositionDefined);
    dom.warning.textContent = 'La décomposition tangentielle / centripète est indéfinie car la vitesse instantanée est approximativement nulle.';
    drawScene(item, data);
  }

  function onTrajectoryChanged() {
    state.trajectoryKey = dom.trajectory.value;
    state.time = 0;
    const item = currentTrajectory();
    const timeMax = trajectoryTimeMax(item);
    dom.timeSlider.max = String(timeMax);
    dom.timeSlider.step = String(Math.max(0.001, timeMax / 6000));
    resetView();
    updateEquationPanel();
    updateAndDraw();
  }

  dom.trajectory.addEventListener('change', onTrajectoryChanged);
  dom.play.addEventListener('click', () => setPlaying(!state.playing));
  dom.reset.addEventListener('click', () => {
    state.time = 0;
    updateAndDraw();
  });
  dom.resetView.addEventListener('click', () => {
    resetView();
    updateAndDraw();
  });
  dom.speed.addEventListener('change', () => {
    state.playbackSpeed = Number(dom.speed.value);
  });
  dom.loop.addEventListener('change', () => {
    state.loop = dom.loop.checked;
  });
  dom.vectorScale.addEventListener('input', () => {
    state.vectorScale = Number(dom.vectorScale.value);
    setMathDigits(dom.vectorScaleOutputDigits, state.vectorScale.toFixed(2));
    updateAndDraw();
  });
  dom.trailDuration.addEventListener('input', () => {
    state.trailDuration = Number(dom.trailDuration.value);
    setMathDigits(dom.trailDurationOutputDigits, state.trailDuration.toFixed(1));
    updateAndDraw();
  });
  dom.fullTrail.addEventListener('change', () => {
    state.fullTrail = dom.fullTrail.checked;
    dom.trailDuration.disabled = state.fullTrail;
    updateAndDraw();
  });
  dom.osculating.addEventListener('change', updateAndDraw);
  dom.projections.addEventListener('change', () => {
    state.projections = dom.projections.checked;
    updateAndDraw();
  });
  dom.grid.addEventListener('change', () => {
    state.grid = dom.grid.checked;
    updateAndDraw();
  });
  dom.timeSlider.addEventListener('input', () => {
    state.time = Number(dom.timeSlider.value);
    updateAndDraw();
  });
  dom.clearVectors.addEventListener('click', () => {
    applyVectorPreset('none');
    updateAndDraw();
  });
  Object.values(dom.toggles).forEach((input) => input.addEventListener('change', updateAndDraw));
  document.querySelectorAll('[data-vector-preset]').forEach((button) => {
    button.addEventListener('click', () => {
      applyVectorPreset(button.dataset.vectorPreset);
      updateAndDraw();
    });
  });

  canvas.addEventListener('pointerdown', (event) => {
    dragging = true;
    dragX = event.clientX;
    dragY = event.clientY;
    viewport.classList.add('dragging');
    canvas.setPointerCapture(event.pointerId);
  });

  canvas.addEventListener('pointermove', (event) => {
    if (!dragging) return;
    const dx = event.clientX - dragX;
    const dy = event.clientY - dragY;
    dragX = event.clientX;
    dragY = event.clientY;

    const spanX = view.xmax - view.xmin;
    const spanY = view.ymax - view.ymin;
    const shiftX = dx * spanX / plotRect.width;
    const shiftY = dy * spanY / plotRect.height;
    view.xmin -= shiftX;
    view.xmax -= shiftX;
    view.ymin += shiftY;
    view.ymax += shiftY;
    updateAndDraw();
  });

  const stopDragging = (event) => {
    if (!dragging) return;
    dragging = false;
    viewport.classList.remove('dragging');
    if (event?.pointerId !== undefined && canvas.hasPointerCapture(event.pointerId)) canvas.releasePointerCapture(event.pointerId);
  };
  canvas.addEventListener('pointerup', stopDragging);
  canvas.addEventListener('pointercancel', stopDragging);
  canvas.addEventListener('lostpointercapture', stopDragging);

  canvas.addEventListener('wheel', (event) => {
    event.preventDefault();
    const rect = canvas.getBoundingClientRect();
    const cursor = V(event.clientX - rect.left, event.clientY - rect.top);
    const anchor = screenToWorld(cursor);
    const currentSpan = view.xmax - view.xmin;
    const factor = Math.exp(event.deltaY * 0.0012);
    const newSpan = clamp(currentSpan * factor, 1, 18);
    const xFraction = (cursor.x - plotRect.left) / plotRect.width;
    const yFraction = (plotRect.bottom - cursor.y) / plotRect.height;

    view.xmin = anchor.x - xFraction * newSpan;
    view.xmax = view.xmin + newSpan;
    view.ymin = anchor.y - yFraction * newSpan;
    view.ymax = view.ymin + newSpan;
    updateAndDraw();
  }, { passive: false });

  document.addEventListener('keydown', (event) => {
    const tag = document.activeElement?.tagName?.toLowerCase();
    if (tag === 'input' || tag === 'select' || tag === 'button') return;
    if (event.code === 'Space') {
      event.preventDefault();
      setPlaying(!state.playing);
    }
    if (event.key.toLowerCase() === 'r') {
      state.time = 0;
      updateAndDraw();
    }
  });

  const resizeObserver = new ResizeObserver(resizeCanvas);
  resizeObserver.observe(viewport);
  window.addEventListener('resize', resizeCanvas);

  let previousTimestamp = performance.now();
  function animate(timestamp) {
    const elapsed = Math.min(0.1, Math.max(0, (timestamp - previousTimestamp) / 1000));
    previousTimestamp = timestamp;
    if (state.playing) {
      const timeMax = trajectoryTimeMax(currentTrajectory());
      state.time += elapsed * state.playbackSpeed;
      if (state.time > timeMax) {
        if (state.loop) state.time %= timeMax;
        else {
          state.time = timeMax;
          setPlaying(false);
        }
      }
    }
    updateAndDraw();
    requestAnimationFrame(animate);
  }

  async function initializeApplication() {
    dom.trajectory.value = state.trajectoryKey;
    dom.fullTrail.checked = state.fullTrail;
    dom.trailDuration.disabled = state.fullTrail;
    dom.timeSlider.max = String(trajectoryTimeMax(currentTrajectory()));
    updateEquationPanel();
    resizeCanvas();
    updateAndDraw();

    try {
      if (!window.MathJax?.startup?.promise) throw new Error('Le moteur MathJax intégré ne s’est pas initialisé.');
      await window.MathJax.startup.promise;
      await window.MathJax.typesetPromise();
      await initializeMathGlyphs();
      mathIsReady = true;
      updateDynamicMathOutputs();
      updateAxisLabelPositions();
      updateAndDraw();
    } catch (error) {
      console.error(error);
      loadingMessage.textContent = 'L’animation est chargée, mais le rendu TeX a échoué. Consultez la console du navigateur.';
      setTimeout(() => loadingMessage.remove(), 2500);
    }

    if (loadingMessage.isConnected) loadingMessage.remove();

    if (navigator.webdriver) {
      setPlaying(false);
      state.time = 2.4;
      updateAndDraw();
    } else {
      requestAnimationFrame(animate);
    }
  }

  void initializeApplication();
})();
