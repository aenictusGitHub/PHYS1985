globalThis.PhysLang?.translateTree(document.documentElement);
var physTranslate = globalThis.PhysLang?.t || (value => value);
(() => {
  'use strict';

  const COLORS = Object.freeze({
    position: '#d9683b',
    velocity: '#2775b6',
    acceleration: '#7758a6',
    tangential: '#b5688b',
    centripetal: '#268576',
    jerk: '#987125',
    trail: [137, 147, 157],
    projection: [217, 104, 59],
  });

  // Rescale the former 500 m squares to physical 1 m squares.
  const LENGTH_SCALE = 500;
  const BALLISTIC_TIME_SCALE = 1 / Math.sqrt(LENGTH_SCALE);
  const GRID_STEP_METRES = 1;

  const PARAMETERS = Object.freeze({
    R: 2,
    x0: 4,
    y0: 4,
    omega: 0.5,
    alpha: 0.02,
    theta0Deg: 0,
    v0: Math.sqrt(80),
    launchAngleDeg: 60,
    g: 9.81,
  });

  const DEFAULT_VIEW = Object.freeze({ xmin: 0, xmax: 8, ymin: 0, ymax: 8 });
  const MC_DEFAULTS = Object.freeze({ R: 2, omega: 1, alpha: 0 });
  const mcParameters = { ...MC_DEFAULTS };
  const LISSAJOUS_MODES = ['original', 'constant-speed'];
  // Keep the historical `mode` field for n=2 shared links; n=3 is independent.
  const lissajousParameters = { mode: 'original', mode3: 'original' };
  const lissajousMode = (n) => lissajousParameters[n===3 ? 'mode3' : 'mode'];
  const CLOSED_PERIOD = 2 * Math.PI / PARAMETERS.omega;
  const BALLISTIC_DURATION = 2 * PARAMETERS.v0 * Math.sin(PARAMETERS.launchAngleDeg * Math.PI / 180) / PARAMETERS.g;
  const AXIS_TICK_STEP = GRID_STEP_METRES;

  const ARROW = Object.freeze({
    shaftWidthPx: 3.2,
    headLengthPx: 18,
    headHalfWidthPx: 7,
    minimumLengthPx: 3,
  });

  const V = (x = 0, y = 0) => ({ x, y });
  const add = (a, b) => V(a.x + b.x, a.y + b.y);
  const sub = (a, b) => V(a.x - b.x, a.y - b.y);
  const scale = (a, s) => V(a.x * s, a.y * s);
  const dot = (a, b) => a.x * b.x + a.y * b.y;
  const norm = (a) => Math.hypot(a.x, a.y);
  const normalize = (a) => {
    const n = norm(a);
    return n > 1e-14 ? scale(a, 1 / n) : V(0, 0);
  };
  const deg2rad = (angle) => angle * Math.PI / 180;
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const wrap = (value, period) => ((value % period) + period) % period;

  function circularState(t) {
    const { R, omega: omega0, alpha } = mcParameters;
    const phase = omega0*t+.5*alpha*t*t;
    return { R, alpha, omega:omega0+alpha*t, radial:V(Math.cos(phase),Math.sin(phase)), tangent:V(-Math.sin(phase),Math.cos(phase)) };
  }

  function circularDuration() {
    // End after 4π of total angular travel (two turns). If the body reverses,
    // count both directions rather than confusing travel with net angle.
    const { omega, alpha } = mcParameters;
    const travel = 4*Math.PI;
    if (alpha === 0) return travel/omega;
    if (alpha > 0) return 2*travel/(omega+Math.sqrt(omega*omega+2*alpha*travel));
    const deceleration = -alpha, stopTravel = omega*omega/(2*deceleration);
    if (travel <= stopTravel) return 2*travel/(omega+Math.sqrt(Math.max(0,omega*omega-2*deceleration*travel)));
    return omega/deceleration+Math.sqrt(2*(travel-stopTravel)/deceleration);
  }

  // For each order, both modes keep the same curve; only q(t) changes.
  function lissajousGeometry(q, n=2) {
    const { R, x0, y0 } = PARAMETERS;
    const d1 = V(-R*Math.sin(q), n*R*Math.cos(n*q));
    const d2 = V(-R*Math.cos(q), -n*n*R*Math.sin(n*q));
    const d3 = V(R*Math.sin(q), -(n**3)*R*Math.cos(n*q));
    const g = norm(d1), gq = dot(d1,d2)/g;
    const gqq = (dot(d2,d2)+dot(d1,d3)-gq*gq)/g;
    return { position:V(x0+R*Math.cos(q),y0+R*Math.sin(n*q)),d1,d2,d3,g,gq,gqq };
  }

  function hermiteValue(a, b, da, db, h, u) {
    const c1 = h*da, c2 = 3*(b-a)-h*(2*da+db), c3 = 2*(a-b)+h*(da+db);
    return a+u*(c1+u*(c2+u*c3));
  }

  const lissajousTables = new Map();
  function getLissajousTables(n=2) {
    if (lissajousTables.has(n)) return lissajousTables.get(n);
    const quarter = Math.PI/2, count = 4096, h = quarter/count;
    // Integrate ds/dq = |dr/dq| over one quarter with Simpson quadrature.
    // Reflection gives the full curve, without any discontinuity in motion.
    const rows=[{q:0,arc:0}];
    for (let i=1;i<=count;i++) {
      const a=rows[i-1], q=i*h;
      const ga=lissajousGeometry(a.q,n).g, gb=lissajousGeometry(q,n).g, gm=lissajousGeometry((a.q+q)/2,n).g;
      rows.push({q,arc:a.arc+h*(ga+4*gm+gb)/6});
    }
    const speed=rows[rows.length-1].arc/(CLOSED_PERIOD/4);
    const table={rows,speed};
    lissajousTables.set(n,table);
    for (const row of rows) row.speedTime=row.arc/speed;
    return table;
  }

  function lissajousMotion(t, n=2) {
    const mode=lissajousMode(n);
    let q=PARAMETERS.omega*t, rate=PARAMETERS.omega, rate2=0, rate3=0;
    if (mode==='constant-speed') {
      const {rows,speed}=getLissajousTables(n), quarterTime=CLOSED_PERIOD/4;
      const phase=wrap(t,CLOSED_PERIOD)/quarterTime, quadrant=Math.min(3,Math.floor(phase));
      const reverse=quadrant%2===1, local=(phase-quadrant)*quarterTime;
      const clock=reverse ? quarterTime-local : local;
      let lo=0, hi=rows.length-1;
      while (hi-lo>1) { const mid=(lo+hi)>>1; if (rows[mid].speedTime<=clock) lo=mid; else hi=mid; }
      const a=rows[lo], b=rows[hi];
      const rateAt=row=>speed/lissajousGeometry(row.q,n).g;
      const dt=b.speedTime-a.speedTime;
      const localQ=clamp(hermiteValue(a.q,b.q,rateAt(a),rateAt(b),dt,clamp((clock-a.speedTime)/dt,0,1)),a.q,b.q);
      q=reverse ? (quadrant+1)*Math.PI/2-localQ : quadrant*Math.PI/2+localQ;
      const {g,gq,gqq}=lissajousGeometry(q,n), B=-gq/g;
      const Bq=-gqq/g+(gq/g)**2;
      rate=speed/g; rate2=rate*rate*B; rate3=rate**3*(2*B*B+Bq);
    }
    const geometry=lissajousGeometry(q,n), {d1,d2,d3}=geometry;
    return {q,position:geometry.position,velocity:scale(d1,rate),
      acceleration:add(scale(d2,rate*rate),scale(d1,rate2)),
      jerk:add(add(scale(d3,rate**3),scale(d2,3*rate*rate2)),scale(d1,rate3))};
  }

  function lissajousUniformParameters(n) {
    return [String.raw`R=2\,\mathrm m,\qquad T=4\pi\,\mathrm s`,
      String.raw`s(t)=\frac{L}{T}\,t,\qquad q(0)=0`,
      String.raw`|\vec v|=\frac{L}{T}\simeq ${getLissajousTables(n).speed.toFixed(3)}\,\mathrm{m\,s^{-1}}`,
      String.raw`\vec a_{\mathrm t}=\vec 0`];
  }

  const TRAJECTORIES = Object.freeze({
    lissajous2: {
      lissajousOrder: 2,
      label: 'Lissajous (𝑛=2)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.50,
      scaleA: 0.50,
      get equations() { return lissajousParameters.mode === 'original' ? [
        String.raw`x(t)=x_0+R\cos\!\bigl(\omega t+\theta_0\bigr)`,
        String.raw`y(t)=y_0+R\sin(2\omega t)`,
      ] : [String.raw`x(t)=x_0+R\cos q(t)`,String.raw`y(t)=y_0+R\sin\!\bigl(2q(t)\bigr)`]; },
      get parameters() { return lissajousParameters.mode === 'original' ? [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}},\qquad \theta_0=0`,
        String.raw`T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
      ] : lissajousUniformParameters(2); },
      position(t) { return lissajousMotion(t).position; },
      velocity(t) { return lissajousMotion(t).velocity; },
      acceleration(t) { return lissajousMotion(t).acceleration; },
      jerk(t) { return lissajousMotion(t).jerk; },
    },

    lissajous3: {
      lissajousOrder: 3,
      label: 'Lissajous (𝑛=3)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.40,
      scaleA: 0.50,
      get equations() { return lissajousMode(3) === 'original' ? [
        String.raw`x(t)=x_0+R\cos\!\bigl(\omega t+\theta_0\bigr)`,
        String.raw`y(t)=y_0+R\sin(3\omega t)`,
      ] : [String.raw`x(t)=x_0+R\cos q(t)`,String.raw`y(t)=y_0+R\sin\!\bigl(3q(t)\bigr)`]; },
      get parameters() { return lissajousMode(3) === 'original' ? [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}},\qquad \theta_0=0`,
        String.raw`n=3,\qquad T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
      ] : lissajousUniformParameters(3); },
      position(t) { return lissajousMotion(t,3).position; },
      velocity(t) { return lissajousMotion(t,3).velocity; },
      acceleration(t) { return lissajousMotion(t,3).acceleration; },
      jerk(t) { return lissajousMotion(t,3).jerk; },
    },

    mc: {
      label: physTranslate('Mouvement circulaire (MC)'),
      get duration() { return mcParameters.alpha === 0 ? 2*Math.PI/mcParameters.omega : circularDuration(); },
      // Only the uniform law is periodic. Never wrap an accelerated motion.
      get closed() { return mcParameters.alpha === 0; },
      scaleV: 0.40,
      scaleA: 0.50,
      scaleJ: 0.08,
      equations: [
        String.raw`\varphi(t)=\omega_0t+\frac12\alpha t^2`,
        String.raw`\omega(t)=\omega_0+\alpha t`,
        String.raw`x(t)=x_0+R\cos\!\bigl(\varphi(t)\bigr)`,
        String.raw`y(t)=y_0+R\sin\!\bigl(\varphi(t)\bigr)`,
      ],
      parameters: [String.raw`v=R|\omega(t)|,\qquad a_{\mathrm c}=R\omega^2(t)`,String.raw`|\vec a_{\mathrm t}|=R|\alpha|\quad(\omega\ne0)`],
      position(t) {
        const { R, radial } = circularState(t);
        return add(V(PARAMETERS.x0,PARAMETERS.y0),scale(radial,R));
      },
      velocity(t) {
        const { R, omega, tangent } = circularState(t);
        return scale(tangent,R*omega);
      },
      acceleration(t) {
        const { R, omega, alpha, radial, tangent } = circularState(t);
        return add(scale(radial,-R*omega*omega),scale(tangent,R*alpha));
      },
      jerk(t) {
        const { R, omega, alpha, radial, tangent } = circularState(t);
        return add(scale(radial,-3*R*omega*alpha),scale(tangent,-R*omega**3));
      },
    },

    fish: {
      label: physTranslate('Courbe poisson'),
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.50,
      scaleA: 0.65,
      equations: [
        String.raw`x(t)=x_0+R\left[\cos(\omega t)-\frac{\sin^2(\omega t)}{\sqrt2}\right]`,
        String.raw`y(t)=y_0+R\cos(\omega t)\sin(\omega t)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, R, omega } = PARAMETERS;
        const q = omega * t;
        const s = Math.sin(q);
        const c = Math.cos(q);
        return V(x0 + R * (c - s * s / Math.sqrt(2)), y0 + R * c * s);
      },
    },

    astroid: {
      label: physTranslate('Astroïde'),
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.50,
      scaleA: 0.50,
      equations: [
        String.raw`x(t)=x_0+R\cos^3(\omega t)`,
        String.raw`y(t)=y_0+R\sin^3(\omega t)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, R, omega } = PARAMETERS;
        const q = omega * t;
        return V(x0 + R * Math.cos(q) ** 3, y0 + R * Math.sin(q) ** 3);
      },
    },

    quadrifolium: {
      label: 'Quadrifolium',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.35,
      scaleA: 0.35,
      equations: [
        String.raw`x(t)=x_0+R\cos(2\omega t)\cos(\omega t)`,
        String.raw`y(t)=y_0+R\cos(2\omega t)\sin(\omega t)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, R, omega } = PARAMETERS;
        const q = omega * t;
        return V(
          x0 + R * Math.cos(2 * q) * Math.cos(q),
          y0 + R * Math.cos(2 * q) * Math.sin(q),
        );
      },
    },

    ballistic: {
      label: physTranslate('Mouvement balistique'),
      equationOrigin: V(0, 0),
      duration: BALLISTIC_DURATION,
      closed: false,
      scaleV: 3 * BALLISTIC_TIME_SCALE,
      scaleA: 25 / LENGTH_SCALE,
      jerk() { return V(0, 0); },
      equations: [
        String.raw`x(t)=x_0+v_0\cos(\theta_0)\,t`,
        String.raw`y(t)=y_0+v_0\sin(\theta_0)\,t-\frac{1}{2}gt^2`,
      ],
      parameters: [
        String.raw`x_0=y_0=0,\qquad v_0=\sqrt{80}\simeq 8.94\,\mathrm{m\,s^{-1}}`,
        String.raw`\theta_0=60^\circ,\qquad g=9.81\,\mathrm{m\,s^{-2}}`,
        String.raw`T=\frac{2v_0\sin\theta_0}{g}\simeq 1.58\,\mathrm s`,
      ],
      position(t) {
        const { v0, launchAngleDeg, g } = PARAMETERS;
        const angle = deg2rad(launchAngleDeg);
        return V(v0 * Math.cos(angle) * t, v0 * Math.sin(angle) * t - 0.5 * g * t * t);
      },
    },

    cardioid: {
      label: physTranslate('Cardioïde'),
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.55,
      scaleA: 0.50,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+a\bigl(2\cos\tau-\cos2\tau\bigr)`,
        String.raw`y(t)=y_0+a\bigl(2\sin\tau-\sin2\tau\bigr)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad a=1\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, omega } = PARAMETERS;
        const a = 1;
        const q = omega * t;
        return V(x0 + a * (2 * Math.cos(q) - Math.cos(2 * q)), y0 + a * (2 * Math.sin(q) - Math.sin(2 * q)));
      },
    },

    lemniscate: {
      label: physTranslate('Lemniscate de Bernoulli'),
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.65,
      scaleA: 0.55,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+\frac{a\cos\tau}{1+\sin^2\tau}`,
        String.raw`y(t)=y_0+\frac{a\sin\tau\cos\tau}{1+\sin^2\tau}`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad a=2.8\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, omega } = PARAMETERS;
        const a = 2.8;
        const q = omega * t;
        const s = Math.sin(q);
        const c = Math.cos(q);
        const denominator = 1 + s * s;
        return V(x0 + a * c / denominator, y0 + a * s * c / denominator);
      },
    },

    rose5: {
      label: physTranslate('Rose à cinq pétales'),
      duration: CLOSED_PERIOD / 2,
      closed: true,
      scaleV: 0.28,
      scaleA: 0.12,
      equations: [
        String.raw`\tau=\omega t,\qquad \rho(\tau)=R\cos(5\tau)`,
        String.raw`x(t)=x_0+\rho(\tau)\cos\tau`,
        String.raw`y(t)=y_0+\rho(\tau)\sin\tau`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2.8\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}},\qquad T=\frac{\pi}{\omega}=2\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, omega } = PARAMETERS;
        const R = 2.8;
        const q = omega * t;
        const rho = R * Math.cos(5 * q);
        return V(x0 + rho * Math.cos(q), y0 + rho * Math.sin(q));
      },
    },

    spiral: {
      label: physTranslate('Spirale d’Archimède'),
      duration: 24,
      closed: false,
      scaleV: 0.95,
      scaleA: 0.85,
      equations: [
        String.raw`\tau=\frac{6\pi}{T}t,\qquad \rho(\tau)=\rho_0+b\tau`,
        String.raw`x(t)=x_0+\rho(\tau)\cos\tau`,
        String.raw`y(t)=y_0+\rho(\tau)\sin\tau`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad \rho_0=0.16\,\mathrm m`,
        String.raw`b=0.16\,\mathrm m,\qquad T=24\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0 } = PARAMETERS;
        const T = 24;
        const tau = 6 * Math.PI * t / T;
        const rho = 0.16 + 0.16 * tau;
        return V(x0 + rho * Math.cos(tau), y0 + rho * Math.sin(tau));
      },
    },

    cycloid: {
      label: physTranslate('Cycloïde'),
      equationOrigin: V(0.8, 1.3),
      equationOriginSubscript: String.raw`\mathrm i`,
      duration: 12,
      closed: false,
      scaleV: 1.25,
      scaleA: 1.0,
      equations: [
        String.raw`\tau=\frac{2\pi}{T}t`,
        String.raw`x(t)=x_\mathrm i+a\bigl(\tau-\sin\tau\bigr)`,
        String.raw`y(t)=y_\mathrm i+a\bigl(1-\cos\tau\bigr)`,
      ],
      parameters: [
        String.raw`x_\mathrm i=0.8\,\mathrm m,\qquad y_\mathrm i=1.3\,\mathrm m`,
        String.raw`a=1\,\mathrm m,\qquad T=12\,\mathrm s`,
      ],
      position(t) {
        const T = 12;
        const a = 1;
        const tau = 2 * Math.PI * t / T;
        return V(0.8 + a * (tau - Math.sin(tau)), 1.3 + a * (1 - Math.cos(tau)));
      },
    },

    deltoid: {
      label: physTranslate('Deltoïde'),
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.55,
      scaleA: 0.38,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+a\bigl(2\cos\tau+\cos2\tau\bigr)`,
        String.raw`y(t)=y_0+a\bigl(2\sin\tau-\sin2\tau\bigr)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad a=0.86\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, omega } = PARAMETERS;
        const a = 0.86;
        const q = omega * t;
        return V(x0 + a * (2 * Math.cos(q) + Math.cos(2 * q)), y0 + a * (2 * Math.sin(q) - Math.sin(2 * q)));
      },
    },

    nephroid: {
      label: physTranslate('Néphroïde'),
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.45,
      scaleA: 0.30,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+a\bigl(3\cos\tau-\cos3\tau\bigr)`,
        String.raw`y(t)=y_0+a\bigl(3\sin\tau-\sin3\tau\bigr)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad a=0.7\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, omega } = PARAMETERS;
        const a = 0.7;
        const q = omega * t;
        return V(x0 + a * (3 * Math.cos(q) - Math.cos(3 * q)), y0 + a * (3 * Math.sin(q) - Math.sin(3 * q)));
      },
    },

    hypotrochoid: {
      label: physTranslate('Hypotrochoïde'),
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.42,
      scaleA: 0.24,
      equations: [
        String.raw`\tau=\omega t,\qquad k=\frac{R-r}{r}`, 
        String.raw`x(t)=x_0+(R-r)\cos\tau+d\cos(k\tau)`,
        String.raw`y(t)=y_0+(R-r)\sin\tau-d\sin(k\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad R=2.4\,\mathrm m`,
        String.raw`r=0.8\,\mathrm m,\qquad d=1.3\,\mathrm m,\qquad k=2`,
      ],
      position(t) {
        const { x0, y0, omega } = PARAMETERS;
        const R = 2.4;
        const r = 0.8;
        const d = 1.3;
        const q = omega * t;
        const k = (R - r) / r;
        return V(x0 + (R - r) * Math.cos(q) + d * Math.cos(k * q), y0 + (R - r) * Math.sin(q) - d * Math.sin(k * q));
      },
    },

    heart: {
      label: physTranslate('Cœur'),
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.32,
      scaleA: 0.16,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+16a\sin^3\tau`,
        String.raw`y(t)=y_0+a\bigl(13\cos\tau-5\cos2\tau-2\cos3\tau-\cos4\tau\bigr)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad a=0.13\,\mathrm m`,
        String.raw`\omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, omega } = PARAMETERS;
        const a = 0.13;
        const q = omega * t;
        return V(
          x0 + 16 * a * Math.sin(q) ** 3,
          y0 + a * (13 * Math.cos(q) - 5 * Math.cos(2 * q) - 2 * Math.cos(3 * q) - Math.cos(4 * q)),
        );
      },
    },

    butterfly: {
      label: physTranslate('Papillon'),
      duration: 24,
      closed: true,
      scaleV: 0.72,
      scaleA: 0.32,
      equations: [
        String.raw`\tau=\frac{12\pi}{T}t`,
        String.raw`f(\tau)=e^{\cos\tau}-2\cos4\tau-\sin^5\!\left(\frac{\tau}{12}\right)`,
        String.raw`x(t)=x_0+A\sin\tau\,f(\tau)`,
        String.raw`y(t)=y_0+A\cos\tau\,f(\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=4\,\mathrm m,\qquad A=0.6\,\mathrm m`,
        String.raw`T=24\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0 } = PARAMETERS;
        const T = 24;
        const A = 0.6;
        const tau = 12 * Math.PI * t / T;
        const f = Math.exp(Math.cos(tau)) - 2 * Math.cos(4 * tau) - Math.sin(tau / 12) ** 5;
        return V(x0 + A * Math.sin(tau) * f, y0 + A * Math.cos(tau) * f);
      },
    },
  });

  // Constant offsets in the displayed laws change with the chosen origin;
  // all time-dependent terms and physical trajectory laws stay unchanged.
  function equationFrame(item, frameOrigin) {
    const base = item.equationOrigin || V(PARAMETERS.x0, PARAMETERS.y0);
    const subscript = item.equationOriginSubscript || '0';
    const parameters = item.parameters.map(line => line.split(/\\qquad\s*/)
      .filter(part => !/^[xy]_(?:0|\\mathrm i)=/.test(part.trim()))
      .join(String.raw`\qquad `)).filter(Boolean);
    return { offset: sub(base, frameOrigin), subscript, parameters };
  }

  // Differentiate the smooth position law, not the playback wrap/clamp.
  // A symmetric seven-point stencil gives fourth-order accuracy without
  // differentiating the noise in the displayed acceleration.
  function jerkAt(item, t) {
    if (item.jerk) return item.jerk(t);
    const h = 0.004;
    const pm1 = item.position(t - h);
    const pp1 = item.position(t + h);
    const pm2 = item.position(t - 2 * h);
    const pp2 = item.position(t + 2 * h);
    const pm3 = item.position(t - 3 * h);
    const pp3 = item.position(t + 3 * h);
    const numerator = add(
      add(scale(sub(pm1, pp1), 13), scale(sub(pp2, pm2), 8)),
      sub(pm3, pp3),
    );
    const result = scale(numerator, 1 / (8 * h ** 3));
    for (const axis of Object.keys(result)) {
      if (Math.abs(result[axis]) < 1e-4 / LENGTH_SCALE) result[axis] = 0;
    }
    return result;
  }

  const jerkScales = new WeakMap();
  function jerkDisplayScale(item) {
    // An explicit scale stays fixed even when the MCU parameters change.
    if (item.scaleJ !== undefined) return item.scaleJ;
    if (!jerkScales.has(item)) jerkScales.set(item,new Map());
    const scales=jerkScales.get(item), key=item.lissajousOrder ? lissajousMode(item.lissajousOrder) : 'default';
    if (!scales.has(key)) {
      let maximum = 0;
      for (let i = 0; i <= 384; i += 1) {
        maximum = Math.max(maximum, norm(jerkAt(item, item.duration * i / 384)));
      }
      // Fixed for each trajectory: arrow length still follows |j(t)|.
      scales.set(key, maximum > 1e-4 / LENGTH_SCALE ? 0.65 * PARAMETERS.R / maximum : 1);
    }
    return scales.get(key);
  }

  // Physical geometry only: independent of camera and vector display scales.
  function osculatingGeometry(data) {
    const speed = norm(data.velocity);
    if (!Number.isFinite(speed) || speed <= 1e-2 / LENGTH_SCALE) {
      return { defined: false, reason: 'stationary' };
    }
    const tangent = scale(data.velocity, 1 / speed);
    const normalAcceleration = sub(data.acceleration, scale(tangent, dot(data.acceleration, tangent)));
    const normalMagnitude = norm(normalAcceleration);
    // Suppress finite-difference roundoff at straight segments and inflections.
    const tolerance = Math.max(1e-5 / LENGTH_SCALE, norm(data.acceleration) * 1e-7);
    if (!Number.isFinite(normalMagnitude) || normalMagnitude <= tolerance) {
      return { defined: false, reason: 'straight' };
    }
    const normal = scale(normalAcceleration, 1 / normalMagnitude);
    const radius = speed * speed / normalMagnitude;
    const center = add(data.position, scale(normal, radius));
    if (!Number.isFinite(radius) || !Object.values(center).every(Number.isFinite)) {
      return { defined: false, reason: 'unresolved' };
    }
    return { defined: true, radius, center, tangent, normal, position: data.position };
  }

  function osculatingPoint(circle, angle) {
    // Anchored at the mobile: avoids center - radius cancellation for large radii.
    return add(circle.position, add(
      scale(circle.tangent, circle.radius * Math.sin(angle)),
      scale(circle.normal, 2 * circle.radius * Math.sin(angle / 2) ** 2),
    ));
  }

  function clipScreenSegment(a, b, bounds) {
    if (![a?.x, a?.y, b?.x, b?.y].every(Number.isFinite)) return null;
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    let first = 0;
    let last = 1;
    const edges = [
      [-dx, a.x - bounds.left], [dx, bounds.right - a.x],
      [-dy, a.y - bounds.top], [dy, bounds.bottom - a.y],
    ];
    for (const [p, q] of edges) {
      if (p === 0) {
        if (q < 0) return null;
      } else {
        const t = q / p;
        if (p < 0) first = Math.max(first, t);
        else last = Math.min(last, t);
        if (first > last) return null;
      }
    }
    return [
      { x: a.x + first * dx, y: a.y + first * dy },
      { x: a.x + last * dx, y: a.y + last * dy },
    ];
  }

  const viewport = document.getElementById('viewport');
  const canvas = document.getElementById('scene-canvas');
  const ctx = canvas.getContext('2d', { alpha: true });
  const loadingMessage = document.getElementById('loading-message');

  const dom = {
    trajectory: document.getElementById('trajectory-select'),
    lissajousControls: document.getElementById('lissajous-controls'),
    lissajousMode: document.getElementById('lissajous-parameterization'),
    lissajousDescription: document.getElementById('lissajous-description'),
    mcControls: document.getElementById('mc-controls'),
    mcRadius: document.getElementById('mc-radius'),
    mcOmega: document.getElementById('mc-omega'),
    mcAlpha: document.getElementById('mc-alpha'),
    mcRadiusDigits: document.getElementById('mc-radius-digits'),
    mcOmegaDigits: document.getElementById('mc-omega-digits'),
    mcAlphaDigits: document.getElementById('mc-alpha-digits'),
    mcPeriodDigits: document.getElementById('mc-period-digits'),
    mcRegime: document.getElementById('mc-regime'),
    mcReset: document.getElementById('mc-reset'),
    equations: document.getElementById('trajectory-equations'),
    play: document.getElementById('play-button'),
    reset: document.getElementById('reset-button'),
    resetView: document.getElementById('reset-view'),
    moveOrigin: document.getElementById('move-origin'),
    resetOrigin: document.getElementById('reset-origin'),
    originHandle: document.getElementById('origin-handle'),
    originXDigits: document.getElementById('origin-x-digits'),
    originYDigits: document.getElementById('origin-y-digits'),
    speed: document.getElementById('speed-select'),
    timeSlider: document.getElementById('time-slider'),
    timeOutputDigits: document.getElementById('time-output-digits'),
    timeBadgeDigits: document.getElementById('time-badge-digits'),
    loop: document.getElementById('loop-toggle'),
    vectorScale: document.getElementById('vector-scale'),
    mobileAppearance: document.getElementById('mobile-appearance'),
    vectorScaleOutputDigits: document.getElementById('vector-scale-output-digits'),
    trailDuration: document.getElementById('trail-duration'),
    trailDurationControls: document.getElementById('trail-duration-controls'),
    trailDurationOutputDigits: document.getElementById('trail-duration-output-digits'),
    fullTrail: document.getElementById('full-trail'),
    projections: document.getElementById('projection-toggle'),
    osculating: document.getElementById('osculating-toggle'),
    curvatureDetails: document.getElementById('curvature-details'),
    curvatureValue: document.getElementById('curvature-value'),
    curvatureDigits: document.getElementById('curvature-digits'),
    curvatureScientific: document.getElementById('curvature-scientific'),
    curvatureExponent: document.getElementById('curvature-exponent'),
    curvatureStatus: document.getElementById('curvature-status'),
    radiusLabel: document.getElementById('radius-label'),
    grid: document.getElementById('grid-toggle'),
    warning: document.getElementById('warning-badge'),
    clearVectors: document.getElementById('clear-vectors'),
    vectorReadouts: document.getElementById('vector-readouts'),
    axisLabels: {
      x: document.getElementById('axis-label-x'),
      y: document.getElementById('axis-label-y'),
    },
    axisTickLayers: {
      x: document.getElementById('axis-ticks-x'),
      y: document.getElementById('axis-ticks-y'),
    },
    toggles: {
      position: document.getElementById('toggle-position'),
      velocity: document.getElementById('toggle-velocity'),
      acceleration: document.getElementById('toggle-acceleration'),
      tangential: document.getElementById('toggle-tangential'),
      centripetal: document.getElementById('toggle-centripetal'),
      jerk: document.getElementById('toggle-jerk'),
    },
  };

  const VECTOR_META = Object.freeze({
    position: {
      symbolTeX: String.raw`\vec r`,
      unitTeX: String.raw`\mathrm m`,
      plainName: 'position',
      color: COLORS.position,
    },
    velocity: {
      symbolTeX: String.raw`\vec v`,
      unitTeX: String.raw`\mathrm{m\,s^{-1}}`,
      plainName: physTranslate('vitesse'),
      color: COLORS.velocity,
    },
    acceleration: {
      symbolTeX: String.raw`\vec a`,
      unitTeX: String.raw`\mathrm{m\,s^{-2}}`,
      plainName: physTranslate('accélération'),
      color: COLORS.acceleration,
    },
    tangential: {
      symbolTeX: String.raw`\vec a_{\mathrm t}`,
      unitTeX: String.raw`\mathrm{m\,s^{-2}}`,
      plainName: physTranslate('accélération tangentielle'),
      color: COLORS.tangential,
    },
    centripetal: {
      symbolTeX: String.raw`\vec a_{\mathrm c}`,
      unitTeX: String.raw`\mathrm{m\,s^{-2}}`,
      plainName: physTranslate('accélération centripète'),
      color: COLORS.centripetal,
    },
    jerk: {
      symbolTeX: String.raw`\vec{\jmath}`,
      unitTeX: String.raw`\mathrm{m\,s^{-3}}`,
      plainName: physTranslate('à-coup'),
      color: COLORS.jerk,
    },
  });

  const readoutElements = {};
  for (const [key, meta] of Object.entries(VECTOR_META)) {
    const element = document.createElement('div');
    element.className = 'vector-readout';
    element.style.setProperty('--readout-color', meta.color);
    element.innerHTML = `
      <div class="vector-readout-line vector-readout-magnitude">
        <span class="tex-math">\\(\\lvert${meta.symbolTeX}\\rvert=\\)</span>
        <span class="math-digits magnitude-digits">0.00</span>
        <span class="tex-math">\\(\\,${meta.unitTeX}\\)</span>
      </div>
      <div class="vector-readout-line vector-readout-components">
        <span class="tex-math">\\(${meta.symbolTeX}=(\\)</span>
        <span class="math-digits component-x-digits">0.0</span>
        <span class="tex-math">\\(,\\,\\)</span>
        <span class="math-digits component-y-digits">0.0</span>
        <span class="tex-math">\\()\\)</span>
      </div>`;
    dom.vectorReadouts.append(element);
    readoutElements[key] = {
      root: element,
      meta,
      magnitude: element.querySelector('.magnitude-digits'),
      componentX: element.querySelector('.component-x-digits'),
      componentY: element.querySelector('.component-y-digits'),
    };
  }

  const state = {
    trajectoryKey: 'lissajous2',
    time: 0,
    playing: true,
    playbackSpeed: 1,
    loop: true,
    vectorScale: 1,
    mobileAppearance: 'point',
    trailDuration: 10,
    fullTrail: true,
    projections: true,
    grid: true,
  };

  const view = { ...DEFAULT_VIEW };
  // The trajectory stays in its original physical coordinates. This is a
  // translation of a fixed reference frame, never a change to the motion law.
  const origin = V(0, 0);
  let movingOrigin = false;
  let originDrag = null;
  const originIsShifted = () => Math.abs(origin.x) > 1e-10 || Math.abs(origin.y) > 1e-10;
  const relativePosition = (position) => sub(position, origin);
  const relativeView = () => ({
    xmin: view.xmin - origin.x, xmax: view.xmax - origin.x,
    ymin: view.ymin - origin.y, ymax: view.ymax - origin.y,
  });
  let viewportWidth = 1;
  let viewportHeight = 1;
  let devicePixelRatio = 1;
  let plotRect = { left: 80, top: 40, width: 400, height: 400, right: 480, bottom: 440 };
  const pointers = new Map();
  let panPointer = null;
  let pinch = null;
  let touchOrigin = null;

  let mathIsReady = false;
  let mathTypesetQueue = Promise.resolve();
  const mathGlyphTemplates = new Map();
  const axisTickElements = { x: new Map(), y: new Map() };

  const currentTrajectory = () => TRAJECTORIES[state.trajectoryKey];
  const trajectoryTimeMax = (item) => item.closed ? 2 * item.duration : item.duration;
  const axisTickValues = (minimum, maximum) => {
    // Keep every grid square at 1 m; only thin the numbers when space is tight.
    const pixelsPerMetre = plotRect.width / (view.xmax - view.xmin);
    const step = AXIS_TICK_STEP * Math.max(1, Math.ceil(38 / pixelsPerMetre));
    const first = Math.ceil((minimum - 1e-9) / step) * step;
    const values = [];
    for (let value = first; value <= maximum + 1e-9; value += step) {
      values.push(Math.abs(value) < 1e-9 ? 0 : value);
    }
    return values;
  };
  const vectorSelection = () => Object.fromEntries(
    Object.entries(dom.toggles).map(([key, input]) => [key, input.checked]),
  );

  function queueTypeset(elements) {
    if (!mathIsReady || !window.MathJax?.typesetPromise) return Promise.resolve();
    mathTypesetQueue = mathTypesetQueue
      .then(() => window.MathJax.typesetPromise(elements))
      .catch((error) => console.error(physTranslate('Échec de la composition MathJax :'), error));
    return mathTypesetQueue;
  }

  async function initializeMathGlyphs() {
    const characters = '0123456789.-+';
    for (const character of characters) {
      const tex = character === '-' ? '{-}' : character === '+' ? '{+}' : character;
      const rendered = await window.MathJax.tex2svgPromise(tex, { display: false });
      rendered.setAttribute('aria-hidden', 'true');
      mathGlyphTemplates.set(character, rendered);
    }
  }

  function setMathDigits(element, text) {
    if (!element) return;
    const value = String(text);
    if (!mathIsReady || mathGlyphTemplates.size === 0) {
      element.textContent = value;
      element.dataset.value = value;
      return;
    }
    if (element.dataset.value === value && element.classList.contains('typeset')) return;

    const fragment = document.createDocumentFragment();
    for (const character of value) {
      const wrapper = document.createElement('span');
      wrapper.className = 'math-glyph';
      wrapper.setAttribute('aria-hidden', 'true');
      const template = mathGlyphTemplates.get(character);
      if (template) wrapper.append(template.cloneNode(true));
      else wrapper.textContent = character;
      fragment.append(wrapper);
    }
    element.replaceChildren(fragment);
    element.classList.add('typeset');
    element.dataset.value = value;
  }

  function synchronizeAxisTickElements(axis, ticks) {
    const elements = axisTickElements[axis];
    const visible = new Set(ticks);

    for (const [tick, record] of elements) {
      if (!visible.has(tick)) {
        record.root.remove();
        elements.delete(tick);
      }
    }

    for (const tick of ticks) {
      if (elements.has(tick)) continue;
      const root = document.createElement('div');
      root.className = 'axis-math-label axis-tick-label';
      root.setAttribute('aria-hidden', 'true');
      const digits = document.createElement('span');
      digits.className = 'math-digits';
      root.append(digits);
      dom.axisTickLayers[axis].append(root);
      setMathDigits(digits, String(tick));
      elements.set(tick, { root, digits });
    }
  }

  function updateDynamicMathOutputs() {
    setMathDigits(dom.timeOutputDigits, state.time.toFixed(2));
    setMathDigits(dom.timeBadgeDigits, state.time.toFixed(2));
    setMathDigits(dom.vectorScaleOutputDigits, state.vectorScale.toFixed(2));
    setMathDigits(dom.trailDurationOutputDigits, state.trailDuration.toFixed(1));
    updateMCReadouts();
  }

  function updateMCReadouts() {
    const uniform = mcParameters.alpha === 0;
    const values = {R:mcParameters.R.toFixed(2),omega:mcParameters.omega.toFixed(2),alpha:mcParameters.alpha.toFixed(2),tmax:circularDuration().toFixed(2)};
    setMathDigits(dom.mcRadiusDigits,values.R);
    setMathDigits(dom.mcOmegaDigits,values.omega);
    setMathDigits(dom.mcAlphaDigits,values.alpha);
    setMathDigits(dom.mcPeriodDigits,(uniform ? circularDuration()/2 : circularDuration()).toFixed(2));
    document.getElementById('mc-period-symbol').hidden = !uniform;
    document.getElementById('mc-duration-symbol').hidden = uniform;
    dom.mcRegime.textContent = uniform ? physTranslate('Mouvement circulaire uniforme') : physTranslate('Mouvement circulaire uniformément accéléré. Pas de période : la durée affichée correspond à deux tours parcourus au total, même si le sens de rotation s’inverse.');
    for (const element of dom.equations.querySelectorAll('[data-mc-value]'))
      setMathDigits(element,values[element.dataset.mcValue]);
    dom.mcRadius.setAttribute('aria-valuetext',physTranslate(`${values.R} mètres`));
    dom.mcOmega.setAttribute('aria-valuetext',physTranslate(`${values.omega} radians par seconde`));
    dom.mcAlpha.setAttribute('aria-valuetext',physTranslate(`${values.alpha} radians par seconde carrée`));
  }

  function changeMCParameters(radius, omega, alpha) {
    if (![radius,omega,alpha].every(Number.isFinite)) return;
    mcParameters.R = Math.round(clamp(radius,.25,3)*100)/100;
    mcParameters.omega = Math.round(clamp(omega,.1,2)*100)/100;
    mcParameters.alpha = Math.round(clamp(alpha,-.2,.2)*100)/100;
    dom.mcRadius.value = String(mcParameters.R);
    dom.mcOmega.value = String(mcParameters.omega);
    dom.mcAlpha.value = String(mcParameters.alpha);
    // New constant parameters define a new circular motion from the same initial
    // phase. Keep the chosen origin, view and playback/paused state.
    state.time = 0;
    configureTimeline();
    updateMCReadouts();
    updateAndDraw();
  }

  function resetView() {
    Object.assign(view, DEFAULT_VIEW);
  }

  function setOrigin(point) {
    origin.x = Math.abs(point.x) < 1e-10 ? 0 : point.x;
    origin.y = Math.abs(point.y) < 1e-10 ? 0 : point.y;
    updateOriginControls();
    updateAndDraw();
  }

  function updateOriginControls() {
    const shifted = originIsShifted();
    dom.resetOrigin.disabled = !shifted;
    setMathDigits(dom.originXDigits, origin.x.toFixed(2));
    setMathDigits(dom.originYDigits, origin.y.toFixed(2));
    updateEquationOffsets();
    dom.originHandle.setAttribute('aria-label', physTranslate(`Origine du repère : X = ${origin.x.toFixed(2)} m, Y = ${origin.y.toFixed(2)} m. Faire glisser pour la déplacer.`));
  }

  function positionOriginHandle() {
    const point = worldToScreen(origin);
    const inside = point.x >= plotRect.left - 0.1 && point.x <= plotRect.right + 0.1
      && point.y >= plotRect.top - 0.1 && point.y <= plotRect.bottom + 0.1;
    dom.originHandle.hidden = !(movingOrigin || originIsShifted()) || !inside;
    dom.originHandle.style.left = `${point.x}px`;
    dom.originHandle.style.top = `${point.y}px`;
  }

  function computePlotRect() {
    const margins = { left: 112, right: 54, top: 42, bottom: 90 };
    const availableWidth = Math.max(120, viewportWidth - margins.left - margins.right);
    const availableHeight = Math.max(120, viewportHeight - margins.top - margins.bottom);
    const viewAspect = (view.xmax - view.xmin) / (view.ymax - view.ymin);

    let width = availableWidth;
    let height = width / viewAspect;
    if (height > availableHeight) {
      height = availableHeight;
      width = height * viewAspect;
    }

    const left = margins.left + 0.5 * (availableWidth - width);
    const top = margins.top + 0.5 * (availableHeight - height);
    plotRect = { left, top, width, height, right: left + width, bottom: top + height };
  }

  function worldToScreen(point) {
    const x = plotRect.left + (point.x - view.xmin) * plotRect.width / (view.xmax - view.xmin);
    const y = plotRect.bottom - (point.y - view.ymin) * plotRect.height / (view.ymax - view.ymin);
    return V(x, y);
  }

  function screenToWorld(point) {
    const x = view.xmin + (point.x - plotRect.left) * (view.xmax - view.xmin) / plotRect.width;
    const y = view.ymin + (plotRect.bottom - point.y) * (view.ymax - view.ymin) / plotRect.height;
    return V(x, y);
  }

  function resizeCanvas() {
    const rect = viewport.getBoundingClientRect();
    viewportWidth = Math.max(1, rect.width);
    viewportHeight = Math.max(1, rect.height);
    devicePixelRatio = Math.min(2.5, Math.max(1, window.devicePixelRatio || 1));
    canvas.width = Math.max(1, Math.round(viewportWidth * devicePixelRatio));
    canvas.height = Math.max(1, Math.round(viewportHeight * devicePixelRatio));
    canvas.style.width = `${viewportWidth}px`;
    canvas.style.height = `${viewportHeight}px`;
    ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
    computePlotRect();
    updateAxisLabelPositions();
    updateAndDraw();
  }

  function positionAt(item, time) {
    if (item.closed) return item.position(wrap(time, item.duration));
    return item.position(clamp(time, 0, item.duration));
  }

  function derivatives(item, time) {
    const t = item.closed ? time : clamp(time, 0, item.duration);
    const h = Math.max(1e-3, Math.min(0.01, item.duration / 3000));
    const p = positionAt(item, t);
    let velocity;
    let acceleration;

    if (item.velocity && item.acceleration) {
      velocity = item.velocity(t);
      acceleration = item.acceleration(t);
    } else if (item.closed) {
      const pm = positionAt(item, t - h);
      const pp = positionAt(item, t + h);
      velocity = scale(sub(pp, pm), 1 / (2 * h));
      acceleration = scale(add(sub(pp, scale(p, 2)), pm), 1 / (h * h));
    } else if (t <= h) {
      const p1 = positionAt(item, t + h);
      const p2 = positionAt(item, t + 2 * h);
      velocity = scale(add(add(scale(p, -3), scale(p1, 4)), scale(p2, -1)), 1 / (2 * h));
      acceleration = scale(add(add(p, scale(p1, -2)), p2), 1 / (h * h));
    } else if (t >= item.duration - h) {
      const p1 = positionAt(item, t - h);
      const p2 = positionAt(item, t - 2 * h);
      velocity = scale(add(add(scale(p, 3), scale(p1, -4)), p2), 1 / (2 * h));
      acceleration = scale(add(add(p, scale(p1, -2)), p2), 1 / (h * h));
    } else {
      const pm = positionAt(item, t - h);
      const pp = positionAt(item, t + h);
      velocity = scale(sub(pp, pm), 1 / (2 * h));
      acceleration = scale(add(sub(pp, scale(p, 2)), pm), 1 / (h * h));
    }

    const speed = norm(velocity);
    const decompositionDefined = speed > 1e-2 / LENGTH_SCALE;
    let tangential = V(0, 0);
    let centripetal = V(0, 0);
    if (decompositionDefined) {
      const tangentUnit = scale(velocity, 1 / speed);
      tangential = scale(tangentUnit, dot(acceleration, tangentUnit));
      centripetal = sub(acceleration, tangential);
      if (item === TRAJECTORIES.mc) {
        const circle = circularState(t);
        tangential = scale(circle.tangent,circle.R*circle.alpha);
        centripetal = scale(circle.radial,-circle.R*circle.omega*circle.omega);
      }
    }

    const jerk = jerkAt(item, item.closed ? wrap(t, item.duration) : t);
    return { position: p, velocity, acceleration, jerk, tangential, centripetal, speed, decompositionDefined };
  }

  function clipToPlot(callback) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(plotRect.left, plotRect.top, plotRect.width, plotRect.height);
    ctx.clip();
    callback();
    ctx.restore();
  }

  function drawLineScreen(a, b, color, width = 1, alpha = 1, dash = []) {
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = 'round';
    ctx.setLineDash(dash);
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
    ctx.restore();
  }

  function drawAxes() {
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,0.88)';
    ctx.fillRect(plotRect.left, plotRect.top, plotRect.width, plotRect.height);
    ctx.restore();

    clipToPlot(() => {
      if (state.grid) {
        const step = GRID_STEP_METRES;
        const xStart = Math.ceil((view.xmin - origin.x) / step) * step + origin.x;
        const yStart = Math.ceil((view.ymin - origin.y) / step) * step + origin.y;
        ctx.save();
        ctx.lineWidth = 1;
        ctx.strokeStyle = 'rgba(148,168,186,0.20)';
        for (let x = xStart; x <= view.xmax + 1e-9; x += step) {
          const s = worldToScreen(V(x, 0));
          ctx.beginPath();
          ctx.moveTo(s.x, plotRect.top);
          ctx.lineTo(s.x, plotRect.bottom);
          ctx.stroke();
        }
        for (let y = yStart; y <= view.ymax + 1e-9; y += step) {
          const s = worldToScreen(V(0, y));
          ctx.beginPath();
          ctx.moveTo(plotRect.left, s.y);
          ctx.lineTo(plotRect.right, s.y);
          ctx.stroke();
        }
        ctx.restore();
      }

      if (view.xmin <= origin.x && view.xmax >= origin.x) {
        const x0 = worldToScreen(origin).x;
        drawLineScreen(V(x0, plotRect.top), V(x0, plotRect.bottom), '#8190a5', 1.7, 0.85);
      }
      if (view.ymin <= origin.y && view.ymax >= origin.y) {
        const y0 = worldToScreen(origin).y;
        drawLineScreen(V(plotRect.left, y0), V(plotRect.right, y0), '#8190a5', 1.7, 0.85);
      }
    });

    ctx.save();
    ctx.strokeStyle = '#bbcbd9';
    ctx.lineWidth = 1;
    ctx.strokeRect(plotRect.left, plotRect.top, plotRect.width, plotRect.height);
    ctx.restore();

    const range = relativeView();
    const xTickValues = axisTickValues(range.xmin, range.xmax);
    const yTickValues = axisTickValues(range.ymin, range.ymax);
    ctx.save();
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 1.2;
    for (const tick of xTickValues) {
      const s = worldToScreen(V(tick + origin.x, view.ymin));
      ctx.beginPath();
      ctx.moveTo(s.x, plotRect.bottom);
      ctx.lineTo(s.x, plotRect.bottom + 7);
      ctx.stroke();
    }
    for (const tick of yTickValues) {
      const s = worldToScreen(V(view.xmin, tick + origin.y));
      ctx.beginPath();
      ctx.moveTo(plotRect.left - 7, s.y);
      ctx.lineTo(plotRect.left, s.y);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawTrail(item) {
    if (state.time <= 0) return;
    const startTime = state.fullTrail ? 0 : Math.max(0, state.time - state.trailDuration);
    const timeSpan = Math.max(0, state.time - startTime);
    const segments = clamp(Math.ceil(timeSpan * 30), 2, 500);
    const [r, g, b] = COLORS.trail;

    clipToPlot(() => {
      let previous = worldToScreen(positionAt(item, startTime));
      for (let index = 1; index <= segments; index += 1) {
        const u = index / segments;
        const time = startTime + timeSpan * u;
        const current = worldToScreen(positionAt(item, time));
        const alpha = state.fullTrail ? 1 : 0.025 + 0.86 * u ** 1.65;
        drawLineScreen(previous, current, `rgb(${r},${g},${b})`, 2.7, alpha);
        previous = current;
      }
    });
  }

  function drawProjectionSystem(position) {
    if (!state.projections) return;
    const p = worldToScreen(position);
    const px = worldToScreen(V(position.x, origin.y));
    const py = worldToScreen(V(origin.x, position.y));

    clipToPlot(() => {
      drawLineScreen(p, px, COLORS.position, 1.15, 0.38, [6, 6]);
      drawLineScreen(p, py, COLORS.position, 1.15, 0.38, [6, 6]);

      for (const point of [px, py]) {
        ctx.save();
        ctx.fillStyle = 'rgba(217,104,59,0.68)';
        ctx.strokeStyle = 'rgba(255,255,255,0.92)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(point.x, point.y, 4.8, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      }
    });
  }

  function drawArrow(startWorld, vectorWorld, lengthScale, color) {
    const start = worldToScreen(startWorld);
    const end = worldToScreen(add(startWorld, scale(vectorWorld, lengthScale)));
    const dx = end.x - start.x;
    const dy = end.y - start.y;
    const length = Math.hypot(dx, dy);
    if (!Number.isFinite(length) || length < ARROW.minimumLengthPx) return;

    const direction = V(dx / length, dy / length);
    const perpendicular = V(-direction.y, direction.x);
    const headLength = Math.min(ARROW.headLengthPx, length * 0.65);
    const headHalfWidth = Math.min(ARROW.headHalfWidthPx, headLength * 0.38);
    const shaftHalfWidth = Math.min(ARROW.shaftWidthPx / 2, headHalfWidth * 0.55);
    const headBase = sub(end, scale(direction, headLength));
    const neck = sub(end, scale(direction, headLength * 0.72));
    // One continuous silhouette: swept-back wings and a seamless shaft,
    // without a white outline crossing their junction.
    const outline = [
      add(start, scale(perpendicular, shaftHalfWidth)),
      add(neck, scale(perpendicular, shaftHalfWidth)),
      add(headBase, scale(perpendicular, headHalfWidth)),
      end,
      sub(headBase, scale(perpendicular, headHalfWidth)),
      sub(neck, scale(perpendicular, shaftHalfWidth)),
      sub(start, scale(perpendicular, shaftHalfWidth)),
    ];
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(outline[0].x, outline[0].y);
    for (const point of outline.slice(1)) ctx.lineTo(point.x, point.y);
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
    ctx.restore();
  }

  function drawDecompositionParallelogram(item, data, selected) {
    if (!data.decompositionDefined || !(selected.tangential && selected.centripetal)) return;
    const factor = item.scaleA * state.vectorScale;
    const pTangential = add(data.position, scale(data.tangential, factor));
    const pCentripetal = add(data.position, scale(data.centripetal, factor));
    const pTotal = add(data.position, scale(data.acceleration, factor));
    drawLineScreen(worldToScreen(pTangential), worldToScreen(pTotal), '#667085', 1.25, 0.72, [7, 6]);
    drawLineScreen(worldToScreen(pCentripetal), worldToScreen(pTotal), '#667085', 1.25, 0.72, [7, 6]);
  }

  function drawSelectedVectors(item, data) {
    const selected = vectorSelection();
    drawDecompositionParallelogram(item, data, selected);

    if (selected.position) drawArrow(origin, relativePosition(data.position), 1, COLORS.position);
    if (selected.acceleration) drawArrow(data.position, data.acceleration, item.scaleA * state.vectorScale, COLORS.acceleration);
    if (selected.centripetal && data.decompositionDefined) drawArrow(data.position, data.centripetal, item.scaleA * state.vectorScale, COLORS.centripetal);
    if (selected.tangential && data.decompositionDefined) drawArrow(data.position, data.tangential, item.scaleA * state.vectorScale, COLORS.tangential);
    if (selected.velocity) drawArrow(data.position, data.velocity, item.scaleV * state.vectorScale, COLORS.velocity);
    if (selected.jerk) drawArrow(data.position, data.jerk, jerkDisplayScale(item) * state.vectorScale, COLORS.jerk);
  }

  function drawParticle(position, velocity) {
    const point = worldToScreen(position);
    const ahead = worldToScreen(add(position, scale(velocity,.02)));
    const angle = Math.hypot(ahead.x-point.x,ahead.y-point.y) > 1e-5 ? Math.atan2(ahead.y-point.y,ahead.x-point.x) : 0;
    if (PhysMobile.draw(ctx, state.mobileAppearance, point.x, point.y, {angle, time:state.time})) return;
    ctx.save();
    ctx.shadowColor = 'rgba(15,23,42,0.22)';
    ctx.shadowBlur = 3;
    ctx.fillStyle = COLORS.position;
    ctx.strokeStyle = 'rgba(255,255,255,0.96)';
    ctx.lineWidth = 2.7;
    ctx.beginPath();
    ctx.arc(point.x, point.y, 7.2, 0, 2 * Math.PI);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  function drawOsculatingCircle(circle) {
    if (!circle) return;
    const center = worldToScreen(circle.center);
    const radius = circle.radius * plotRect.width / (view.xmax - view.xmin);
    let last = null;
    let nodes = 0;
    const trace = (a, b, p, q, level) => {
      const sagitta = 2 * radius * Math.sin((b - a) / 4) ** 2;
      if (Math.max(p.x, q.x) + sagitta < plotRect.left || Math.min(p.x, q.x) - sagitta > plotRect.right
        || Math.max(p.y, q.y) + sagitta < plotRect.top || Math.min(p.y, q.y) - sagitta > plotRect.bottom) {
        last = null;
        return;
      }
      if (++nodes > 8192) { last = null; return; }
      if (sagitta <= 0.35) {
        const segment = clipScreenSegment(p, q, plotRect);
        if (!segment) { last = null; return; }
        const [start, end] = segment;
        if (!last || Math.hypot(start.x - last.x, start.y - last.y) > 0.01) ctx.moveTo(start.x, start.y);
        ctx.lineTo(end.x, end.y);
        last = end;
      } else if (level < 36) {
        const middle = (a + b) / 2;
        const m = worldToScreen(osculatingPoint(circle, middle));
        trace(a, middle, p, m, level + 1);
        trace(middle, b, m, q, level + 1);
      } else last = null;
    };
    clipToPlot(() => {
      ctx.save();
      ctx.strokeStyle = '#268576';
      ctx.lineWidth = 1.5;
      ctx.globalAlpha = 0.8;
      ctx.setLineDash([6, 5]);
      ctx.beginPath();
      // Tessellation anchored at the mobile also keeps very large circles
      // accurate on canvas implementations that store paths as 32-bit floats.
      for (let i = 0; i < 8; i += 1) {
        const a = i * Math.PI / 4;
        const b = (i + 1) * Math.PI / 4;
        trace(a, b, worldToScreen(osculatingPoint(circle, a)), worldToScreen(osculatingPoint(circle, b)), 0);
      }
      ctx.stroke();
      ctx.restore();
      drawRadiusAnnotation(worldToScreen(circle.position), center, plotRect);
    });
  }

  function drawScene(item, data) {
    ctx.clearRect(0, 0, viewportWidth, viewportHeight);
    drawAxes();
    drawOsculatingCircle(updateCurvatureReadout(data));
    drawTrail(item);
    drawProjectionSystem(data.position);
    drawSelectedVectors(item, data);
    drawParticle(data.position, data.velocity);
  }

  function updateCurvatureReadout(data) {
    dom.radiusLabel.hidden = true;
    dom.curvatureDetails.hidden = !dom.osculating.checked;
    if (!dom.osculating.checked) return null;
    const circle = osculatingGeometry(data);
    dom.curvatureValue.hidden = !circle.defined;
    dom.curvatureStatus.hidden = circle.defined;
    if (!circle.defined) {
      const messages = {
        stationary: physTranslate('Vitesse quasi nulle : le cercle osculateur et son rayon sont indéfinis.'),
        straight: physTranslate('Courbure quasi nulle : le rayon tend vers l’infini ; aucun cercle fini n’est tracé.'),
        unresolved: physTranslate('Le rayon de courbure ne peut pas être résolu à cet instant.'),
      };
      dom.curvatureStatus.textContent = messages[circle.reason];
      return null;
    }
    const scientific = circle.radius >= 1e5 || circle.radius < 0.01;
    dom.curvatureScientific.hidden = !scientific;
    if (scientific) {
      const [mantissa, exponent] = circle.radius.toExponential(2).split('e');
      setMathDigits(dom.curvatureDigits, mantissa);
      setMathDigits(dom.curvatureExponent, String(Number(exponent)));
    } else {
      setMathDigits(dom.curvatureDigits, circle.radius.toFixed(2));
    }
    dom.curvatureValue.setAttribute('aria-label', physTranslate('Rayon de courbure : ') + circle.radius.toPrecision(5) + physTranslate(' mètres'));
    return circle;
  }

  function drawRadiusAnnotation(start, center, bounds) {
    const segment = clipScreenSegment(start, center, bounds);
    if (!segment) return;
    const [a, b] = segment;
    ctx.save();
    ctx.strokeStyle = '#268576';
    ctx.lineWidth = 1.6;
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
    // A small cross marks the actual center, never an artificially clipped endpoint.
    if (center.x > bounds.left + 5 && center.x < bounds.right - 5
      && center.y > bounds.top + 5 && center.y < bounds.bottom - 5) {
      ctx.beginPath();
      ctx.moveTo(center.x - 4, center.y);
      ctx.lineTo(center.x + 4, center.y);
      ctx.moveTo(center.x, center.y - 4);
      ctx.lineTo(center.x, center.y + 4);
      ctx.stroke();
    }
    ctx.restore();
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const length = Math.hypot(dx, dy);
    if (length < 36) return;
    const x = (a.x + b.x) / 2 - 14 * dy / length;
    const y = (a.y + b.y) / 2 + 14 * dx / length;
    if (x < bounds.left + 20 || x > bounds.right - 20 || y < bounds.top + 20 || y > bounds.bottom - 20) return;
    dom.radiusLabel.hidden = false;
    dom.radiusLabel.style.left = x + 'px';
    dom.radiusLabel.style.top = y + 'px';
  }

  function updateReadouts(data) {
    const vectors = {
      position: relativePosition(data.position),
      velocity: data.velocity,
      acceleration: data.acceleration,
      tangential: data.tangential,
      centripetal: data.centripetal,
      jerk: data.jerk,
    };
    const selected = vectorSelection();

    for (const [key, vector] of Object.entries(vectors)) {
      const elements = readoutElements[key];
      const magnitude = norm(vector).toFixed(2);
      const componentX = vector.x.toFixed(2);
      const componentY = vector.y.toFixed(2);

      elements.root.classList.toggle('visible', selected[key]);
      setMathDigits(elements.magnitude, magnitude);
      setMathDigits(elements.componentX, componentX);
      setMathDigits(elements.componentY, componentY);
      elements.root.setAttribute(
        'aria-label',
        physTranslate(`${elements.meta.plainName} : norme ${magnitude} ; composantes (${componentX}, ${componentY})`),
      );
    }
  }

  function updateEquationOffsets() {
    const frame = equationFrame(currentTrajectory(), origin);
    for (const element of dom.equations.querySelectorAll('[data-offset-axis]')) {
      const axis = element.dataset.offsetAxis;
      const value = frame.offset[axis];
      const text = (Math.abs(value) < 0.005 ? 0 : value).toFixed(2);
      setMathDigits(element, text);
      element.parentElement.setAttribute('aria-label', physTranslate(`${axis}, constante de position : ${text} mètres`));
    }
  }

  function updateEquationPanel() {
    const item = currentTrajectory();
    const frame = equationFrame(item, origin);
    const isMC = state.trajectoryKey === 'mc';
    dom.mcControls.hidden = !isMC;
    dom.lissajousControls.hidden = !item.lissajousOrder;
    dom.lissajousMode.value = lissajousMode(item.lissajousOrder);
    dom.lissajousDescription.textContent = dom.lissajousMode.value==='original'
      ? physTranslate('Loi sinusoïdale originale : le module de la vitesse et celui de l’accélération varient.')
      : physTranslate('La distance parcourue est proportionnelle au temps. L’accélération est uniquement centripète. L désigne la longueur totale de la courbe.');
    // Only the numbers below change during an origin drag. Keeping the TeX
    // and line count fixed avoids reflow, delayed updates and mobile jumps.
    if (mathIsReady && window.MathJax?.typesetClear) window.MathJax.typesetClear([dom.equations]);
    dom.equations.innerHTML = [
      ...item.equations.map((equation) => `<div class="equation"><span class="tex-math">\\(\\displaystyle ${equation}\\)</span></div>`),
      ...['x', 'y'].map(axis => `<div class="equation parameters equation-numeric"><span class="tex-math">\\(${axis}_{${frame.subscript}}=\\)</span><span class="math-digits" data-offset-axis="${axis}"></span><span class="tex-math">\\(\\,\\mathrm m\\)</span></div>`),
      ...frame.parameters.map((parameter) => `<div class="equation parameters parameter-line"><span class="tex-math">\\(${parameter}\\)</span></div>`),
      ...(isMC ? [
        ['R',String.raw`R=`,String.raw`\mathrm m`],
        ['omega',String.raw`\omega_0=`,String.raw`\mathrm{rad\,s^{-1}}`],
        ['alpha',String.raw`\alpha=`,String.raw`\mathrm{rad\,s^{-2}}`],
        ['tmax',String.raw`t_{\max}=`,String.raw`\mathrm s`],
      ].map(([key,symbol,unit])=>`<div class="equation parameters equation-numeric"><span class="tex-math">\\(${symbol}\\)</span><span class="math-digits" data-mc-value="${key}"></span><span class="tex-math">\\(\\,${unit}\\)</span></div>`) : []),
    ].join('');
    updateEquationOffsets();
    updateMCReadouts();
    if (mathIsReady) void queueTypeset([dom.equations]);
  }

  function updateAxisLabelPositions() {
    computePlotRect();
    if (!mathIsReady) return;

    const place = (element, x, y, visible = true) => {
      element.hidden = !visible;
      if (!visible) return;
      element.style.left = `${x}px`;
      element.style.top = `${y}px`;
    };

    place(dom.axisLabels.x, plotRect.left + 0.5 * plotRect.width, plotRect.bottom + 54);
    place(dom.axisLabels.y, plotRect.left - 50, plotRect.top - 18);

    const range = relativeView();
    const xTicks = axisTickValues(range.xmin, range.xmax);
    const yTicks = axisTickValues(range.ymin, range.ymax);
    synchronizeAxisTickElements('x', xTicks);
    synchronizeAxisTickElements('y', yTicks);

    for (const tick of xTicks) {
      const sx = worldToScreen(V(tick + origin.x, view.ymin)).x;
      place(axisTickElements.x.get(tick).root, sx, plotRect.bottom + 14);
    }
    for (const tick of yTicks) {
      const sy = worldToScreen(V(view.xmin, tick + origin.y)).y;
      place(axisTickElements.y.get(tick).root, plotRect.left - 14, sy);
    }
  }

  function applyVectorPreset(name) {
    const selected = {
      position: false,
      velocity: false,
      acceleration: false,
      tangential: false,
      centripetal: false,
      jerk: false,
    };
    if (name === 'velocity') selected.velocity = true;
    if (name === 'acceleration') selected.acceleration = true;
    if (name === 'decomposition') {
      selected.acceleration = true;
      selected.tangential = true;
      selected.centripetal = true;
    }
    if (name === 'all') Object.keys(selected).forEach((key) => { selected[key] = true; });
    for (const [key, checked] of Object.entries(selected)) dom.toggles[key].checked = checked;
  }

  function setPlaying(playing) {
    state.playing = playing;
    dom.play.textContent = playing ? 'Pause' : physTranslate('Lire');
    dom.play.setAttribute('aria-label', playing ? physTranslate('Mettre l’animation en pause') : physTranslate('Lire l’animation'));
  }

  function updateAndDraw() {
    if (!ctx) return;
    computePlotRect();
    const item = currentTrajectory();
    const data = derivatives(item, state.time);
    const selected = vectorSelection();

    dom.timeSlider.value = String(state.time);
    setMathDigits(dom.timeOutputDigits, state.time.toFixed(2));
    setMathDigits(dom.timeBadgeDigits, state.time.toFixed(2));
    updateReadouts(data);
    updateAxisLabelPositions();

    const decompositionRequested = selected.tangential || selected.centripetal;
    dom.warning.hidden = !(decompositionRequested && !data.decompositionDefined);
    dom.warning.textContent = physTranslate('La décomposition tangentielle / centripète est indéfinie car la vitesse instantanée est approximativement nulle.');
    drawScene(item, data);
    positionOriginHandle();
  }

  function configureTimeline() {
    const timeMax = trajectoryTimeMax(currentTrajectory());
    dom.timeSlider.max = String(timeMax);
    dom.timeSlider.step = String(Math.max(0.001, timeMax / 6000));
  }

  function onTrajectoryChanged() {
    state.trajectoryKey = dom.trajectory.value;
    state.time = 0;
    configureTimeline();
    resetView();
    updateEquationPanel();
    updateAndDraw();
  }

  dom.trajectory.addEventListener('change', onTrajectoryChanged);
  dom.lissajousMode.addEventListener('change', () => {
    const order=currentTrajectory().lissajousOrder;
    if (!order || !LISSAJOUS_MODES.includes(dom.lissajousMode.value)) return;
    lissajousParameters[order===3 ? 'mode3' : 'mode'] = dom.lissajousMode.value;
    state.time = 0;
    updateEquationPanel();
    updateAndDraw();
  });
  dom.mobileAppearance.addEventListener('change', () => {
    state.mobileAppearance = dom.mobileAppearance.value;
    updateAndDraw();
  });
  dom.mcRadius.addEventListener('input',()=>changeMCParameters(Number(dom.mcRadius.value),mcParameters.omega,mcParameters.alpha));
  dom.mcOmega.addEventListener('input',()=>changeMCParameters(mcParameters.R,Number(dom.mcOmega.value),mcParameters.alpha));
  dom.mcAlpha.addEventListener('input',()=>changeMCParameters(mcParameters.R,mcParameters.omega,Number(dom.mcAlpha.value)));
  dom.mcReset.addEventListener('click',()=>changeMCParameters(MC_DEFAULTS.R,MC_DEFAULTS.omega,MC_DEFAULTS.alpha));
  dom.play.addEventListener('click', () => setPlaying(!state.playing));
  dom.reset.addEventListener('click', () => {
    state.time = 0;
    updateAndDraw();
  });
  dom.resetView.addEventListener('click', () => {
    resetView();
    updateAndDraw();
  });
  dom.moveOrigin.addEventListener('click', () => {
    movingOrigin = !movingOrigin;
    dom.moveOrigin.setAttribute('aria-pressed', String(movingOrigin));
    viewport.classList.toggle('moving-origin', movingOrigin);
    updateAndDraw();
  });
  dom.resetOrigin.addEventListener('click', () => setOrigin(V(0, 0)));
  dom.speed.addEventListener('change', () => {
    state.playbackSpeed = Number(dom.speed.value);
  });
  dom.loop.addEventListener('change', () => {
    state.loop = dom.loop.checked;
  });
  dom.vectorScale.addEventListener('input', () => {
    state.vectorScale = Number(dom.vectorScale.value);
    setMathDigits(dom.vectorScaleOutputDigits, state.vectorScale.toFixed(2));
    updateAndDraw();
  });
  dom.trailDuration.addEventListener('input', () => {
    state.trailDuration = Number(dom.trailDuration.value);
    setMathDigits(dom.trailDurationOutputDigits, state.trailDuration.toFixed(1));
    updateAndDraw();
  });
  dom.fullTrail.addEventListener('change', () => {
    state.fullTrail = dom.fullTrail.checked;
    dom.trailDuration.disabled = state.fullTrail;
    dom.trailDurationControls.hidden = state.fullTrail;
    updateAndDraw();
  });
  dom.osculating.addEventListener('change', updateAndDraw);
  dom.projections.addEventListener('change', () => {
    state.projections = dom.projections.checked;
    updateAndDraw();
  });
  dom.grid.addEventListener('change', () => {
    state.grid = dom.grid.checked;
    updateAndDraw();
  });
  dom.timeSlider.addEventListener('input', () => {
    state.time = Number(dom.timeSlider.value);
    updateAndDraw();
  });
  dom.clearVectors.addEventListener('click', () => {
    applyVectorPreset('none');
    updateAndDraw();
  });
  Object.values(dom.toggles).forEach((input) => input.addEventListener('change', updateAndDraw));
  document.querySelectorAll('[data-vector-preset]').forEach((button) => {
    button.addEventListener('click', () => {
      applyVectorPreset(button.dataset.vectorPreset);
      updateAndDraw();
    });
  });

  const pointerScreen = (event) => {
    const rect = canvas.getBoundingClientRect();
    return V(event.clientX - rect.left, event.clientY - rect.top);
  };
  const zoomView = (anchor, cursor, spanX, spanY) => {
    const xFraction = (cursor.x - plotRect.left) / plotRect.width;
    const yFraction = (plotRect.bottom - cursor.y) / plotRect.height;
    view.xmin = anchor.x - xFraction * spanX;
    view.xmax = view.xmin + spanX;
    view.ymin = anchor.y - yFraction * spanY;
    view.ymax = view.ymin + spanY;
    updateAndDraw();
  };
  const pinchGeometry = (ids) => {
    const [a, b] = ids.map(id => pointers.get(id).point);
    return { center: scale(add(a, b), .5), distance: Math.hypot(b.x - a.x, b.y - a.y) };
  };
  const beginPinch = () => {
    const ids = [...pointers.keys()].slice(0, 2), { center, distance } = pinchGeometry(ids);
    // A second finger takes precedence over moving O. Undo the first finger's
    // tentative origin change, including a tap in "Déplacer l’origine" mode.
    if (originDrag && touchOrigin) setOrigin(touchOrigin);
    originDrag = null;
    panPointer = null;
    pinch = { ids, distance: Math.max(1, distance), anchor: screenToWorld(center),
      spanX: view.xmax - view.xmin, spanY: view.ymax - view.ymin };
    viewport.classList.add('dragging');
  };
  dom.originHandle.addEventListener('keydown', (event) => {
    const directions = { ArrowLeft: V(-1, 0), ArrowRight: V(1, 0), ArrowUp: V(0, 1), ArrowDown: V(0, -1) };
    if (!directions[event.key]) return;
    event.preventDefault();
    setOrigin(add(origin, scale(directions[event.key], event.shiftKey ? 1 : 0.1)));
  });

  viewport.addEventListener('pointerdown', (event) => {
    const onOrigin = dom.originHandle.contains(event.target);
    if ((!onOrigin && event.target !== canvas) || event.button !== 0) return;
    // Multi-touch is supported; a mouse or pen cannot hijack another pointer.
    if (pointers.size && (event.pointerType !== 'touch'
      || [...pointers.values()].some(pointer => pointer.type !== 'touch'))) return;
    event.preventDefault();
    if (!pointers.size) touchOrigin = { ...origin };
    const point = pointerScreen(event);
    pointers.set(event.pointerId, { point, type: event.pointerType });
    viewport.setPointerCapture(event.pointerId);
    if (pointers.size >= 2) {
      if (!pinch) beginPinch();
      return;
    }
    if (movingOrigin || onOrigin) {
      const world = screenToWorld(point);
      if (!onOrigin && (world.x < view.xmin || world.x > view.xmax || world.y < view.ymin || world.y > view.ymax)) return;
      if (!onOrigin) setOrigin(world);
      originDrag = { pointerId: event.pointerId, offset: sub(origin, world) };
    } else {
      panPointer = event.pointerId;
      viewport.classList.add('dragging');
    }
  });

  viewport.addEventListener('pointermove', (event) => {
    const pointer = pointers.get(event.pointerId);
    if (!pointer) return;
    event.preventDefault();
    const previous = pointer.point;
    pointer.point = pointerScreen(event);
    if (pinch) {
      if (!pinch.ids.includes(event.pointerId)) return;
      const { center, distance } = pinchGeometry(pinch.ids);
      const spanX = clamp(pinch.spanX * pinch.distance / Math.max(1, distance), 1, 18);
      zoomView(pinch.anchor, center, spanX, spanX * pinch.spanY / pinch.spanX);
      return;
    }
    if (originDrag?.pointerId === event.pointerId) {
      const point = add(screenToWorld(pointer.point), originDrag.offset);
      setOrigin(V(clamp(point.x, view.xmin, view.xmax), clamp(point.y, view.ymin, view.ymax)));
      return;
    }
    if (panPointer !== event.pointerId) return;
    const dx = pointer.point.x - previous.x, dy = pointer.point.y - previous.y;
    const spanX = view.xmax - view.xmin;
    const spanY = view.ymax - view.ymin;
    const shiftX = dx * spanX / plotRect.width;
    const shiftY = dy * spanY / plotRect.height;
    view.xmin -= shiftX;
    view.xmax -= shiftX;
    view.ymin += shiftY;
    view.ymax += shiftY;
    updateAndDraw();
  });

  const stopPointer = (event) => {
    if (!pointers.delete(event.pointerId)) return;
    if (originDrag?.pointerId === event.pointerId) originDrag = null;
    if (panPointer === event.pointerId) panPointer = null;
    if (pinch?.ids.includes(event.pointerId)) {
      pinch = null;
      if (pointers.size >= 2) beginPinch();
      // Rebase at the remaining finger: no jump and no accidental move of O.
      else if (pointers.size === 1) panPointer = pointers.keys().next().value;
    }
    if (!pointers.size) touchOrigin = null;
    viewport.classList.toggle('dragging', pinch !== null || panPointer !== null);
    if (viewport.hasPointerCapture(event.pointerId)) viewport.releasePointerCapture(event.pointerId);
  };
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) viewport.addEventListener(type, stopPointer);
  const cancelPointers = () => {
    const ids = [...pointers.keys()];
    pointers.clear();panPointer = null;pinch = null;originDrag = null;touchOrigin = null;
    viewport.classList.remove('dragging');
    for (const id of ids) if (viewport.hasPointerCapture(id)) viewport.releasePointerCapture(id);
  };
  window.addEventListener('blur', cancelPointers);
  document.addEventListener('visibilitychange', () => { if (document.hidden) cancelPointers(); });

  canvas.addEventListener('wheel', (event) => {
    event.preventDefault();
    if (pointers.size) return;
    const cursor = pointerScreen(event);
    const anchor = screenToWorld(cursor);
    const currentSpan = view.xmax - view.xmin;
    const factor = Math.exp(event.deltaY * 0.0012);
    const newSpan = clamp(currentSpan * factor, 1, 18);
    zoomView(anchor, cursor, newSpan, newSpan * (view.ymax - view.ymin) / currentSpan);
  }, { passive: false });

  document.addEventListener('keydown', (event) => {
    const tag = document.activeElement?.tagName?.toLowerCase();
    if (tag === 'input' || tag === 'select' || tag === 'button') return;
    if (event.code === 'Space') {
      event.preventDefault();
      setPlaying(!state.playing);
    }
    if (event.key.toLowerCase() === 'r') {
      state.time = 0;
      updateAndDraw();
    }
  });

  const resizeObserver = new ResizeObserver(resizeCanvas);
  resizeObserver.observe(viewport);
  window.addEventListener('resize', resizeCanvas);

  let previousTimestamp = performance.now();
  function animate(timestamp) {
    const elapsed = Math.min(0.1, Math.max(0, (timestamp - previousTimestamp) / 1000));
    previousTimestamp = timestamp;
    if (state.playing) {
      const timeMax = trajectoryTimeMax(currentTrajectory());
      state.time += elapsed * state.playbackSpeed;
      if (state.time > timeMax) {
        if (state.loop) state.time %= timeMax;
        else {
          state.time = timeMax;
          setPlaying(false);
        }
      }
    }
    updateAndDraw();
    requestAnimationFrame(animate);
  }

  async function initializeApplication() {
    dom.trajectory.value = state.trajectoryKey;
    dom.fullTrail.checked = state.fullTrail;
    dom.trailDuration.disabled = state.fullTrail;
    dom.trailDurationControls.hidden = state.fullTrail;
    configureTimeline();
    updateOriginControls();
    updateEquationPanel();
    resizeCanvas();
    updateAndDraw();

    try {
      if (!window.MathJax?.startup?.promise) throw new Error(physTranslate('Le moteur MathJax intégré ne s’est pas initialisé.'));
      await window.MathJax.startup.promise;
      await window.MathJax.typesetPromise();
      await initializeMathGlyphs();
      mathIsReady = true;
      updateDynamicMathOutputs();
      updateOriginControls();
      updateAxisLabelPositions();
      updateAndDraw();
    } catch (error) {
      console.error(error);
      loadingMessage.textContent = physTranslate('L’animation est chargée, mais le rendu TeX a échoué. Consultez la console du navigateur.');
      setTimeout(() => loadingMessage.remove(), 2500);
    }

    if (loadingMessage.isConnected) loadingMessage.remove();

    const shared = await window.PhysShare?.register({id:'kinematics-2d',pause:()=>setPlaying(false),
      capture:()=>({state:PhysShare.pick(state,'trajectoryKey time playbackSpeed loop vectorScale trailDuration fullTrail projections grid mobileAppearance'),mc:{...mcParameters},lissajous:{...lissajousParameters},origin:{...origin},view:{...view},movingOrigin}),
      restore:(s,ui)=>{
        PhysShare.member(s.state.trajectoryKey,Object.keys(TRAJECTORIES));
        // Locally shared links from the retired experimental mode use the original law.
        const lissajousMode = s.lissajous?.mode === 'constant-acceleration' ? 'original' : s.lissajous?.mode ?? 'original';
        PhysShare.member(lissajousMode,LISSAJOUS_MODES);
        const lissajousMode3 = s.lissajous?.mode3 ?? 'original';
        PhysShare.member(lissajousMode3,LISSAJOUS_MODES);
        s.state.mobileAppearance = PhysMobile.normalize(s.state.mobileAppearance ?? 'point');
        PhysShare.member(s.state.mobileAppearance,PhysMobile.kinds);
        PhysShare.range(s.mc.R,.25,3);PhysShare.range(s.mc.omega,.1,2);PhysShare.range(s.mc.alpha,-.2,.2);
        if(!(s.view.xmax>s.view.xmin&&s.view.ymax>s.view.ymin))throw Error(physTranslate('Vue non valide.'));
        for(const key of ['xmin','xmax','ymin','ymax'])PhysShare.range(s.view[key],-1e4,1e4);
        PhysShare.range(s.view.xmax-s.view.xmin,.001,1e4);PhysShare.range(s.view.ymax-s.view.ymin,.001,1e4);
        setPlaying(false);originDrag=null;PhysShare.set(mcParameters,s.mc);PhysShare.set(state,s.state);state.playing=false;
        lissajousParameters.mode=lissajousMode;
        lissajousParameters.mode3=lissajousMode3;
        PhysShare.range(state.time,0,trajectoryTimeMax(currentTrajectory()));
        PhysShare.set(view,s.view);PhysShare.set(origin,s.origin);ui();
        dom.mobileAppearance.value=state.mobileAppearance;
        movingOrigin=!!s.movingOrigin;dom.moveOrigin.setAttribute('aria-pressed',String(movingOrigin));viewport.classList.toggle('moving-origin',movingOrigin);
        dom.trailDuration.disabled=state.fullTrail;dom.trailDurationControls.hidden=state.fullTrail;
        configureTimeline();updateEquationPanel();updateMCReadouts();updateOriginControls();updateDynamicMathOutputs();updateAndDraw();
      }
    });

    if (navigator.webdriver) {
      setPlaying(false);
      if (!shared) state.time = 2.4;
      updateAndDraw();
    } else {
      requestAnimationFrame(animate);
    }
  }

  void initializeApplication();
})();
