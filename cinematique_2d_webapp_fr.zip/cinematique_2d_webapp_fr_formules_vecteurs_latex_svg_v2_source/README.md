# Cinématique 2D interactive

Application web autonome en français, inspirée du notebook Julia `Cinématique_loop.ipynb`.

## Fonctionnalités

- affichage numérique uniquement dans les cadres associés aux grandeurs vectorielles ;
- mention « © J. Martin » maintenue sur une seule ligne.

- 17 trajectoires planes, dont les mouvements du notebook :
  - Lissajous $n=2$ ;
  - Lissajous $n=3$ ;
  - mouvement circulaire uniformément accéléré ;
  - courbe poisson ;
  - astroïde ;
  - quadrifolium ;
  - mouvement balistique.
- Courbes supplémentaires : cardioïde, lemniscate de Bernoulli, rose à cinq pétales, spirale d’Archimède, cycloïde, deltoïde, néphroïde, hypotrochoïde, cœur et papillon.
- Choix indépendant des vecteurs :
  - position `r(t)` ;
  - vitesse `v(t)` ;
  - accélération `a(t)` ;
  - accélération tangentielle `a_t(t)` ;
  - accélération centripète `a_c(t)`.
- Le vecteur position part toujours de l’origine globale `(0, 0)`.
- La longueur des tiges varie avec la norme des vecteurs, tandis que la largeur des tiges et la géométrie des pointes restent fixes à l’écran.
- Décomposition de l’accélération avec parallélogramme pointillé.
- Traînée temporelle à disparition progressive ; en mode « historique complet », toute la courbe reste à opacité constante.
- Projections de la particule sur les axes.
- Grille, déplacement de la vue par glissement et zoom à la molette ; les graduations sont affichées tous les 2000 m sur le domaine visible.
- Toutes les expressions mathématiques, les axes et le temps sont composés en TeX et rendus en SVG par une copie locale de MathJax.
- Pour une trajectoire fermée, la borne temporelle par défaut vaut deux fois la durée d’un parcours complet.
- Valeurs numériques composées en TeX sous les formes $|\vec v|=\cdots$ et $\vec v=(\cdots,\cdots)$.

## Utilisation

### Fichier autonome

Ouvrir directement :

```text
cinematique_2d_webapp_fr_formules_vecteurs_latex_svg.html
```

Ce fichier inclut le CSS, le JavaScript et MathJax ; aucune connexion internet n’est requise.

### Version source

Dans le dossier source :

```bash
./serve.sh
```

puis ouvrir :

```text
http://127.0.0.1:8000
```

## Commandes

- `Espace` : lire ou mettre en pause ;
- `R` : revenir à `t = 0` ;
- glissement dans la figure : déplacer la vue ;
- molette : zoomer autour du pointeur ;
- « Réinitialiser la vue » : restaurer le domaine `[0, 4000] × [0, 4000]`.

## Structure

```text
cinematique_2d_webapp_fr_formules_vecteurs_latex_svg_source/
├── index.html
├── style.css
├── app.js
├── serve.sh
├── README.md
└── vendor/
    └── mathjax/
        ├── tex-svg.js
        └── LICENSE
```

## Remarque sur le notebook source

Dans quelques définitions du notebook, la composante `y(t)` utilise `x0` au lieu de `y0`. L’application emploie la notation sémantiquement correcte `y0`. Dans les paramètres du notebook, `x0 = y0`, de sorte que cette correction ne modifie pas les trajectoires numériques correspondantes.

## Identification

L’en-tête affiche « PHYS1985 - ULiege ».
