# Cinématique 2D interactive

Application web autonome en français, inspirée du notebook Julia `Cinématique_loop.ipynb`.

## Fonctionnalités

L’option « À-coup » affiche le vecteur \(\vec{\jmath}=\mathrm d\vec a/\mathrm dt\), sa norme et ses composantes en \(\mathrm{m\,s^{-3}}\). La couleur ocre et le rendu LaTeX sont communs aux versions 2D et 3D. La sélection « Tous » l’inclut et « Effacer » le masque.

L’à-coup est calculé directement à partir de la loi de position par une différence centrale à sept points, d’ordre quatre (pas de \(0.004\,\mathrm s\)). La loi analytique est évaluée de part et d’autre de l’instant, y compris aux bornes : le retour de lecture en boucle n’est pas interprété comme un choc physique. Pour le mouvement balistique, l’à-coup est exactement nul.

Comme pour les autres grandeurs de dimensions différentes, le vecteur a sa propre échelle graphique. Cette échelle est fixe pour chaque trajectoire : la longueur reste proportionnelle à la norme instantanée, et le réglage « Facteur de longueur des vecteurs » lui est également appliqué. Les valeurs numériques restent exprimées en unités physiques.

- affichage numérique uniquement dans les cadres associés aux grandeurs vectorielles ;
- mention « © J. Martin » maintenue sur une seule ligne.

- 17 trajectoires planes, dont les mouvements du notebook et le mouvement circulaire réglable :
  - Lissajous $n=2$ ;
  - Lissajous $n=3$ ;
  - mouvement circulaire (MC), réunissant MCU et MCUA, avec rayon, vitesse angulaire initiale et accélération angulaire réglables ;
  - courbe poisson ;
  - astroïde ;
  - quadrifolium ;
  - mouvement balistique.
- Courbes supplémentaires : cardioïde, lemniscate de Bernoulli, rose à cinq pétales, spirale d’Archimède, cycloïde, deltoïde, néphroïde, hypotrochoïde, cœur et papillon.
- Choix indépendant des vecteurs :
  - position `r(t)` ;
  - vitesse `v(t)` ;
  - accélération `a(t)` ;
  - à-coup `j(t)` ;
  - accélération tangentielle `a_t(t)` ;
  - accélération centripète `a_c(t)`.
- Le vecteur position part de l’origine choisie, initialement `(0, 0)`.
- « Déplacer l’origine » permet de cliquer dans le graphique ou de faire glisser O, sans déplacer la trajectoire ni recommencer l’animation. « Origine initiale » remet le repère à zéro, indépendamment du bouton de cadrage.
- Les axes, la grille, les projections et les coordonnées suivent le nouveau repère. Le vecteur position vaut `(X − X_O, Y − Y_O)` ; vitesses, accélérations, à-coup et cercle osculateur restent inchangés. Chaque déplacement définit un nouveau repère fixe, sans simuler un observateur en mouvement.
- Les équations x(t), y(t) sont celles du repère choisi. Leurs constantes x₀ et y₀ (xᵢ et yᵢ pour la cycloïde) sont recalculées immédiatement pendant le déplacement de O ; les autres paramètres ne changent pas. Les coordonnées X_O et Y_O rappellent la position du nouveau repère dans l’ancien.
- Les valeurs sont mises à jour sans recomposer les formules ni modifier la hauteur du panneau pendant le glissement. Un espacement explicite sépare chaque signe égal de sa valeur dynamique.
- La longueur des tiges varie avec la norme des vecteurs, tandis que la largeur des tiges et la géométrie des pointes restent fixes à l’écran.
- Décomposition de l’accélération avec parallélogramme pointillé.
- Historique complet activé par défaut : toute la trajectoire passée reste visible en gris clair, à opacité constante. Décocher cette option réactive la traînée temporelle à disparition progressive.
- Projections de la particule sur les axes.
- Grille métrique : chaque carré correspond à 1 m × 1 m, y compris après déplacement de la vue ou zoom. Les nombres sont espacés davantage si nécessaire pour rester lisibles.
- Toutes les expressions mathématiques, les axes et le temps sont composés en TeX et rendus en SVG par une copie locale de MathJax.
- Pour une trajectoire fermée, la borne temporelle par défaut vaut deux fois la durée d’un parcours complet.
- Valeurs numériques composées en TeX sous les formes $|\vec v|=\cdots$ et $\vec v=(\cdots,\cdots)$.

## Utilisation

### Mouvement circulaire (MC)

L’unique trajectoire **Mouvement circulaire (MC)** remplace les entrées MCU et MCUA. Les curseurs règlent le rayon de 0.25 à 3 m et la vitesse angulaire initiale ω₀ de 0.1 à 2 rad/s, par pas de 0.05, ainsi que l’accélération angulaire α de −0.20 à +0.20 rad/s², par pas de 0.01. Valeurs initiales : R = 2 m, ω₀ = 1 rad/s et α = 0. Le centre physique reste en (4,4) m et la phase initiale est nulle. Les lois sont φ(t) = ω₀t + αt²/2, ω(t) = ω₀ + αt, x = x₀ + R cos φ et y = y₀ + R sin φ.

Tout changement recommence à t = 0, sans changer l’origine, le cadrage ni l’état de lecture/pause. Les paramètres sont conservés lorsqu’on quitte cette trajectoire ; « Réinitialiser » restaure ses valeurs initiales. À α = 0, le panneau indique exactement « Mouvement circulaire uniforme » et la période T = 2π/ω₀. À α non nul, il indique « Mouvement circulaire uniformément accéléré », sans lui attribuer de période : le temps maximal correspond à deux tours parcourus au total (∫|ω(t)|dt = 4π), y compris après une inversion du sens. La loi accélérée n’est jamais repliée modulo une durée ; seule la lecture en boucle recommence l’expérience. Équations, valeurs des vecteurs et cercle osculateur suivent les curseurs ; la grille reste à 1 m. Déplacer l’origine continue de mettre à jour x₀ et y₀ sans modifier le mouvement.

Les dérivées sont analytiques : v⃗ = Rω e⃗φ, a⃗ = −Rω² e⃗r + Rα e⃗φ et j⃗ = −3Rωα e⃗r − Rω³ e⃗φ. À vitesse non nulle, le rayon osculateur vaut R. Lors d’un arrêt instantané avant une inversion, la décomposition tangentielle/centripète et le cercle osculateur sont signalés indéfinis, mais le vecteur accélération reste calculé. Les facteurs graphiques des vecteurs restent fixes pendant le réglage, de façon à montrer les variations de leurs normes.

### Fichier autonome

Ouvrir directement :

```text
cinematique_2d_webapp_fr_formules_vecteurs_latex_svg.html
```

Ce fichier inclut le CSS, le JavaScript et MathJax ; aucune connexion internet n’est requise.

### Version source

Dans le dossier source :

```bash
./serve.sh
```

puis ouvrir :

```text
http://127.0.0.1:8000
```

## Commandes

- `Espace` : lire ou mettre en pause ;
- `R` : revenir à `t = 0` ;
- glissement dans la figure : déplacer la vue ;
- molette : zoomer autour du pointeur ;
- « Réinitialiser la vue » : restaurer le domaine `[0, 8] × [0, 8]` m.

### Échelle physique

Les longueurs de toutes les trajectoires ont été divisées par 500, sans changer leur forme ni leur cadrage. Positions, paramètres, vitesses, accélérations, à-coups et rayons de courbure sont exprimés dans cette nouvelle échelle physique. Les lois temporelles sont conservées, sauf pour le mouvement balistique : sa vitesse initiale vaut √80 ≈ 8.94 m/s et son temps de vol ≈ 1.58 s afin de conserver g = 9.81 m/s².

## Structure

```text
cinematique_2d_webapp_fr_formules_vecteurs_latex_svg_source/
├── index.html
├── style.css
├── app.js
├── serve.sh
├── README.md
└── vendor/
    └── mathjax/
        ├── tex-svg.js
        └── LICENSE
```

## Remarque sur le notebook source

Dans quelques définitions du notebook, la composante `y(t)` utilise `x0` au lieu de `y0`. L’application emploie la notation sémantiquement correcte `y0`. Dans les paramètres du notebook, `x0 = y0`, de sorte que cette correction ne modifie pas les trajectoires numériques correspondantes.

## Identification

L’en-tête affiche « PHYS1985 - ULiege ».
## Cercle osculateur instantané

Dans **Affichage**, l’option **Cercle osculateur et rayon** (désactivée au départ) ajoute le cercle en pointillés, son rayon en trait plein et son centre marqué d’une petite croix. Le rayon est noté $R_c$, avec sa valeur en mètres. Le cercle osculateur est le cercle qui épouse le mieux la courbe localement.

Le cercle garde la même échelle spatiale que la trajectoire, indépendamment du facteur de longueur des vecteurs. En 3D, il est construit dans le plan de la vitesse et de l’accélération centripète puis projeté avec la caméra. Activer l’option ne change ni le mouvement, ni le cadrage.

Aux points de vitesse quasi nulle, le cercle est indéfini. Lorsque la courbure est quasi nulle, le rayon tend vers l’infini et aucun cercle fini n’est affiché. Ces cas sont signalés dans le panneau. Si un grand cercle dépasse le champ de vue, seule sa partie visible est tracée : il n’est pas remis artificiellement à l’échelle.
