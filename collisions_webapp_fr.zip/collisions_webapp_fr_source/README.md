# Collisions — PHYS1985

Ouvrir `index.html` : version avec fichiers séparés, y compris MathJax, utilisable hors connexion. `python3 build.py` crée aussi `collisions_webapp_fr.html`, la version autonome.

[Ouvrir l’animation publiée](https://aenictusgithub.github.io/PHYS1985/collisions_webapp_fr.html). Le catalogue PHYS1985 fournit également son QR code. Le prototype de frottements reste indépendant et n’est pas publié.

## Exploration

- Collisions en une ou deux dimensions : élastiques, inélastiques avec restitution réglable, parfaitement inélastiques avec corps solidaires.
- Exemples frontaux, rattrapage, choc décentré, trajectoires obliques et absence de rencontre.
- Masses, vitesses initiales et décalage vertical réglables ; modifier ces paramètres recommence l’expérience.
- En 2D, module et angle des vitesses initiales. Décalage : centres initialement en `(-2, b/2)` et `(2, -b/2)` mètres.
- Vitesses des deux corps affichées simultanément avec la quantité de mouvement totale (appelée aussi « impulsion totale »). Celle-ci n’est pas l’intégrale temporelle d’une force : c’est `P = m₁v₁ + m₂v₂`.
- Les deux vitesses partagent une échelle fixe pour chaque configuration. Le vecteur total est présenté dans un diagramme séparé, avec son propre témoin en kg·m/s. Sa direction correspond aux mêmes axes que la scène. Un vecteur nul est signalé explicitement.
- Choix possible des quantités de mouvement individuelles à la place des vitesses ; centre de masse, normale de contact et trajectoires désactivables.
- Bilan calculé immédiatement avant/après le choc, graphiques d’énergie ou de quantité de mouvement, saut instantané au choc, lecture lente et navigation temporelle.
- Nombres et unités en MathJax, décimales avec point. Les glyphes numériques partagent une seule ligne de base.
- Relief discret des corps par dégradé radial et ombre légère. Ce relief est seulement graphique ; le modèle mécanique reste celui décrit ci-dessous.
- En 2D, les flèches des vitesses partent du centre des corps et sont dessinées après les deux balles pour rester au premier plan. En 1D, les vitesses restent légèrement décalées sur le côté, avec un petit trait de rattachement. Les quantités de mouvement individuelles conservent également ce décalage. La direction et la longueur des vecteurs restent exactes ; les symboles évitent les balles et les étiquettes voisines.
- En 1D et en 2D, cadrage calculé dès le départ pour toutes les positions pendant la durée choisie, avec une marge et l’enveloppe de rotation d’une paire soudée. Aucun dézoom ni recentrage pendant la lecture ou la navigation temporelle. Seul un changement de durée ou de paramètres recalcule la zone spatiale ; un redimensionnement de la fenêtre adapte sa projection à l’écran. Le cadrage minimum reste plus large en 2D.

## Modèle mécanique

Système isolé, sans paroi ni force extérieure. Deux disques homogènes de rayon 0.35 m, sans rotation initiale. Le mouvement se déroule dans le plan ; en 1D les centres sont contraints au même axe. Les masses sont réglables indépendamment du rayon (densités différentes).

L’instant du contact est calculé analytiquement, par la première racine admissible de `|r₂−r₁+(v₂−v₁)t|²=(2R)²`. La propagation est analytique de part et d’autre, sans dépendre de la fréquence d’affichage. Un cas sans rencontre ou un choc au-delà de la durée est explicitement signalé.

### Rebond : élastique ou inélastique

Contact lisse et impulsion normale, sans rotation induite. Avec `n` du corps 1 vers le corps 2 et `uₙ=(v₂−v₁)·n` :

`J = −(1+e)uₙ / (1/m₁+1/m₂)`

`v₁f=v₁i−Jn/m₁`, `v₂f=v₂i+Jn/m₂`.

La composante tangentielle de la vitesse relative ne change pas. La perte d’énergie vaut `½ μ (1−e²)uₙ²`, où `μ=m₁m₂/(m₁+m₂)`. Le mode élastique impose `e=1` ; le mode inélastique propose `0.05 ≤ e ≤ 0.95`.

### Choc parfaitement inélastique

Liaison rigide idéalisée : les corps restent soudés au contact. C’est une hypothèse distincte du simple contact lisse avec `e=0`, qui n’empêche pas en général le glissement tangentiel en 2D.

La vitesse du centre de masse est `V_C=P/(m₁+m₂)`. Le moment cinétique relatif initial `L_C` fixe `ω=L_C/I_C`, avec `I_C=Σ(mᵢ|rᵢ−C|²+½mᵢR²)`. Après soudure, l’ensemble translate et tourne ; les vitesses des centres sont `vᵢ=V_C+ω e_z×(rᵢ−C)`. La liaison peut transmettre un couple impulsionnel.

L’énergie affichée inclut la translation et la rotation propre des disques : `K=Σ(½mᵢ|vᵢ|²+½Iᵢω²)`. En 1D ou lors d’un choc central, `ω=0` et les deux vitesses finales sont identiques. En 2D décentrée, elles peuvent différer même sans mouvement relatif des surfaces soudées.

Le relief graphique ne transforme pas ces disques en sphères homogènes : ces dernières auraient un autre moment d’inertie.

## Vérifications

`node check_physics.cjs` contrôle 218 configurations (exemples et échantillonnage déterministe) : conservation des quantités de mouvement linéaire et angulaire, énergie, restitution normale, composante tangentielle, non-recouvrement, timing, invariance à la fréquence, chemins complets et limites de cadrage. Le choc rasant est traité avec une tolérance sur le discriminant pour éviter une impulsion parasite d’arrondi.

`node check_ui.cjs` utilise un adaptateur de contrôleur et de dessin, **pas un navigateur**. Les tests couvrent les changements de paramètres/exemples, les trois modes dans les deux dimensions, lecture/arrêt, navigation, stabilité du cadrage sous les options, cadrage entièrement fixe sur trois durées et deux tailles d’écran pour tous les exemples/modes, ajustement immédiat à la durée et corps restant dans le cadre, dégradés des balles, dégagement des flèches en 1D, ancrage central et ordre de dessin au premier plan des vitesses en 2D (sans changement de longueur ni direction), saut vertical du graphique et alignement des nombres.

Avec `PHYS1985_MATHJAX_ROOT=/chemin/vers/mathjax/js`, ce test emploie également le vrai moteur MathJax pour vérifier les formules. Il a été exécuté ainsi lors de la création. Aucun test visuel dans un navigateur n’est revendiqué.

Trois commandes WebMCP optionnelles réutilisent les mêmes actions : lecture de l’état, choix d’un exemple et choix d’un instant. Les contrats et les échecs sans modification partielle ont été testés dans l’adaptateur. Aucun contexte WebMCP natif n’étant disponible, l’enregistrement natif n’a pas été vérifié ; les navigateurs sans cette API utilisent simplement les contrôles habituels.

Reconstruire le fichier autonome : `python3 build.py`. Cette commande ne publie rien.

## Références

- [OpenStax — Types of collisions](https://openstax.org/books/university-physics-volume-1/pages/9-4-types-of-collisions)
- [OpenStax — Conservation of angular momentum](https://openstax.org/books/university-physics-volume-1/pages/11-3-conservation-of-angular-momentum)
- MathJax local sous licence Apache 2.0, texte dans `vendor/mathjax/LICENSE.txt`.
