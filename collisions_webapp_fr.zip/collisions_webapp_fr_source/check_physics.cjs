const assert=require('node:assert/strict'),P=require('./physics.js');
const near=(a,b,tol=1e-9)=>assert(Math.abs(a-b)<=tol*Math.max(1,Math.abs(a),Math.abs(b)),`${a} != ${b}`),vec=(a,b)=>a.forEach((v,i)=>near(v,b[i]));
let cases=0;
for(const dimension of ['line','plane'])for(const preset of Object.values(P.presets[dimension]))for(const mode of ['elastic','inelastic','sticking']){
  const sim=new P.Simulation(dimension,{...preset,mode});cases++;
  for(let t=0;t<=12;t+=.071){const q=sim.sample(t);vec(q.P,sim.P0);vec(q.C,P.add(sim.C0,P.mul(sim.V,t)));near(q.L,sim.L0);assert(q.K<=sim.K0+1e-9);near(q.K+q.loss,sim.K0);assert(P.norm(P.sub(q.r2,q.r1))>=2*sim.radius-1e-9);if(mode==='elastic')near(q.K,sim.K0);if(q.stuck)near(P.norm(P.sub(q.r2,q.r1)),2*sim.radius);}
  if(!sim.impact)continue;
  const pre=sim.sample(sim.tc,'before'),post=sim.sample(sim.tc);vec(pre.r1,post.r1);vec(pre.r2,post.r2);near(P.norm(P.sub(post.r2,post.r1)),.7);
  if(mode!=='sticking'){
    const n=sim.impact.n,ui=P.sub(pre.v2,pre.v1),uf=P.sub(post.v2,post.v1);near(P.dot(uf,n),-sim.restitution*P.dot(ui,n));near(P.cross(uf,n),P.cross(ui,n));
    const reduced=sim.p.m1*sim.p.m2/sim.M;near(post.loss,.5*reduced*(1-sim.restitution**2)*P.dot(ui,n)**2);
  }else{near(P.dot(P.sub(post.v2,post.v1),sim.impact.n),0);near(post.K,.5*sim.M*P.dot(sim.V,sim.V)+.5*sim.impact.I*sim.impact.omega**2);}
  const a=new P.Simulation(dimension,{...preset,mode}),b=new P.Simulation(dimension,{...preset,mode});for(let i=0;i<300;i++)a.advance(1/60);for(let i=0;i<100;i++)b.advance(.05);vec(a.sample().r1,b.sample().r1);near(a.t,5);assert(a.done);a.seek(0);assert(!a.done);vec(a.sample().r1,a.r1);
  const path=sim.path(5);near(path[0].t,0);near(path.at(-1).t,5);if(sim.tc<5)assert(path.some(q=>q.t===sim.tc));
  const bounds=sim.bounds(5);for(const q of path)for(const r of [q.r1,q.r2]){assert(r[0]>=bounds.xmin+sim.radius-1e-8&&r[0]<=bounds.xmax-sim.radius+1e-8);assert(r[1]>=bounds.ymin+sim.radius-1e-8&&r[1]<=bounds.ymax-sim.radius+1e-8);}
}
const elastic=new P.Simulation();near(elastic.tc,1.65);vec(elastic.impact.v1,[0,0]);vec(elastic.impact.v2,[2,0]);
const sticky=new P.Simulation('line',{mode:'sticking'});vec(sticky.impact.v1,[1,0]);vec(sticky.impact.v2,[1,0]);near(sticky.sample(3).loss,1);
const offset=new P.Simulation('plane',{mode:'sticking'});assert(Math.abs(offset.impact.omega)>.1);assert(P.norm(P.sub(offset.impact.v1,offset.impact.v2))>.1);
const tangent=new P.Simulation('plane',{offset:.7});near(tangent.tc,2);near(tangent.impact.Jn,0,1e-7);
assert.equal(new P.Simulation('plane',{offset:.701}).tc,Infinity);assert.equal(new P.Simulation('line',{u1:0,u2:0}).tc,Infinity);assert.equal(new P.Simulation('line',{u1:1,u2:1}).tc,Infinity);
assert(new P.Simulation('line',{u1:.01,u2:0}).tc>12);
for(const p of [{m1:0},{m2:-1},{duration:0},{e:2},{u1:NaN},{speed1:-1},{mode:'unknown'}])assert.throws(()=>new P.Simulation('line',p));
assert.throws(()=>elastic.advance(-1));assert.throws(()=>elastic.seek(NaN));assert.throws(()=>new P.Simulation('__proto__'));
// Deterministic broad coverage: mass ratios, obliquity, signs, restitutions.
let seed=89354;const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2**32;};
for(let i=0;i<250;i++){
  const sim=new P.Simulation('plane',{m1:.5+4.5*rnd(),m2:.5+4.5*rnd(),speed1:4*rnd(),speed2:4*rnd(),phi1:30*(rnd()-.5),phi2:180+30*(rnd()-.5),offset:1.4*(rnd()-.5),e:rnd(),mode:['elastic','inelastic','sticking'][i%3]});
  if(sim.impact){const s=sim.sample(sim.tc+3);vec(s.P,sim.P0);near(s.L,sim.L0);assert(s.K<=sim.K0+1e-8);assert(P.norm(P.sub(s.r2,s.r1))>=.7-1e-8);cases++;}
}
console.log(`Physics passed: ${cases} collision configurations; momentum, angular momentum, energy, restitution, contact timing, paths, no overlap, and playback invariance.`);
