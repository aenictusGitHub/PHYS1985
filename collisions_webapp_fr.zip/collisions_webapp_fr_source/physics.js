var physTranslate = globalThis.PhysLang?.t || (value => value);
/* Isolated disks, instantaneous impact; analytic motion on either side.
 * Smooth disks for rebound, rigid welded pair for perfectly inelastic impact. */
const CollisionPhysics=(()=>{
  'use strict';
  const add=(a,b)=>[a[0]+b[0],a[1]+b[1]],sub=(a,b)=>[a[0]-b[0],a[1]-b[1]],mul=(a,k)=>[a[0]*k,a[1]*k],dot=(a,b)=>a[0]*b[0]+a[1]*b[1],cross=(a,b)=>a[0]*b[1]-a[1]*b[0],perp=a=>[-a[1],a[0]],norm=a=>Math.hypot(...a);
  const rotate=(a,angle)=>[a[0]*Math.cos(angle)-a[1]*Math.sin(angle),a[0]*Math.sin(angle)+a[1]*Math.cos(angle)];
  const presets={
    line:{target:{m1:1,m2:1,u1:2,u2:0},headon:{m1:2,m2:3,u1:2,u2:-1},chase:{m1:3,m2:1,u1:3,u2:1},miss:{m1:1,m2:1,u1:-1,u2:1}},
    plane:{offset:{m1:1,m2:1,speed1:2,speed2:0,phi1:0,phi2:180,offset:.45},headon:{m1:2,m2:3,speed1:2,speed2:1,phi1:0,phi2:180,offset:0},cross:{m1:1,m2:2,speed1:2,speed2:1,phi1:14,phi2:-166,offset:-1},miss:{m1:1,m2:1,speed1:2,speed2:0,phi1:0,phi2:180,offset:1.2}},
  };
  function contactTime(r1,r2,v1,v2,R){
    const d=sub(r2,r1),u=sub(v2,v1),a=dot(u,u),b=dot(d,u),c=dot(d,d)-R*R;
    if(c< -1e-10)throw new Error(physTranslate('Les corps se recouvrent initialement.'));
    if(a<1e-24||b>=0)return Infinity;
    const disc=b*b-a*c,tol=1e-13*Math.max(1,b*b,a*c);
    if(disc< -tol)return Infinity;
    const root=Math.sqrt(disc<=tol?0:disc);
    return Math.max(0,c/(-b+root));
  }
  class Simulation{
    constructor(dimension='line',parameters={}){
      if(!Object.hasOwn(presets,dimension))throw new Error(physTranslate('Dimension inconnue.'));
      this.dimension=dimension;
      this.p={m1:1,m2:1,u1:2,u2:0,speed1:2,speed2:0,phi1:0,phi2:180,offset:0,e:.5,mode:'elastic',duration:5,...Object.values(presets[dimension])[0],...parameters};
      const p=this.p;
      if(!['elastic','inelastic','sticking'].includes(p.mode)||!['m1','m2','u1','u2','speed1','speed2','phi1','phi2','offset','e','duration'].every(k=>Number.isFinite(p[k]))||p.m1<=0||p.m2<=0||p.duration<=0||p.e<0||p.e>1||p.speed1<0||p.speed2<0)throw new Error(physTranslate('Paramètres physiques non valides.'));
      this.radius=.35;this.M=p.m1+p.m2;this.restitution=p.mode==='elastic'?1:p.mode==='sticking'?0:p.e;
      this.r1=[-2,dimension==='line'?0:p.offset/2];this.r2=[2,dimension==='line'?0:-p.offset/2];
      const velocity=(speed,phi)=>{const a=phi*Math.PI/180;return [speed*Math.cos(a),speed*Math.sin(a)];};
      this.v1=dimension==='line'?[p.u1,0]:velocity(p.speed1,p.phi1);this.v2=dimension==='line'?[p.u2,0]:velocity(p.speed2,p.phi2);
      this.I1=.5*p.m1*this.radius**2;this.I2=.5*p.m2*this.radius**2;
      this.P0=add(mul(this.v1,p.m1),mul(this.v2,p.m2));this.V=mul(this.P0,1/this.M);
      this.C0=mul(add(mul(this.r1,p.m1),mul(this.r2,p.m2)),1/this.M);
      this.K0=.5*p.m1*dot(this.v1,this.v1)+.5*p.m2*dot(this.v2,this.v2);
      this.L0=cross(this.r1,mul(this.v1,p.m1))+cross(this.r2,mul(this.v2,p.m2));
      this.tc=contactTime(this.r1,this.r2,this.v1,this.v2,2*this.radius);this.impact=null;this.t=0;
      if(Number.isFinite(this.tc)){
        const r1=add(this.r1,mul(this.v1,this.tc)),r2=add(this.r2,mul(this.v2,this.tc)),C=add(this.C0,mul(this.V,this.tc)),n=mul(sub(r2,r1),1/norm(sub(r2,r1))),uN=dot(sub(this.v2,this.v1),n);
        let v1,v2,omega=0,Jn=0;const d1=sub(r1,C),d2=sub(r2,C),I=this.I1+this.I2+p.m1*dot(d1,d1)+p.m2*dot(d2,d2);
        if(p.mode==='sticking'){
          const L=cross(d1,mul(sub(this.v1,this.V),p.m1))+cross(d2,mul(sub(this.v2,this.V),p.m2));omega=L/I;
          v1=add(this.V,mul(perp(d1),omega));v2=add(this.V,mul(perp(d2),omega));
        }else{
          Jn=-(1+this.restitution)*uN/(1/p.m1+1/p.m2);v1=sub(this.v1,mul(n,Jn/p.m1));v2=add(this.v2,mul(n,Jn/p.m2));
        }
        this.impact={r1,r2,C,n,uN,v1,v2,d1,d2,I,omega,Jn,J1:mul(sub(v1,this.v1),p.m1),J2:mul(sub(v2,this.v2),p.m2),grazing:Math.abs(uN)<1e-8};
      }
    }
    get done(){return this.t>=this.p.duration-1e-9;}
    sample(t=this.t,side='after'){
      if(!Number.isFinite(t)||t<0)throw new Error(physTranslate('Instant non valide.'));
      const p=this.p,hit=this.impact,after=!!hit&&(t>this.tc||(t===this.tc&&side!=='before'));
      let r1,r2,v1,v2,omega=0,angle=0;
      if(!after){r1=add(this.r1,mul(this.v1,t));r2=add(this.r2,mul(this.v2,t));v1=[...this.v1];v2=[...this.v2];}
      else if(p.mode==='sticking'){
        const dt=t-this.tc,C=add(hit.C,mul(this.V,dt));omega=hit.omega;angle=omega*dt;const d1=rotate(hit.d1,angle),d2=rotate(hit.d2,angle);
        r1=add(C,d1);r2=add(C,d2);v1=add(this.V,mul(perp(d1),omega));v2=add(this.V,mul(perp(d2),omega));
      }else {r1=add(hit.r1,mul(hit.v1,t-this.tc));r2=add(hit.r2,mul(hit.v2,t-this.tc));v1=[...hit.v1];v2=[...hit.v2];}
      const p1=mul(v1,p.m1),p2=mul(v2,p.m2),P=add(p1,p2),C=mul(add(mul(r1,p.m1),mul(r2,p.m2)),1/this.M);
      const K1=.5*p.m1*dot(v1,v1)+.5*this.I1*omega**2,K2=.5*p.m2*dot(v2,v2)+.5*this.I2*omega**2,K=K1+K2;
      const L=cross(r1,p1)+cross(r2,p2)+(this.I1+this.I2)*omega,loss=Math.max(0,this.K0-K);
      return {t,r1,r2,v1,v2,p1,p2,P,C,K1,K2,K,loss,L,omega,angle,after,stuck:after&&p.mode==='sticking',momentumError:norm(sub(P,this.P0)),angularError:L-this.L0,energyError:K+loss-this.K0};
    }
    seek(t){if(!Number.isFinite(t))throw new Error(physTranslate('Instant non valide.'));this.t=Math.max(0,Math.min(this.p.duration,t));return this.sample();}
    advance(dt){if(!Number.isFinite(dt)||dt<0)throw new Error(physTranslate('Pas de temps non valide.'));this.t=Math.min(this.p.duration,this.t+dt);if(this.p.duration-this.t<1e-9)this.t=this.p.duration;return this.sample();}
    bounds(t=this.t){
      const points=[this.r1,this.r2],hit=this.impact,current=this.sample(t);points.push(current.r1,current.r2);
      if(hit&&t>=this.tc){points.push(hit.r1,hit.r2);if(this.p.mode==='sticking'){
        const orbit=Math.max(norm(hit.d1),norm(hit.d2));for(const c of [hit.C,current.C])for(const sx of [-1,1])for(const sy of [-1,1])points.push([c[0]+sx*orbit,c[1]+sy*orbit]);
      }}
      return {xmin:Math.min(...points.map(p=>p[0]))-this.radius,xmax:Math.max(...points.map(p=>p[0]))+this.radius,ymin:Math.min(...points.map(p=>p[1]))-this.radius,ymax:Math.max(...points.map(p=>p[1]))+this.radius};
    }
    path(until=this.t){
      const count=this.p.mode==='sticking'&&until>this.tc?Math.min(600,Math.max(40,Math.ceil(Math.abs(this.impact.omega)*(until-this.tc)*20))):2;
      const times=Array.from({length:count+1},(_,i)=>until*i/count);if(this.tc>0&&this.tc<until)times.push(this.tc);times.sort((a,b)=>a-b);
      return times.map(t=>this.sample(t));
    }
  }
  return {presets,Simulation,contactTime,add,sub,mul,dot,cross,norm};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=CollisionPhysics;
