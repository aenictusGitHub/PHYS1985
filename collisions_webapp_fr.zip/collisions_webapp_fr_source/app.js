if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',startCollisionApp);else startCollisionApp();
async function startCollisionApp(){
  'use strict';
  const $=id=>document.getElementById(id),tex=String.raw,CP=CollisionPhysics;
  try{
    await MathJax.startup.promise;
    const C={one:'#2775b6',two:'#429b88',fillTwo:'#94d9c5',ink:'#233449',muted:'#607185',grid:'#dce4ec',loss:'#b5688b'};
    const state={sim:new CP.Simulation(),playing:false,frame:0,last:null,lastReadout:-Infinity,legend:''},labels=new Map(),glyphs=new Map(),units=new Map();
    const names={line:{target:'Cible immobile — masses égales',headon:'Rencontre frontale',chase:'Rattrapage',miss:'Corps qui s’éloignent'},plane:{offset:'Choc décentré',headon:'Choc frontal',cross:'Trajectoires obliques',miss:'Sans rencontre'}};
    const controls=[['mass-1','m1',2,tex`\mathrm{kg}`],['mass-2','m2',2,tex`\mathrm{kg}`],['u1','u1',2,tex`\mathrm{m\,s^{-1}}`],['u2','u2',2,tex`\mathrm{m\,s^{-1}}`],['speed1','speed1',2,tex`\mathrm{m\,s^{-1}}`],['speed2','speed2',2,tex`\mathrm{m\,s^{-1}}`],['phi1','phi1',0,tex`{}^\circ`],['phi2','phi2',0,tex`{}^\circ`],['offset','offset',2,tex`\mathrm m`],['restitution','e',2,''],['duration','duration',0,tex`\mathrm s`]];
    function math(el,value){if(el.dataset.math===value)return;el.replaceChildren(MathJax.tex2svg(value,{display:false}));el.dataset.math=value;}
    function part(value){const svg=MathJax.tex2svg(value,{display:false}).querySelector('svg'),[x,y,width,height]=svg.getAttribute('viewBox').split(/\s+/).map(Number);return {svg,x,y,width,height,ex:parseFloat(svg.getAttribute('width'))/width};}
    for(const el of document.querySelectorAll('[data-tex]'))math(el,el.dataset.tex);
    for(const c of '0123456789.-')glyphs.set(c,part(c));
    const top0=Math.min(...[...glyphs.values()].map(g=>g.y)),bottom0=Math.max(...[...glyphs.values()].map(g=>g.y+g.height));
    MathJax.startup.document.updateDocument();
    function number(el,value,digits=3,unit=''){
      if(!Number.isFinite(value))throw new Error('Valeur numérique non finie.');
      const string=(Math.abs(value)<.5*10**-digits?0:value).toFixed(digits),key=string+'|'+unit;if(el.dataset.number===key)return;
      const parts=[...string].map(c=>glyphs.get(c));if(unit){if(!units.has(unit))units.set(unit,part(unit));parts.push(units.get(unit));}
      const svg=parts[0].svg.cloneNode(false),ex=glyphs.get('0').ex;let width=0,top=top0,bottom=bottom0;
      for(const [i,p]of parts.entries()){if(i===string.length)width+=1000/6;const g=document.createElementNS('http://www.w3.org/2000/svg','g');g.setAttribute('transform',`translate(${width-p.x},0)`);g.append(...[...p.svg.children].map(c=>c.cloneNode(true)));svg.append(g);width+=p.width;top=Math.min(top,p.y);bottom=Math.max(bottom,p.y+p.height);}
      svg.setAttribute('viewBox',`0 ${top} ${width} ${bottom-top}`);svg.setAttribute('width',`${width*ex}ex`);svg.setAttribute('height',`${(bottom-top)*ex}ex`);svg.style.verticalAlign=`${-bottom*ex}ex`;svg.setAttribute('role','img');svg.setAttribute('aria-label',string+' '+unit.replace(/\\mathrm|[{}]/g,'').replace(/\\,/g,' '));
      el.classList.add('number');el.replaceChildren(svg);el.dataset.number=key;
    }
    const fixed=(v,d=2)=>(Math.abs(v)<.5*10**-d?0:v).toFixed(d);
    function vectorValue(el,v,unit){const plane=state.sim.dimension==='plane';math(el,(plane?tex`\left(${fixed(v[0])};\ ${fixed(v[1])}\right)` : fixed(v[0]))+tex`\,`+unit);}
    function pause(){state.playing=false;state.last=null;if(state.frame)cancelAnimationFrame(state.frame);state.frame=0;$('play').textContent='Lire';$('play').setAttribute('aria-pressed','false');}
    function play(){if(state.sim.done)restart();state.playing=true;state.last=null;$('play').textContent='Pause';$('play').setAttribute('aria-pressed','true');if(!state.frame)state.frame=requestAnimationFrame(frame);}
    function restart(){pause();state.sim.seek(0);render();}
    function replace(parameters){pause();state.sim=new CP.Simulation(state.sim.dimension,{...state.sim.p,...parameters});sync();render();}
    function configure(dimension,example=Object.keys(CP.presets[dimension])[0]){
      pause();const previous=state.sim.p;state.sim=new CP.Simulation(dimension,{mode:previous.mode,e:previous.e,duration:previous.duration,...CP.presets[dimension][example]});
      const options=Object.keys(CP.presets[dimension]).map(key=>{const el=document.createElement('option');el.value=key;el.textContent=names[dimension][key];return el;});
      const custom=document.createElement('option');custom.value='custom';custom.textContent='Réglage personnalisé';options.push(custom);$('example').replaceChildren(...options);$('example').value=example;sync();render();
    }
    function sync(){
      const sim=state.sim,p=sim.p,plane=sim.dimension==='plane',sticky=p.mode==='sticking';
      // Fit every position over the chosen duration once, at configuration time.
      // Bounds include both disks and the welded pair's rotational envelope.
      // Playback, seeking and visibility toggles must never recenter or zoom.
      const full=sim.bounds(p.duration);
      state.sceneBounds={xmin:full.xmin-.5,xmax:full.xmax+.5,ymin:full.ymin-.5,ymax:full.ymax+.5};
      $('dimension').value=sim.dimension;$('mode').value=p.mode;$('line-controls').hidden=plane;$('plane-controls').hidden=!plane;$('restitution-control').hidden=p.mode!=='inelastic';
      for(const [id,key,digits,unit]of controls){$(id).value=p[key];number($(id+'-value'),p[key],digits,unit);$(id).setAttribute('aria-valuetext',p[key].toFixed(digits));}
      $('timeline').max=p.duration;$('scene-title').textContent=plane?'Collision dans le plan':'Collision sur un axe';
      $('mode-note').textContent=p.mode==='elastic'?'L’énergie cinétique est conservée.':sticky?'Les corps restent solidaires après le choc.':'Une partie de l’énergie cinétique est dissipée ; les corps se séparent après le choc.';
      math($('impact-equation'),sticky?(plane?tex`\omega=\frac{L_C}{I_C},\quad \vec V_C=\frac{\vec P}{m_1+m_2}`:tex`v_{1f}=v_{2f}=\frac{m_1v_{1i}+m_2v_{2i}}{m_1+m_2}`):tex`(\vec v_{2f}-\vec v_{1f})\cdot\vec n=-e(\vec v_{2i}-\vec v_{1i})\cdot\vec n`);
      math($('energy-equation'),tex`E_{\mathrm{diss}}=K_i-K_f\ge0`);
      $('model-note').textContent=sticky?'Liaison rigide idéalisée au contact. Dans un choc décentré, l’ensemble tourne : l’énergie cinétique inclut cette rotation et le moment cinétique est conservé.':'Contact lisse : l’impulsion est dirigée selon la normale du corps 1 vers le corps 2. La composante tangentielle de la vitesse relative est inchangée. Pour le choc élastique, le coefficient de restitution vaut 1.';
      const has=!!sim.impact,inTime=has&&sim.tc<=p.duration;$('before').disabled=!inTime;$('after').disabled=!inTime;
      $('comparison-wrap').hidden=!has;$('no-collision').hidden=has;
      $('ensemble-speed-row').hidden=!(sticky&&plane);$('ensemble-rotation-row').hidden=!(sticky&&plane);
      if(has){
        const a=sim.sample(sim.tc,'before'),b=sim.sample(sim.tc);
        for(const [suffix,s]of [['before',a],['after',b]]){vectorValue($('v1-'+suffix),s.v1,tex`\mathrm{m\,s^{-1}}`);vectorValue($('v2-'+suffix),s.v2,tex`\mathrm{m\,s^{-1}}`);vectorValue($('P-'+suffix),s.P,tex`\mathrm{kg\,m\,s^{-1}}`);number($('K-'+suffix),s.K,3,tex`\mathrm J`);}
        if(sticky&&plane){
          for(const i of [1,2])math($('v'+i+'-after'),tex`\text{—}`);
          for(const suffix of ['before','after'])vectorValue($('VC-'+suffix),sim.V,tex`\mathrm{m\,s^{-1}}`);
          math($('omega-before'),tex`\text{—}`);number($('omega-after'),b.omega,2,tex`\mathrm{rad\,s^{-1}}`);
        }
      }
      $('comparison-note').textContent=(plane?'Les couples indiquent les composantes selon les axes horizontal et vertical. ':'Les valeurs sont signées selon l’axe horizontal. ')+(sticky&&plane?'Après le choc, l’ensemble est décrit par la vitesse de son centre de masse C et sa vitesse angulaire. Avant le choc, il n’existe pas encore d’ensemble rigide ; les disques n’ont pas de rotation propre.':'')+(has&&!inTime?' Le choc prévu est au-delà de la durée choisie.':'');
      if(has)math($('contact-info'),tex`t_{\mathrm{choc}}=${fixed(sim.tc,2)}\,\mathrm s`);else{$('contact-info').replaceChildren();delete $('contact-info').dataset.math;$('contact-info').textContent='Pas de rencontre prévue';}
      $('observation').textContent=p.mode==='elastic'?'L’énergie cinétique et la quantité de mouvement totale restent constantes. Avec deux masses égales et une cible immobile, le choc frontal échange les vitesses.':sticky?(plane?'Un choc décentré conserve aussi le moment cinétique : les corps solidaires tournent autour de leur centre de masse, qui poursuit son mouvement rectiligne uniforme.':'Après le choc, les deux corps ont une vitesse commune. La quantité de mouvement est conservée, mais une partie de l’énergie cinétique est dissipée.'):'La quantité de mouvement reste constante, même si l’énergie cinétique diminue. En deux dimensions, la perte dépend de la vitesse relative normale au contact, et pas de sa seule norme.';
      state.legend='';
    }
    function surface(id){const canvas=$(id),r=canvas.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1),ctx=canvas.getContext('2d');if(canvas.width!==Math.round(r.width*dpr)||canvas.height!==Math.round(r.height*dpr)){canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,r.width,r.height);return {ctx,w:r.width,h:r.height};}
    function line(ctx,points,color,width=1,dash=[]){if(!points.length)return;ctx.beginPath();ctx.moveTo(...points[0]);for(const p of points.slice(1))ctx.lineTo(...p);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.setLineDash(dash);ctx.stroke();ctx.setLineDash([]);}
    function dot(ctx,x,y,r,fill,stroke=fill){ctx.beginPath();ctx.arc(x,y,r,0,2*Math.PI);ctx.fillStyle=fill;ctx.fill();ctx.strokeStyle=stroke;ctx.lineWidth=1.2;ctx.stroke();}
    function body(ctx,x,y,r,index){
      const colors=index===1?['#b8ddf6','#62a8d9','#2775b6','#1c5280']:['#e1f8ee','#b6e8d7','#94d9c5','#529c89'];
      const shade=ctx.createRadialGradient(x-r*.34,y-r*.38,r*.03,x-r*.08,y-r*.1,r*1.14);
      for(const [offset,color]of [[0,colors[0]],[.3,colors[1]],[.7,colors[2]],[1,colors[3]]])shade.addColorStop(offset,color);
      ctx.save();ctx.shadowColor='rgba(35,52,73,.16)';ctx.shadowBlur=Math.min(7,r*.3);ctx.shadowOffsetY=Math.min(3,r*.12);
      ctx.beginPath();ctx.arc(x,y,r,0,2*Math.PI);ctx.fillStyle=shade;ctx.fill();ctx.restore();
      ctx.strokeStyle=index===1?'#23679c':'#68ae9a';ctx.lineWidth=.7;ctx.stroke();
    }
    function arrow(ctx,a,b,color,width=2.4){const dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);if(length<1e-8)return;const ux=dx/length,uy=dy/length,head=Math.min(8,length*.4);line(ctx,[a,b],color,width);line(ctx,[[b[0]-head*ux-head*.48*uy,b[1]-head*uy+head*.48*ux],b,[b[0]-head*ux+head*.48*uy,b[1]-head*uy-head*.48*ux]],color,width);}
    function label(layer,key,value,x,y,color=C.ink,tick=false){let el=labels.get(layer+key);if(!el){el=document.createElement('span');$(layer).append(el);labels.set(layer+key,el);}el.hidden=false;el.className='plot-label'+(tick?' tick':'');math(el,value);el.style.left=x+'px';el.style.top=y+'px';el.style.color=color;return el;}
    function numericLabel(layer,key,value,x,y,digits=0,unit=''){let el=labels.get(layer+key);if(!el){el=document.createElement('span');$(layer).append(el);labels.set(layer+key,el);}el.hidden=false;el.className='plot-label tick';el.style.left=x+'px';el.style.top=y+'px';el.style.color=C.muted;number(el,value,digits,unit);return el;}
    const sceneLabelSizes=new WeakMap();
    let sceneLabelPlan=null;
    function placeSceneLabels(ctx,requests,centers,radius,segments,w,h,project){
      const signature=[$('vectors').value,$('center').checked,$('normal').checked].join('|');
      if(!sceneLabelPlan||sceneLabelPlan.sim!==state.sim||sceneLabelPlan.w!==w||sceneLabelPlan.h!==h||sceneLabelPlan.signature!==signature||!project){
        const frames=[];
        if(project){
          const sim=state.sim,count=Math.min(512,Math.max(128,Math.ceil(Math.abs(sim.impact?.omega||0)*sim.p.duration*24/Math.PI)));
          const times=Array.from({length:count+1},(_,i)=>i*sim.p.duration/count);
          if(sim.impact&&sim.tc<=sim.p.duration)times.push(sim.tc,Math.max(0,sim.tc-.0001));
          for(const t of times){const s=sim.sample(t);frames.push({centers:[project(s.r1),project(s.r2)],center:project(s.C)});}
        }else frames.push({centers,center:requests.find(r=>r.key==='center')?.anchor||centers[0]});
        sceneLabelPlan={sim:state.sim,w,h,signature,frames,records:new Map()};
      }
      const plan=sceneLabelPlan;
      const anchorAt=(request,frame)=>{
        if(request.key==='m1'||request.key==='vector1')return frame.centers[0];
        if(request.key==='m2'||request.key==='vector2')return frame.centers[1];
        if(request.key==='center'||request.key==='vector0')return frame.center;
        return request.anchor;
      };
      const position=(record,anchor)=>{
        const q=record.fixed||[anchor[0]+record.offset[0],anchor[1]+record.offset[1]];
        return [Math.max(record.hw+8,Math.min(w-record.hw-8,q[0])),Math.max(76+record.hh,Math.min(h-65-record.hh,q[1]))];
      };
      for(const request of requests){
        const {key,symbol,anchor,direction,gap,color}=request;
        const el=label('scene-labels',key,symbol,0,0,color);
        let size=sceneLabelSizes.get(el);
        if(!size||size.symbol!==symbol||size.viewport!==w){
          const box=el.getBoundingClientRect();
          size={symbol,viewport:w,width:Math.max(18,box.width),height:Math.max(24,box.height)};
          sceneLabelSizes.set(el,size);
        }
        let record=plan.records.get(key);
        if(!record){
          // Reserve room for the zero-vector notation before it appears at impact.
          const hw=Math.max(size.width/2,key.startsWith('vector')?size.height*1.15:0),hh=size.height/2;
          const ideal=[direction[0]*gap,direction[1]*gap];
          let best=null;
          const consider=(offset,fixed=null)=>{
            const candidate={request,hw,hh,offset,fixed},positions=[];
            let blocked=0,distance=0;
            for(let f=0;f<plan.frames.length;f++){
              const frame=plan.frames[f],a=anchorAt(request,frame),q=position(candidate,a);
              positions.push(q);
              // Static UI axes and the bodies' whole motion are obstacles.
              if(Math.abs(q[0]-56)<hw+57&&Math.abs(q[1]-(h-58))<hh+56)blocked++;
              for(const c of frame.centers){
                if(Math.hypot(Math.max(0,Math.abs(c[0]-q[0])-hw),Math.max(0,Math.abs(c[1]-q[1])-hh))<radius+10)blocked++;
              }
              for(const old of plan.records.values()){
                const r=old.positions[f];
                if(Math.abs(q[0]-r[0])<hw+old.hw+12&&Math.abs(q[1]-r[1])<hh+old.hh+12)blocked++;
              }
              distance+=Math.hypot(q[0]-a[0]-ideal[0],q[1]-a[1]-ideal[1]);
              if(best&&blocked*1e6>best.score)return;
            }
            const score=blocked*1e6+distance/plan.frames.length+(fixed?60:0);
            if(!best||score<best.score)best={...candidate,positions,score,blocked};
          };
          consider(ideal);
          if(best.blocked){
            const preferred=Math.atan2(direction[1],direction[0]);
            for(let distance=Math.max(22,gap);distance<=Math.max(220,gap+160);distance+=16){
              for(let i=0;i<24;i++){
                const angle=preferred+i*Math.PI/12;
                consider([distance*Math.cos(angle),distance*Math.sin(angle)]);
              }
            }
          }
          // If no moving offset is clear for the whole trajectory, use one
          // fixed annotation with a leader, rather than changing sides in flight.
          if(best.blocked){
            for(let y=76+hh;y<=h-65-hh;y+=12)for(let x=8+hw;x<=w-8-hw;x+=12)consider([0,0],[x,y]);
          }
          record=best;plan.records.set(key,record);
        }
        const q=position(record,anchor);
        el.style.left=q[0]+'px';el.style.top=q[1]+'px';
        el.dataset.sceneAnnotation=key;
        el.dataset.layoutWidth=String(size.width);el.dataset.layoutHeight=String(size.height);
        el.dataset.layoutOffset=JSON.stringify(record.offset);
        el.dataset.layoutFixed=record.fixed?JSON.stringify(record.fixed):'';
        // The label follows the body, even when its arrow reverses at impact.
        // A leader points to the arrow tip when their separation is appreciable.
        const target=request.target||anchor;
        if(record.fixed||CP.norm(CP.sub(q,target))>gap+32){
          const delta=CP.sub(q,target),length=CP.norm(delta),u=CP.mul(delta,1/Math.max(length,1e-9));
          const inset=Math.min(size.width/2/Math.max(1e-9,Math.abs(u[0])),size.height/2/Math.max(1e-9,Math.abs(u[1])))+5;
          if(length>inset+8){
            ctx.save();ctx.globalAlpha=.45;line(ctx,[target,CP.sub(q,CP.mul(u,inset))],color,1.1,[2,4]);ctx.restore();
          }
        }
      }
    }
    function drawScene(s){
      const {ctx,w,h}=surface('scene-canvas'),sim=state.sim,plane=sim.dimension==='plane',b=state.sceneBounds,pad=w<450?58:95;
      for(const el of $('scene-labels').children)el.hidden=true;
      const annotations=[],vectorSegments=[];
      const annotate=(key,symbol,anchor,direction,gap,color)=>annotations.push({key,symbol,anchor,direction,gap,color});
      const spanX=Math.max(plane?12:6,b.xmax-b.xmin),spanY=Math.max(plane?8:3,b.ymax-b.ymin),scale=Math.min((w-2*pad)/spanX,(h-140)/spanY),cx=(b.xmin+b.xmax)/2,cy=(b.ymin+b.ymax)/2;
      const P=v=>[w/2+(v[0]-cx)*scale,h*.53-(v[1]-cy)*scale],tag=(key,value,x,y,color=C.ink)=>label('scene-labels',key,value,Math.max(27,Math.min(w-27,x)),Math.max(25,Math.min(h-25,y)),color);
      ctx.save();ctx.beginPath();ctx.rect(0,0,w,h);ctx.clip();
      if(!plane)line(ctx,[[24,P([0,0])[1]],[w-24,P([0,0])[1]]],C.grid,1);
      if($('traces').checked){const path=sim.path(s.t);for(const [key,color]of [['r1',C.one],['r2',C.two]]){line(ctx,path.map(q=>P(q[key])),color,1.8);const a=P(sim[key]);ctx.globalAlpha=.4;dot(ctx,...a,2,color);ctx.globalAlpha=1;}}
      if($('center').checked){const q=P(s.C),start=P(sim.C0);line(ctx,[start,q],C.muted,1,[3,5]);line(ctx,[[q[0]-5,q[1]],[q[0]+5,q[1]]],C.muted,1.5);line(ctx,[[q[0],q[1]-5],[q[0],q[1]+5]],C.muted,1.5);annotate('center','C',q,[0,1],23,C.muted);}
      if($('normal').checked&&sim.impact){const hit=sim.impact,a=CP.add(hit.r1,CP.mul(hit.n,sim.radius)),start=P(CP.sub(a,CP.mul(hit.n,.5))),end=P(CP.add(a,CP.mul(hit.n,.9)));arrow(ctx,start,end,C.muted,1.3);annotate('normal',tex`\vec n`,end,[0,-1],20,C.muted);vectorSegments.push([start,end]);}
      if(s.stuck)line(ctx,[P(s.r1),P(s.r2)],C.muted,2.5);
      const radius=sim.radius*scale,centers=[P(s.r1),P(s.r2)];
      for(const i of [1,2]){const q=centers[i-1],color=i===1?C.one:C.two;body(ctx,...q,radius,i);if(s.stuck){const end=[q[0]+radius*.75*Math.cos(s.angle),q[1]-radius*.75*Math.sin(s.angle)];line(ctx,[q,end],i===1?'#b9def7':C.two,1.4);}annotate('m'+i,'m_'+i,q,[0,i===1?1:-1],radius+20,color);}
      const segmentDistance=(p,a,b)=>{const d=CP.sub(b,a),length2=CP.dot(d,d),t=length2?Math.max(0,Math.min(1,CP.dot(CP.sub(p,a),d)/length2)):0;return CP.norm(CP.sub(p,CP.add(a,CP.mul(d,t))));};
      function vectorLabel(key,symbol,tip,center,color){
        const direction=key==='vector1'?[0,-1]:key==='vector2'?[0,1]:[1,0];
        annotations.push({key,symbol,anchor:center,target:tip,direction,gap:radius+24,color});
      }
      // A single, configuration-fixed scale for both vectors. Visibility never changes the camera.
      const kind=$('vectors').value,vel=kind==='velocity';
      if(kind!=='none'){
        const hit=sim.impact,maxV=i=>Math.max(CP.norm(sim['v'+i]),hit?(sim.p.mode==='sticking'?CP.norm(sim.V)+Math.abs(hit.omega)*CP.norm(hit['d'+i]):CP.norm(hit['v'+i])):0),max=Math.max(maxV(1)*(vel?1:sim.p.m1),maxV(2)*(vel?1:sim.p.m2),1),vectorScale=Math.min(76,w*.14)/max;
        // A welded 2D pair has one translational velocity, applied at C;
        // its separate angular velocity is shown in the scene footer.
        for(const i of (s.stuck&&plane&&vel?[0]:[1,2])){
          const v=i===0?sim.V:s[(vel?'v':'p')+i],center=i===0?P(s.C):centers[i-1],delta=[v[0]*vectorScale,-v[1]*vectorScale],length=Math.hypot(...delta),color=i===0?C.ink:i===1?C.one:C.two,symbol=i===0?tex`\vec V_C`:vel?tex`\vec v_${i}`:tex`\vec p_${i}`;
          if(length>.001){
            const u=CP.mul(delta,1/length),perp=[-u[1],u[0]],preferred=(i===1?-1:1)*(Math.sign(perp[1])||Math.sign(perp[0]));let best=null;
            if(vel){
              // Every velocity originates at the body (or assembly) center. Bodies were
              // painted first, so even a short arrow stays in the foreground.
              const tip=CP.add(center,delta),n=CP.mul(perp,preferred);
              arrow(ctx,center,tip,color);vectorSegments.push([center,tip]);vectorLabel('vector'+i,symbol,tip,center,color);
              continue;
            }
            // Translate the whole arrow sideways: its length and direction stay exact,
            // including when it is shorter than the ball radius after impact.
            for(const sign of [preferred,-preferred])for(const extra of [0,14,28]){
              const n=CP.mul(perp,sign),a=CP.add(center,CP.mul(n,radius+10+extra)),tip=CP.add(a,delta);
              const covered=centers.reduce((sum,c)=>sum+Math.max(0,radius+8-segmentDistance(c,a,tip))**2,0);
              const outside=[a,tip].reduce((sum,q)=>sum+Math.max(0,10-q[0],q[0]-w+10)**2+Math.max(0,65-q[1],q[1]-h+25)**2,0),score=1000*covered+outside+extra;
              if(!best||score<best.score)best={a,tip,n,score};
            }
            ctx.globalAlpha=.4;line(ctx,[CP.add(center,CP.mul(best.n,radius+2)),best.a],color,1,[2,3]);ctx.globalAlpha=1;
            arrow(ctx,best.a,best.tip,color);vectorSegments.push([best.a,best.tip]);vectorLabel('vector'+i,symbol,best.tip,center,color);
          }else vectorLabel('vector'+i,symbol+tex`=\vec 0`,center,center,color);
        }
        const reference=2**Math.floor(Math.log2(max)),a=[w-30-reference*vectorScale,35],tip=[w-30,35];arrow(ctx,a,tip,C.muted,1.6);tag('vector-key',reference+tex`\,`+(vel?tex`\mathrm{m\,s^{-1}}`:tex`\mathrm{kg\,m\,s^{-1}}`),(a[0]+tip[0])/2,56,C.muted);
      }
      placeSceneLabels(ctx,annotations,centers,radius,vectorSegments,w,h,P);
      ctx.restore();
      const a=[34,h-30];arrow(ctx,a,[a[0]+30,a[1]],C.muted,1.4);tag('axisX','x',a[0]+43,a[1],C.muted);if(plane){arrow(ctx,a,[a[0],a[1]-30],C.muted,1.4);tag('axisY','y',a[0],a[1]-43,C.muted);}
      const length=2**Math.floor(Math.log2(Math.max(.1,Math.min(90,w*.18)/scale))),x=w-28-length*scale,y=h-28;line(ctx,[[x,y],[w-28,y]],C.muted,1.4);for(const X of [x,w-28])line(ctx,[[X,y-4],[X,y+4]],C.muted,1.4);numericLabel('scene-labels','scale',length,(x+w-28)/2,y-18,length<1?2:0,tex`\mathrm m`);
      $('scene').setAttribute('aria-label',$('scene-title').textContent+'. Instant '+s.t.toFixed(2)+' s. '+$('status-badge').textContent+'. Énergie cinétique '+s.K.toFixed(3)+' J.');
    }
    function geometry(w,h){return {left:w<420?63:76,right:Math.max(95,w-26),top:35,bottom:h-48};}
    function drawTotalMomentum(s){
      $('total-momentum-panel').hidden=!$('total-momentum').checked;if($('total-momentum-panel').hidden)return;
      const {ctx,w,h}=surface('momentum-canvas'),sim=state.sim,magnitude=CP.norm(s.P),max=Math.max(1,CP.norm(sim.P0),CP.norm(sim.v1)*sim.p.m1,CP.norm(sim.v2)*sim.p.m2),factor=Math.min(39,w*.24)/max;
      for(const el of $('momentum-labels').children)el.hidden=true;
      const delta=[s.P[0]*factor,-s.P[1]*factor],a=[w*.43-delta[0]/2,52-delta[1]/2],b=CP.add(a,delta),color='#7758a6';
      if(magnitude>1e-9){arrow(ctx,a,b,color,2.8);const u=CP.mul(delta,1/Math.hypot(...delta));label('momentum-labels','P',tex`\vec P`,b[0]-u[1]*18+u[0]*13,b[1]+u[0]*18+u[1]*13,color);}
      else{dot(ctx,...a,2.3,color);label('momentum-labels','zero',tex`\vec P=\vec 0`,a[0]+38,a[1],color);}
      const reference=2**Math.floor(Math.log2(max)),x=(w-reference*factor)/2;arrow(ctx,[x,h-35],[x+reference*factor,h-35],C.muted,1.4);label('momentum-labels','key',reference+tex`\,\mathrm{kg\,m\,s^{-1}}`,w/2,h-15,C.muted,true);
      $('momentum-diagram').setAttribute('aria-label','Impulsion totale : composantes '+s.P.map(v=>v.toFixed(2)).join(' et ')+' kg m/s.');
    }
    function drawHistory(s){
      const {ctx,w,h}=surface('history-canvas'),g=geometry(w,h),sim=state.sim,energy=$('chart-select').value==='energy';for(const el of $('history-labels').children)el.hidden=true;
      const series=energy?[{name:'K',get:q=>q.K,color:C.one},{name:tex`E_{\mathrm{diss}}`,get:q=>q.loss,color:C.loss},{name:tex`K+E_{\mathrm{diss}}`,get:q=>q.K+q.loss,color:C.ink,dash:[6,4]}]:[{name:'P_x',get:q=>q.P[0],color:C.one},...(sim.dimension==='plane'?[{name:'P_y',get:q=>q.P[1],color:C.two,dash:[5,3]}]:[])];
      const key=$('chart-select').value+sim.dimension;if(state.legend!==key){$('chart-key').replaceChildren();for(const q of series){const row=document.createElement('span'),swatch=document.createElement('i'),symbol=document.createElement('span');swatch.style.borderColor=q.color;if(q.dash)swatch.style.borderTopStyle='dashed';math(symbol,q.name);row.append(swatch,symbol);$('chart-key').append(row);}state.legend=key;}
      const data=[sim.sample(0)];if(sim.impact&&sim.tc<=sim.p.duration){data.push(sim.sample(sim.tc,'before'),sim.sample(sim.tc));}data.push(sim.sample(sim.p.duration));
      const values=series.flatMap(q=>data.map(q.get)),min=Math.min(0,...values),max=Math.max(0,...values),span=Math.max(1,max-min),low=min-.1*span,high=max+.15*span,X=t=>g.left+t/sim.p.duration*(g.right-g.left),Y=v=>g.bottom-(v-low)/(high-low)*(g.bottom-g.top),ticks=w<450?3:5;
      for(let i=0;i<=ticks;i++){const t=i*sim.p.duration/ticks,x=X(t);line(ctx,[[x,g.top],[x,g.bottom]],C.grid);numericLabel('history-labels','x'+i,t,x,g.bottom+18,Number.isInteger(t)?0:1);}
      for(let i=0;i<=4;i++){const value=low+(high-low)*i/4,y=Y(value);line(ctx,[[g.left,y],[g.right,y]],C.grid);if(Math.abs(y-Y(0))>=22)numericLabel('history-labels','y'+i,value,g.left-12,y,high-low<10?1:0).style.transform='translate(-100%,-50%)';}
      numericLabel('history-labels','y-zero',0,g.left-12,Y(0)).style.transform='translate(-100%,-50%)';
      label('history-labels','unitY',energy?tex`E\,[\mathrm J]`:tex`P\,[\mathrm{kg\,m\,s^{-1}}]`,g.left,13).style.transform='translate(0,-50%)';label('history-labels','unitX',tex`t\,[\mathrm s]`,(g.left+g.right)/2,h-10);
      line(ctx,[[g.left,Y(0)],[g.right,Y(0)]],C.muted,1,[3,5]);
      const past=data.filter(q=>q.t<=s.t);past.push(s);
      for(const q of series){ctx.globalAlpha=.25;line(ctx,data.map(v=>[X(v.t),Y(q.get(v))]),q.color,1.5,q.dash||[]);ctx.globalAlpha=1;line(ctx,past.map(v=>[X(v.t),Y(q.get(v))]),q.color,2,q.dash||[]);dot(ctx,X(s.t),Y(q.get(s)),3,q.color);}
      line(ctx,[[X(s.t),g.top],[X(s.t),g.bottom]],C.muted,1,[4,4]);$('history').setAttribute('aria-valuemax',sim.p.duration);$('history').setAttribute('aria-valuenow',s.t);$('history').setAttribute('aria-valuetext',s.t.toFixed(2)+' s');
    }
    function render(readouts=true){
      const sim=state.sim,s=sim.sample();if(readouts){
        for(const id of ['time-value','timeline-value'])number($(id),s.t,2,tex`\mathrm s`);$('timeline').value=s.t;$('timeline').setAttribute('aria-valuetext',s.t.toFixed(2)+' s');
        vectorValue($('P-value'),s.P,tex`\mathrm{kg\,m\,s^{-1}}`);number($('K-value'),s.K,3,tex`\mathrm J`);number($('loss-value'),s.loss,3,tex`\mathrm J`);number($('omega-value'),s.omega,2,tex`\mathrm{rad\,s^{-1}}`);$('rotation-info').hidden=!s.stuck||sim.dimension!=='plane';
        if(s.stuck&&sim.dimension==='plane')vectorValue($('ensemble-velocity-value'),sim.V,tex`\mathrm{m\,s^{-1}}`);
        $('status-badge').textContent=!sim.impact?'Sans rencontre':s.stuck?'Corps solidaires':s.after?'Après le choc':sim.tc>sim.p.duration?'Choc hors durée':'Avant le choc';$('status-badge').dataset.mode=s.after?'after':'before';drawHistory(s);
      }drawScene(s);drawTotalMomentum(s);
    }
    function seek(t){pause();state.sim.seek(t);render();}
    function frame(now){state.frame=0;if(!state.playing)return;const dt=state.last===null?0:Math.min(.1,Math.max(0,(now-state.last)/1000))*Number($('speed').value);state.last=now;
      try{state.sim.advance(dt);const refresh=now-state.lastReadout>=80;if(refresh)state.lastReadout=now;render(refresh);if(state.sim.done){pause();render();return;}}
      catch(error){pause();$('loading').hidden=false;$('loading').textContent='Animation interrompue : '+error.message;console.error(error);return;}state.frame=requestAnimationFrame(frame);
    }
    $('dimension').addEventListener('change',()=>configure($('dimension').value));$('example').addEventListener('change',()=>{if($('example').value!=='custom')configure(state.sim.dimension,$('example').value);});
    $('mode').addEventListener('change',()=>replace({mode:$('mode').value}));
    for(const [id,key]of controls)$(id).addEventListener('input',()=>{$('example').value='custom';replace({[key]:Number($(id).value)});});
    $('play').addEventListener('click',()=>{if(state.playing){pause();render();}else play();});$('restart').addEventListener('click',restart);$('reset').addEventListener('click',()=>configure(state.sim.dimension));
    $('timeline').addEventListener('input',()=>seek(Number($('timeline').value)));$('before').addEventListener('click',()=>{if(! $('before').disabled)seek(Math.max(0,state.sim.tc-.015));});$('after').addEventListener('click',()=>{if(! $('after').disabled)seek(state.sim.tc);});
    for(const id of ['vectors','traces','center','normal','chart-select','total-momentum'])$(id).addEventListener('change',()=>render());
    const plot=$('history'),seekPointer=e=>{const r=plot.getBoundingClientRect(),q=geometry(r.width,r.height);seek((e.clientX-r.left-q.left)/(q.right-q.left)*state.sim.p.duration);};
    plot.addEventListener('pointerdown',e=>{if(e.button!==undefined&&e.button!==0)return;plot.setPointerCapture(e.pointerId);seekPointer(e);});plot.addEventListener('pointermove',e=>{if(plot.hasPointerCapture(e.pointerId))seekPointer(e);});for(const name of ['pointerup','pointercancel'])plot.addEventListener(name,e=>{if(plot.hasPointerCapture(e.pointerId))plot.releasePointerCapture(e.pointerId);});
    plot.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();seek(e.key==='Home'?0:e.key==='End'?state.sim.p.duration:state.sim.t+(e.key==='ArrowLeft'?-.05:.05));}});
    document.addEventListener('keydown',e=>{if(e.target.closest('input,select,button,[role="slider"]')||e.ctrlKey||e.metaKey||e.altKey)return;if(e.code==='Space'){e.preventDefault();$('play').click();}if(e.key.toLowerCase()==='r')restart();});document.addEventListener('visibilitychange',()=>{if(document.hidden){pause();render();}});
    new ResizeObserver(()=>render()).observe($('scene'));configure('line');$('loading').hidden=true;
    // Optional page-local controls; browsers without WebMCP keep the same UI.
    if(document.modelContext?.registerTool){
      const lifecycle=new AbortController(),read=()=>({dimension:state.sim.dimension,parameters:{...state.sim.p},playing:state.playing,collisionTime:Number.isFinite(state.sim.tc)?state.sim.tc:null,state:state.sim.sample()});
      const object=(input,keys)=>{if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!keys.includes(k)))throw new Error('Commande non valide.');};
      const commands=[
        {name:'read_collision_experiment',title:'Lire l’expérience de collision',description:'Lire les paramètres et le bilan instantané en unités SI, sans modifier la simulation.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true},execute(input){object(input,[]);return read();}},
        {name:'select_collision_example',title:'Choisir un exemple de collision',description:'Choisir la dimension, un exemple et le type de collision. Remet l’expérience au départ et en pause.',inputSchema:{type:'object',properties:{dimension:{type:'string',enum:['line','plane']},example:{type:'string',enum:['target','headon','chase','offset','cross','miss']},mode:{type:'string',enum:['elastic','inelastic','sticking']}},required:['dimension','example','mode'],additionalProperties:false},annotations:{readOnlyHint:false},execute(input){object(input,['dimension','example','mode']);if(!Object.hasOwn(CP.presets,input.dimension)||!Object.hasOwn(CP.presets[input.dimension],input.example)||!['elastic','inelastic','sticking'].includes(input.mode))throw new Error('Exemple ou type de collision non valide.');configure(input.dimension,input.example);replace({mode:input.mode});return read();}},
        {name:'seek_collision_experiment',title:'Choisir un instant de la collision',description:'Mettre en pause et afficher un instant compris entre zéro et la durée choisie, ou juste avant/après le choc.',inputSchema:{type:'object',properties:{time:{type:'number',minimum:0},atImpact:{type:'string',enum:['before','after']}},additionalProperties:false},annotations:{readOnlyHint:false},execute(input){object(input,['time','atImpact']);if(Object.hasOwn(input,'time')===Object.hasOwn(input,'atImpact'))throw new Error('Choisir un instant ou un côté du choc, mais pas les deux.');let t=input.time;if(Object.hasOwn(input,'atImpact')){if(!['before','after'].includes(input.atImpact)||!state.sim.impact||state.sim.tc>state.sim.p.duration)throw new Error('Pas de choc accessible dans cette durée.');t=input.atImpact==='before'?Math.max(0,state.sim.tc-.015):state.sim.tc;}if(!Number.isFinite(t)||t<0||t>state.sim.p.duration)throw new Error('Instant hors limites.');seek(t);return read();}},
      ];
      for(const command of commands){try{void Promise.resolve(document.modelContext.registerTool(command,{signal:lifecycle.signal})).catch(error=>console.warn('Commandes agent indisponibles.',error));}catch(error){console.warn('Commandes agent indisponibles.',error);}}
      window.addEventListener('pagehide',()=>lifecycle.abort(),{once:true});
    }
  }catch(error){$('loading').hidden=false;$('loading').textContent='L’application n’a pas pu démarrer : '+error.message;console.error(error);}
}
