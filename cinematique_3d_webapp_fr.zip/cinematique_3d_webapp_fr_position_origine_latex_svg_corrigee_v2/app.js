(() => {
  'use strict';

  const COLORS = Object.freeze({
    position: '#d9683b',
    velocity: '#2775b6',
    acceleration: '#7758a6',
    tangential: '#b5688b',
    normal: '#268576',
    jerk: '#987125',
    trail: [137, 147, 157],
  });

  const PARAMETERS = Object.freeze({
    R: 1,
    x0: 1,
    y0: 1,
    z0: 1,
    omega: 0.5,
    alpha: 0.02,
    theta0Deg: 0,
  });

  // Physical laws use metres. The rendering coordinate system is kept
  // separate so changing physical scale preserves framing and arrow meshes.
  const SCENE_UNITS_PER_METRE = 2000;
  const BALLISTIC_TIME_SCALE = 1 / Math.sqrt(SCENE_UNITS_PER_METRE);
  const T_MAX = 10 * Math.PI * BALLISTIC_TIME_SCALE;
  const CLOSED_PERIOD = 2 * Math.PI / PARAMETERS.omega;
  const DOUBLE_CLOSED_PERIOD = 2 * CLOSED_PERIOD;
  const MCUA_TURN_DURATION = (Math.sqrt(PARAMETERS.omega ** 2 + 4 * Math.PI * PARAMETERS.alpha) - PARAMETERS.omega) / PARAMETERS.alpha;
  const MCUA_DURATION = 2 * MCUA_TURN_DURATION;
  const BUTTERFLY_DURATION = 24;
  const AXIS_TICK_STEP = 1;
  const AXIS_TICK_STEP_WORLD = AXIS_TICK_STEP * SCENE_UNITS_PER_METRE;
  const BASE_CAMERA_DISTANCE = 13800;
  const ZOOM_AXIS_STEP_DISTANCE = 3500;
  const ARROW = Object.freeze({
    shaftRadiusWorld: 19,
    headRadiusWorld: 55,
    headLengthWorld: 120,
    positionShorteningWorld: 150,
  });

  const V = (x = 0, y = 0, z = 0) => ({ x, y, z });
  const add = (a, b) => V(a.x + b.x, a.y + b.y, a.z + b.z);
  const sub = (a, b) => V(a.x - b.x, a.y - b.y, a.z - b.z);
  const scale = (a, s) => V(a.x * s, a.y * s, a.z * s);
  const dot = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
  const cross = (a, b) => V(
    a.y * b.z - a.z * b.y,
    a.z * b.x - a.x * b.z,
    a.x * b.y - a.y * b.x,
  );
  const norm = (a) => Math.hypot(a.x, a.y, a.z);
  const normalize = (a) => {
    const n = norm(a);
    return n > 1e-14 ? scale(a, 1 / n) : V(0, 0, 0);
  };

  // Keep the original z coordinate vertical in the rendered scene.
  const toWorld = (p) => V(p.x, p.z, p.y);
  const toScene = (p) => scale(toWorld(p), SCENE_UNITS_PER_METRE);
  const deg2rad = (angle) => angle * Math.PI / 180;
  const POSITION_VECTOR_ORIGIN = Object.freeze(V(0, 0, 0));

  const TRAJECTORIES = Object.freeze({
    lissajous: {
      label: 'Lissajous (𝑛=2)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.5,
      scaleA: 0.5,
      equations: [
        String.raw`x(t)=x_0+R\cos(\omega t)`,
        String.raw`y(t)=y_0+R\sin(2\omega t)`,
        String.raw`z(t)=z_0+R\sin(3\omega t)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=1\,\mathrm{m}`,
        String.raw`R=1\,\mathrm{m},\qquad \omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, z0, R, omega, theta0Deg } = PARAMETERS;
        const n = 2;
        return V(
          x0 + R * Math.cos(omega * t + deg2rad(theta0Deg)),
          y0 + R * Math.sin(n * omega * t),
          z0 + R * Math.sin(1.5 * n * omega * t),
        );
      },
    },
    lissajous3: {
      label: 'Lissajous (𝑛=3)',
      duration: DOUBLE_CLOSED_PERIOD,
      closed: true,
      scaleV: 0.32,
      scaleA: 0.16,
      equations: [
        String.raw`x(t)=x_0+R\cos(\omega t)`,
        String.raw`y(t)=y_0+R\sin(3\omega t)`,
        String.raw`z(t)=z_0+R\sin\!\left(\frac{9}{2}\omega t\right)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=1\,\mathrm{m}`,
        String.raw`R=1\,\mathrm{m},\qquad \omega=0.5\,\mathrm{rad\,s^{-1}}`,
        String.raw`n=3,\qquad T=\frac{4\pi}{\omega}=8\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, R, omega, theta0Deg } = PARAMETERS;
        const n = 3;
        return V(
          x0 + R * Math.cos(omega * t + deg2rad(theta0Deg)),
          y0 + R * Math.sin(n * omega * t),
          z0 + R * Math.sin(1.5 * n * omega * t),
        );
      },
    },
    astroid: {
      label: 'Astroïde',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.5,
      scaleA: 0.5,
      equations: [
        String.raw`x(t)=x_0+R\cos^3(\omega t)`,
        String.raw`y(t)=y_0+R\sin^3(\omega t)`,
        String.raw`z(t)=z_0+R\sin(2\omega t)\cos(2\omega t)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=1\,\mathrm{m}`,
        String.raw`R=1\,\mathrm{m},\qquad \omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, z0, R, omega } = PARAMETERS;
        const q = omega * t;
        const c = Math.cos(q);
        const sinq = Math.sin(q);
        return V(
          x0 + R * c ** 3,
          y0 + R * sinq ** 3,
          z0 + R * Math.sin(2 * q) * Math.cos(2 * q),
        );
      },
    },
    quadrifolium: {
      label: 'Quadrifolium',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.35,
      scaleA: 0.35,
      equations: [
        String.raw`x(t)=x_0+R\cos(2\omega t)\cos(\omega t)`,
        String.raw`y(t)=y_0+R\cos(2\omega t)\sin(\omega t)`,
        String.raw`z(t)=z_0+R\sin(2\omega t)\sin(\omega t)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=1\,\mathrm{m}`,
        String.raw`R=1\,\mathrm{m},\qquad \omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, z0, R, omega } = PARAMETERS;
        const q = omega * t;
        return V(
          x0 + R * Math.cos(2 * q) * Math.cos(q),
          y0 + R * Math.cos(2 * q) * Math.sin(q),
          z0 + R * Math.sin(2 * q) * Math.sin(q),
        );
      },
    },
    mcua: {
      label: 'Mouvement circulaire uniformément accéléré',
      duration: MCUA_DURATION,
      closed: false,
      scaleV: 0.5,
      scaleA: 0.5,
      equations: [
        String.raw`\varphi(t)=\frac{1}{2}\alpha t^2+\omega_0t+\theta_0`,
        String.raw`x(t)=x_0+R\cos\!\bigl(\varphi(t)\bigr)`,
        String.raw`y(t)=y_0+R\sin\!\bigl(\varphi(t)\bigr)`,
        String.raw`z(t)=z_0`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=1\,\mathrm{m},\qquad R=1\,\mathrm{m}`,
        String.raw`\omega_0=0.5\,\mathrm{rad\,s^{-1}},\qquad \alpha=0.02\,\mathrm{rad\,s^{-2}}`,
        String.raw`T_{\mathrm{tour}}\simeq 10.40\,\mathrm s,\qquad t_{\max}=2T_{\mathrm{tour}}\simeq 20.80\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, R, omega, alpha, theta0Deg } = PARAMETERS;
        const phi = 0.5 * alpha * t * t + omega * t + deg2rad(theta0Deg);
        return V(x0 + R * Math.cos(phi), y0 + R * Math.sin(phi), z0);
      },
    },
    fish: {
      label: 'Courbe poisson',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.5,
      scaleA: 0.65,
      equations: [
        String.raw`x(t)=x_0+R\left[\cos(\omega t)-\frac{\sin^2(\omega t)}{\sqrt{2}}\right]`,
        String.raw`y(t)=y_0+R\cos(\omega t)\sin(\omega t)`,
        String.raw`z(t)=z_0`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=1\,\mathrm{m}`,
        String.raw`R=1\,\mathrm{m},\qquad \omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, z0, R, omega } = PARAMETERS;
        const q = omega * t;
        const sinq = Math.sin(q);
        const c = Math.cos(q);
        return V(
          x0 + R * (c - sinq * sinq / Math.sqrt(2)),
          y0 + R * c * sinq,
          z0,
        );
      },
    },
    trefoil: {
      label: 'Nœud de trèfle T(2,3)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.40,
      scaleA: 0.20,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+\bigl(R_0+r\cos(3\tau)\bigr)\cos(2\tau)`,
        String.raw`y(t)=y_0+\bigl(R_0+r\cos(3\tau)\bigr)\sin(2\tau)`,
        String.raw`z(t)=z_0+r\sin(3\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=1\,\mathrm m`,
        String.raw`R_0=0.55\,\mathrm m,\qquad r=0.325\,\mathrm m`,
        String.raw`T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const R0 = 0.55;
        const r = 0.325;
        const q = omega * t;
        const radial = R0 + r * Math.cos(3 * q);
        return V(
          x0 + radial * Math.cos(2 * q),
          y0 + radial * Math.sin(2 * q),
          z0 + r * Math.sin(3 * q),
        );
      },
    },
    figureEightKnot: {
      label: 'Nœud en huit',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.25,
      scaleA: 0.16,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+A\bigl[2+\cos(2\tau)\bigr]\cos(3\tau)`,
        String.raw`y(t)=y_0+A\bigl[2+\cos(2\tau)\bigr]\sin(3\tau)`,
        String.raw`z(t)=z_0+A\sin(4\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=1\,\mathrm m,\qquad A=0.31\,\mathrm m`,
        String.raw`T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const A = 0.31;
        const q = omega * t;
        const radial = A * (2 + Math.cos(2 * q));
        return V(
          x0 + radial * Math.cos(3 * q),
          y0 + radial * Math.sin(3 * q),
          z0 + A * Math.sin(4 * q),
        );
      },
    },
    cinquefoil: {
      label: 'Nœud à cinq lobes T(2,5)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.33,
      scaleA: 0.12,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+\bigl(R_0+r\cos(5\tau)\bigr)\cos(2\tau)`,
        String.raw`y(t)=y_0+\bigl(R_0+r\cos(5\tau)\bigr)\sin(2\tau)`,
        String.raw`z(t)=z_0+r\sin(5\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=1\,\mathrm m`,
        String.raw`R_0=0.575\,\mathrm m,\qquad r=0.275\,\mathrm m`,
        String.raw`T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const R0 = 0.575;
        const r = 0.275;
        const q = omega * t;
        const radial = R0 + r * Math.cos(5 * q);
        return V(
          x0 + radial * Math.cos(2 * q),
          y0 + radial * Math.sin(2 * q),
          z0 + r * Math.sin(5 * q),
        );
      },
    },
    toroidalHelix: {
      label: 'Hélice toroïdale (7 spires)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.35,
      scaleA: 0.09,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+\bigl(R_0+r\cos(n\tau)\bigr)\cos\tau`,
        String.raw`y(t)=y_0+\bigl(R_0+r\cos(n\tau)\bigr)\sin\tau`,
        String.raw`z(t)=z_0+r\sin(n\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=1\,\mathrm m`,
        String.raw`R_0=0.625\,\mathrm m,\qquad r=0.24\,\mathrm m,\qquad n=7`,
        String.raw`T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const R0 = 0.625;
        const r = 0.24;
        const n = 7;
        const q = omega * t;
        const radial = R0 + r * Math.cos(n * q);
        return V(
          x0 + radial * Math.cos(q),
          y0 + radial * Math.sin(q),
          z0 + r * Math.sin(n * q),
        );
      },
    },
    viviani: {
      label: 'Courbe de Viviani',
      duration: DOUBLE_CLOSED_PERIOD,
      closed: true,
      scaleV: 0.90,
      scaleA: 2.00,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+a\cos\tau`,
        String.raw`y(t)=y_0+a\sin\tau`,
        String.raw`z(t)=z_0+2a\sin\!\left(\frac{\tau}{2}\right)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=1\,\mathrm m,\qquad a=0.425\,\mathrm m`,
        String.raw`T=\frac{4\pi}{\omega}=8\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const a = 0.425;
        const q = omega * t;
        return V(
          x0 + a * Math.cos(q),
          y0 + a * Math.sin(q),
          z0 + 2 * a * Math.sin(0.5 * q),
        );
      },
    },
    sphericalRose: {
      label: 'Rose sphérique (3 pétales)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.24,
      scaleA: 0.13,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+R\cos(3\tau)\cos\tau`,
        String.raw`y(t)=y_0+R\cos(3\tau)\sin\tau`,
        String.raw`z(t)=z_0+R\sin(3\tau)`,
      ],
      parameters: [
        String.raw`R=0.85\,\mathrm m,\qquad T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
        String.raw`(x-x_0)^2+(y-y_0)^2+(z-z_0)^2=R^2`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const R = 0.85;
        const q = omega * t;
        const latitudeRadius = R * Math.cos(3 * q);
        return V(
          x0 + latitudeRadius * Math.cos(q),
          y0 + latitudeRadius * Math.sin(q),
          z0 + R * Math.sin(3 * q),
        );
      },
    },
    sphericalSpiral: {
      label: 'Spirale sphérique (5 enroulements)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.18,
      scaleA: 0.05,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+R\cos(2\tau)\cos(5\tau)`,
        String.raw`y(t)=y_0+R\cos(2\tau)\sin(5\tau)`,
        String.raw`z(t)=z_0+R\sin(2\tau)`,
      ],
      parameters: [
        String.raw`R=0.85\,\mathrm m,\qquad T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
        String.raw`(x-x_0)^2+(y-y_0)^2+(z-z_0)^2=R^2`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const R = 0.85;
        const q = omega * t;
        const latitudeRadius = R * Math.cos(2 * q);
        return V(
          x0 + latitudeRadius * Math.cos(5 * q),
          y0 + latitudeRadius * Math.sin(5 * q),
          z0 + R * Math.sin(2 * q),
        );
      },
    },
    harmonicKnot: {
      label: 'Nœud harmonique (3,4,5)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.16,
      scaleA: 0.06,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+R\cos(3\tau)`,
        String.raw`y(t)=y_0+R\sin(4\tau)`,
        String.raw`z(t)=z_0+R\sin(5\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=1\,\mathrm m,\qquad R=0.775\,\mathrm m`,
        String.raw`T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const R = 0.775;
        const q = omega * t;
        return V(
          x0 + R * Math.cos(3 * q),
          y0 + R * Math.sin(4 * q),
          z0 + R * Math.sin(5 * q),
        );
      },
    },
    heart: {
      label: 'Cœur tridimensionnel',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.65,
      scaleA: 0.55,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+16A\sin^3\tau`,
        String.raw`y(t)=y_0+A\bigl[13\cos\tau-5\cos(2\tau)-2\cos(3\tau)-\cos(4\tau)\bigr]`,
        String.raw`z(t)=z_0+B\sin(2\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=1\,\mathrm m`,
        String.raw`A=0.0475\,\mathrm m,\qquad B=0.225\,\mathrm m,\qquad T=4\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const A = 0.0475;
        const B = 0.225;
        const q = omega * t;
        const s = Math.sin(q);
        return V(
          x0 + 16 * A * s ** 3,
          y0 + A * (13 * Math.cos(q) - 5 * Math.cos(2 * q) - 2 * Math.cos(3 * q) - Math.cos(4 * q)),
          z0 + B * Math.sin(2 * q),
        );
      },
    },
    butterfly: {
      label: 'Papillon tridimensionnel',
      duration: BUTTERFLY_DURATION,
      closed: true,
      scaleV: 0.12,
      scaleA: 0.018,
      equations: [
        String.raw`\tau=\frac{12\pi t}{T}`,
        String.raw`\rho(\tau)=e^{\sin\tau}-2\cos(4\tau)+\sin^5\!\left(\frac{2\tau-\pi}{24}\right)`,
        String.raw`x(t)=x_0+A\rho(\tau)\sin\tau`,
        String.raw`y(t)=y_0+A\rho(\tau)\cos\tau`,
        String.raw`z(t)=z_0+B\sin(3\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=1\,\mathrm m`,
        String.raw`A=0.22\,\mathrm m,\qquad B=0.26\,\mathrm m,\qquad T=24\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0 } = PARAMETERS;
        const A = 0.22;
        const B = 0.26;
        const q = 12 * Math.PI * t / BUTTERFLY_DURATION;
        const rho = Math.exp(Math.sin(q))
          - 2 * Math.cos(4 * q)
          + Math.sin((2 * q - Math.PI) / 24) ** 5;
        return V(
          x0 + A * rho * Math.sin(q),
          y0 + A * rho * Math.cos(q),
          z0 + B * Math.sin(3 * q),
        );
      },
    },
    ballistic: {
      label: 'Trajectoire balistique',
      duration: T_MAX,
      closed: false,
      scaleV: 3 * BALLISTIC_TIME_SCALE,
      scaleA: 25 / SCENE_UNITS_PER_METRE,
      jerk() { return V(0, 0, 0); },
      equations: [
        String.raw`x(t)=x_0+v_0\cos(\theta_0)t`,
        String.raw`y(t)=y_0`,
        String.raw`z(t)=z_0+v_0\sin(\theta_0)t-\frac{1}{2}gt^2`,
      ],
      parameters: [
        String.raw`x_0=z_0=0\,\mathrm{m},\qquad y_0=1\,\mathrm{m}`,
        String.raw`v_0=\sqrt{20}\simeq 4.47\,\mathrm{m\,s^{-1}},\qquad \theta_0=60^\circ,\qquad g=9.81\,\mathrm{m\,s^{-2}}`,
        String.raw`\vec a=\vec g=-g\,\vec e_z`,
      ],
      position(t) {
        const v0 = Math.sqrt(20);
        const theta = deg2rad(60);
        const g = 9.81;
        return V(
          v0 * t * Math.cos(theta),
          PARAMETERS.y0,
          v0 * t * Math.sin(theta) - 0.5 * g * t * t,
        );
      },
    },
  });

  function derivatives(trajectory, t) {
    const h = 1e-3;
    const pm = trajectory.position(t - h);
    const p = trajectory.position(t);
    const pp = trajectory.position(t + h);
    const velocity = scale(sub(pp, pm), 1 / (2 * h));
    const acceleration = scale(add(add(pp, pm), scale(p, -2)), 1 / (h * h));
    const speed = norm(velocity);
    let tangential = V(0, 0, 0);
    let normal = { ...acceleration };
    let decompositionDefined = false;

    if (speed > 1e-5 / SCENE_UNITS_PER_METRE) {
      const tangent = scale(velocity, 1 / speed);
      tangential = scale(tangent, dot(acceleration, tangent));
      normal = sub(acceleration, tangential);
      decompositionDefined = true;
    }

    const jerk = jerkAt(trajectory, t);
    return { position: p, velocity, acceleration, jerk, tangential, normal, speed, decompositionDefined };
  }

  // Differentiate the smooth position law, not the playback wrap/clamp.
  // A symmetric seven-point stencil gives fourth-order accuracy without
  // differentiating the noise in the displayed acceleration.
  function jerkAt(item, t) {
    if (item.jerk) return item.jerk(t);
    const h = 0.004;
    const pm1 = item.position(t - h);
    const pp1 = item.position(t + h);
    const pm2 = item.position(t - 2 * h);
    const pp2 = item.position(t + 2 * h);
    const pm3 = item.position(t - 3 * h);
    const pp3 = item.position(t + 3 * h);
    const numerator = add(
      add(scale(sub(pm1, pp1), 13), scale(sub(pp2, pm2), 8)),
      sub(pm3, pp3),
    );
    const result = scale(numerator, 1 / (8 * h ** 3));
    for (const axis of Object.keys(result)) {
      if (Math.abs(result[axis]) < 1e-4 / SCENE_UNITS_PER_METRE) result[axis] = 0;
    }
    return result;
  }

  const jerkScales = new WeakMap();
  function jerkDisplayScale(item) {
    if (!jerkScales.has(item)) {
      let maximum = 0;
      for (let i = 0; i <= 384; i += 1) {
        maximum = Math.max(maximum, norm(jerkAt(item, item.duration * i / 384)));
      }
      // Fixed for each trajectory: arrow length still follows |j(t)|.
      jerkScales.set(item, maximum > 1e-4 / SCENE_UNITS_PER_METRE ? 0.65 * PARAMETERS.R / maximum : 1);
    }
    return jerkScales.get(item);
  }

  // Physical geometry only: independent of camera and vector display scales.
  function osculatingGeometry(data) {
    const speed = norm(data.velocity);
    if (!Number.isFinite(speed) || speed <= 1e-2 / SCENE_UNITS_PER_METRE) {
      return { defined: false, reason: 'stationary' };
    }
    const tangent = scale(data.velocity, 1 / speed);
    const normalAcceleration = sub(data.acceleration, scale(tangent, dot(data.acceleration, tangent)));
    const normalMagnitude = norm(normalAcceleration);
    // Suppress finite-difference roundoff at straight segments and inflections.
    const tolerance = Math.max(1e-5 / SCENE_UNITS_PER_METRE, norm(data.acceleration) * 1e-7);
    if (!Number.isFinite(normalMagnitude) || normalMagnitude <= tolerance) {
      return { defined: false, reason: 'straight' };
    }
    const normal = scale(normalAcceleration, 1 / normalMagnitude);
    const radius = speed * speed / normalMagnitude;
    const center = add(data.position, scale(normal, radius));
    if (!Number.isFinite(radius) || !Object.values(center).every(Number.isFinite)) {
      return { defined: false, reason: 'unresolved' };
    }
    return { defined: true, radius, center, tangent, normal, position: data.position };
  }

  function osculatingPoint(circle, angle) {
    // Anchored at the mobile: avoids center - radius cancellation for large radii.
    return add(circle.position, add(
      scale(circle.tangent, circle.radius * Math.sin(angle)),
      scale(circle.normal, 2 * circle.radius * Math.sin(angle / 2) ** 2),
    ));
  }

  function clipScreenSegment(a, b, bounds) {
    if (![a?.x, a?.y, b?.x, b?.y].every(Number.isFinite)) return null;
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    let first = 0;
    let last = 1;
    const edges = [
      [-dx, a.x - bounds.left], [dx, bounds.right - a.x],
      [-dy, a.y - bounds.top], [dy, bounds.bottom - a.y],
    ];
    for (const [p, q] of edges) {
      if (p === 0) {
        if (q < 0) return null;
      } else {
        const t = q / p;
        if (p < 0) first = Math.max(first, t);
        else last = Math.min(last, t);
        if (first > last) return null;
      }
    }
    return [
      { x: a.x + first * dx, y: a.y + first * dy },
      { x: a.x + last * dx, y: a.y + last * dy },
    ];
  }

  const viewport = document.getElementById('viewport');
  const loadingMessage = document.getElementById('loading-message');
  const canvas = document.createElement('canvas');
  canvas.setAttribute('aria-label', 'Canevas interactif de cinématique en trois dimensions');
  viewport.prepend(canvas);
  const ctx = canvas.getContext('2d', { alpha: true });

  const state = {
    trajectoryKey: 'lissajous',
    time: 0,
    playing: true,
    playbackSpeed: 1,
    loop: true,
    vectorScale: 1,
    trailDuration: 4,
    fullTrail: true,
    projections: false,
  };

  const camera = {
    yaw: 0.78,
    pitch: 0.48,
    distance: 13800,
    target: V(2000, 2000, 2000),
    fov: deg2rad(42),
  };

  let viewportWidth = 1;
  let viewportHeight = 1;
  let dpr = 1;

  const dom = {
    trajectory: document.getElementById('trajectory-select'),
    play: document.getElementById('play-button'),
    reset: document.getElementById('reset-button'),
    resetView: document.getElementById('reset-view'),
    topView: document.getElementById('top-view'),
    frontView: document.getElementById('front-view'),
    sideView: document.getElementById('side-view'),
    speed: document.getElementById('speed-select'),
    timeSlider: document.getElementById('time-slider'),
    timeOutputDigits: document.getElementById('time-output-digits'),
    timeBadgeDigits: document.getElementById('time-badge-digits'),
    loop: document.getElementById('loop-toggle'),
    vectorScale: document.getElementById('vector-scale'),
    vectorScaleOutputDigits: document.getElementById('vector-scale-output-digits'),
    trailDuration: document.getElementById('trail-duration'),
    trailDurationOutputDigits: document.getElementById('trail-duration-output-digits'),
    fullTrail: document.getElementById('full-trail'),
    projections: document.getElementById('projection-toggle'),
    osculating: document.getElementById('osculating-toggle'),
    curvatureDetails: document.getElementById('curvature-details'),
    curvatureValue: document.getElementById('curvature-value'),
    curvatureDigits: document.getElementById('curvature-digits'),
    curvatureScientific: document.getElementById('curvature-scientific'),
    curvatureExponent: document.getElementById('curvature-exponent'),
    curvatureStatus: document.getElementById('curvature-status'),
    radiusLabel: document.getElementById('radius-label'),
    equations: document.getElementById('trajectory-equations'),
    vectorReadouts: document.getElementById('vector-readouts'),
    warning: document.getElementById('warning-badge'),
    axisLabels: {
      x: document.getElementById('axis-label-x'),
      y: document.getElementById('axis-label-y'),
      z: document.getElementById('axis-label-z'),
    },
    lengthScaleDigits: document.getElementById('length-scale-digits'),
    lengthScaleBar: document.getElementById('length-scale-bar'),
    lengthScalePath: document.getElementById('length-scale-path'),
    clearVectors: document.getElementById('clear-vectors'),
    toggles: {
      position: document.getElementById('toggle-position'),
      velocity: document.getElementById('toggle-velocity'),
      acceleration: document.getElementById('toggle-acceleration'),
      tangential: document.getElementById('toggle-tangential'),
      normal: document.getElementById('toggle-normal'),
      jerk: document.getElementById('toggle-jerk'),
    },
  };

  const VECTOR_META = Object.freeze({
    position: {
      symbolTeX: String.raw`\vec r`,
      unitTeX: String.raw`\mathrm m`,
      plainName: 'position',
      color: COLORS.position,
    },
    velocity: {
      symbolTeX: String.raw`\vec v`,
      unitTeX: String.raw`\mathrm{m\,s^{-1}}`,
      plainName: 'vitesse',
      color: COLORS.velocity,
    },
    acceleration: {
      symbolTeX: String.raw`\vec a`,
      unitTeX: String.raw`\mathrm{m\,s^{-2}}`,
      plainName: 'accélération',
      color: COLORS.acceleration,
    },
    tangential: {
      symbolTeX: String.raw`\vec a_{\mathrm t}`,
      unitTeX: String.raw`\mathrm{m\,s^{-2}}`,
      plainName: 'accélération tangentielle',
      color: COLORS.tangential,
    },
    normal: {
      symbolTeX: String.raw`\vec a_{\mathrm c}`,
      unitTeX: String.raw`\mathrm{m\,s^{-2}}`,
      plainName: 'accélération centripète',
      color: COLORS.normal,
    },
    jerk: {
      symbolTeX: String.raw`\vec{\jmath}`,
      unitTeX: String.raw`\mathrm{m\,s^{-3}}`,
      plainName: 'à-coup',
      color: COLORS.jerk,
    },
  });

  const readoutElements = {};
  for (const [key, meta] of Object.entries(VECTOR_META)) {
    const element = document.createElement('div');
    element.className = 'vector-readout';
    element.style.setProperty('--readout-color', meta.color);
    element.innerHTML = `
      <div class="vector-readout-line vector-readout-magnitude">
        <span class="tex-math">\\(\\lvert${meta.symbolTeX}\\rvert=\\)</span>
        <span class="math-digits magnitude-digits">0.00</span>
        <span class="tex-math">\\(\\,${meta.unitTeX}\\)</span>
      </div>
      <div class="vector-readout-line vector-readout-components">
        <span class="tex-math">\\(${meta.symbolTeX}=(\\)</span>
        <span class="math-digits component-x-digits">0.0</span>
        <span class="tex-math">\\(,\\,\\)</span>
        <span class="math-digits component-y-digits">0.0</span>
        <span class="tex-math">\\(,\\,\\)</span>
        <span class="math-digits component-z-digits">0.0</span>
        <span class="tex-math">\\()\\)</span>
      </div>`;
    dom.vectorReadouts.append(element);
    readoutElements[key] = {
      root: element,
      meta,
      magnitude: element.querySelector('.magnitude-digits'),
      componentX: element.querySelector('.component-x-digits'),
      componentY: element.querySelector('.component-y-digits'),
      componentZ: element.querySelector('.component-z-digits'),
    };
  }

  let mathIsReady = false;
  let mathTypesetQueue = Promise.resolve();
  const mathGlyphTemplates = new Map();
  let axisLabelLayoutKey = '';

  function queueTypeset(elements) {
    if (!mathIsReady || !window.MathJax?.typesetPromise) return Promise.resolve();
    mathTypesetQueue = mathTypesetQueue
      .then(() => window.MathJax.typesetPromise(elements))
      .catch((error) => console.error('Échec de la composition MathJax :', error));
    return mathTypesetQueue;
  }

  async function initializeMathGlyphs() {
    const characters = '0123456789.-+';
    for (const character of characters) {
      const tex = character === '-' ? '{-}' : character === '+' ? '{+}' : character;
      const rendered = await window.MathJax.tex2svgPromise(tex, { display: false });
      rendered.setAttribute('aria-hidden', 'true');
      mathGlyphTemplates.set(character, rendered);
    }
  }

  function setMathDigits(element, text) {
    if (!element) return;
    const value = String(text);
    if (!mathIsReady || mathGlyphTemplates.size === 0) {
      element.textContent = value;
      element.dataset.value = value;
      return;
    }
    if (element.dataset.value === value && element.classList.contains('typeset')) return;

    const fragment = document.createDocumentFragment();
    for (const character of value) {
      const wrapper = document.createElement('span');
      wrapper.className = 'math-glyph';
      wrapper.setAttribute('aria-hidden', 'true');
      const template = mathGlyphTemplates.get(character);
      if (template) wrapper.append(template.cloneNode(true));
      else wrapper.textContent = character;
      fragment.append(wrapper);
    }
    element.replaceChildren(fragment);
    element.classList.add('typeset');
    element.dataset.value = value;
  }

  function updateDynamicMathOutputs() {
    setMathDigits(dom.timeOutputDigits, state.time.toFixed(2));
    setMathDigits(dom.timeBadgeDigits, state.time.toFixed(2));
    setMathDigits(dom.vectorScaleOutputDigits, state.vectorScale.toFixed(2));
    setMathDigits(dom.trailDurationOutputDigits, state.trailDuration.toFixed(1));
  }

  const currentTrajectory = () => TRAJECTORIES[state.trajectoryKey];
  const trajectoryTimeMax = (item) => item.closed ? 2 * item.duration : item.duration;
  const axisTickValues = (minimum, maximum) => {
    const first = Math.ceil((minimum - 1e-9) / AXIS_TICK_STEP_WORLD) * AXIS_TICK_STEP_WORLD;
    const values = [];
    for (let value = first; value <= maximum + 1e-9; value += AXIS_TICK_STEP_WORLD) {
      values.push(Math.abs(value) < 1e-9 ? 0 : value);
    }
    return values;
  };
  const axisRange = (coordinate) => {
    const zoomSteps = Math.max(0, Math.floor((camera.distance - BASE_CAMERA_DISTANCE + 1e-9) / ZOOM_AXIS_STEP_DISTANCE));
    const halfSteps = 1 + zoomSteps;
    const center = Math.round(coordinate / AXIS_TICK_STEP_WORLD) * AXIS_TICK_STEP_WORLD;
    const minimum = center - halfSteps * AXIS_TICK_STEP_WORLD;
    const maximum = center + halfSteps * AXIS_TICK_STEP_WORLD;
    return { minimum, maximum, ticks: axisTickValues(minimum, maximum) };
  };
  const currentAxisRanges = () => ({
    x: axisRange(camera.target.x),
    y: axisRange(camera.target.z),
    z: axisRange(camera.target.y),
  });
  const vectorSelection = () => Object.fromEntries(
    Object.entries(dom.toggles).map(([key, input]) => [key, input.checked]),
  );

  function resetCamera() {
    camera.yaw = 0.78;
    camera.pitch = 0.48;
    camera.distance = BASE_CAMERA_DISTANCE;
    camera.target = V(2000, 2000, 2000);
  }

  function cameraBasis() {
    const cp = Math.cos(camera.pitch);
    const cameraPosition = add(camera.target, scale(V(
      cp * Math.sin(camera.yaw),
      Math.sin(camera.pitch),
      cp * Math.cos(camera.yaw),
    ), camera.distance));
    const forward = normalize(sub(camera.target, cameraPosition));
    // The yaw-defined horizontal axis remains continuous at both poles,
    // where crossing the viewing direction with vertical would be singular.
    const right = V(Math.cos(camera.yaw), 0, -Math.sin(camera.yaw));
    const up = normalize(cross(right, forward));
    const focal = 0.5 * viewportHeight / Math.tan(camera.fov / 2);
    return { cameraPosition, forward, right, up, focal };
  }

  function projectWorld(point, basis) {
    const relative = sub(point, basis.cameraPosition);
    const depth = dot(relative, basis.forward);
    if (depth <= 5) return null;
    const x = dot(relative, basis.right);
    const y = dot(relative, basis.up);
    const perspective = basis.focal / depth;
    return {
      x: viewportWidth / 2 + x * perspective,
      y: viewportHeight / 2 - y * perspective,
      depth,
      perspective,
    };
  }

  const projectPhysical = (point, basis) => projectWorld(toScene(point), basis);

  function strokeSegment(a, b, basis, color, width = 1, alpha = 1, dash = []) {
    const pa = projectWorld(a, basis);
    const pb = projectWorld(b, basis);
    if (!pa || !pb) return;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.setLineDash(dash);
    ctx.beginPath();
    ctx.moveTo(pa.x, pa.y);
    ctx.lineTo(pb.x, pb.y);
    ctx.stroke();
    ctx.restore();
  }

  function drawReferenceFrame(basis) {
    const levels = [0, 2000, 4000];
    const soft = '#9cacbf';
    const ranges = currentAxisRanges();

    // The 0–2 m reference cube uses 0–4000 rendering coordinates.
    for (const value of levels) {
      strokeSegment(V(0, 0, value), V(4000, 0, value), basis, soft, 1, 0.28);
      strokeSegment(V(value, 0, 0), V(value, 0, 4000), basis, soft, 1, 0.28);

      strokeSegment(V(0, value, 0), V(4000, value, 0), basis, soft, 1, 0.17);
      strokeSegment(V(value, 0, 0), V(value, 4000, 0), basis, soft, 1, 0.17);

      strokeSegment(V(0, 0, value), V(0, 4000, value), basis, soft, 1, 0.17);
      strokeSegment(V(0, value, 0), V(0, value, 4000), basis, soft, 1, 0.17);
    }

    const corners = [];
    for (const x of [0, 4000]) {
      for (const y of [0, 4000]) {
        for (const z of [0, 4000]) corners.push(V(x, y, z));
      }
    }
    const edges = [];
    for (let i = 0; i < corners.length; i += 1) {
      for (let j = i + 1; j < corners.length; j += 1) {
        const a = corners[i];
        const b = corners[j];
        const differing = Number(a.x !== b.x) + Number(a.y !== b.y) + Number(a.z !== b.z);
        if (differing === 1) edges.push([a, b]);
      }
    }
    for (const [a, b] of edges) strokeSegment(a, b, basis, '#607089', 1.4, 0.78);

    // Axes and tick marks extend dynamically as the user zooms or pans.
    const axisColor = '#52627a';
    strokeSegment(V(ranges.x.minimum, 0, 0), V(ranges.x.maximum, 0, 0), basis, axisColor, 1.55, 0.82);
    strokeSegment(V(0, 0, ranges.y.minimum), V(0, 0, ranges.y.maximum), basis, axisColor, 1.55, 0.82);
    strokeSegment(V(0, ranges.z.minimum, 0), V(0, ranges.z.maximum, 0), basis, axisColor, 1.55, 0.82);

    // Physical spacing remains AXIS_TICK_STEP. The marks themselves keep a
    // readable screen size and orientation, including in the top view.
    ctx.save();
    ctx.strokeStyle = axisColor;
    ctx.lineWidth = 1.3;
    ctx.globalAlpha = 0.82;
    for (const [axis,unit] of [['x',V(1,0,0)],['y',V(0,0,1)],['z',V(0,1,0)]]) {
      const start = projectWorld(scale(unit,ranges[axis].minimum),basis);
      const end = projectWorld(scale(unit,ranges[axis].maximum),basis);
      if (!start || !end || Math.abs(dot(unit,basis.forward)) > .985) continue;
      const length = Math.hypot(end.x-start.x,end.y-start.y);
      if (length < 45) continue;
      const nx = -(end.y-start.y)/length, ny = (end.x-start.x)/length;
      for (const tick of ranges[axis].ticks) {
        const p = projectWorld(scale(unit,tick),basis);
        if (!p) continue;
        ctx.beginPath();
        ctx.moveTo(p.x-5*nx,p.y-5*ny);
        ctx.lineTo(p.x+5*nx,p.y+5*ny);
        ctx.stroke();
      }
    }
    ctx.restore();

    updateLengthScale(basis);
    drawAxisLabels(basis, ranges);
  }

  function updateLengthScale(basis) {
    // A screen-parallel segment at the camera target has constant depth.
    // Its pixel length is exact there; perspective changes scale elsewhere.
    const pixelsPerMetre = SCENE_UNITS_PER_METRE * basis.focal / camera.distance;
    const maximumWidth = Math.max(40,Math.min(200,viewportWidth-80));
    const minimumWidth = Math.min(70,maximumWidth/2);
    let metres = AXIS_TICK_STEP;
    while (metres*pixelsPerMetre > maximumWidth) metres /= 2;
    while (metres*pixelsPerMetre < minimumWidth) metres *= 2;
    const pixels = metres*pixelsPerMetre;
    const width = String(pixels+4);
    if (dom.lengthScaleBar.getAttribute('width') !== width) {
      dom.lengthScaleBar.setAttribute('width',width);
      dom.lengthScaleBar.setAttribute('viewBox',`0 0 ${width} 14`);
      dom.lengthScalePath.setAttribute('d',`M2 2V12 M2 7H${pixels+2} M${pixels+2} 2V12`);
    }
    setMathDigits(dom.lengthScaleDigits,String(metres));
    const description = `Étalon de longueur : ${metres} mètres, au centre de la vue (perspective).`;
    if (dom.lengthScaleBar.parentElement.getAttribute('aria-label') !== description)
      dom.lengthScaleBar.parentElement.setAttribute('aria-label',description);
  }

  function drawAxisLabels(basis, ranges) {
    // Screen-space clearance is independent of zoom. No particle or vector
    // position enters this layout, so labels cannot jump during playback.
    const key = [viewportWidth, viewportHeight, camera.yaw, camera.pitch,
      camera.distance, camera.target.x, camera.target.y, camera.target.z,
      mathIsReady, getComputedStyle(dom.axisLabels.x).fontSize].join('|');
    if (key === axisLabelLayoutKey) return;
    axisLabelLayoutKey = key;
    const axes = [], occupied = [], sizes = new Map();
    const worldAxis = { x: V(1, 0, 0), y: V(0, 0, 1), z: V(0, 1, 0) };
    const size = element => {
      if (!sizes.has(element)) {
        element.hidden = false;
        element.style.visibility = 'hidden';
        sizes.set(element, { w: element.offsetWidth, h: element.offsetHeight });
        element.hidden = true;
        element.style.visibility = '';
      }
      return sizes.get(element);
    };
    const overlap = (a, b, gap = 4) => a.x < b.x + b.w + gap
      && a.x + a.w + gap > b.x && a.y < b.y + b.h + gap && a.y + a.h + gap > b.y;
    const frame = viewport.getBoundingClientRect();
    for (const selector of ['.viewport-toolbar', '.time-badge', '.length-scale']) {
      const r = viewport.querySelector(selector).getBoundingClientRect();
      occupied.push({ x: r.left - frame.left, y: r.top - frame.top, w: r.width, h: r.height });
    }
    for (const axis of ['x', 'y', 'z']) {
      dom.axisLabels[axis].hidden = true;
      const unit = worldAxis[axis], range = ranges[axis];
      const start = projectWorld(scale(unit, range.minimum), basis);
      const end = projectWorld(scale(unit, range.maximum), basis);
      // A depth axis is not a readable ruler in an aligned face/side/top view.
      if (!start || !end || Math.abs(dot(unit, basis.forward)) > .985) continue;
      const dx = end.x - start.x, dy = end.y - start.y, length = Math.hypot(dx, dy);
      if (length < 45) continue;
      const midpoint = projectWorld(scale(unit, (range.minimum + range.maximum) / 2), basis);
      if (!midpoint) continue;
      let nx = -dy / length, ny = dx / length;
      const outside = nx * (midpoint.x - viewportWidth / 2) + ny * (midpoint.y - viewportHeight / 2);
      if (outside < -1 || Math.abs(outside) <= 1 && (axis === 'z' ? nx > 0 : ny < 0)) { nx = -nx; ny = -ny; }
      axes.push({ axis, unit, range, start, end, midpoint, nx, ny });
    }
    const crossesAxis = rect => axes.some(({ start: a, end: b }) => {
      // Segment/rectangle clipping also keeps a label clear of another axis.
      let lo = 0, hi = 1;
      for (const [v, delta, min, max] of [[a.x, b.x-a.x, rect.x-2, rect.x+rect.w+2],
        [a.y, b.y-a.y, rect.y-2, rect.y+rect.h+2]]) {
        if (Math.abs(delta) < 1e-8) { if (v < min || v > max) return false; }
        else { const t1 = (min-v)/delta, t2 = (max-v)/delta; lo = Math.max(lo, Math.min(t1,t2)); hi = Math.min(hi, Math.max(t1,t2)); }
      }
      return lo <= hi;
    });
    const place = (element, candidates) => {
      const { w, h } = size(element);
      for (const p of candidates) {
        const rect = { x: p.x-w/2, y: p.y-h/2, w, h };
        if (rect.x < 6 || rect.y < 6 || rect.x+w > viewportWidth-6 || rect.y+h > viewportHeight-6
          || occupied.some(r => overlap(rect,r)) || crossesAxis(rect)) continue;
        element.style.left = `${p.x}px`; element.style.top = `${p.y}px`;
        element.hidden = false; occupied.push(rect); return true;
      }
      return false;
    };
    const support = (element, nx, ny) => { const s = size(element); return (Math.abs(nx)*s.w + Math.abs(ny)*s.h)/2; };
    const cubeCorners = [];
    for (const x of [0,4000]) for (const y of [0,4000]) for (const z of [0,4000]) {
      const p = projectWorld(V(x,y,z),basis);
      if (p) cubeCorners.push(p);
    }
    // An offset from the axis alone can still lie inside the front face of
    // the cube. Clear its projected silhouette, including the title's size.
    const titleDistance = (title, p, nx, ny, minimum) => {
      if (!cubeCorners.length) return minimum;
      const boundary = Math.max(...cubeCorners.map(q => q.x*nx+q.y*ny));
      return Math.max(minimum, boundary-p.x*nx-p.y*ny+support(title,nx,ny)+8);
    };
    // Only axis titles are annotated; the common tick spacing is given in
    // the fixed length-scale legend beside the scene.
    for (const a of axes) {
      const title = dom.axisLabels[a.axis];
      const distance = 18 + support(title,a.nx,a.ny);
      const candidates = [];
      if (a.axis !== 'z') {
        // Move away from the cube's center, on the same side as the axis.
        // A perpendicular offset alone would put both titles at the bottom
        // corner in an oblique view and make their association ambiguous.
        const center = projectWorld(V(2000,2000,2000),basis);
        for (const fraction of [.5,.7,.3]) {
          const p = projectWorld(scale(a.unit,a.range.minimum+fraction*(a.range.maximum-a.range.minimum)),basis);
          if (!p || !center) continue;
          const length = Math.hypot(p.x-center.x,p.y-center.y);
          if (length < 1) continue;
          const nx = (p.x-center.x)/length, ny = (p.y-center.y)/length;
          const d = titleDistance(title,p,nx,ny,distance);
          for (const extra of [0,12,24]) candidates.push({x:p.x+nx*(d+extra),y:p.y+ny*(d+extra)});
        }
      }
      for (const fraction of [.5,.7,.3]) {
        const p = projectWorld(scale(a.unit, a.range.minimum + fraction*(a.range.maximum-a.range.minimum)),basis);
        if (p) {
          const outerDistance = titleDistance(title,p,a.nx,a.ny,distance);
          for (const extra of [0,12,24]) candidates.push({ x: p.x+a.nx*(outerDistance+extra), y: p.y+a.ny*(outerDistance+extra) });
        }
      }
      // On a narrow viewport the vertical title fits above the end of its
      // axis better than outside the left edge.
      const length = Math.hypot(a.end.x-a.start.x,a.end.y-a.start.y);
      const ux = (a.end.x-a.start.x)/length, uy = (a.end.y-a.start.y)/length;
      const endpoint = { x:a.end.x+a.nx*6, y:a.end.y+a.ny*6 };
      const extension = titleDistance(title,endpoint,ux,uy,24+support(title,ux,uy));
      candidates.push({ x:endpoint.x+ux*extension, y:endpoint.y+uy*extension });
      place(title,candidates);
    }
  }

  function drawTrail(item, basis) {
    const start = state.fullTrail ? 0 : Math.max(0, state.time - state.trailDuration);
    const span = Math.max(0, state.time - start);
    const n = Math.max(2, Math.min(1200, Math.ceil(span / 0.05) + 1));
    let previous = null;

    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = 2.25;
    for (let i = 0; i < n; i += 1) {
      const age = i / (n - 1);
      const t = start + span * age;
      const projected = projectPhysical(item.position(t), basis);
      if (previous && projected) {
        const alpha = state.fullTrail ? 1 : 0.9 * age ** 1.6;
        ctx.strokeStyle = `rgba(${COLORS.trail[0]}, ${COLORS.trail[1]}, ${COLORS.trail[2]}, ${alpha})`;
        ctx.beginPath();
        ctx.moveTo(previous.x, previous.y);
        ctx.lineTo(projected.x, projected.y);
        ctx.stroke();
      }
      previous = projected;
    }
    ctx.restore();
  }

  function drawProjectionSystem(position, basis) {
    if (!state.projections) return;
    const p = projectPhysical(position, basis);
    if (!p) return;
    const projectedPoints = [
      V(position.x, position.y, 0),
      V(position.x, 0, position.z),
      V(0, position.y, position.z),
    ];

    ctx.save();
    ctx.setLineDash([6, 5]);
    ctx.strokeStyle = 'rgba(217, 104, 59, 0.32)';
    ctx.lineWidth = 1.25;
    for (const point of projectedPoints) {
      const q = projectPhysical(point, basis);
      if (!q) continue;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(q.x, q.y);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.beginPath();
      ctx.arc(q.x, q.y, 4.2, 0, 2 * Math.PI);
      ctx.fillStyle = 'rgba(217, 104, 59, 0.72)';
      ctx.fill();
      ctx.setLineDash([6, 5]);
    }
    ctx.restore();
  }

  function drawParticle(position, basis) {
    const p = projectPhysical(position, basis);
    if (!p) return;
    const radius = Math.max(6.5, Math.min(11, 58 * p.perspective));
    const gradient = ctx.createRadialGradient(
      p.x - 0.32 * radius,
      p.y - 0.35 * radius,
      0.15 * radius,
      p.x,
      p.y,
      radius,
    );
    gradient.addColorStop(0, '#f3b699');
    gradient.addColorStop(0.35, COLORS.position);
    gradient.addColorStop(1, '#b75129');
    ctx.save();
    ctx.shadowColor = 'rgba(15, 23, 42, 0.25)';
    ctx.shadowBlur = 3;
    ctx.beginPath();
    ctx.arc(p.x, p.y, radius, 0, 2 * Math.PI);
    ctx.fillStyle = gradient;
    ctx.fill();
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.stroke();
    ctx.restore();
  }

  function arrowMaterialColor(color, diffuse, specular = 0) {
    const rgb = [1, 3, 5].map(index => parseInt(color.slice(index, index + 2), 16));
    return 'rgb(' + rgb.map(value => Math.round(Math.min(255,
      Math.max(0, value * diffuse + 255 * specular)))).join(',') + ')';
  }

  function drawDepthArrowMarker(p, color, towardCamera, radius) {
    // Retain the dot/cross convention when the arrow is seen almost end-on.
    // The cap is shaded, with no white border around the arrow.
    const r = Math.max(5.5, radius);
    const gradient = ctx.createRadialGradient(p.x - r * 0.3, p.y - r * 0.35,
      r * 0.08, p.x, p.y, r);
    gradient.addColorStop(0, arrowMaterialColor(color, 1, 0.3));
    gradient.addColorStop(0.4, color);
    gradient.addColorStop(1, arrowMaterialColor(color, 0.55));
    ctx.save();
    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, 2 * Math.PI);
    ctx.fillStyle = gradient;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.lineWidth = 1.6;
    if (towardCamera) {
      ctx.beginPath();
      ctx.arc(p.x, p.y, Math.max(1.5, 0.23 * r), 0, 2 * Math.PI);
      ctx.fill();
    } else {
      const d = 0.34 * r;
      ctx.beginPath();
      ctx.moveTo(p.x - d, p.y - d);
      ctx.lineTo(p.x + d, p.y + d);
      ctx.moveTo(p.x + d, p.y - d);
      ctx.lineTo(p.x - d, p.y + d);
      ctx.stroke();
    }
    ctx.restore();
  }

  function buildArrowFaces(originPhysical, vectorPhysical, lengthScale, color, basis) {
    const originWorld = toScene(originPhysical);
    const directionWorld = toScene(scale(vectorPhysical, lengthScale));
    const shaftLength = norm(directionWorld);
    if (!Number.isFinite(shaftLength) || shaftLength < 1e-7) return [];
    const unit = scale(directionWorld, 1 / shaftLength);
    const shaftEndWorld = add(originWorld, directionWorld);
    // Keep the previous endpoint convention and all physical/display scales.
    const headTipWorld = add(shaftEndWorld, scale(unit, ARROW.headLengthWorld));
    const origin = projectWorld(originWorld, basis);
    const shaftEnd = projectWorld(shaftEndWorld, basis);
    const tip = projectWorld(headTipWorld, basis);
    const mid = projectWorld(add(originWorld, scale(directionWorld, 0.5)), basis);
    if (!origin || !shaftEnd || !tip || !mid) return [];

    const reference = Math.abs(unit.y) < 0.9 ? V(0, 1, 0) : V(1, 0, 0);
    const side = normalize(cross(unit, reference));
    const otherSide = normalize(cross(unit, side));
    // Maintain legibility at distant zooms without changing axial lengths.
    const shaftRadius = Math.max(ARROW.shaftRadiusWorld, 1.2 / mid.perspective);
    const headRadius = Math.max(ARROW.headRadiusWorld,
      shaftRadius * ARROW.headRadiusWorld / ARROW.shaftRadiusWorld,
      3.6 / shaftEnd.perspective);
    const segments = 24;
    const radial = Array.from({ length: segments }, (_, i) => {
      const angle = 2 * Math.PI * i / segments;
      return add(scale(side, Math.cos(angle)), scale(otherSide, Math.sin(angle)));
    });
    const ring = (center, radius) => radial.map(n => add(center, scale(n, radius)));
    const startRing = ring(originWorld, shaftRadius);
    const shaftRing = ring(shaftEndWorld, shaftRadius);
    const headRing = ring(shaftEndWorld, headRadius);
    const light = normalize(add(add(scale(basis.right, -0.45),
      scale(basis.up, 0.65)), scale(basis.forward, -0.8)));
    const faces = [];
    function face(vertices, normal, part) {
      const center = scale(vertices.reduce((sum, p) => add(sum, p), V()), 1 / vertices.length);
      const view = normalize(sub(basis.cameraPosition, center));
      if (dot(normal, view) <= 1e-10) return;
      const points = vertices.map(p => projectWorld(p, basis));
      if (points.some(p => !p)) return;
      const diffuse = 0.42 + 0.58 * Math.max(0, dot(normal, light));
      const halfway = normalize(add(light, view));
      const specular = 0.25 * Math.max(0, dot(normal, halfway)) ** 24;
      faces.push({
        kind: 'face', part, points, normal, vertices,
        depth: points.reduce((sum, p) => sum + p.depth, 0) / points.length,
        color: arrowMaterialColor(color, diffuse, specular),
      });
    }
    face(startRing, scale(unit, -1), 'tail');
    for (let i = 0; i < segments; i += 1) {
      const j = (i + 1) % segments;
      const normal = normalize(add(radial[i], radial[j]));
      face([startRing[i], startRing[j], shaftRing[j], shaftRing[i]], normal, 'shaft');
      // Annular underside closes the cone around the cylindrical shaft.
      face([shaftRing[i], shaftRing[j], headRing[j], headRing[i]], scale(unit, -1), 'shoulder');
      const coneNormal = normalize(cross(sub(headRing[j], headRing[i]),
        sub(headTipWorld, headRing[i])));
      face([headRing[i], headRing[j], headTipWorld], coneNormal, 'head');
    }
    const projectedLength = Math.hypot(tip.x - origin.x, tip.y - origin.y);
    const localView = normalize(sub(add(originWorld, scale(directionWorld, 0.5)),
      basis.cameraPosition));
    if (Math.abs(dot(unit, localView)) > 0.9975 || projectedLength < 1.5) {
      const towardCamera = dot(unit, localView) < 0;
      faces.push({ kind: 'depth-marker', depth: Math.min(origin.depth, tip.depth) - 0.01,
        point: towardCamera ? tip : origin, color, towardCamera,
        radius: Math.max(5.5, headRadius * shaftEnd.perspective) });
    }
    return faces;
  }

  function paintArrowFaces(faces) {
    // Sort the faces of ALL selected vectors together, not one flat arrow at a time.
    faces.sort((a, b) => b.depth - a.depth);
    ctx.save();
    ctx.globalAlpha = 1;
    ctx.lineJoin = 'round';
    for (const face of faces) {
      if (face.kind === 'depth-marker') {
        drawDepthArrowMarker(face.point, face.color, face.towardCamera, face.radius);
        continue;
      }
      ctx.beginPath();
      ctx.moveTo(face.points[0].x, face.points[0].y);
      for (const p of face.points.slice(1)) ctx.lineTo(p.x, p.y);
      ctx.closePath();
      ctx.fillStyle = face.color;
      ctx.strokeStyle = face.color;
      // Same-colour overlap covers subpixel seams between adjacent mesh faces.
      ctx.lineWidth = 0.6;
      ctx.fill();
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawArrow(originPhysical, vectorPhysical, lengthScale, color, basis) {
    paintArrowFaces(buildArrowFaces(originPhysical, vectorPhysical, lengthScale, color, basis));
  }

  function drawSelectedVectors(item, data, basis) {
    const selected = vectorSelection();
    const positionVector = data.position;
    const faces = [];
    const append = (origin, vector, factor, color) =>
      faces.push(...buildArrowFaces(origin, vector, factor, color, basis));

    if (selected.position) {
      const positionLength = norm(positionVector);
      const shortening = Math.min(ARROW.positionShorteningWorld / SCENE_UNITS_PER_METRE, Math.max(0, positionLength));
      const displayedPosition = positionLength > 1e-9
        ? scale(positionVector, Math.max(0, positionLength - shortening) / positionLength)
        : V(0, 0, 0);
      append(POSITION_VECTOR_ORIGIN, displayedPosition, 1, COLORS.position);
    }
    if (selected.acceleration) append(data.position, data.acceleration, item.scaleA * state.vectorScale, COLORS.acceleration);
    if (selected.normal && data.decompositionDefined) append(data.position, data.normal, item.scaleA * state.vectorScale, COLORS.normal);
    if (selected.tangential && data.decompositionDefined) append(data.position, data.tangential, item.scaleA * state.vectorScale, COLORS.tangential);
    if (selected.velocity) append(data.position, data.velocity, item.scaleV * state.vectorScale, COLORS.velocity);
    if (selected.jerk) append(data.position, data.jerk, jerkDisplayScale(item) * state.vectorScale, COLORS.jerk);
    paintArrowFaces(faces);
  }

  function drawOsculatingCircle(circle, basis) {
    if (!circle) return;
    const bounds = { left: 0, top: 0, right: viewportWidth, bottom: viewportHeight };
    const halfX = viewportWidth / (2 * basis.focal);
    const halfY = viewportHeight / (2 * basis.focal);
    const planeNorms = [1, Math.hypot(1, halfX), Math.hypot(1, halfX),
      Math.hypot(1, halfY), Math.hypot(1, halfY)];
    const sample = (angle) => {
      const physical = osculatingPoint(circle, angle);
      const relative = sub(toScene(physical), basis.cameraPosition);
      const depth = dot(relative, basis.forward);
      const x = dot(relative, basis.right);
      const y = dot(relative, basis.up);
      return {
        projected: projectPhysical(physical, basis),
        planes: [depth - 6, depth * halfX - x, depth * halfX + x,
          depth * halfY - y, depth * halfY + y],
      };
    };
    let last = null;
    let nodes = 0;
    const trace = (a, b, pa, pb, level) => {
      // Sagitta bounds the distance from this arc to its chord in world space.
      // Frustum culling prevents huge circles near inflections from wasting work
      // or being joined across the camera's near plane.
      const sagitta = 2 * circle.radius * SCENE_UNITS_PER_METRE * Math.sin((b - a) / 4) ** 2;
      if (pa.planes.some((d, i) => Math.max(d, pb.planes[i]) + sagitta * planeNorms[i] < 0)) {
        last = null;
        return;
      }
      if (++nodes > 8192) { last = null; return; }
      const middle = (a + b) / 2;
      const pm = sample(middle);
      const p = pa.projected;
      const q = pb.projected;
      const m = pm.projected;
      // Distance to the projected chord, not to its midpoint: perspective
      // does not preserve the angular midpoint, even for an almost straight arc.
      const lengthSquared = p && q ? (q.x - p.x) ** 2 + (q.y - p.y) ** 2 : 0;
      const fraction = p && q && m && lengthSquared > 0
        ? Math.max(0, Math.min(1, ((m.x - p.x) * (q.x - p.x) + (m.y - p.y) * (q.y - p.y)) / lengthSquared))
        : 0;
      const error = p && q && m
        ? Math.hypot(m.x - p.x - fraction * (q.x - p.x), m.y - p.y - fraction * (q.y - p.y))
        : Infinity;
      if (error <= 0.5) {
        const segment = clipScreenSegment(p, q, bounds);
        if (!segment) { last = null; return; }
        const [start, end] = segment;
        if (!last || Math.hypot(start.x - last.x, start.y - last.y) > 0.01) ctx.moveTo(start.x, start.y);
        ctx.lineTo(end.x, end.y);
        last = end;
      } else if (level < 36) {
        trace(a, middle, pa, pm, level + 1);
        trace(middle, b, pm, pb, level + 1);
      } else {
        last = null; // Never draw an unresolved chord across the visible scene.
      }
    };
    ctx.save();
    ctx.strokeStyle = '#268576';
    ctx.lineWidth = 1.5;
    ctx.globalAlpha = 0.8;
    ctx.setLineDash([6, 5]);
    ctx.beginPath();
    for (let i = 0; i < 8; i += 1) {
      const a = i * Math.PI / 4;
      const b = (i + 1) * Math.PI / 4;
      trace(a, b, sample(a), sample(b), 0);
    }
    ctx.stroke();
    ctx.restore();

    // Clip the radius in world space before perspective projection.
    let start = toScene(circle.position);
    let end = toScene(circle.center);
    const startDepth = dot(sub(start, basis.cameraPosition), basis.forward);
    const endDepth = dot(sub(end, basis.cameraPosition), basis.forward);
    if (startDepth <= 6 && endDepth <= 6) return;
    if (startDepth < 6) start = add(start, scale(sub(end, start), (6 - startDepth) / (endDepth - startDepth)));
    if (endDepth < 6) end = add(start, scale(sub(end, start), (6 - startDepth) / (endDepth - startDepth)));
    drawRadiusAnnotation(projectWorld(start, basis), projectWorld(end, basis), bounds, endDepth >= 6);
  }

  function drawScene(item, data) {
    ctx.clearRect(0, 0, viewportWidth, viewportHeight);
    const basis = cameraBasis();
    drawReferenceFrame(basis);
    drawOsculatingCircle(updateCurvatureReadout(data), basis);
    drawTrail(item, basis);
    drawProjectionSystem(data.position, basis);
    drawSelectedVectors(item, data, basis);
    drawParticle(data.position, basis);
  }

  function updateCurvatureReadout(data) {
    dom.radiusLabel.hidden = true;
    dom.curvatureDetails.hidden = !dom.osculating.checked;
    if (!dom.osculating.checked) return null;
    const circle = osculatingGeometry(data);
    dom.curvatureValue.hidden = !circle.defined;
    dom.curvatureStatus.hidden = circle.defined;
    if (!circle.defined) {
      const messages = {
        stationary: 'Vitesse quasi nulle : le cercle osculateur et son rayon sont indéfinis.',
        straight: 'Courbure quasi nulle : le rayon tend vers l’infini ; aucun cercle fini n’est tracé.',
        unresolved: 'Le rayon de courbure ne peut pas être résolu à cet instant.',
      };
      dom.curvatureStatus.textContent = messages[circle.reason];
      return null;
    }
    const scientific = circle.radius >= 1e5 || circle.radius < 0.01;
    dom.curvatureScientific.hidden = !scientific;
    if (scientific) {
      const [mantissa, exponent] = circle.radius.toExponential(2).split('e');
      setMathDigits(dom.curvatureDigits, mantissa);
      setMathDigits(dom.curvatureExponent, String(Number(exponent)));
    } else {
      setMathDigits(dom.curvatureDigits, circle.radius.toFixed(2));
    }
    dom.curvatureValue.setAttribute('aria-label', 'Rayon de courbure : ' + circle.radius.toPrecision(5) + ' mètres');
    return circle;
  }

  function drawRadiusAnnotation(start, center, bounds, centerVisible = true) {
    const segment = clipScreenSegment(start, center, bounds);
    if (!segment) return;
    const [a, b] = segment;
    ctx.save();
    ctx.strokeStyle = '#268576';
    ctx.lineWidth = 1.6;
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
    // A small cross marks the actual center, never an artificially clipped endpoint.
    if (centerVisible && center.x > bounds.left + 5 && center.x < bounds.right - 5
      && center.y > bounds.top + 5 && center.y < bounds.bottom - 5) {
      ctx.beginPath();
      ctx.moveTo(center.x - 4, center.y);
      ctx.lineTo(center.x + 4, center.y);
      ctx.moveTo(center.x, center.y - 4);
      ctx.lineTo(center.x, center.y + 4);
      ctx.stroke();
    }
    ctx.restore();
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const length = Math.hypot(dx, dy);
    if (length < 36) return;
    const x = (a.x + b.x) / 2 - 14 * dy / length;
    const y = (a.y + b.y) / 2 + 14 * dx / length;
    if (x < bounds.left + 20 || x > bounds.right - 20 || y < bounds.top + 20 || y > bounds.bottom - 20) return;
    dom.radiusLabel.hidden = false;
    dom.radiusLabel.style.left = x + 'px';
    dom.radiusLabel.style.top = y + 'px';
  }

  function updateReadouts(data) {
    const vectors = {
      position: data.position,
      velocity: data.velocity,
      acceleration: data.acceleration,
      tangential: data.tangential,
      normal: data.normal,
      jerk: data.jerk,
    };
    const selected = vectorSelection();

    for (const [key, vector] of Object.entries(vectors)) {
      const elements = readoutElements[key];
      const magnitude = norm(vector).toFixed(2);
      const componentX = vector.x.toFixed(2);
      const componentY = vector.y.toFixed(2);
      const componentZ = vector.z.toFixed(2);

      elements.root.classList.toggle('visible', selected[key]);
      setMathDigits(elements.magnitude, magnitude);
      setMathDigits(elements.componentX, componentX);
      setMathDigits(elements.componentY, componentY);
      setMathDigits(elements.componentZ, componentZ);
      elements.root.setAttribute(
        'aria-label',
        `${elements.meta.plainName} : norme ${magnitude} ; composantes (${componentX}, ${componentY}, ${componentZ})`,
      );
    }
  }

  function updateEquationPanel() {
    const item = currentTrajectory();
    if (mathIsReady && window.MathJax?.typesetClear) {
      window.MathJax.typesetClear([dom.equations]);
    }
    dom.equations.innerHTML = [
      ...item.equations.map((equation) => `<div class="equation"><span class="tex-math">\\(\\displaystyle ${equation}\\)</span></div>`),
      ...item.parameters.map((parameter) => `<div class="equation parameters parameter-line"><span class="tex-math">\\(${parameter}\\)</span></div>`),
    ].join('');
    if (mathIsReady) void queueTypeset([dom.equations]);
  }

  function applyVectorPreset(name) {
    const selected = {
      position: false,
      velocity: false,
      acceleration: false,
      tangential: false,
      normal: false,
      jerk: false,
    };
    if (name === 'velocity') selected.velocity = true;
    if (name === 'acceleration') selected.acceleration = true;
    if (name === 'decomposition') {
      selected.acceleration = true;
      selected.tangential = true;
      selected.normal = true;
    }
    if (name === 'all') Object.keys(selected).forEach((key) => { selected[key] = true; });
    for (const [key, checked] of Object.entries(selected)) dom.toggles[key].checked = checked;
  }

  function setPlaying(playing) {
    state.playing = playing;
    dom.play.textContent = playing ? 'Pause' : 'Lire';
    dom.play.setAttribute('aria-label', playing ? 'Mettre l’animation en pause' : 'Lire l’animation');
  }

  function updateAndDraw() {
    const item = currentTrajectory();
    const data = derivatives(item, state.time);
    const selected = vectorSelection();

    dom.timeSlider.value = String(state.time);
    setMathDigits(dom.timeOutputDigits, state.time.toFixed(2));
    setMathDigits(dom.timeBadgeDigits, state.time.toFixed(2));
    updateReadouts(data);

    const decompositionRequested = selected.tangential || selected.normal;
    dom.warning.hidden = !(decompositionRequested && !data.decompositionDefined);
    dom.warning.textContent = 'La décomposition tangentielle / centripète est indéfinie car la vitesse instantanée est approximativement nulle.';
    drawScene(item, data);
  }

  function configureTimelineForCurrentTrajectory() {
    const timeMax = trajectoryTimeMax(currentTrajectory());
    dom.timeSlider.max = String(timeMax);
    dom.timeSlider.step = String(Math.max(0.001, timeMax / 6000));
  }

  function onTrajectoryChanged() {
    state.trajectoryKey = dom.trajectory.value;
    state.time = 0;
    configureTimelineForCurrentTrajectory();
    updateEquationPanel();
    updateAndDraw();
  }

  function resizeCanvas() {
    const rect = viewport.getBoundingClientRect();
    viewportWidth = Math.max(1, rect.width);
    viewportHeight = Math.max(1, rect.height);
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(viewportWidth * dpr);
    canvas.height = Math.round(viewportHeight * dpr);
    canvas.style.width = `${viewportWidth}px`;
    canvas.style.height = `${viewportHeight}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    updateAndDraw();
  }

  let dragging = false;
  let dragMode = 'rotate';
  let previousPointer = null;
  canvas.addEventListener('contextmenu', (event) => event.preventDefault());
  canvas.addEventListener('pointerdown', (event) => {
    dragging = true;
    dragMode = (event.shiftKey || event.button === 1 || event.button === 2) ? 'pan' : 'rotate';
    previousPointer = { x: event.clientX, y: event.clientY };
    canvas.setPointerCapture(event.pointerId);
    canvas.style.cursor = 'grabbing';
  });
  canvas.addEventListener('pointermove', (event) => {
    if (!dragging || !previousPointer) return;
    const dx = event.clientX - previousPointer.x;
    const dy = event.clientY - previousPointer.y;
    previousPointer = { x: event.clientX, y: event.clientY };

    if (dragMode === 'pan') {
      const basis = cameraBasis();
      const worldPerPixel = camera.distance / Math.max(1, basis.focal);
      const translation = add(
        scale(basis.right, -dx * worldPerPixel),
        scale(basis.up, dy * worldPerPixel),
      );
      camera.target = add(camera.target, translation);
    } else {
      camera.yaw -= dx * 0.006;
      camera.pitch = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, camera.pitch + dy * 0.006));
    }
    updateAndDraw();
  });
  const finishPointer = (event) => {
    dragging = false;
    previousPointer = null;
    if (canvas.hasPointerCapture(event.pointerId)) canvas.releasePointerCapture(event.pointerId);
    canvas.style.cursor = 'grab';
  };
  canvas.addEventListener('pointerup', finishPointer);
  canvas.addEventListener('pointercancel', finishPointer);
  canvas.addEventListener('wheel', (event) => {
    event.preventDefault();
    camera.distance *= Math.exp(event.deltaY * 0.0012);
    camera.distance = Math.max(5200, Math.min(26000, camera.distance));
    updateAndDraw();
  }, { passive: false });
  canvas.style.cursor = 'grab';

  dom.trajectory.addEventListener('change', onTrajectoryChanged);
  dom.play.addEventListener('click', () => setPlaying(!state.playing));
  dom.reset.addEventListener('click', () => {
    state.time = 0;
    setPlaying(true);
    updateAndDraw();
  });
  dom.resetView.addEventListener('click', () => {
    resetCamera();
    updateAndDraw();
  });
  dom.topView.addEventListener('click', () => {
    camera.pitch = Math.PI / 2;
    updateAndDraw();
  });
  dom.frontView.addEventListener('click', () => {
    camera.yaw = 0;
    camera.pitch = 0;
    updateAndDraw();
  });
  dom.sideView.addEventListener('click', () => {
    camera.yaw = -Math.PI / 2;
    camera.pitch = 0;
    updateAndDraw();
  });
  dom.speed.addEventListener('change', () => { state.playbackSpeed = Number(dom.speed.value); });
  dom.loop.addEventListener('change', () => { state.loop = dom.loop.checked; });
  dom.vectorScale.addEventListener('input', () => {
    state.vectorScale = Number(dom.vectorScale.value);
    setMathDigits(dom.vectorScaleOutputDigits, state.vectorScale.toFixed(2));
    updateAndDraw();
  });
  dom.trailDuration.addEventListener('input', () => {
    state.trailDuration = Number(dom.trailDuration.value);
    setMathDigits(dom.trailDurationOutputDigits, state.trailDuration.toFixed(1));
    updateAndDraw();
  });
  dom.fullTrail.addEventListener('change', () => {
    state.fullTrail = dom.fullTrail.checked;
    dom.trailDuration.disabled = state.fullTrail;
    updateAndDraw();
  });
  dom.osculating.addEventListener('change', updateAndDraw);
  dom.projections.addEventListener('change', () => {
    state.projections = dom.projections.checked;
    updateAndDraw();
  });
  dom.timeSlider.addEventListener('input', () => {
    state.time = Number(dom.timeSlider.value);
    updateAndDraw();
  });
  dom.clearVectors.addEventListener('click', () => {
    applyVectorPreset('none');
    updateAndDraw();
  });
  Object.values(dom.toggles).forEach((input) => input.addEventListener('change', updateAndDraw));
  document.querySelectorAll('[data-vector-preset]').forEach((button) => {
    button.addEventListener('click', () => {
      applyVectorPreset(button.dataset.vectorPreset);
      updateAndDraw();
    });
  });

  document.addEventListener('keydown', (event) => {
    const tag = document.activeElement?.tagName?.toLowerCase();
    if (tag === 'input' || tag === 'select' || tag === 'button') return;
    if (event.code === 'Space') {
      event.preventDefault();
      setPlaying(!state.playing);
    }
    if (event.key.toLowerCase() === 'r') {
      state.time = 0;
      updateAndDraw();
    }
  });

  const resizeObserver = new ResizeObserver(resizeCanvas);
  resizeObserver.observe(viewport);
  window.addEventListener('resize', resizeCanvas);

  let previousTimestamp = performance.now();
  function animate(timestamp) {
    const elapsed = Math.min(0.1, Math.max(0, (timestamp - previousTimestamp) / 1000));
    previousTimestamp = timestamp;
    if (state.playing) {
      const duration = trajectoryTimeMax(currentTrajectory());
      state.time += elapsed * state.playbackSpeed;
      if (state.time > duration) {
        if (state.loop) state.time %= duration;
        else {
          state.time = duration;
          setPlaying(false);
        }
      }
    }
    updateAndDraw();
    requestAnimationFrame(animate);
  }

  async function initializeApplication() {
    dom.trajectory.value = state.trajectoryKey;
    dom.fullTrail.checked = state.fullTrail;
    dom.trailDuration.disabled = state.fullTrail;
    dom.projections.checked = state.projections;
    configureTimelineForCurrentTrajectory();
    updateEquationPanel();
    resizeCanvas();
    updateAndDraw();

    try {
      if (!window.MathJax?.startup?.promise) {
        throw new Error('Le moteur MathJax intégré ne s’est pas initialisé.');
      }
      await window.MathJax.startup.promise;
      await window.MathJax.typesetPromise();
      await initializeMathGlyphs();
      mathIsReady = true;
      updateDynamicMathOutputs();
      updateAndDraw();
    } catch (error) {
      console.error(error);
      loadingMessage.textContent = 'L’animation est chargée, mais le rendu TeX a échoué. Consultez la console du navigateur.';
      setTimeout(() => loadingMessage.remove(), 2500);
    }

    if (loadingMessage.isConnected) loadingMessage.remove();

    if (navigator.webdriver) {
      setPlaying(false);
      updateAndDraw();
    } else {
      requestAnimationFrame(animate);
    }
  }

  void initializeApplication();
})();
