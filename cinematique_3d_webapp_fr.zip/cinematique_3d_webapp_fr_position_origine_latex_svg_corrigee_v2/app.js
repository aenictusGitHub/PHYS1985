(() => {
  'use strict';

  const COLORS = Object.freeze({
    position: '#ff4500',
    velocity: '#1874cd',
    acceleration: '#663399',
    tangential: '#cd6090',
    normal: '#008b00',
    trail: [91, 101, 115],
  });

  const PARAMETERS = Object.freeze({
    R: 2000,
    x0: 2000,
    y0: 2000,
    z0: 2000,
    omega: 0.5,
    alpha: 0.02,
    theta0Deg: 0,
  });

  const T_MAX = 10 * Math.PI;
  const CLOSED_PERIOD = 2 * Math.PI / PARAMETERS.omega;
  const DOUBLE_CLOSED_PERIOD = 2 * CLOSED_PERIOD;
  const MCUA_TURN_DURATION = (Math.sqrt(PARAMETERS.omega ** 2 + 4 * Math.PI * PARAMETERS.alpha) - PARAMETERS.omega) / PARAMETERS.alpha;
  const MCUA_DURATION = 2 * MCUA_TURN_DURATION;
  const BUTTERFLY_DURATION = 24;
  const AXIS_TICK_STEP = 2000;
  const BASE_CAMERA_DISTANCE = 13800;
  const ZOOM_AXIS_STEP_DISTANCE = 3500;
  const ARROW = Object.freeze({
    shaftRadiusWorld: 19,
    headRadiusWorld: 55,
    headLengthWorld: 120,
    positionShorteningWorld: 150,
  });

  const V = (x = 0, y = 0, z = 0) => ({ x, y, z });
  const add = (a, b) => V(a.x + b.x, a.y + b.y, a.z + b.z);
  const sub = (a, b) => V(a.x - b.x, a.y - b.y, a.z - b.z);
  const scale = (a, s) => V(a.x * s, a.y * s, a.z * s);
  const dot = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
  const cross = (a, b) => V(
    a.y * b.z - a.z * b.y,
    a.z * b.x - a.x * b.z,
    a.x * b.y - a.y * b.x,
  );
  const norm = (a) => Math.hypot(a.x, a.y, a.z);
  const normalize = (a) => {
    const n = norm(a);
    return n > 1e-14 ? scale(a, 1 / n) : V(0, 0, 0);
  };

  // Keep the original z coordinate vertical in the rendered scene.
  const toWorld = (p) => V(p.x, p.z, p.y);
  const deg2rad = (angle) => angle * Math.PI / 180;
  const POSITION_VECTOR_ORIGIN = Object.freeze(V(0, 0, 0));

  const TRAJECTORIES = Object.freeze({
    lissajous: {
      label: 'Lissajous (𝑛=2)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.5,
      scaleA: 0.5,
      equations: [
        String.raw`x(t)=x_0+R\cos(\omega t)`,
        String.raw`y(t)=y_0+R\sin(2\omega t)`,
        String.raw`z(t)=z_0+R\sin(3\omega t)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=2000\,\mathrm{m}`,
        String.raw`R=2000\,\mathrm{m},\qquad \omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, z0, R, omega, theta0Deg } = PARAMETERS;
        const n = 2;
        return V(
          x0 + R * Math.cos(omega * t + deg2rad(theta0Deg)),
          y0 + R * Math.sin(n * omega * t),
          z0 + R * Math.sin(1.5 * n * omega * t),
        );
      },
    },
    lissajous3: {
      label: 'Lissajous (𝑛=3)',
      duration: DOUBLE_CLOSED_PERIOD,
      closed: true,
      scaleV: 0.32,
      scaleA: 0.16,
      equations: [
        String.raw`x(t)=x_0+R\cos(\omega t)`,
        String.raw`y(t)=y_0+R\sin(3\omega t)`,
        String.raw`z(t)=z_0+R\sin\!\left(\frac{9}{2}\omega t\right)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=2000\,\mathrm{m}`,
        String.raw`R=2000\,\mathrm{m},\qquad \omega=0.5\,\mathrm{rad\,s^{-1}}`,
        String.raw`n=3,\qquad T=\frac{4\pi}{\omega}=8\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, R, omega, theta0Deg } = PARAMETERS;
        const n = 3;
        return V(
          x0 + R * Math.cos(omega * t + deg2rad(theta0Deg)),
          y0 + R * Math.sin(n * omega * t),
          z0 + R * Math.sin(1.5 * n * omega * t),
        );
      },
    },
    astroid: {
      label: 'Astroïde',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.5,
      scaleA: 0.5,
      equations: [
        String.raw`x(t)=x_0+R\cos^3(\omega t)`,
        String.raw`y(t)=y_0+R\sin^3(\omega t)`,
        String.raw`z(t)=z_0+R\sin(2\omega t)\cos(2\omega t)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=2000\,\mathrm{m}`,
        String.raw`R=2000\,\mathrm{m},\qquad \omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, z0, R, omega } = PARAMETERS;
        const q = omega * t;
        const c = Math.cos(q);
        const sinq = Math.sin(q);
        return V(
          x0 + R * c ** 3,
          y0 + R * sinq ** 3,
          z0 + R * Math.sin(2 * q) * Math.cos(2 * q),
        );
      },
    },
    quadrifolium: {
      label: 'Quadrifolium',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.35,
      scaleA: 0.35,
      equations: [
        String.raw`x(t)=x_0+R\cos(2\omega t)\cos(\omega t)`,
        String.raw`y(t)=y_0+R\cos(2\omega t)\sin(\omega t)`,
        String.raw`z(t)=z_0+R\sin(2\omega t)\sin(\omega t)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=2000\,\mathrm{m}`,
        String.raw`R=2000\,\mathrm{m},\qquad \omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, z0, R, omega } = PARAMETERS;
        const q = omega * t;
        return V(
          x0 + R * Math.cos(2 * q) * Math.cos(q),
          y0 + R * Math.cos(2 * q) * Math.sin(q),
          z0 + R * Math.sin(2 * q) * Math.sin(q),
        );
      },
    },
    mcua: {
      label: 'Mouvement circulaire uniformément accéléré',
      duration: MCUA_DURATION,
      closed: false,
      scaleV: 0.5,
      scaleA: 0.5,
      equations: [
        String.raw`\varphi(t)=\frac{1}{2}\alpha t^2+\omega_0t+\theta_0`,
        String.raw`x(t)=x_0+R\cos\!\bigl(\varphi(t)\bigr)`,
        String.raw`y(t)=y_0+R\sin\!\bigl(\varphi(t)\bigr)`,
        String.raw`z(t)=z_0`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=2000\,\mathrm{m},\qquad R=2000\,\mathrm{m}`,
        String.raw`\omega_0=0.5\,\mathrm{rad\,s^{-1}},\qquad \alpha=0.02\,\mathrm{rad\,s^{-2}}`,
        String.raw`T_{\mathrm{tour}}\simeq 10.40\,\mathrm s,\qquad t_{\max}=2T_{\mathrm{tour}}\simeq 20.80\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, R, omega, alpha, theta0Deg } = PARAMETERS;
        const phi = 0.5 * alpha * t * t + omega * t + deg2rad(theta0Deg);
        return V(x0 + R * Math.cos(phi), y0 + R * Math.sin(phi), z0);
      },
    },
    fish: {
      label: 'Courbe poisson',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.5,
      scaleA: 0.65,
      equations: [
        String.raw`x(t)=x_0+R\left[\cos(\omega t)-\frac{\sin^2(\omega t)}{\sqrt{2}}\right]`,
        String.raw`y(t)=y_0+R\cos(\omega t)\sin(\omega t)`,
        String.raw`z(t)=z_0`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=2000\,\mathrm{m}`,
        String.raw`R=2000\,\mathrm{m},\qquad \omega=0.5\,\mathrm{rad\,s^{-1}}`,
      ],
      position(t) {
        const { x0, y0, z0, R, omega } = PARAMETERS;
        const q = omega * t;
        const sinq = Math.sin(q);
        const c = Math.cos(q);
        return V(
          x0 + R * (c - sinq * sinq / Math.sqrt(2)),
          y0 + R * c * sinq,
          z0,
        );
      },
    },
    trefoil: {
      label: 'Nœud de trèfle T(2,3)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.40,
      scaleA: 0.20,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+\bigl(R_0+r\cos(3\tau)\bigr)\cos(2\tau)`,
        String.raw`y(t)=y_0+\bigl(R_0+r\cos(3\tau)\bigr)\sin(2\tau)`,
        String.raw`z(t)=z_0+r\sin(3\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=2000\,\mathrm m`,
        String.raw`R_0=1100\,\mathrm m,\qquad r=650\,\mathrm m`,
        String.raw`T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const R0 = 1100;
        const r = 650;
        const q = omega * t;
        const radial = R0 + r * Math.cos(3 * q);
        return V(
          x0 + radial * Math.cos(2 * q),
          y0 + radial * Math.sin(2 * q),
          z0 + r * Math.sin(3 * q),
        );
      },
    },
    figureEightKnot: {
      label: 'Nœud en huit',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.25,
      scaleA: 0.16,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+A\bigl[2+\cos(2\tau)\bigr]\cos(3\tau)`,
        String.raw`y(t)=y_0+A\bigl[2+\cos(2\tau)\bigr]\sin(3\tau)`,
        String.raw`z(t)=z_0+A\sin(4\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=2000\,\mathrm m,\qquad A=620\,\mathrm m`,
        String.raw`T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const A = 620;
        const q = omega * t;
        const radial = A * (2 + Math.cos(2 * q));
        return V(
          x0 + radial * Math.cos(3 * q),
          y0 + radial * Math.sin(3 * q),
          z0 + A * Math.sin(4 * q),
        );
      },
    },
    cinquefoil: {
      label: 'Nœud à cinq lobes T(2,5)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.33,
      scaleA: 0.12,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+\bigl(R_0+r\cos(5\tau)\bigr)\cos(2\tau)`,
        String.raw`y(t)=y_0+\bigl(R_0+r\cos(5\tau)\bigr)\sin(2\tau)`,
        String.raw`z(t)=z_0+r\sin(5\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=2000\,\mathrm m`,
        String.raw`R_0=1150\,\mathrm m,\qquad r=550\,\mathrm m`,
        String.raw`T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const R0 = 1150;
        const r = 550;
        const q = omega * t;
        const radial = R0 + r * Math.cos(5 * q);
        return V(
          x0 + radial * Math.cos(2 * q),
          y0 + radial * Math.sin(2 * q),
          z0 + r * Math.sin(5 * q),
        );
      },
    },
    toroidalHelix: {
      label: 'Hélice toroïdale (7 spires)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.35,
      scaleA: 0.09,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+\bigl(R_0+r\cos(n\tau)\bigr)\cos\tau`,
        String.raw`y(t)=y_0+\bigl(R_0+r\cos(n\tau)\bigr)\sin\tau`,
        String.raw`z(t)=z_0+r\sin(n\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=2000\,\mathrm m`,
        String.raw`R_0=1250\,\mathrm m,\qquad r=480\,\mathrm m,\qquad n=7`,
        String.raw`T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const R0 = 1250;
        const r = 480;
        const n = 7;
        const q = omega * t;
        const radial = R0 + r * Math.cos(n * q);
        return V(
          x0 + radial * Math.cos(q),
          y0 + radial * Math.sin(q),
          z0 + r * Math.sin(n * q),
        );
      },
    },
    viviani: {
      label: 'Courbe de Viviani',
      duration: DOUBLE_CLOSED_PERIOD,
      closed: true,
      scaleV: 0.90,
      scaleA: 2.00,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+a\cos\tau`,
        String.raw`y(t)=y_0+a\sin\tau`,
        String.raw`z(t)=z_0+2a\sin\!\left(\frac{\tau}{2}\right)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=2000\,\mathrm m,\qquad a=850\,\mathrm m`,
        String.raw`T=\frac{4\pi}{\omega}=8\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const a = 850;
        const q = omega * t;
        return V(
          x0 + a * Math.cos(q),
          y0 + a * Math.sin(q),
          z0 + 2 * a * Math.sin(0.5 * q),
        );
      },
    },
    sphericalRose: {
      label: 'Rose sphérique (3 pétales)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.24,
      scaleA: 0.13,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+R\cos(3\tau)\cos\tau`,
        String.raw`y(t)=y_0+R\cos(3\tau)\sin\tau`,
        String.raw`z(t)=z_0+R\sin(3\tau)`,
      ],
      parameters: [
        String.raw`R=1700\,\mathrm m,\qquad T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
        String.raw`(x-x_0)^2+(y-y_0)^2+(z-z_0)^2=R^2`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const R = 1700;
        const q = omega * t;
        const latitudeRadius = R * Math.cos(3 * q);
        return V(
          x0 + latitudeRadius * Math.cos(q),
          y0 + latitudeRadius * Math.sin(q),
          z0 + R * Math.sin(3 * q),
        );
      },
    },
    sphericalSpiral: {
      label: 'Spirale sphérique (5 enroulements)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.18,
      scaleA: 0.05,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+R\cos(2\tau)\cos(5\tau)`,
        String.raw`y(t)=y_0+R\cos(2\tau)\sin(5\tau)`,
        String.raw`z(t)=z_0+R\sin(2\tau)`,
      ],
      parameters: [
        String.raw`R=1700\,\mathrm m,\qquad T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
        String.raw`(x-x_0)^2+(y-y_0)^2+(z-z_0)^2=R^2`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const R = 1700;
        const q = omega * t;
        const latitudeRadius = R * Math.cos(2 * q);
        return V(
          x0 + latitudeRadius * Math.cos(5 * q),
          y0 + latitudeRadius * Math.sin(5 * q),
          z0 + R * Math.sin(2 * q),
        );
      },
    },
    harmonicKnot: {
      label: 'Nœud harmonique (3,4,5)',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.16,
      scaleA: 0.06,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+R\cos(3\tau)`,
        String.raw`y(t)=y_0+R\sin(4\tau)`,
        String.raw`z(t)=z_0+R\sin(5\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=2000\,\mathrm m,\qquad R=1550\,\mathrm m`,
        String.raw`T=\frac{2\pi}{\omega}=4\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const R = 1550;
        const q = omega * t;
        return V(
          x0 + R * Math.cos(3 * q),
          y0 + R * Math.sin(4 * q),
          z0 + R * Math.sin(5 * q),
        );
      },
    },
    heart: {
      label: 'Cœur tridimensionnel',
      duration: CLOSED_PERIOD,
      closed: true,
      scaleV: 0.65,
      scaleA: 0.55,
      equations: [
        String.raw`\tau=\omega t`,
        String.raw`x(t)=x_0+16A\sin^3\tau`,
        String.raw`y(t)=y_0+A\bigl[13\cos\tau-5\cos(2\tau)-2\cos(3\tau)-\cos(4\tau)\bigr]`,
        String.raw`z(t)=z_0+B\sin(2\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=2000\,\mathrm m`,
        String.raw`A=95\,\mathrm m,\qquad B=450\,\mathrm m,\qquad T=4\pi\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0, omega } = PARAMETERS;
        const A = 95;
        const B = 450;
        const q = omega * t;
        const s = Math.sin(q);
        return V(
          x0 + 16 * A * s ** 3,
          y0 + A * (13 * Math.cos(q) - 5 * Math.cos(2 * q) - 2 * Math.cos(3 * q) - Math.cos(4 * q)),
          z0 + B * Math.sin(2 * q),
        );
      },
    },
    butterfly: {
      label: 'Papillon tridimensionnel',
      duration: BUTTERFLY_DURATION,
      closed: true,
      scaleV: 0.12,
      scaleA: 0.018,
      equations: [
        String.raw`\tau=\frac{12\pi t}{T}`,
        String.raw`\rho(\tau)=e^{\sin\tau}-2\cos(4\tau)+\sin^5\!\left(\frac{2\tau-\pi}{24}\right)`,
        String.raw`x(t)=x_0+A\rho(\tau)\sin\tau`,
        String.raw`y(t)=y_0+A\rho(\tau)\cos\tau`,
        String.raw`z(t)=z_0+B\sin(3\tau)`,
      ],
      parameters: [
        String.raw`x_0=y_0=z_0=2000\,\mathrm m`,
        String.raw`A=440\,\mathrm m,\qquad B=520\,\mathrm m,\qquad T=24\,\mathrm s`,
      ],
      position(t) {
        const { x0, y0, z0 } = PARAMETERS;
        const A = 440;
        const B = 520;
        const q = 12 * Math.PI * t / BUTTERFLY_DURATION;
        const rho = Math.exp(Math.sin(q))
          - 2 * Math.cos(4 * q)
          + Math.sin((2 * q - Math.PI) / 24) ** 5;
        return V(
          x0 + A * rho * Math.sin(q),
          y0 + A * rho * Math.cos(q),
          z0 + B * Math.sin(3 * q),
        );
      },
    },
    ballistic: {
      label: 'Trajectoire balistique',
      duration: T_MAX,
      closed: false,
      scaleV: 3,
      scaleA: 25,
      equations: [
        String.raw`x(t)=x_0+v_0\cos(\theta_0)t`,
        String.raw`y(t)=y_0+v_0\sin(\theta_0)t-\frac{1}{2}gt^2`,
        String.raw`z(t)=z_0`,
      ],
      parameters: [
        String.raw`x_0=y_0=0\,\mathrm{m},\qquad z_0=2000\,\mathrm{m}`,
        String.raw`v_0=200\,\mathrm{m\,s^{-1}},\qquad \theta_0=60^\circ,\qquad g=9.81\,\mathrm{m\,s^{-2}}`,
      ],
      position(t) {
        const v0 = 200;
        const theta = deg2rad(60);
        const g = 9.81;
        return V(
          v0 * t * Math.cos(theta),
          v0 * t * Math.sin(theta) - 0.5 * g * t * t,
          PARAMETERS.z0,
        );
      },
    },
  });

  function derivatives(trajectory, t) {
    const h = 1e-3;
    const pm = trajectory.position(t - h);
    const p = trajectory.position(t);
    const pp = trajectory.position(t + h);
    const velocity = scale(sub(pp, pm), 1 / (2 * h));
    const acceleration = scale(add(add(pp, pm), scale(p, -2)), 1 / (h * h));
    const speed = norm(velocity);
    let tangential = V(0, 0, 0);
    let normal = { ...acceleration };
    let decompositionDefined = false;

    if (speed > 1e-5) {
      const tangent = scale(velocity, 1 / speed);
      tangential = scale(tangent, dot(acceleration, tangent));
      normal = sub(acceleration, tangential);
      decompositionDefined = true;
    }

    return { position: p, velocity, acceleration, tangential, normal, speed, decompositionDefined };
  }

  const viewport = document.getElementById('viewport');
  const loadingMessage = document.getElementById('loading-message');
  const canvas = document.createElement('canvas');
  canvas.setAttribute('aria-label', 'Canevas interactif de cinématique en trois dimensions');
  viewport.prepend(canvas);
  const ctx = canvas.getContext('2d', { alpha: true });

  const state = {
    trajectoryKey: 'lissajous',
    time: 0,
    playing: true,
    playbackSpeed: 1,
    loop: true,
    vectorScale: 1,
    trailDuration: 4,
    fullTrail: false,
    projections: true,
  };

  const camera = {
    yaw: 0.78,
    pitch: 0.48,
    distance: 13800,
    target: V(2000, 2000, 2000),
    fov: deg2rad(42),
  };

  let viewportWidth = 1;
  let viewportHeight = 1;
  let dpr = 1;

  const dom = {
    trajectory: document.getElementById('trajectory-select'),
    play: document.getElementById('play-button'),
    reset: document.getElementById('reset-button'),
    resetView: document.getElementById('reset-view'),
    speed: document.getElementById('speed-select'),
    timeSlider: document.getElementById('time-slider'),
    timeOutputDigits: document.getElementById('time-output-digits'),
    timeBadgeDigits: document.getElementById('time-badge-digits'),
    loop: document.getElementById('loop-toggle'),
    vectorScale: document.getElementById('vector-scale'),
    vectorScaleOutputDigits: document.getElementById('vector-scale-output-digits'),
    trailDuration: document.getElementById('trail-duration'),
    trailDurationOutputDigits: document.getElementById('trail-duration-output-digits'),
    fullTrail: document.getElementById('full-trail'),
    projections: document.getElementById('projection-toggle'),
    equations: document.getElementById('trajectory-equations'),
    vectorReadouts: document.getElementById('vector-readouts'),
    warning: document.getElementById('warning-badge'),
    axisLabels: {
      x: document.getElementById('axis-label-x'),
      y: document.getElementById('axis-label-y'),
      z: document.getElementById('axis-label-z'),
    },
    axisTickLayers: {
      x: document.getElementById('axis-ticks-x'),
      y: document.getElementById('axis-ticks-y'),
      z: document.getElementById('axis-ticks-z'),
    },
    clearVectors: document.getElementById('clear-vectors'),
    toggles: {
      position: document.getElementById('toggle-position'),
      velocity: document.getElementById('toggle-velocity'),
      acceleration: document.getElementById('toggle-acceleration'),
      tangential: document.getElementById('toggle-tangential'),
      normal: document.getElementById('toggle-normal'),
    },
  };

  const VECTOR_META = Object.freeze({
    position: {
      symbolTeX: String.raw`\vec r`,
      unitTeX: String.raw`\mathrm m`,
      plainName: 'position',
      color: COLORS.position,
    },
    velocity: {
      symbolTeX: String.raw`\vec v`,
      unitTeX: String.raw`\mathrm{m\,s^{-1}}`,
      plainName: 'vitesse',
      color: COLORS.velocity,
    },
    acceleration: {
      symbolTeX: String.raw`\vec a`,
      unitTeX: String.raw`\mathrm{m\,s^{-2}}`,
      plainName: 'accélération',
      color: COLORS.acceleration,
    },
    tangential: {
      symbolTeX: String.raw`\vec a_{\mathrm t}`,
      unitTeX: String.raw`\mathrm{m\,s^{-2}}`,
      plainName: 'accélération tangentielle',
      color: COLORS.tangential,
    },
    normal: {
      symbolTeX: String.raw`\vec a_{\mathrm c}`,
      unitTeX: String.raw`\mathrm{m\,s^{-2}}`,
      plainName: 'accélération centripète',
      color: COLORS.normal,
    },
  });

  const readoutElements = {};
  for (const [key, meta] of Object.entries(VECTOR_META)) {
    const element = document.createElement('div');
    element.className = 'vector-readout';
    element.style.setProperty('--readout-color', meta.color);
    element.innerHTML = `
      <div class="vector-readout-line vector-readout-magnitude">
        <span class="tex-math">\\(\\lvert${meta.symbolTeX}\\rvert=\\)</span>
        <span class="math-digits magnitude-digits">0.00</span>
        <span class="tex-math">\\(\\,${meta.unitTeX}\\)</span>
      </div>
      <div class="vector-readout-line vector-readout-components">
        <span class="tex-math">\\(${meta.symbolTeX}=(\\)</span>
        <span class="math-digits component-x-digits">0.0</span>
        <span class="tex-math">\\(,\\,\\)</span>
        <span class="math-digits component-y-digits">0.0</span>
        <span class="tex-math">\\(,\\,\\)</span>
        <span class="math-digits component-z-digits">0.0</span>
        <span class="tex-math">\\()\\)</span>
      </div>`;
    dom.vectorReadouts.append(element);
    readoutElements[key] = {
      root: element,
      meta,
      magnitude: element.querySelector('.magnitude-digits'),
      componentX: element.querySelector('.component-x-digits'),
      componentY: element.querySelector('.component-y-digits'),
      componentZ: element.querySelector('.component-z-digits'),
    };
  }

  let mathIsReady = false;
  let mathTypesetQueue = Promise.resolve();
  const mathGlyphTemplates = new Map();
  const axisTickElements = { x: new Map(), y: new Map(), z: new Map() };

  function queueTypeset(elements) {
    if (!mathIsReady || !window.MathJax?.typesetPromise) return Promise.resolve();
    mathTypesetQueue = mathTypesetQueue
      .then(() => window.MathJax.typesetPromise(elements))
      .catch((error) => console.error('Échec de la composition MathJax :', error));
    return mathTypesetQueue;
  }

  async function initializeMathGlyphs() {
    const characters = '0123456789.-+';
    for (const character of characters) {
      const tex = character === '-' ? '{-}' : character === '+' ? '{+}' : character;
      const rendered = await window.MathJax.tex2svgPromise(tex, { display: false });
      rendered.setAttribute('aria-hidden', 'true');
      mathGlyphTemplates.set(character, rendered);
    }
  }

  function setMathDigits(element, text) {
    if (!element) return;
    const value = String(text);
    if (!mathIsReady || mathGlyphTemplates.size === 0) {
      element.textContent = value;
      element.dataset.value = value;
      return;
    }
    if (element.dataset.value === value && element.classList.contains('typeset')) return;

    const fragment = document.createDocumentFragment();
    for (const character of value) {
      const wrapper = document.createElement('span');
      wrapper.className = 'math-glyph';
      wrapper.setAttribute('aria-hidden', 'true');
      const template = mathGlyphTemplates.get(character);
      if (template) wrapper.append(template.cloneNode(true));
      else wrapper.textContent = character;
      fragment.append(wrapper);
    }
    element.replaceChildren(fragment);
    element.classList.add('typeset');
    element.dataset.value = value;
  }

  function synchronizeAxisTickElements(axis, ticks) {
    const elements = axisTickElements[axis];
    const visible = new Set(ticks);

    for (const [tick, record] of elements) {
      if (!visible.has(tick)) {
        record.root.remove();
        elements.delete(tick);
      }
    }

    for (const tick of ticks) {
      let record = elements.get(tick);
      if (!record) {
        const root = document.createElement('div');
        root.className = 'axis-math-label axis-tick-label';
        root.setAttribute('aria-hidden', 'true');
        const digits = document.createElement('span');
        digits.className = 'math-digits';
        root.append(digits);
        dom.axisTickLayers[axis].append(root);
        record = { root, digits };
        elements.set(tick, record);
      }
      setMathDigits(record.digits, String(tick));
    }
  }

  function updateDynamicMathOutputs() {
    setMathDigits(dom.timeOutputDigits, state.time.toFixed(2));
    setMathDigits(dom.timeBadgeDigits, state.time.toFixed(2));
    setMathDigits(dom.vectorScaleOutputDigits, state.vectorScale.toFixed(2));
    setMathDigits(dom.trailDurationOutputDigits, state.trailDuration.toFixed(1));
    for (const elements of Object.values(axisTickElements)) {
      for (const [tick, record] of elements) setMathDigits(record.digits, String(tick));
    }
  }

  const currentTrajectory = () => TRAJECTORIES[state.trajectoryKey];
  const trajectoryTimeMax = (item) => item.closed ? 2 * item.duration : item.duration;
  const axisTickValues = (minimum, maximum) => {
    const first = Math.ceil((minimum - 1e-9) / AXIS_TICK_STEP) * AXIS_TICK_STEP;
    const values = [];
    for (let value = first; value <= maximum + 1e-9; value += AXIS_TICK_STEP) {
      values.push(Math.abs(value) < 1e-9 ? 0 : value);
    }
    return values;
  };
  const axisRange = (coordinate) => {
    const zoomSteps = Math.max(0, Math.floor((camera.distance - BASE_CAMERA_DISTANCE + 1e-9) / ZOOM_AXIS_STEP_DISTANCE));
    const halfSteps = 1 + zoomSteps;
    const center = Math.round(coordinate / AXIS_TICK_STEP) * AXIS_TICK_STEP;
    const minimum = center - halfSteps * AXIS_TICK_STEP;
    const maximum = center + halfSteps * AXIS_TICK_STEP;
    return { minimum, maximum, ticks: axisTickValues(minimum, maximum) };
  };
  const currentAxisRanges = () => ({
    x: axisRange(camera.target.x),
    y: axisRange(camera.target.z),
    z: axisRange(camera.target.y),
  });
  const vectorSelection = () => Object.fromEntries(
    Object.entries(dom.toggles).map(([key, input]) => [key, input.checked]),
  );

  function resetCamera() {
    camera.yaw = 0.78;
    camera.pitch = 0.48;
    camera.distance = BASE_CAMERA_DISTANCE;
    camera.target = V(2000, 2000, 2000);
  }

  function cameraBasis() {
    const cp = Math.cos(camera.pitch);
    const cameraPosition = add(camera.target, scale(V(
      cp * Math.sin(camera.yaw),
      Math.sin(camera.pitch),
      cp * Math.cos(camera.yaw),
    ), camera.distance));
    const forward = normalize(sub(camera.target, cameraPosition));
    let right = normalize(cross(forward, V(0, 1, 0)));
    if (norm(right) < 1e-8) right = V(1, 0, 0);
    const up = normalize(cross(right, forward));
    const focal = 0.5 * viewportHeight / Math.tan(camera.fov / 2);
    return { cameraPosition, forward, right, up, focal };
  }

  function projectWorld(point, basis) {
    const relative = sub(point, basis.cameraPosition);
    const depth = dot(relative, basis.forward);
    if (depth <= 5) return null;
    const x = dot(relative, basis.right);
    const y = dot(relative, basis.up);
    const perspective = basis.focal / depth;
    return {
      x: viewportWidth / 2 + x * perspective,
      y: viewportHeight / 2 - y * perspective,
      depth,
      perspective,
    };
  }

  const projectPhysical = (point, basis) => projectWorld(toWorld(point), basis);

  function strokeSegment(a, b, basis, color, width = 1, alpha = 1, dash = []) {
    const pa = projectWorld(a, basis);
    const pb = projectWorld(b, basis);
    if (!pa || !pb) return;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.setLineDash(dash);
    ctx.beginPath();
    ctx.moveTo(pa.x, pa.y);
    ctx.lineTo(pb.x, pb.y);
    ctx.stroke();
    ctx.restore();
  }

  function drawReferenceFrame(basis) {
    const levels = [0, 2000, 4000];
    const soft = '#9cacbf';
    const ranges = currentAxisRanges();

    // The original 0–4000 m reference cube remains visible.
    for (const value of levels) {
      strokeSegment(V(0, 0, value), V(4000, 0, value), basis, soft, 1, 0.28);
      strokeSegment(V(value, 0, 0), V(value, 0, 4000), basis, soft, 1, 0.28);

      strokeSegment(V(0, value, 0), V(4000, value, 0), basis, soft, 1, 0.17);
      strokeSegment(V(value, 0, 0), V(value, 4000, 0), basis, soft, 1, 0.17);

      strokeSegment(V(0, 0, value), V(0, 4000, value), basis, soft, 1, 0.17);
      strokeSegment(V(0, value, 0), V(0, value, 4000), basis, soft, 1, 0.17);
    }

    const corners = [];
    for (const x of [0, 4000]) {
      for (const y of [0, 4000]) {
        for (const z of [0, 4000]) corners.push(V(x, y, z));
      }
    }
    const edges = [];
    for (let i = 0; i < corners.length; i += 1) {
      for (let j = i + 1; j < corners.length; j += 1) {
        const a = corners[i];
        const b = corners[j];
        const differing = Number(a.x !== b.x) + Number(a.y !== b.y) + Number(a.z !== b.z);
        if (differing === 1) edges.push([a, b]);
      }
    }
    for (const [a, b] of edges) strokeSegment(a, b, basis, '#607089', 1.4, 0.78);

    // Axes and tick marks extend dynamically as the user zooms or pans.
    const axisColor = '#52627a';
    const tickHalfLength = 85;
    strokeSegment(V(ranges.x.minimum, 0, 0), V(ranges.x.maximum, 0, 0), basis, axisColor, 1.55, 0.82);
    strokeSegment(V(0, 0, ranges.y.minimum), V(0, 0, ranges.y.maximum), basis, axisColor, 1.55, 0.82);
    strokeSegment(V(0, ranges.z.minimum, 0), V(0, ranges.z.maximum, 0), basis, axisColor, 1.55, 0.82);

    for (const tick of ranges.x.ticks) {
      strokeSegment(V(tick, -tickHalfLength, 0), V(tick, tickHalfLength, 0), basis, axisColor, 1.3, 0.82);
    }
    for (const tick of ranges.y.ticks) {
      strokeSegment(V(0, -tickHalfLength, tick), V(0, tickHalfLength, tick), basis, axisColor, 1.3, 0.82);
    }
    for (const tick of ranges.z.ticks) {
      strokeSegment(V(-tickHalfLength, tick, 0), V(tickHalfLength, tick, 0), basis, axisColor, 1.3, 0.82);
    }

    drawAxisLabels(basis, ranges);
  }

  function placeAxisMathLabel(element, point, basis) {
    const p = projectWorld(point, basis);
    const margin = 110;
    if (!p || !Number.isFinite(p.x) || !Number.isFinite(p.y)
      || p.x < -margin || p.x > viewportWidth + margin
      || p.y < -margin || p.y > viewportHeight + margin) {
      element.hidden = true;
      return;
    }
    element.hidden = false;
    element.style.left = `${p.x}px`;
    element.style.top = `${p.y}px`;
  }

  function drawAxisLabels(basis, ranges) {
    synchronizeAxisTickElements('x', ranges.x.ticks);
    synchronizeAxisTickElements('y', ranges.y.ticks);
    synchronizeAxisTickElements('z', ranges.z.ticks);

    placeAxisMathLabel(dom.axisLabels.x, V(ranges.x.maximum + 450, -130, -120), basis);
    placeAxisMathLabel(dom.axisLabels.y, V(-140, -130, ranges.y.maximum + 450), basis);
    placeAxisMathLabel(dom.axisLabels.z, V(-140, ranges.z.maximum + 450, -120), basis);

    for (const tick of ranges.x.ticks) {
      placeAxisMathLabel(axisTickElements.x.get(tick).root, V(tick, -150, -110), basis);
    }
    for (const tick of ranges.y.ticks) {
      placeAxisMathLabel(axisTickElements.y.get(tick).root, V(-125, -150, tick), basis);
    }
    for (const tick of ranges.z.ticks) {
      placeAxisMathLabel(axisTickElements.z.get(tick).root, V(-125, tick, -110), basis);
    }
  }

  function drawTrail(item, basis) {
    const start = state.fullTrail ? 0 : Math.max(0, state.time - state.trailDuration);
    const span = Math.max(0, state.time - start);
    const n = Math.max(2, Math.min(1200, Math.ceil(span / 0.05) + 1));
    let previous = null;

    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = 2.25;
    for (let i = 0; i < n; i += 1) {
      const age = i / (n - 1);
      const t = start + span * age;
      const projected = projectPhysical(item.position(t), basis);
      if (previous && projected) {
        const alpha = state.fullTrail ? 1 : 0.9 * age ** 1.6;
        ctx.strokeStyle = `rgba(${COLORS.trail[0]}, ${COLORS.trail[1]}, ${COLORS.trail[2]}, ${alpha})`;
        ctx.beginPath();
        ctx.moveTo(previous.x, previous.y);
        ctx.lineTo(projected.x, projected.y);
        ctx.stroke();
      }
      previous = projected;
    }
    ctx.restore();
  }

  function drawProjectionSystem(position, basis) {
    if (!state.projections) return;
    const p = projectPhysical(position, basis);
    if (!p) return;
    const projectedPoints = [
      V(position.x, position.y, 0),
      V(position.x, 0, position.z),
      V(0, position.y, position.z),
    ];

    ctx.save();
    ctx.setLineDash([6, 5]);
    ctx.strokeStyle = 'rgba(255, 69, 0, 0.32)';
    ctx.lineWidth = 1.25;
    for (const point of projectedPoints) {
      const q = projectPhysical(point, basis);
      if (!q) continue;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(q.x, q.y);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.beginPath();
      ctx.arc(q.x, q.y, 4.2, 0, 2 * Math.PI);
      ctx.fillStyle = 'rgba(255, 69, 0, 0.72)';
      ctx.fill();
      ctx.setLineDash([6, 5]);
    }
    ctx.restore();
  }

  function drawParticle(position, basis) {
    const p = projectPhysical(position, basis);
    if (!p) return;
    const radius = Math.max(6.5, Math.min(11, 58 * p.perspective));
    const gradient = ctx.createRadialGradient(
      p.x - 0.32 * radius,
      p.y - 0.35 * radius,
      0.15 * radius,
      p.x,
      p.y,
      radius,
    );
    gradient.addColorStop(0, '#ffb08f');
    gradient.addColorStop(0.35, COLORS.position);
    gradient.addColorStop(1, '#bd2e00');
    ctx.save();
    ctx.shadowColor = 'rgba(15, 23, 42, 0.25)';
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.arc(p.x, p.y, radius, 0, 2 * Math.PI);
    ctx.fillStyle = gradient;
    ctx.fill();
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.stroke();
    ctx.restore();
  }

  function projectedSeparation(a, b, basis) {
    const pa = projectWorld(a, basis);
    const pb = projectWorld(b, basis);
    if (!pa || !pb) return 0;
    return Math.hypot(pb.x - pa.x, pb.y - pa.y);
  }

  function drawDepthArrowMarker(p, color, towardCamera, radius) {
    const r = Math.max(5.5, radius);
    ctx.save();
    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, 2 * Math.PI);
    ctx.fillStyle = color;
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#fff';
    ctx.stroke();
    ctx.strokeStyle = '#fff';
    ctx.fillStyle = '#fff';
    ctx.lineWidth = 2;
    if (towardCamera) {
      ctx.beginPath();
      ctx.arc(p.x, p.y, Math.max(2, 0.27 * r), 0, 2 * Math.PI);
      ctx.fill();
    } else {
      const d = 0.4 * r;
      ctx.beginPath();
      ctx.moveTo(p.x - d, p.y - d);
      ctx.lineTo(p.x + d, p.y + d);
      ctx.moveTo(p.x + d, p.y - d);
      ctx.lineTo(p.x - d, p.y + d);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawArrow(originPhysical, vectorPhysical, lengthScale, color, basis) {
    const originWorld = toWorld(originPhysical);
    const directionWorld = toWorld(scale(vectorPhysical, lengthScale));
    const shaftLength = norm(directionWorld);
    if (!Number.isFinite(shaftLength) || shaftLength < 1e-7) return;

    const unit = scale(directionWorld, 1 / shaftLength);
    const shaftEndWorld = add(originWorld, directionWorld);
    const headTipWorld = add(shaftEndWorld, scale(unit, ARROW.headLengthWorld));
    const shaftMidWorld = add(originWorld, scale(directionWorld, 0.5));

    let side = normalize(cross(unit, basis.forward));
    if (norm(side) < 1e-7) side = { ...basis.right };

    const shaftSide = scale(side, ARROW.shaftRadiusWorld);
    const headSide = scale(side, ARROW.headRadiusWorld);

    const origin = projectWorld(originWorld, basis);
    const shaftEnd = projectWorld(shaftEndWorld, basis);
    const headTip = projectWorld(headTipWorld, basis);
    const headBasePlus = projectWorld(add(shaftEndWorld, headSide), basis);
    const headBaseMinus = projectWorld(sub(shaftEndWorld, headSide), basis);
    if (!origin || !shaftEnd || !headTip || !headBasePlus || !headBaseMinus) return;

    const shaftWidth = Math.max(
      2,
      projectedSeparation(
        sub(shaftMidWorld, shaftSide),
        add(shaftMidWorld, shaftSide),
        basis,
      ),
    );
    const projectedShaftLength = Math.hypot(shaftEnd.x - origin.x, shaftEnd.y - origin.y);
    const projectedHeadRadius = 0.5 * Math.hypot(
      headBasePlus.x - headBaseMinus.x,
      headBasePlus.y - headBaseMinus.y,
    );

    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (projectedShaftLength > 0.4) {
      ctx.beginPath();
      ctx.moveTo(origin.x, origin.y);
      ctx.lineTo(shaftEnd.x, shaftEnd.y);
      ctx.lineWidth = shaftWidth + 3;
      ctx.strokeStyle = 'rgba(255,255,255,0.80)';
      ctx.stroke();
      ctx.lineWidth = shaftWidth;
      ctx.strokeStyle = color;
      ctx.stroke();
    }

    const nearlyAlongView = Math.abs(dot(unit, basis.forward)) > 0.975;
    const projectedHeadLength = Math.hypot(headTip.x - shaftEnd.x, headTip.y - shaftEnd.y);
    if (nearlyAlongView || projectedHeadLength < 1.5) {
      drawDepthArrowMarker(
        headTip,
        color,
        dot(unit, basis.forward) < 0,
        projectedHeadRadius,
      );
    } else {
      ctx.beginPath();
      ctx.moveTo(headTip.x, headTip.y);
      ctx.lineTo(headBasePlus.x, headBasePlus.y);
      ctx.lineTo(headBaseMinus.x, headBaseMinus.y);
      ctx.closePath();
      ctx.lineWidth = 3;
      ctx.strokeStyle = 'rgba(255,255,255,0.82)';
      ctx.stroke();
      ctx.fillStyle = color;
      ctx.fill();
    }
    ctx.restore();
  }

  function drawSelectedVectors(item, data, basis) {
    const selected = vectorSelection();
    const positionVector = data.position;

    if (selected.position) {
      const positionLength = norm(positionVector);
      const shortening = Math.min(ARROW.positionShorteningWorld, Math.max(0, positionLength));
      const displayedPosition = positionLength > 1e-9
        ? scale(positionVector, Math.max(0, positionLength - shortening) / positionLength)
        : V(0, 0, 0);
      drawArrow(POSITION_VECTOR_ORIGIN, displayedPosition, 1, COLORS.position, basis);
    }
    if (selected.acceleration) drawArrow(data.position, data.acceleration, item.scaleA * state.vectorScale, COLORS.acceleration, basis);
    if (selected.normal && data.decompositionDefined) drawArrow(data.position, data.normal, item.scaleA * state.vectorScale, COLORS.normal, basis);
    if (selected.tangential && data.decompositionDefined) drawArrow(data.position, data.tangential, item.scaleA * state.vectorScale, COLORS.tangential, basis);
    if (selected.velocity) drawArrow(data.position, data.velocity, item.scaleV * state.vectorScale, COLORS.velocity, basis);
  }

  function drawScene(item, data) {
    ctx.clearRect(0, 0, viewportWidth, viewportHeight);
    const basis = cameraBasis();
    drawReferenceFrame(basis);
    drawTrail(item, basis);
    drawProjectionSystem(data.position, basis);
    drawSelectedVectors(item, data, basis);
    drawParticle(data.position, basis);
  }

  function updateReadouts(data) {
    const vectors = {
      position: data.position,
      velocity: data.velocity,
      acceleration: data.acceleration,
      tangential: data.tangential,
      normal: data.normal,
    };
    const selected = vectorSelection();

    for (const [key, vector] of Object.entries(vectors)) {
      const elements = readoutElements[key];
      const magnitude = norm(vector).toFixed(2);
      const componentX = vector.x.toFixed(1);
      const componentY = vector.y.toFixed(1);
      const componentZ = vector.z.toFixed(1);

      elements.root.classList.toggle('visible', selected[key]);
      setMathDigits(elements.magnitude, magnitude);
      setMathDigits(elements.componentX, componentX);
      setMathDigits(elements.componentY, componentY);
      setMathDigits(elements.componentZ, componentZ);
      elements.root.setAttribute(
        'aria-label',
        `${elements.meta.plainName} : norme ${magnitude} ; composantes (${componentX}, ${componentY}, ${componentZ})`,
      );
    }
  }

  function updateEquationPanel() {
    const item = currentTrajectory();
    if (mathIsReady && window.MathJax?.typesetClear) {
      window.MathJax.typesetClear([dom.equations]);
    }
    dom.equations.innerHTML = [
      ...item.equations.map((equation) => `<div class="equation"><span class="tex-math">\\(\\displaystyle ${equation}\\)</span></div>`),
      ...item.parameters.map((parameter) => `<div class="equation parameters parameter-line"><span class="tex-math">\\(${parameter}\\)</span></div>`),
    ].join('');
    if (mathIsReady) void queueTypeset([dom.equations]);
  }

  function applyVectorPreset(name) {
    const selected = {
      position: false,
      velocity: false,
      acceleration: false,
      tangential: false,
      normal: false,
    };
    if (name === 'velocity') selected.velocity = true;
    if (name === 'acceleration') selected.acceleration = true;
    if (name === 'decomposition') {
      selected.acceleration = true;
      selected.tangential = true;
      selected.normal = true;
    }
    if (name === 'all') Object.keys(selected).forEach((key) => { selected[key] = true; });
    for (const [key, checked] of Object.entries(selected)) dom.toggles[key].checked = checked;
  }

  function setPlaying(playing) {
    state.playing = playing;
    dom.play.textContent = playing ? 'Pause' : 'Lire';
    dom.play.setAttribute('aria-label', playing ? 'Mettre l’animation en pause' : 'Lire l’animation');
  }

  function updateAndDraw() {
    const item = currentTrajectory();
    const data = derivatives(item, state.time);
    const selected = vectorSelection();

    dom.timeSlider.value = String(state.time);
    setMathDigits(dom.timeOutputDigits, state.time.toFixed(2));
    setMathDigits(dom.timeBadgeDigits, state.time.toFixed(2));
    updateReadouts(data);

    const decompositionRequested = selected.tangential || selected.normal;
    dom.warning.hidden = !(decompositionRequested && !data.decompositionDefined);
    dom.warning.textContent = 'La décomposition tangentielle / centripète est indéfinie car la vitesse instantanée est approximativement nulle.';
    drawScene(item, data);
  }

  function configureTimelineForCurrentTrajectory() {
    const timeMax = trajectoryTimeMax(currentTrajectory());
    dom.timeSlider.max = String(timeMax);
    dom.timeSlider.step = String(Math.max(0.001, timeMax / 6000));
  }

  function onTrajectoryChanged() {
    state.trajectoryKey = dom.trajectory.value;
    state.time = 0;
    configureTimelineForCurrentTrajectory();
    updateEquationPanel();
    updateAndDraw();
  }

  function resizeCanvas() {
    const rect = viewport.getBoundingClientRect();
    viewportWidth = Math.max(1, rect.width);
    viewportHeight = Math.max(1, rect.height);
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(viewportWidth * dpr);
    canvas.height = Math.round(viewportHeight * dpr);
    canvas.style.width = `${viewportWidth}px`;
    canvas.style.height = `${viewportHeight}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    updateAndDraw();
  }

  let dragging = false;
  let dragMode = 'rotate';
  let previousPointer = null;
  canvas.addEventListener('contextmenu', (event) => event.preventDefault());
  canvas.addEventListener('pointerdown', (event) => {
    dragging = true;
    dragMode = (event.shiftKey || event.button === 1 || event.button === 2) ? 'pan' : 'rotate';
    previousPointer = { x: event.clientX, y: event.clientY };
    canvas.setPointerCapture(event.pointerId);
    canvas.style.cursor = 'grabbing';
  });
  canvas.addEventListener('pointermove', (event) => {
    if (!dragging || !previousPointer) return;
    const dx = event.clientX - previousPointer.x;
    const dy = event.clientY - previousPointer.y;
    previousPointer = { x: event.clientX, y: event.clientY };

    if (dragMode === 'pan') {
      const basis = cameraBasis();
      const worldPerPixel = camera.distance / Math.max(1, basis.focal);
      const translation = add(
        scale(basis.right, -dx * worldPerPixel),
        scale(basis.up, dy * worldPerPixel),
      );
      camera.target = add(camera.target, translation);
    } else {
      camera.yaw -= dx * 0.006;
      camera.pitch = Math.max(-1.18, Math.min(1.18, camera.pitch + dy * 0.006));
    }
    updateAndDraw();
  });
  const finishPointer = (event) => {
    dragging = false;
    previousPointer = null;
    if (canvas.hasPointerCapture(event.pointerId)) canvas.releasePointerCapture(event.pointerId);
    canvas.style.cursor = 'grab';
  };
  canvas.addEventListener('pointerup', finishPointer);
  canvas.addEventListener('pointercancel', finishPointer);
  canvas.addEventListener('wheel', (event) => {
    event.preventDefault();
    camera.distance *= Math.exp(event.deltaY * 0.0012);
    camera.distance = Math.max(5200, Math.min(26000, camera.distance));
    updateAndDraw();
  }, { passive: false });
  canvas.style.cursor = 'grab';

  dom.trajectory.addEventListener('change', onTrajectoryChanged);
  dom.play.addEventListener('click', () => setPlaying(!state.playing));
  dom.reset.addEventListener('click', () => {
    state.time = 0;
    setPlaying(true);
    updateAndDraw();
  });
  dom.resetView.addEventListener('click', () => {
    resetCamera();
    updateAndDraw();
  });
  dom.speed.addEventListener('change', () => { state.playbackSpeed = Number(dom.speed.value); });
  dom.loop.addEventListener('change', () => { state.loop = dom.loop.checked; });
  dom.vectorScale.addEventListener('input', () => {
    state.vectorScale = Number(dom.vectorScale.value);
    setMathDigits(dom.vectorScaleOutputDigits, state.vectorScale.toFixed(2));
    updateAndDraw();
  });
  dom.trailDuration.addEventListener('input', () => {
    state.trailDuration = Number(dom.trailDuration.value);
    setMathDigits(dom.trailDurationOutputDigits, state.trailDuration.toFixed(1));
    updateAndDraw();
  });
  dom.fullTrail.addEventListener('change', () => {
    state.fullTrail = dom.fullTrail.checked;
    dom.trailDuration.disabled = state.fullTrail;
    updateAndDraw();
  });
  dom.projections.addEventListener('change', () => {
    state.projections = dom.projections.checked;
    updateAndDraw();
  });
  dom.timeSlider.addEventListener('input', () => {
    state.time = Number(dom.timeSlider.value);
    updateAndDraw();
  });
  dom.clearVectors.addEventListener('click', () => {
    applyVectorPreset('none');
    updateAndDraw();
  });
  Object.values(dom.toggles).forEach((input) => input.addEventListener('change', updateAndDraw));
  document.querySelectorAll('[data-vector-preset]').forEach((button) => {
    button.addEventListener('click', () => {
      applyVectorPreset(button.dataset.vectorPreset);
      updateAndDraw();
    });
  });

  document.addEventListener('keydown', (event) => {
    const tag = document.activeElement?.tagName?.toLowerCase();
    if (tag === 'input' || tag === 'select' || tag === 'button') return;
    if (event.code === 'Space') {
      event.preventDefault();
      setPlaying(!state.playing);
    }
    if (event.key.toLowerCase() === 'r') {
      state.time = 0;
      updateAndDraw();
    }
  });

  const resizeObserver = new ResizeObserver(resizeCanvas);
  resizeObserver.observe(viewport);
  window.addEventListener('resize', resizeCanvas);

  let previousTimestamp = performance.now();
  function animate(timestamp) {
    const elapsed = Math.min(0.1, Math.max(0, (timestamp - previousTimestamp) / 1000));
    previousTimestamp = timestamp;
    if (state.playing) {
      const duration = trajectoryTimeMax(currentTrajectory());
      state.time += elapsed * state.playbackSpeed;
      if (state.time > duration) {
        if (state.loop) state.time %= duration;
        else {
          state.time = duration;
          setPlaying(false);
        }
      }
    }
    updateAndDraw();
    requestAnimationFrame(animate);
  }

  async function initializeApplication() {
    dom.trajectory.value = state.trajectoryKey;
    configureTimelineForCurrentTrajectory();
    updateEquationPanel();
    resizeCanvas();
    updateAndDraw();

    try {
      if (!window.MathJax?.startup?.promise) {
        throw new Error('Le moteur MathJax intégré ne s’est pas initialisé.');
      }
      await window.MathJax.startup.promise;
      await window.MathJax.typesetPromise();
      await initializeMathGlyphs();
      mathIsReady = true;
      updateDynamicMathOutputs();
      updateAndDraw();
    } catch (error) {
      console.error(error);
      loadingMessage.textContent = 'L’animation est chargée, mais le rendu TeX a échoué. Consultez la console du navigateur.';
      setTimeout(() => loadingMessage.remove(), 2500);
    }

    if (loadingMessage.isConnected) loadingMessage.remove();

    if (navigator.webdriver) {
      setPlaying(false);
      updateAndDraw();
    } else {
      requestAnimationFrame(animate);
    }
  }

  void initializeApplication();
})();
