# Application web de cinématique 3D — édition française TeX/SVG

Cette version pour navigateur reproduit l’animation tridimensionnelle et permet d’afficher indépendamment :

- la position $\vec r(t)$, représentée depuis l’origine $(0,0,0)$ ;
- la vitesse $\vec v(t)$ ;
- l’accélération totale $\vec a(t)$ ;
- l’accélération tangentielle $\vec a_{\mathrm t}(t)$ ;
- l’accélération centripète $\vec a_{\mathrm c}(t)$.

Elle comprend également le choix de la trajectoire, la lecture/pause, le déplacement manuel dans le temps, la vitesse de lecture, le facteur de longueur des tiges des vecteurs, la durée de la traînée, la rotation et le zoom de la caméra, les projections orthogonales et les valeurs numériques des vecteurs.

## Comportement des flèches

- La longueur de la tige est proportionnelle à la norme du vecteur sélectionné.
- Le rayon de la tige est fixé à 15 unités de la scène.
- Le rayon et la longueur de la pointe sont fixés respectivement à 50 et 120 unités ; ils ne dépendent pas de la norme du vecteur.
- Les flèches ne sont pas coupées par la boîte de référence.
- La trajectoire s’efface progressivement derrière la particule.

## Rendu LaTeX

Toutes les expressions mathématiques sont rendues localement par MathJax sous forme de chemins SVG. Cela comprend :

- les formules de la section **Grandeurs vectorielles** ;
- toutes les équations et tous les paramètres de la section **Mouvement** ;
- $x\,[\mathrm m]$, $y\,[\mathrm m]$, $z\,[\mathrm m]$ et les graduations des axes ;
- l’expression dynamique $t=\cdots\,\mathrm s$ ;
- les unités et les normes des vecteurs dans le panneau des valeurs numériques.

Les annotations des axes ont un arrière-plan transparent. Leur apparence ne dépend ni du support MathML du navigateur ni des polices mathématiques installées sur l’ordinateur.

Aucun fichier de police n’est fourni. Le texte ordinaire de l’interface utilise une pile locale Latin Modern / Computer Modern / STIX avec repli serif.

Le JavaScript MathJax fourni est distribué sous licence Apache 2.0 ; voir `vendor/mathjax/LICENSE`.

## Trajectoires

Le sélecteur contient 17 trajectoires :

- Lissajous $n=2$ et **Lissajous $n=3$** ;
- astroïde, quadrifolium, mouvement circulaire uniformément accéléré, courbe poisson et trajectoire balistique ;
- nœuds de trèfle, en huit, à cinq lobes et harmonique ;
- hélice toroïdale, courbe de Viviani, rose sphérique et spirale sphérique ;
- cœur et papillon tridimensionnels.

Pour la nouvelle courbe de Lissajous $n=3$ :

\[
x(t)=x_0+R\cos(\omega t),\qquad
 y(t)=y_0+R\sin(3\omega t),\qquad
 z(t)=z_0+R\sin\!\left(\frac{9}{2}\omega t\right).
\]

Avec $\omega=0.5\,\mathrm{rad\,s^{-1}}$, sa période de fermeture est $T=8\pi\,\mathrm s$.

## Exécution

Ouvrir directement le fichier HTML autonome, ou lancer la version source :

```bash
./serve.sh
```

Puis ouvrir `http://localhost:8000`.

L’ouverture directe de `index.html` fonctionne également dans les versions courantes de Firefox et Chromium.

## Commandes

- Faire glisser la vue 3D pour la tourner.
- Utiliser la molette de la souris pour zoomer.
- Appuyer sur la barre d’espace pour lire ou mettre en pause.
- Appuyer sur `R` pour recommencer le mouvement.

## Notes techniques

- Les dérivées sont calculées numériquement par différences finies centrées.
- La décomposition utilise $\vec a_{\mathrm t}=(\vec a\cdot\vec e_v)\vec e_v$ et $\vec a_{\mathrm c}=\vec a-\vec a_{\mathrm t}$.
- Lorsque la vitesse instantanée est nulle, la décomposition tangentielle/normale est indéfinie ; l’application masque alors les flèches correspondantes et affiche un avertissement.


## Mise à jour de l’interface

- l’en-tête porte la mention exacte « PHYS1985 - ULiege » ;
- les cadres vectoriels affichent la norme et les trois composantes sous forme TeX/SVG ;
- les graduations des axes sont générées tous les 2000 m et s’étendent avec le dézoom ou le déplacement de la vue ;
- `Maj` + glisser (ou bouton central/droit + glisser) déplace la vue ;
- l’historique complet est opaque, sans atténuation ;
- pour les courbes fermées, la borne temporelle par défaut vaut deux périodes géométriques.

## Ajustements de lisibilité

- Les cadres des grandeurs vectorielles utilisent une grille responsive avec une largeur minimale suffisante pour afficher les trois composantes.
- L’affichage séparé et redondant de la position sous la scène a été retiré ; la position reste disponible dans son propre cadre quand le vecteur `Position` est sélectionné.
- La mention `© J. Martin` est forcée sur une seule ligne.
