# Application web de cinématique 3D — édition française TeX/SVG

La trajectoire balistique se déroule dans le plan vertical xz, avec y = 1 m constant. La pesanteur est dirigée vers les z négatifs : a = (0, 0, −9.81) m/s². Le départ se fait à x = z = 0 ; θ₀ est l’angle de lancement au-dessus de l’horizontale.

Cette version pour navigateur reproduit l’animation tridimensionnelle et permet d’afficher indépendamment :

- la position $\vec r(t)$, représentée depuis l’origine $(0,0,0)$ ;
- la vitesse $\vec v(t)$ ;
- l’accélération totale $\vec a(t)$ ;
- l’à-coup $\vec{\jmath}(t)$ ;
- l’accélération tangentielle $\vec a_{\mathrm t}(t)$ ;
- l’accélération centripète $\vec a_{\mathrm c}(t)$.

Elle comprend également le choix de la trajectoire, la lecture/pause, le déplacement manuel dans le temps, la vitesse de lecture, le facteur de longueur des vecteurs, la durée de la traînée, la rotation et le zoom de la caméra, les projections orthogonales et les valeurs numériques des vecteurs.

## À-coup

L’option « À-coup » affiche le vecteur \(\vec{\jmath}=\mathrm d\vec a/\mathrm dt\), sa norme et ses composantes en \(\mathrm{m\,s^{-3}}\). La couleur ocre et le rendu LaTeX sont communs aux versions 2D et 3D. La sélection « Tous » l’inclut et « Effacer » le masque.

L’à-coup est calculé directement à partir de la loi de position par une différence centrale à sept points, d’ordre quatre (pas de \(0.004\,\mathrm s\)). La loi analytique est évaluée de part et d’autre de l’instant, y compris aux bornes : le retour de lecture en boucle n’est pas interprété comme un choc physique. Pour le mouvement balistique, l’à-coup est exactement nul.

Le vecteur a sa propre échelle graphique, fixe pour chaque trajectoire : sa longueur reste proportionnelle à la norme instantanée. Le réglage « Facteur de longueur des vecteurs » lui est également appliqué. Les valeurs numériques restent exprimées en unités physiques.

## Comportement des flèches

- La longueur du vecteur affiché est proportionnelle à sa norme.
- Les tiges sont cylindriques et les pointes coniques, avec un éclairage directionnel et des reflets discrets. Leurs faces sont projetées en perspective et triées par profondeur entre tous les vecteurs sélectionnés.
- Le rayon de la tige est de 19 unités de la scène ; celui de la pointe est de 55 unités. Un minimum de lisibilité est conservé lors des dézooms importants. La longueur de la pointe reste fixée à 120 unités, comme auparavant.
- Les faces de la tige et de la pointe se rejoignent sans contour blanc. Le point / la croix d’une flèche vue presque de bout est conservé sur une pastille ombrée.
- Les flèches ne sont pas limitées au domaine des axes de référence.
- L’historique complet de la trajectoire est visible par défaut ; la traînée limitée reste optionnelle.

## Rendu LaTeX

Toutes les expressions mathématiques sont rendues localement par MathJax sous forme de chemins SVG. Cela comprend :

- les formules de la section **Grandeurs vectorielles** ;
- toutes les équations et tous les paramètres de la section **Mouvement** ;
- $x\,[\mathrm m]$, $y\,[\mathrm m]$, $z\,[\mathrm m]$ et la valeur de l’étalon de longueur ;
- l’expression dynamique $t=\cdots\,\mathrm s$ ;
- les unités et les normes des vecteurs dans le panneau des valeurs numériques.

Les annotations des axes ont un arrière-plan transparent. Leur apparence ne dépend ni du support MathML du navigateur ni des polices mathématiques installées sur l’ordinateur.

Aucun fichier de police n’est fourni. Le texte ordinaire de l’interface utilise une pile locale Latin Modern / Computer Modern / STIX avec repli serif.

Le JavaScript MathJax fourni est distribué sous licence Apache 2.0 ; voir `vendor/mathjax/LICENSE`.

## Trajectoires

Le sélecteur contient 17 trajectoires :

- Lissajous $n=2$ et **Lissajous $n=3$** ;
- astroïde, quadrifolium, mouvement circulaire uniformément accéléré, courbe poisson et trajectoire balistique ;
- nœuds de trèfle, en huit, à cinq lobes et harmonique ;
- hélice toroïdale, courbe de Viviani, rose sphérique et spirale sphérique ;
- cœur et papillon tridimensionnels.

Pour la nouvelle courbe de Lissajous $n=3$ :

\[
x(t)=x_0+R\cos(\omega t),\qquad
 y(t)=y_0+R\sin(3\omega t),\qquad
 z(t)=z_0+R\sin\!\left(\frac{9}{2}\omega t\right).
\]

Avec $\omega=0.5\,\mathrm{rad\,s^{-1}}$, sa période de fermeture est $T=8\pi\,\mathrm s$.

## Exécution

Ouvrir directement le fichier HTML autonome, ou lancer la version source :

```bash
./serve.sh
```

Puis ouvrir `http://localhost:8000`.

L’ouverture directe de `index.html` fonctionne également dans les versions courantes de Firefox et Chromium.

## Commandes

- Faire glisser la vue 3D pour la tourner.
- Utiliser la molette de la souris pour zoomer.
- Appuyer sur la barre d’espace pour lire ou mettre en pause.
- Appuyer sur `R` pour recommencer le mouvement.

## Notes techniques

- Les dérivées sont calculées numériquement par différences finies centrées.
- La décomposition utilise $\vec a_{\mathrm t}=(\vec a\cdot\vec e_v)\vec e_v$ et $\vec a_{\mathrm c}=\vec a-\vec a_{\mathrm t}$.
- Lorsque la vitesse instantanée est nulle, la décomposition tangentielle/normale est indéfinie ; l’application masque alors les flèches correspondantes et affiche un avertissement.


## Mise à jour de l’interface

- l’en-tête porte la mention exacte « PHYS1985 - ULiege » ;
- les cadres vectoriels affichent la norme et les trois composantes sous forme TeX/SVG ;
- les axes portent uniquement des graduations, sans nombres, tous les 1 m. Elles s’étendent avec le dézoom ou le déplacement de la vue et gardent une longueur lisible à l’écran, y compris en vue du dessus ;
- l’étalon en bas à droite est un segment avec sa longueur indiquée dessous, sans texte supplémentaire. Sa longueur à l’écran suit exactement le zoom à la profondeur du centre de la vue, pour un segment parallèle à l’écran. La perspective modifie l’échelle des objets plus proches ou plus éloignés. La distance de référence vaut 1 m au départ ; elle est divisée ou multipliée par deux, si nécessaire, pour que l’étalon reste lisible et ne déborde pas ;
- `Maj` + glisser (ou bouton central/droit + glisser) déplace la vue ;
- la rotation permet d’atteindre la verticale, jusqu’à ±90°, sans changement brusque d’orientation ; le bouton « Vue du dessus » place directement la caméra au-dessus, en conservant le zoom et le centre de la vue ;
- « Vue de face » aligne la vue sur le plan xz et « Vue de côté » sur le plan yz, avec z vertical. Ces vues conservent aussi le zoom, le centre, l’instant et l’état de lecture ; la rotation à la souris reste libre ensuite ;
- les titres sont espacés en pixels, avec un fond blanc discret. Leur placement dépend de la caméra, jamais du mouvement de la particule. Dans les vues alignées, le titre et les graduations de l’axe vu de bout sont masqués ; les titres hors cadre ou trop serrés ne se superposent pas ;
- le repère comporte uniquement trois axes cartésiens fléchés, passant par l’origine physique commune (0,0,0), sans boîte ni quadrillage de plans. Chaque axe se prolonge un peu avant l’origine et après sa dernière graduation. Les titres x, y et z sont placés près des extrémités positives, sans recouvrir les axes ni les commandes ;
- les projections orthogonales sont masquées par défaut et restent activables dans « Affichage » ;
- l’historique complet est activé par défaut, en gris clair opaque et sans atténuation ; décocher cette option réactive la durée de la traînée ;
- pour les courbes fermées, la borne temporelle par défaut vaut deux périodes géométriques.

## Ajustements de lisibilité

- Les dimensions physiques des 17 trajectoires ont été divisées par 2000 : le domaine de référence couvre 0 à 2 m, avec un centre en (1,1,1) m. La forme et le cadrage sont préservés grâce à une conversion explicite entre mètres et coordonnées internes du dessin.
- Les équations, paramètres, positions, dérivées et rayons de courbure utilisent tous cette échelle métrique. Les composantes numériques comportent deux décimales.
- Les durées et lois angulaires sont inchangées, sauf pour la trajectoire balistique : pour garder g = 9.81 m/s², la vitesse initiale et la durée sont divisées par √2000 (v₀ = √20 ≈ 4.47 m/s, durée ≈ 0.70 s). Sa forme et les longueurs graphiques relatives des vecteurs sont conservées.

- Les cadres des grandeurs vectorielles utilisent une grille responsive avec une largeur minimale suffisante pour afficher les trois composantes.
- L’affichage séparé et redondant de la position sous la scène a été retiré ; la position reste disponible dans son propre cadre quand le vecteur `Position` est sélectionné.
- La mention `© J. Martin` est forcée sur une seule ligne.
## Cercle osculateur instantané

Dans **Affichage**, l’option **Cercle osculateur et rayon** (désactivée au départ) ajoute le cercle en pointillés, son rayon en trait plein et son centre marqué d’une petite croix. Le rayon est noté $R_c$, avec sa valeur en mètres. Le cercle osculateur est le cercle qui épouse le mieux la courbe localement.

Le cercle garde la même échelle spatiale que la trajectoire, indépendamment du facteur de longueur des vecteurs. En 3D, il est construit dans le plan de la vitesse et de l’accélération centripète puis projeté avec la caméra. Activer l’option ne change ni le mouvement, ni le cadrage.

Aux points de vitesse quasi nulle, le cercle est indéfini. Lorsque la courbure est quasi nulle, le rayon tend vers l’infini et aucun cercle fini n’est affiché. Ces cas sont signalés dans le panneau. Si un grand cercle dépasse le champ de vue, seule sa partie visible est tracée : il n’est pas remis artificiellement à l’échelle.
