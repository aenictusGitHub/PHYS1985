# Énergie mécanique — PHYS1985

Ouvrir index.html, sans serveur ni connexion. MathJax est fourni localement.

Deux expériences idéales sans dissipation : ressort horizontal et pendule double.
Toutes les grandeurs sont en unités SI ; les angles des curseurs sont en degrés.
La hauteur minimale de chaque masse définit son zéro d’énergie potentielle.

L’oscillateur utilise une solution analytique. Le pendule utilise les équations
de Lagrange avec une matrice de masse symétrique, intégrées par RK4 à pas adaptatif
(doublement du pas et correction de Richardson ; tolérance locale 1e-11).
Aucune remise à l’échelle ne force la conservation de l’énergie. La sélection
d’un instant réintègre depuis l’échantillon précédent, sans interpolation linéaire
des positions qui fausserait le bilan énergétique.

Les sources séparées sont regroupées dans l’archive du dépôt PHYS1985.
Le thème commun est injecté par tools/build_apps.py. Les tests physiques sont
dans tools/check_energy.py à la racine du dépôt.
