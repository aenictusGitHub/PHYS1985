# Énergie mécanique — PHYS1985

Ouvrir index.html, sans serveur ni connexion. MathJax est fourni localement.

Quatre expériences : ressort horizontal, pendule simple, pendule double et deux corps
en interaction gravitationnelle universelle. Les trois premiers systèmes proposent
l’option avec ou sans frottements ; le système gravitationnel est isolé.
Toutes les grandeurs sont en unités SI ; les angles des curseurs sont en degrés.
Pour les pendules, la hauteur minimale de chaque masse définit son zéro d’énergie potentielle.

Le pendule simple utilise l’équation complète theta'' + gamma theta' + (g/l) sin(theta) = 0,
sans approximation des petits angles. La tige est rigide et sans masse ; elle autorise
les rotations complètes. Sa longueur, la masse, la pesanteur, l’angle et la vitesse
angulaire initiaux sont réglables. La hauteur est mesurée depuis le point le plus bas,
et l’angle affiché est ramené entre -180 et 180 degrés.

Le modèle à deux corps utilise G = 6.67430e-11 m^3 kg^-1 s^-2, sans adoucissement
du potentiel -G m1 m2 / r. Les deux corps se déplacent dans le référentiel de leur
centre de masse ; le potentiel de la paire est compté une seule fois. Les masses
sont réglables de 0.2 à 5 fois 10^12 kg, la séparation initiale de 6 à 20 m et la
vitesse relative tangentielle de 0.5 à 1.8 fois la vitesse circulaire. Cette plage
conserve un moment cinétique non nul et évite les collisions singulières.
Exemples : orbites circulaires, elliptiques, masses inégales et échappement.
Les énergies sont affichées en multiples explicites de 10^12 J ; le potentiel
est nul à l’infini et négatif à distance finie. Le diagramme et le graphique
placent les énergies positives et négatives de part et d’autre de zéro.
L’intégration relative conserve le centre de masse fixe ; les tests vérifient
les références de Kepler, l’énergie et le moment cinétique sans les renormaliser.

Sans frottements, l’oscillateur utilise une solution analytique. Le pendule double utilise les équations
de Lagrange avec une matrice de masse symétrique, intégrées par RK4 à pas adaptatif
(doublement du pas et correction de Richardson ; tolérance locale 1e-11).
Aucune remise à l’échelle ne force la conservation de l’énergie. La sélection
d’un instant réintègre depuis l’échantillon précédent, sans interpolation linéaire
des positions qui fausserait le bilan énergétique.

L’option « Avec frottements » applique à chaque masse la force visqueuse
F_f = -m gamma v, avec gamma en secondes inverses. Pour le pendule double, ces forces
cartésiennes donnent les forces généralisées Q = -gamma M qdot. La puissance
dissipée vaut 2 gamma K. Son intégrale est calculée comme une variable d’état
indépendante : le contrôle numérique porte sur E + E_diss - E(0), sans forcer
la somme à rester constante. Les deux corps gravitationnels, le pendule simple
et l’oscillateur amorti utilisent aussi l’intégrateur
adaptatif ; les régimes sous-amorti, critique et suramorti sont pris en charge.

Les sources séparées sont regroupées dans l’archive du dépôt PHYS1985.
Le thème commun est injecté par tools/build_apps.py. Les tests physiques sont
dans tools/check_energy.py à la racine du dépôt.
