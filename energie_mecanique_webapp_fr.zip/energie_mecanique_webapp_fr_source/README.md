# Énergie mécanique — PHYS1985

Ouvrir index.html, sans serveur ni connexion. MathJax est fourni localement.

Les masses sphériques des pendules et des deux corps gravitationnels reprennent le relief de Collisions : dégradé radial bleu ou vert clair, reflet supérieur gauche et ombre discrète. Leurs centres, rayons d’affichage, trajectoires, commandes et modèles mécaniques restent inchangés. Les points des graphes gardent un dessin plat.

Cinq expériences : oscillateurs harmonique et anharmonique, pendule simple, pendule double et deux corps
en interaction gravitationnelle universelle. Les quatre premiers systèmes proposent
l’option avec ou sans frottements ; le système gravitationnel est isolé.
Toutes les grandeurs sont en unités SI ; les angles des curseurs sont en degrés.
Le ressort anharmonique utilise U(x) = kx²/2 + αx⁴/4 et F_x = −kx − αx³,
avec α ≥ 0 réglable en N/m³. Son mouvement est intégré sans approximation
harmonique. α = 0 retrouve le ressort harmonique ; à α > 0 la période diminue
quand l’amplitude augmente. La courbe et les points de rebroussement utilisent
ce même potentiel, y compris avec frottements ou déplacement initial direct.
La période est affichée sous l’animation des deux oscillateurs, en secondes et
en LaTeX. Pour le ressort harmonique, T = 2π√(m/k). Pour le ressort anharmonique,
elle est calculée à partir de l’énergie initiale (position et vitesse) par une
quadrature du potentiel, après suppression de la singularité au rebroussement.
Elle se met à jour avec les paramètres et le déplacement initial de la masse.
Avec frottements, la valeur est explicitement une période de référence sans
amortissement à l’amplitude initiale, pas une période mesurée du mouvement amorti.
Au repos, le texte précise qu’il s’agit de la limite des petites oscillations.
Tous les graphes d’énergie portent une graduation verticale « 0 », sans doublon
ni recouvrement avec les graduations voisines. Dans la gravitation, C désigne
explicitement le centre de masse.
Pour les pendules, la hauteur minimale de chaque masse définit son zéro d’énergie potentielle.
La durée par défaut est de 10 s pour le pendule double, de 30 s pour les autres
systèmes. Elle reste réglable ; changer un paramètre ou un exemple conserve la
durée choisie. Sélectionner un système rétablit sa durée par défaut.

Dans « Affichage », l’oscillateur propose le vecteur vitesse instantanée, désactivé
par défaut. Le vecteur est décalé au-dessus de la masse et relié à elle par un guide
discret ; son sens suit la vitesse et sa longueur lui est proportionnelle, avec une
échelle fixe pendant l’expérience. À vitesse nulle, seule la notation du vecteur nul
reste affichée. L’option ne modifie ni l’instant ni les paramètres et fonctionne avec
ou sans frottements. Le ressort passe subtilement du gris bleuté en compression au
gris chaud en extension, avec une teinte neutre à sa longueur d’équilibre.

À l’instant initial et avant « Lire », les masses peuvent être déplacées à la souris
ou au toucher. Les touches fléchées sur une masse sélectionnée offrent la même
commande au clavier (Maj pour un déplacement plus grand). Le ressort reste
horizontal ; les pendules conservent leurs longueurs. Déplacer la masse supérieure
du pendule double entraîne la seconde sans changer l’angle de la deuxième tige.
Pour la gravitation, chaque masse ajuste la séparation et l’orientation de la paire
en conservant le centre de masse fixe. Les curseurs, valeurs LaTeX et énergies
suivent le geste ; les réglages de vitesse et de frottement ne changent pas.
Pour les deux corps, le rapport à la vitesse circulaire reste fixé : la vitesse
relative est recalculée avec la nouvelle séparation et reste tangentielle.
Les limites et pas des curseurs s’appliquent aussi au déplacement direct.
L’aperçu est calculé sans intégrer toute la trajectoire, recalculée au relâchement.
Échap ou l’annulation du geste restaure le réglage précédent. Les masses ne sont
pas déplaçables pendant la lecture ni en pause à un instant ultérieur ; choisir
« Recommencer » pour modifier à nouveau leur position initiale.

Le pendule simple utilise l’équation complète theta'' + gamma theta' + (g/l) sin(theta) = 0,
sans approximation des petits angles. La tige est rigide et sans masse ; elle autorise
les rotations complètes. Sa longueur, la masse, la pesanteur, l’angle et la vitesse
angulaire initiaux sont réglables. La hauteur est mesurée depuis le point le plus bas,
et l’angle affiché est ramené entre -180 et 180 degrés.

Le modèle à deux corps utilise G = 6.67430e-11 m^3 kg^-1 s^-2, sans adoucissement
du potentiel -G m1 m2 / r. Les deux corps se déplacent dans le référentiel de leur
centre de masse ; le potentiel de la paire est compté une seule fois. Son orientation
initiale est réglable sur un tour complet, depuis l’horizontale. Les masses
sont réglables de 0.2 à 5 fois 10^12 kg, la séparation initiale de 6 à 20 m et la
vitesse relative tangentielle de 0.5 à 1.8 fois la vitesse circulaire. Cette plage
conserve un moment cinétique non nul et évite les collisions singulières.
Exemples : orbites circulaires, elliptiques, masses inégales et échappement.
Les énergies sont affichées en multiples explicites de 10^12 J ; le potentiel
est nul à l’infini et négatif à distance finie. Le diagramme et le graphique
placent les énergies positives et négatives de part et d’autre de zéro.
L’intégration relative conserve le centre de masse fixe ; les tests vérifient
les références de Kepler, l’énergie et le moment cinétique sans les renormaliser.
L’option « Vitesses instantanées » montre les deux vecteurs dans le référentiel
du centre de masse, chacun dans la couleur de son corps. Leur longueur est
proportionnelle à la vitesse avec une même échelle pour les deux masses, fixe
pendant l’expérience. Les flèches partent du bord des corps pour garder visibles
même les petites vitesses. Le cadre réserve la même place aux annotations, que
les vecteurs soient visibles ou non. Les cases « Traces du mouvement » et
« Vitesses instantanées » ajoutent ou retirent seulement leurs tracés : elles
ne changent ni le zoom, ni les positions, ni les étiquettes des masses, ni
les paramètres ou l’instant de lecture. Les trajectoires visibles et les corps
partagent toujours la même projection, y compris après un déplacement initial.
Pour les deux corps, les traces colorées couvrent tout le trajet depuis l’instant
initial jusqu’à l’instant affiché, sans effacer les portions plus anciennes.
Pour les trajectoires d’échappement, le dézoom réduit aussi progressivement les
disques des masses. Leur taille suit l’échelle de la vue par rapport au départ,
en tendant vers un petit repère visible à grande distance. Ces disques sont des
symboles, pas des rayons physiques ; les textes restent de taille constante.
Revenir en arrière ou recommencer restitue la même taille au même instant.

Sans frottements, l’oscillateur harmonique utilise une solution analytique. Le pendule double utilise les équations
de Lagrange avec une matrice de masse symétrique, intégrées par RK4 à pas adaptatif
(doublement du pas et correction de Richardson ; tolérance locale 1e-11).
Aucune remise à l’échelle ne force la conservation de l’énergie. La sélection
d’un instant réintègre depuis l’échantillon précédent, sans interpolation linéaire
des positions qui fausserait le bilan énergétique.
Les restes de temps infimes dus à l’arrondi de l’horloge sont acceptés lorsque
leur erreur est sous la tolérance ; ils ne doivent pas interrompre la lecture.

L’option « Avec frottements » applique à chaque masse la force visqueuse
F_f = -m gamma v, avec gamma en secondes inverses. Pour le pendule double, ces forces
cartésiennes donnent les forces généralisées Q = -gamma M qdot. La puissance
dissipée vaut 2 gamma K. Son intégrale est calculée comme une variable d’état
indépendante : le contrôle numérique porte sur E + E_diss - E(0), sans forcer
la somme à rester constante. Les deux corps gravitationnels, le pendule simple
et l’oscillateur amorti utilisent aussi l’intégrateur
adaptatif ; les régimes sous-amorti, critique et suramorti sont pris en charge.

Les sources séparées sont regroupées dans l’archive du dépôt PHYS1985.
Le thème commun est injecté par tools/build_apps.py. Les tests physiques sont
dans tools/check_energy.py à la racine du dépôt.
Les valeurs numériques assemblent les tracés LaTeX mis en cache dans un seul SVG :
chiffres, point décimal et unité partagent une même ligne de base, indépendante
des chiffres affichés. Les tests de commande dans tools/check_energy_ui.cjs
vérifient aussi cet assemblage et la lecture continue à 60, 59.94 et 120 Hz.
