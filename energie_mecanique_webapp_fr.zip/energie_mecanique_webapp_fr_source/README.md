# Énergie mécanique — PHYS1985

Ouvrir index.html, sans serveur ni connexion. MathJax est fourni localement.

Deux expériences : ressort horizontal et pendule double, avec ou sans frottements.
Toutes les grandeurs sont en unités SI ; les angles des curseurs sont en degrés.
La hauteur minimale de chaque masse définit son zéro d’énergie potentielle.

Sans frottements, l’oscillateur utilise une solution analytique. Le pendule utilise les équations
de Lagrange avec une matrice de masse symétrique, intégrées par RK4 à pas adaptatif
(doublement du pas et correction de Richardson ; tolérance locale 1e-11).
Aucune remise à l’échelle ne force la conservation de l’énergie. La sélection
d’un instant réintègre depuis l’échantillon précédent, sans interpolation linéaire
des positions qui fausserait le bilan énergétique.

L’option « Avec frottements » applique à chaque masse la force visqueuse
F_f = -m gamma v, avec gamma en secondes inverses. Pour le pendule, ces forces
cartésiennes donnent les forces généralisées Q = -gamma M qdot. La puissance
dissipée vaut 2 gamma K. Son intégrale est calculée comme une variable d’état
indépendante : le contrôle numérique porte sur E + E_diss - E(0), sans forcer
la somme à rester constante. L’oscillateur amorti utilise aussi l’intégrateur
adaptatif ; les régimes sous-amorti, critique et suramorti sont pris en charge.

Les sources séparées sont regroupées dans l’archive du dépôt PHYS1985.
Le thème commun est injecté par tools/build_apps.py. Les tests physiques sont
dans tools/check_energy.py à la racine du dépôt.
