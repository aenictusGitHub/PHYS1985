/* Pure physical models. Angles are measured from the downward vertical. */
const EnergyModels = (() => {
  'use strict';
  function oscillator(p, t) {
    const omega = Math.sqrt(p.k / p.m);
    const x = p.x0 * Math.cos(omega * t) + p.v0 / omega * Math.sin(omega * t);
    const v = -p.x0 * omega * Math.sin(omega * t) + p.v0 * Math.cos(omega * t);
    return oscillatorState(p, [x, v, 0], t);
  }
  function oscillatorState(p, y, t) {
    const [x, v, D] = y;
    const K = .5 * p.m * v * v, U = .5 * p.k * x * x;
    return {t, y, x, v, K, U, D, E: K + U, parts: [K, U]};
  }
  function oscillatorRhs(p, y) {
    const [x, v] = y, gamma = p.gamma || 0;
    return [v, -p.k / p.m * x - gamma * v, gamma * p.m * v * v];
  }
  function rhs(p, y) {
    const [a, b, u, v] = y, delta = a - b;
    const cross = p.m2 * p.l1 * p.l2;
    const A = (p.m1 + p.m2) * p.l1 ** 2, B = cross * Math.cos(delta), C = p.m2 * p.l2 ** 2;
    const f = -cross * Math.sin(delta) * v * v - (p.m1 + p.m2) * p.g * p.l1 * Math.sin(a);
    const h = cross * Math.sin(delta) * u * u - p.m2 * p.g * p.l2 * Math.sin(b);
    const determinant = A * C - B * B;
    // Cartesian viscous forces -gamma*m_i*v_i give Q = -gamma*M*qdot.
    // The last component integrates the dissipated work independently of E.
    const gamma = p.gamma || 0;
    return [u, v, (f * C - B * h) / determinant - gamma * u,
      (A * h - B * f) / determinant - gamma * v,
      gamma * (A * u * u + 2 * B * u * v + C * v * v)];
  }
  function step(p, y, dt, derivative = rhs) {
    const shift = (k, scale) => y.map((v, i) => v + scale * k[i]);
    const a = derivative(p, y), b = derivative(p, shift(a, dt / 2)), c = derivative(p, shift(b, dt / 2)), d = derivative(p, shift(c, dt));
    return y.map((v, i) => v + dt * (a[i] + 2 * b[i] + 2 * c[i] + d[i]) / 6);
  }
  function pendulum(p, y, t) {
    const [a, b, u, v] = y;
    const x1 = p.l1 * Math.sin(a), z1 = -p.l1 * Math.cos(a);
    const x2 = x1 + p.l2 * Math.sin(b), z2 = z1 - p.l2 * Math.cos(b);
    const K1 = .5 * p.m1 * p.l1 ** 2 * u * u;
    // Sum squared Cartesian velocities to keep kinetic energy nonnegative.
    const vx2 = p.l1 * u * Math.cos(a) + p.l2 * v * Math.cos(b);
    const vz2 = p.l1 * u * Math.sin(a) + p.l2 * v * Math.sin(b);
    const K2 = .5 * p.m2 * (vx2 * vx2 + vz2 * vz2);
    const U1 = p.m1 * p.g * p.l1 * (1 - Math.cos(a));
    const U2 = p.m2 * p.g * (p.l1 * (1 - Math.cos(a)) + p.l2 * (1 - Math.cos(b)));
    return {t, y, x1, z1, x2, z2, K: K1 + K2, U: U1 + U2, D: y[4] || 0, E: K1 + U1 + K2 + U2, parts: [K1, U1, K2, U2]};
  }
  function simulate(model, p, duration) {
    const count = Math.round(duration * 60), samples = [];
    if (model === 'oscillator' && !(p.gamma > 0)) {
      for (let i = 0; i <= count; i++) samples.push(oscillator(p, i / 60));
      return {samples, at: t => oscillator(p, t), maxError: 0};
    }
    const evaluate = model === 'oscillator' ? oscillatorState : pendulum;
    const derivative = model === 'oscillator' ? oscillatorRhs : rhs;
    let y = model === 'oscillator' ? [p.x0, p.v0, 0] : [p.theta1 * Math.PI / 180, p.theta2 * Math.PI / 180, p.omega1, p.omega2, 0];
    const advance = (initial, dt) => {
      // Step doubling controls local error even for extreme mass ratios. The
      // Richardson correction raises accuracy without forcing energy to match.
      let next = initial, elapsed = 0, h = Math.min(dt, 1 / 240), attempts = 0;
      while (elapsed < dt - 1e-14) {
        if (++attempts > 10000) throw new Error('Le calcul demande un pas de temps trop petit.');
        h = Math.min(h, dt - elapsed);
        const full = step(p, next, h, derivative);
        const half = step(p, step(p, next, h / 2, derivative), h / 2, derivative);
        const error = Math.max(...half.map((v, i) => Math.abs(v - full[i]) / (15 * (1 + Math.max(Math.abs(next[i]), Math.abs(v))))));
        if (!Number.isFinite(error)) throw new Error('Le calcul du mouvement a échoué.');
        if (error <= 1e-11) {
          next = half.map((v, i) => v + (v - full[i]) / 15);
          elapsed += h;
        }
        h *= Math.max(.2, Math.min(2, .85 * Math.pow(1e-11 / Math.max(error, 1e-30), .2)));
        if (h < 1e-9) throw new Error('Le calcul demande un pas de temps trop petit.');
      }
      return next;
    };
    samples.push(evaluate(p, y, 0));
    let maxError = 0;
    for (let i = 1; i <= count; i++) {
      y = advance(y, 1 / 60);
      const sample = evaluate(p, y, i / 60);
      if (!Number.isFinite(sample.E)) throw new Error('Le calcul du mouvement a échoué.');
      maxError = Math.max(maxError, Math.abs(sample.E + sample.D - samples[0].E));
      samples.push(sample);
    }
    return {samples, maxError, at(t) {
      const bounded = Math.max(0, Math.min(duration, t));
      const base = samples[Math.min(count, Math.floor(bounded * 60))];
      return evaluate(p, advance(base.y, bounded - base.t), bounded);
    }};
  }
  return {oscillator, oscillatorState, oscillatorRhs, rhs, step, pendulum, simulate};
})();

// A projected helix: fixed turn count, smoothly changing pitch, straight leads.
function coilSpringPoints(start, end, centerY) {
  const turns = 12, samplesPerTurn = 48, length = Math.max(0, end - start);
  const lead = Math.min(9, length * .15), radiusX = length / (4 * turns + 8);
  const radiusY = Math.min(10, length / 2);
  const first = start + lead + 2 * radiusX, last = end - lead;
  const points = [[start, centerY], [first, centerY]];
  for (let i = 1; i <= turns * samplesPerTurn; i++) {
    const u = i / (turns * samplesPerTurn), angle = 2 * Math.PI * turns * u;
    points.push([first + (last - first) * u + radiusX * (Math.cos(angle) - 1), centerY + radiusY * Math.sin(angle)]);
  }
  points.push([end, centerY]);
  return points;
}

// The same file works when embedded in the standalone page or deferred in sources.
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startEnergyApp);
  else startEnergyApp();
}

async function startEnergyApp() {
  'use strict';
  const $ = id => document.getElementById(id);
  try {
    await MathJax.startup.promise;
    const tex = String.raw;
    const COLORS = {K: '#2775b6', U: '#b5688b', E: '#268576', K2: '#268576', U2: '#bc8b3b', D: '#a0acb9', ink: '#233449', muted: '#607185', grid: '#dce4ec'};
    const DEFINITIONS = {
      oscillator: {
        title: 'Oscillateur harmonique',
        note: 'Une masse reliée à un ressort horizontal. Aux extrémités, l’énergie est potentielle ; au passage par l’équilibre, elle est cinétique.',
        defaults: {m: 1, k: 4, x0: 1, v0: 0},
        fields: [
          ['m', 'Masse', 'm', .2, 5, .1, tex`\mathrm{kg}`],
          ['k', 'Raideur', 'k', .5, 20, .5, tex`\mathrm{N\,m^{-1}}`],
          ['x0', 'Position initiale', 'x_0', -2, 2, .05, tex`\mathrm m`],
          ['v0', 'Vitesse initiale', 'v_{x0}', -4, 4, .1, tex`\mathrm{m\,s^{-1}}`],
        ],
        examples: [
          ['Lâché sans vitesse', {x0: 1, v0: 0}],
          ['Passage par l’équilibre', {x0: 0, v0: 2}],
          ['Position et vitesse initiales', {x0: .7, v0: 1.4}],
          ['Au repos à l’équilibre', {x0: 0, v0: 0}],
        ],
        equations: [tex`U=\frac12 kx^2`, tex`K=\frac12 mv_x^2`, tex`E=K+U=\mathrm{constante}`, tex`\omega=\sqrt{\frac{k}{m}},\quad T=\frac{2\pi}{\omega}`, tex`x(t)=x_0\cos\omega t+\frac{v_{x0}}{\omega}\sin\omega t`],
        reference: 'L’origine de l’énergie potentielle est la position d’équilibre du ressort. Le mouvement est horizontal.',
      },
      pendulum: {
        title: 'Pendule double',
        note: 'Deux masses échangent de l’énergie par les tiges. Le mouvement peut être complexe, mais l’énergie mécanique totale reste constante.',
        defaults: {m1: 1, m2: 1, l1: 1.2, l2: 1, theta1: 120, theta2: -30, omega1: 0, omega2: 0, g: 9.81},
        fields: [
          ['m1', 'Masse supérieure', 'm_1', .2, 5, .1, tex`\mathrm{kg}`],
          ['m2', 'Masse inférieure', 'm_2', .2, 5, .1, tex`\mathrm{kg}`],
          ['l1', 'Première longueur', '\\ell_1', .5, 2, .05, tex`\mathrm m`],
          ['l2', 'Deuxième longueur', '\\ell_2', .5, 2, .05, tex`\mathrm m`],
          ['theta1', 'Angle initial supérieur', '\\theta_{10}', -170, 170, 1, tex`{}^\circ`],
          ['theta2', 'Angle initial inférieur', '\\theta_{20}', -170, 170, 1, tex`{}^\circ`],
          ['omega1', 'Vitesse angulaire initiale', '\\dot\theta_{10}', -3, 3, .1, tex`\mathrm{rad\,s^{-1}}`],
          ['omega2', 'Vitesse angulaire initiale', '\\dot\theta_{20}', -3, 3, .1, tex`\mathrm{rad\,s^{-1}}`],
          ['g', 'Pesanteur', 'g', .5, 20, .01, tex`\mathrm{m\,s^{-2}}`],
        ],
        examples: [
          ['Grands échanges d’énergie', {}],
          ['Petites oscillations couplées', {theta1: 15, theta2: 0}],
          ['Masses différentes', {m1: 2, m2: .5, theta1: 90, theta2: -60}],
          ['Au repos à l’équilibre', {theta1: 0, theta2: 0}],
        ],
        equations: [tex`K_i=\frac12 m_i\lvert\vec v_i\rvert^2`, tex`U_i=m_i g(z_i-z_{i,\min})`, tex`K=K_1+K_2,\quad U=U_1+U_2`, tex`E=K_1+U_1+K_2+U_2`, tex`\frac{\mathrm dE}{\mathrm dt}=0`],
        reference: 'Tiges rigides, sans masse, pivot fixe. Les angles sont mesurés depuis la verticale descendante. Pour chaque masse, le potentiel est nul à sa hauteur minimale, lorsque les deux tiges sont verticales vers le bas.',
      },
    };
    const state = {model: 'oscillator', p: {}, t: 0, duration: 30, playing: false, simulation: null, last: null, frame: 0, dirty: false, readoutTime: -1};
    const glyphs = new Map(), units = new Map();
    function math(el, value) {
      if (el.dataset.math === value) return;
      el.replaceChildren(MathJax.tex2svg(value, {display: false}));
      el.dataset.math = value;
    }
    for (const el of document.querySelectorAll('[data-tex]')) math(el, el.dataset.tex);
    for (const char of '0123456789.-') glyphs.set(char, MathJax.tex2svg(char, {display: false}));
    // tex2svg creates both the visible SVG and accessible MathML, but does not
    // install page styles itself. Install them before showing any math output.
    MathJax.startup.document.updateDocument();
    function number(el, value, digits = 2, unit = '') {
      if (!Number.isFinite(value)) throw new Error('Valeur non finie.');
      const clean = Math.abs(value) < .5 * 10 ** (-digits) ? 0 : value;
      const string = clean.toFixed(digits);
      const key = `${string}|${unit}`;
      if (el.dataset.number === key) return;
      el.classList.add('number');
      const nodes = [...string].map(char => {
        const span = document.createElement('span');
        span.className = 'number-glyph'; span.setAttribute('aria-hidden', 'true');
        span.append(glyphs.get(char).cloneNode(true)); return span;
      });
      if (unit) {
        if (!units.has(unit)) units.set(unit, MathJax.tex2svg(unit, {display: false}));
        const span = document.createElement('span'); span.className = 'number-unit'; span.setAttribute('aria-hidden', 'true');
        span.append(units.get(unit).cloneNode(true)); nodes.push(span);
      }
      el.replaceChildren(...nodes); el.dataset.number = key;
      el.setAttribute('aria-label', string + (unit ? ' ' + unit.replace(/\\mathrm|[{}]/g, '').replace(/\\,/g, ' ') : ''));
    }
    function components(sample) {
      const parts = state.model === 'pendulum' && $('detail').checked ? [
        {symbol: 'K_1', value: sample.parts[0], color: COLORS.K},
        {symbol: 'U_1', value: sample.parts[1], color: COLORS.U},
        {symbol: 'K_2', value: sample.parts[2], color: COLORS.K2},
        {symbol: 'U_2', value: sample.parts[3], color: COLORS.U2},
      ] : [{symbol: 'K', value: sample.K, color: COLORS.K}, {symbol: 'U', value: sample.U, color: COLORS.U}];
      if (state.p.gamma > 0) parts.push({symbol: tex`E_{\mathrm{diss}}`, value: sample.D, color: COLORS.D});
      return parts;
    }
    function setPlaying(value) {
      state.playing = value; state.last = null;
      $('play').textContent = value ? 'Pause' : 'Lire';
      $('play').setAttribute('aria-pressed', String(value));
      if (value && !state.frame) state.frame = requestAnimationFrame(frame);
    }
    function setTime(value) {
      state.t = Math.max(0, Math.min(state.duration, value)); render();
    }
    function makeParameters() {
      const definition = DEFINITIONS[state.model];
      $('parameters').replaceChildren();
      for (const [key, title, symbol, min, max, step, unit] of definition.fields) {
        const root = document.createElement('div'); root.className = 'parameter';
        const row = document.createElement('div'); row.className = 'parameter-title';
        const label = document.createElement('label'); label.className = 'field-label'; label.htmlFor = `param-${key}`;
        label.append(title + ' '); const formula = document.createElement('span'); math(formula, symbol); label.append(formula);
        const output = document.createElement('output'); output.htmlFor = `param-${key}`; output.id = `value-${key}`;
        row.append(label); root.append(row);
        const input = document.createElement('input'); input.type = 'range'; input.id = `param-${key}`;
        Object.assign(input, {min, max, step, value: state.p[key]});
        input.addEventListener('input', () => {
          state.p[key] = Number(input.value); number(output, state.p[key], key.startsWith('theta') ? 0 : 2, unit);
          $('example-select').value = 'custom'; scheduleRebuild();
        });
        root.append(input, output); number(output, state.p[key], key.startsWith('theta') ? 0 : 2, unit);
        $('parameters').append(root);
      }
    }
    function setExample(index) {
      const definition = DEFINITIONS[state.model];
      state.p = {...definition.defaults, ...definition.examples[index][1]};
      $('example-select').value = String(index); makeParameters(); rebuild();
    }
    function setModel() {
      state.model = $('model-select').value;
      const definition = DEFINITIONS[state.model];
      $('scene-title').textContent = definition.title;
      $('example-select').replaceChildren(...definition.examples.map(([label], i) => new Option(label, String(i))));
      const custom = new Option('Réglage personnalisé', 'custom'); custom.disabled = true; $('example-select').append(custom);
      $('detail-row').hidden = $('trail-row').hidden = state.model !== 'pendulum';
      $('position-badge').hidden = state.model !== 'oscillator';
      setExample(0);
    }
    function updateFrictionInterface() {
      const on = $('friction-toggle').checked, definition = DEFINITIONS[state.model];
      state.p.gamma = on ? Number($('damping-slider').value) : 0;
      $('damping-controls').hidden = !on;
      $('dissipation-card').hidden = !on;
      $('friction-badge').textContent = on ? 'Avec frottements' : 'Sans frottement';
      number($('damping-readout'), Number($('damping-slider').value), 2, tex`\mathrm{s^{-1}}`);
      $('model-note').textContent = on
        ? (state.model === 'oscillator' ? 'La force de frottement freine la masse. L’énergie mécanique est progressivement dissipée.' : 'Les deux masses échangent de l’énergie et subissent un frottement. Leur énergie mécanique totale diminue.')
        : definition.note;
      $('reference-note').textContent = definition.reference;
      $('conservation-note').textContent = on
        ? 'Frottement visqueux sur chaque masse, proportionnel à sa vitesse. L’énergie mécanique perdue est transférée au milieu ; elle n’est pas détruite.'
        : 'Système idéal, sans frottement. Les échanges modifient la répartition de l’énergie, pas son total.';
      let equations = definition.equations;
      if (on) {
        equations = state.model === 'oscillator'
          ? [tex`U=\frac12 kx^2,\quad K=\frac12 mv_x^2`, tex`\vec F_{\mathrm f}=-m\gamma\vec v`, tex`\ddot x+\gamma\dot x+\frac{k}{m}x=0`]
          : [definition.equations[0], definition.equations[1], tex`\vec F_{\mathrm f,i}=-m_i\gamma\vec v_i`];
        equations = [...equations, tex`E=K+U`, tex`\frac{\mathrm dE}{\mathrm dt}=-2\gamma K`, tex`E_{\mathrm{diss}}=\int_0^t 2\gamma K(\tau)\,\mathrm d\tau`, tex`E+E_{\mathrm{diss}}=E(0)`];
      }
      $('relations').replaceChildren(...equations.map(eq => {
        const div = document.createElement('div'); div.className = 'equation'; math(div, eq); return div;
      }));
      math($('balance-symbol'), on ? tex`E+E_{\mathrm{diss}}=E(0)` : 'E=K+U');
      math($('error-symbol'), on ? tex`\Delta E+E_{\mathrm{diss}}` : 'E(t)-E(0)');
    }
    function scheduleRebuild() {
      setPlaying(false);
      if (state.dirty) return;
      state.dirty = true;
      requestAnimationFrame(() => { state.dirty = false; rebuild(); });
    }
    function rebuild() {
      setPlaying(false); state.t = 0;
      state.duration = Number($('duration').value);
      updateFrictionInterface();
      state.simulation = EnergyModels.simulate(state.model, state.p, state.duration);
      $('time-slider').max = state.duration; $('history').setAttribute('aria-valuemax', state.duration);
      number($('duration-readout'), state.duration, 0, tex`\mathrm s`);
      $('accuracy-note').textContent = state.simulation.maxError > 1e-5 * Math.max(1, state.simulation.samples[0].E) ? 'écart numérique à surveiller' : 'écart numérique';
      updateKeys(); render();
    }
    function updateKeys() {
      const parts = components(state.simulation.at(state.t));
      $('energy-key').replaceChildren(); $('energy-stack').replaceChildren(); $('chart-key').replaceChildren();
      for (const [i, part] of parts.entries()) {
        const row = document.createElement('div'); row.className = 'key-row';
        const swatch = document.createElement('span'); swatch.className = 'key-swatch'; swatch.style.background = part.color;
        const label = document.createElement('span'); math(label, part.symbol);
        const value = document.createElement('span'); value.id = `part-${i}`; value.className = 'key-value';
        row.append(swatch, label, value); $('energy-key').append(row);
        const segment = document.createElement('div'); segment.className = 'energy-segment'; segment.id = `segment-${i}`; segment.style.background = part.color;
        $('energy-stack').append(segment);
        const legend = document.createElement('span'); legend.append(swatch.cloneNode(), label.cloneNode(true)); $('chart-key').append(legend);
      }
      const on = state.p.gamma > 0;
      const total = document.createElement('span'); const dash = document.createElement('span'); dash.className = 'key-swatch'; dash.style.borderTop = `2px ${on ? 'solid' : 'dashed'} ${COLORS.ink}`;
      const label = document.createElement('span'); math(label, on ? 'E(t)' : 'E'); total.append(dash, label); $('chart-key').append(total);
      if (on) {
        const reference = document.createElement('span'), marker = dash.cloneNode(), symbol = document.createElement('span');
        marker.style.borderTop = `2px dashed ${COLORS.muted}`; math(symbol, 'E(0)'); reference.append(marker, symbol); $('chart-key').append(reference);
      }
    }
    function surface(id) {
      const canvas = $(id), rect = canvas.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(1, rect.width), h = Math.max(1, rect.height);
      if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
        canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      }
      const ctx = canvas.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
      return {ctx, w, h};
    }
    const labels = new Map();
    function label(layer, name, text, x, y, color = COLORS.ink, tick = false) {
      const key = layer + '-' + name;
      if (!labels.has(key)) {
        const node = document.createElement('span'); $(layer).append(node); labels.set(key, node);
      }
      const node = labels.get(key); node.hidden = false; node.className = 'plot-label' + (tick ? ' tick' : '');
      math(node, text); node.style.left = `${x}px`; node.style.top = `${y}px`; node.style.color = color;
    }
    function hideLabels(layer) { for (const node of $(layer).children) node.hidden = true; }
    function line(ctx, points, color, width = 2, dash = []) {
      if (!points.length) return;
      ctx.beginPath(); ctx.moveTo(...points[0]); for (let i = 1; i < points.length; i++) ctx.lineTo(...points[i]);
      ctx.strokeStyle = color; ctx.lineWidth = width; ctx.setLineDash(dash); ctx.stroke(); ctx.setLineDash([]);
    }
    function dot(ctx, x, y, radius, color) { ctx.beginPath(); ctx.arc(x, y, radius, 0, 2 * Math.PI); ctx.fillStyle = color; ctx.fill(); }
    function drawOscillator(sample) {
      const {ctx, w, h} = surface('scene-canvas'), p = state.p;
      const initial = state.simulation.samples[0], A = Math.sqrt(2 * initial.E / p.k);
      const range = Math.max(.25, A * 1.12), yMax = Math.max(.1, initial.E * 1.4, .55 * p.k * range ** 2);
      const left = 44, right = w - 28, top = 70, bottom = h * .65;
      const X = x => (left + right) / 2 + x / range * (right - left) / 2;
      const Y = u => bottom - u / yMax * (bottom - top);
      line(ctx, [[left, bottom], [right, bottom]], COLORS.grid, 1);
      line(ctx, [[X(0), top], [X(0), bottom]], COLORS.grid, 1);
      const curve = [];
      for (let i = 0; i <= 120; i++) { const x = -range + 2 * range * i / 120; curve.push([X(x), Y(.5 * p.k * x * x)]); }
      line(ctx, curve, COLORS.U, 2);
      line(ctx, [[left, Y(sample.E)], [right, Y(sample.E)]], COLORS.E, 1.5, [5, 4]);
      line(ctx, [[X(sample.x), bottom], [X(sample.x), Y(sample.U)]], COLORS.U, 4);
      line(ctx, [[X(sample.x), Y(sample.U)], [X(sample.x), Y(sample.E)]], COLORS.K, 4);
      dot(ctx, X(sample.x), Y(sample.U), 5, COLORS.ink);
      label('scene-labels', 'potential', tex`U(x)=\tfrac12 kx^2`, (left + right) / 2, 54, COLORS.U);
      label('scene-labels', 'energy', p.gamma > 0 ? 'E(t)' : 'E', right - 8, Y(sample.E) - 13, COLORS.E);
      label('scene-labels', 'zero', '0', X(0), bottom + 18, COLORS.muted, true);
      if (A > 1e-8) {
        label('scene-labels', 'aminus', p.gamma > 0 ? '-A_0' : '-A', X(-A), bottom + 18, COLORS.muted, true);
        label('scene-labels', 'aplus', p.gamma > 0 ? 'A_0' : 'A', X(A), bottom + 18, COLORS.muted, true);
      }
      const rail = h - 52, massX = X(sample.x), anchor = 20;
      line(ctx, [[anchor, rail - 25], [anchor, rail + 20]], COLORS.muted, 3);
      line(ctx, [[anchor, rail + 20], [w - 20, rail + 20]], COLORS.grid, 1);
      line(ctx, [[X(0), rail - 25], [X(0), rail + 20]], COLORS.grid, 1, [3, 3]);
      ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      line(ctx, coilSpringPoints(anchor, massX - 15, rail), COLORS.muted, 2);
      ctx.restore();
      ctx.fillStyle = COLORS.K; ctx.fillRect(massX - 15, rail - 15, 30, 30);
      label('scene-labels', 'mass', 'm', massX, rail - 29, COLORS.K);
    }
    function drawPendulum(sample) {
      const {ctx, w, h} = surface('scene-canvas'), p = state.p;
      const length = p.l1 + p.l2, scale = Math.min((w - 80) / (2 * length), (h - 75) / (2 * length));
      const origin = [w / 2, h / 2 + 20], point = (x, z) => [origin[0] + scale * x, origin[1] - scale * z];
      const a = point(sample.x1, sample.z1), b = point(sample.x2, sample.z2);
      if ($('trail').checked) {
        const start = Math.max(0, Math.floor(state.t * 60) - 360), end = Math.floor(state.t * 60);
        const points = state.simulation.samples.slice(start, end + 1).map(s => point(s.x2, s.z2)); points.push(b);
        line(ctx, points, '#c3d5e1', 1.5);
      }
      line(ctx, [[origin[0], origin[1] - length * scale], [origin[0], origin[1] + length * scale]], COLORS.grid, 1, [4, 5]);
      line(ctx, [origin, a, b], '#778da0', 3);
      dot(ctx, ...origin, 4, COLORS.ink);
      dot(ctx, ...a, 7 + Math.sqrt(p.m1) * 3, COLORS.K);
      dot(ctx, ...b, 7 + Math.sqrt(p.m2) * 3, COLORS.K2);
      label('scene-labels', 'mass1', 'm_1', a[0] + 22, a[1] - 16, COLORS.K);
      label('scene-labels', 'mass2', 'm_2', b[0] + 22, b[1] + 17, COLORS.K2);
      label('scene-labels', 'origin', 'O', origin[0] - 14, origin[1] - 12, COLORS.muted);
      const gx = w - 30, gy = h - 64;
      line(ctx, [[gx, gy], [gx, gy + 27]], COLORS.muted, 2);
      line(ctx, [[gx - 4, gy + 21], [gx, gy + 27], [gx + 4, gy + 21]], COLORS.muted, 2);
      label('scene-labels', 'gravity', tex`\vec g`, gx - 14, gy + 12, COLORS.muted);
    }
    function chartGeometry(w, h) {
      const ymax = Math.max(.1, state.simulation.samples[0].E * 1.16);
      return {left: 66, right: w - 28, top: 23, bottom: h - 45, ymax};
    }
    function drawHistory(sample) {
      const {ctx, w, h} = surface('history-canvas'), r = chartGeometry(w, h);
      const X = t => r.left + t / state.duration * (r.right - r.left), Y = e => r.bottom - e / r.ymax * (r.bottom - r.top);
      hideLabels('history-labels');
      const nx = w < 500 ? 3 : 5;
      for (let i = 0; i <= nx; i++) {
        const t = state.duration * i / nx;
        line(ctx, [[X(t), r.top], [X(t), r.bottom]], COLORS.grid, 1);
        label('history-labels', `x${i}`, t.toFixed(t % 1 ? 1 : 0), X(t), r.bottom + 17, COLORS.muted, true);
      }
      for (let i = 0; i <= 4; i++) {
        const e = r.ymax * i / 4;
        line(ctx, [[r.left, Y(e)], [r.right, Y(e)]], COLORS.grid, 1);
        label('history-labels', `y${i}`, e.toFixed(r.ymax < 1 ? 2 : 1), r.left - 25, Y(e), COLORS.muted, true);
      }
      label('history-labels', 'xunit', tex`t\,[\mathrm s]`, (r.left + r.right) / 2, h - 10);
      label('history-labels', 'yunit', tex`E\,[\mathrm J]`, 29, 10);
      const stride = Math.max(1, Math.floor(state.simulation.samples.length / Math.max(200, w)));
      const samples = state.simulation.samples.filter((s, i) => i % stride === 0 && s.t < state.t);
      samples.push(sample);
      const parts = components(sample), stacked = $('stacked').checked;
      let lower = samples.map(() => 0);
      for (let k = 0; k < parts.length; k++) {
        const values = samples.map(s => components(s)[k].value);
        const upper = values.map((v, i) => v + (stacked ? lower[i] : 0));
        const points = samples.map((s, i) => [X(s.t), Y(upper[i])]);
        if (stacked) {
          ctx.beginPath(); points.forEach((p, i) => i ? ctx.lineTo(...p) : ctx.moveTo(...p));
          for (let i = samples.length - 1; i >= 0; i--) ctx.lineTo(X(samples[i].t), Y(lower[i]));
          ctx.closePath(); ctx.globalAlpha = .72; ctx.fillStyle = parts[k].color; ctx.fill(); ctx.globalAlpha = 1;
        }
        line(ctx, points, parts[k].color, stacked ? 1 : 2);
        if (!stacked) dot(ctx, X(sample.t), Y(values[values.length - 1]), 3, parts[k].color);
        lower = upper;
      }
      line(ctx, [[r.left, Y(state.simulation.samples[0].E)], [r.right, Y(state.simulation.samples[0].E)]], state.p.gamma > 0 ? COLORS.muted : COLORS.ink, 1.5, [6, 4]);
      if (state.p.gamma > 0) line(ctx, samples.map(s => [X(s.t), Y(s.E)]), COLORS.ink, 2);
      line(ctx, [[X(state.t), r.top], [X(state.t), r.bottom]], '#8998a7', 1.5, [3, 3]);
      dot(ctx, X(state.t), Y(sample.E), 4, COLORS.ink);
    }
    function render() {
      if (!state.simulation) return;
      const sample = state.simulation.at(state.t), E0 = state.simulation.samples[0].E;
      $('time-slider').value = state.t; $('history').setAttribute('aria-valuenow', state.t.toFixed(2));
      $('history').setAttribute('aria-valuetext', state.t.toFixed(2) + ' secondes');
      if (!state.playing || Math.abs(state.t - state.readoutTime) >= 1 / 15) {
        state.readoutTime = state.t;
        number($('time-readout'), state.t, 2, tex`\mathrm s`); number($('scene-time'), state.t, 2, tex`\mathrm s`);
        if (state.model === 'oscillator') number($('position-readout'), sample.x, 2, tex`\mathrm m`);
        number($('kinetic-readout'), sample.K, 3, tex`\mathrm J`);
        number($('potential-readout'), sample.U, 3, tex`\mathrm J`);
        number($('total-readout'), sample.E, 3, tex`\mathrm J`);
        number($('dissipation-readout'), sample.D, 3, tex`\mathrm J`);
        const error = sample.E + sample.D - E0;
        number($('error-readout'), error, Math.abs(error) < .0000005 ? 0 : 6, tex`\mathrm J`);
        for (const [i, part] of components(sample).entries()) {
          number($(`part-${i}`), part.value, 3, tex`\mathrm J`);
        }
      }
      const budget = sample.E + sample.D;
      for (const [i, part] of components(sample).entries()) {
        $(`segment-${i}`).style.height = `${budget > 1e-12 ? 100 * part.value / budget : 0}%`;
      }
      $('energy-stack').style.height = `${E0 > 1e-12 ? Math.min(100, 100 * budget / E0) : 0}%`;
      const scene = $('scene'); scene.setAttribute('aria-label', `${DEFINITIONS[state.model].title}. Instant ${state.t.toFixed(2)} s ; énergie cinétique ${sample.K.toFixed(3)} J ; énergie potentielle ${sample.U.toFixed(3)} J ; énergie dissipée ${sample.D.toFixed(3)} J.`);
      hideLabels('scene-labels');
      if (state.model === 'oscillator') drawOscillator(sample); else drawPendulum(sample);
      drawHistory(sample);
      $('observation').textContent = E0 < 1e-12 ? 'Le système reste au repos à l’équilibre : les énergies cinétique et potentielle sont nulles.'
        : state.p.gamma > 0 ? 'Les frottements dissipent de l’énergie. La partie grise représente l’énergie transférée au milieu ; ajoutée à l’énergie mécanique restante, elle retrouve l’énergie initiale.'
        : state.model === 'pendulum' ? 'Chaque masse peut gagner ou perdre de l’énergie. Seule la somme des énergies des deux masses est conservée.'
        : sample.K / E0 < .05 ? 'Près d’une extrémité, la masse ralentit : l’énergie est essentiellement potentielle.'
        : sample.U / E0 < .05 ? 'Près de l’équilibre, la vitesse est maximale : l’énergie est essentiellement cinétique.'
        : 'Pendant le mouvement, l’énergie cinétique et l’énergie potentielle se transforment l’une en l’autre.';
    }
    function frame(now) {
      state.frame = 0;
      if (!state.playing) return;
      if (state.last !== null) state.t += Math.min(.1, (now - state.last) / 1000) * Number($('playback-speed').value);
      state.last = now;
      if (state.t >= state.duration) {
        if ($('loop').checked) state.t %= state.duration;
        else { state.t = state.duration; setPlaying(false); }
      }
      render(); if (state.playing) state.frame = requestAnimationFrame(frame);
    }
    $('model-select').addEventListener('change', setModel);
    $('example-select').addEventListener('change', () => setExample(Number($('example-select').value)));
    $('reset-parameters').addEventListener('click', () => { $('damping-slider').value = '0.25'; setExample(0); });
    $('friction-toggle').addEventListener('change', rebuild);
    $('damping-slider').addEventListener('input', () => {
      number($('damping-readout'), Number($('damping-slider').value), 2, tex`\mathrm{s^{-1}}`);
      scheduleRebuild();
    });
    $('play').addEventListener('click', () => { if (state.t >= state.duration) state.t = 0; setPlaying(!state.playing); });
    $('restart').addEventListener('click', () => { setPlaying(false); setTime(0); });
    $('time-slider').addEventListener('input', () => { setPlaying(false); setTime(Number($('time-slider').value)); });
    $('duration').addEventListener('input', () => { number($('duration-readout'), Number($('duration').value), 0, tex`\mathrm s`); scheduleRebuild(); });
    $('detail').addEventListener('change', () => { updateKeys(); render(); });
    for (const id of ['stacked', 'trail']) $(id).addEventListener('change', render);
    function seek(event) {
      const rect = $('history').getBoundingClientRect(), r = chartGeometry(rect.width, rect.height);
      setPlaying(false); setTime((event.clientX - rect.left - r.left) / (r.right - r.left) * state.duration);
    }
    $('history').addEventListener('pointerdown', event => { $('history').setPointerCapture(event.pointerId); seek(event); });
    $('history').addEventListener('pointermove', event => { if ($('history').hasPointerCapture(event.pointerId)) seek(event); });
    $('history').addEventListener('keydown', event => {
      const change = {ArrowLeft: -.1, ArrowRight: .1, ArrowDown: -1, ArrowUp: 1};
      if (event.key in change) { event.preventDefault(); setPlaying(false); setTime(state.t + change[event.key]); }
      if (event.key === 'Home' || event.key === 'End') { event.preventDefault(); setPlaying(false); setTime(event.key === 'Home' ? 0 : state.duration); }
    });
    document.addEventListener('keydown', event => {
      if (event.target.closest('input, select, button, [role="slider"]') || event.ctrlKey || event.metaKey || event.altKey) return;
      if (event.code === 'Space') { event.preventDefault(); $('play').click(); }
      if (event.key.toLowerCase() === 'r') $('restart').click();
    });
    document.addEventListener('visibilitychange', () => { if (document.hidden) setPlaying(false); });
    new ResizeObserver(() => render()).observe($('scene'));
    new ResizeObserver(() => render()).observe($('history'));
    setModel(); $('loading').hidden = true;
  } catch (error) {
    $('loading').hidden = false;
    $('loading').textContent = 'L’animation n’a pas pu démarrer. Rechargez la page. ' + error.message;
    console.error(error);
  }
}
