/* Pure physical models. Angles are measured from the downward vertical. */
const EnergyModels = (() => {
  'use strict';
  const G = 6.67430e-11;
  const oscillatorPotential = (p, x) => .5 * p.k * x * x + .25 * (p.alpha || 0) * x ** 4;
  // Stable positive root of U(A)=E, including the harmonic limit alpha=0.
  const oscillatorAmplitude = (p, E) => Math.sqrt(4 * Math.max(0, E) / (p.k + Math.sqrt(p.k ** 2 + 4 * (p.alpha || 0) * Math.max(0, E))));
  function oscillatorPeriod(p, E = oscillatorPotential(p, p.x0) + .5 * p.m * p.v0 ** 2) {
    // Conservative period at energy E. Substituting x=A*sin(theta) removes
    // the turning-point singularity in 4*sqrt(m/2)*integral dx/sqrt(E-U).
    // T = 4*sqrt(m)*integral_0^(pi/2) [k+alpha*A^2*(1+sin^2(theta))/2]^-1/2 dtheta.
    // At rest this returns the small-amplitude limit, not an observed cycle.
    const alpha = p.alpha || 0;
    if (![p.m, p.k, alpha, E].every(Number.isFinite) || p.m <= 0 || p.k <= 0 || alpha < 0 || E < 0) throw new Error('Paramètres de période non valides.');
    if (alpha === 0 || E === 0) return 2 * Math.PI * Math.sqrt(p.m / p.k);
    const A = oscillatorAmplitude(p, E), b = .5 * alpha * A * A, n = 64, h = Math.PI / (2 * n);
    const integrand = theta => 1 / Math.sqrt(p.k + b * (1 + Math.sin(theta) ** 2));
    let sum = integrand(0) + integrand(Math.PI / 2);
    for (let i = 1; i < n; i++) sum += (i % 2 ? 4 : 2) * integrand(i * h);
    return 4 * Math.sqrt(p.m) * h * sum / 3;
  }
  function oscillator(p, t) {
    const omega = Math.sqrt(p.k / p.m);
    const x = p.x0 * Math.cos(omega * t) + p.v0 / omega * Math.sin(omega * t);
    const v = -p.x0 * omega * Math.sin(omega * t) + p.v0 * Math.cos(omega * t);
    return oscillatorState(p, [x, v, 0], t);
  }
  function oscillatorState(p, y, t) {
    const [x, v, D] = y;
    const K = .5 * p.m * v * v, U = oscillatorPotential(p, x);
    return {t, y, x, v, K, U, D, E: K + U, parts: [K, U]};
  }
  function oscillatorRhs(p, y) {
    const [x, v] = y, gamma = p.gamma || 0;
    return [v, -(p.k * x + (p.alpha || 0) * x ** 3) / p.m - gamma * v, gamma * p.m * v * v];
  }
  function simplePendulum(p, y, t) {
    const [theta, omega, D = 0] = y;
    const x = p.l * Math.sin(theta), z = -p.l * Math.cos(theta);
    const K = .5 * p.m * p.l ** 2 * omega ** 2;
    // Half-angle form avoids cancellation near the lowest point.
    const U = 2 * p.m * p.g * p.l * Math.sin(theta / 2) ** 2;
    return {t, y, theta, omega, x, z, K, U, D, E: K + U, parts: [K, U]};
  }
  function simplePendulumRhs(p, y) {
    const [theta, omega] = y, gamma = p.gamma || 0;
    return [omega, -p.g / p.l * Math.sin(theta) - gamma * omega,
      gamma * p.m * p.l ** 2 * omega ** 2];
  }
  function gravity(p, y, t) {
    const [x, z, vx, vz] = y, r = Math.hypot(x, z), total = p.m1 + p.m2;
    const f1 = p.m2 / total, f2 = p.m1 / total, speed2 = vx * vx + vz * vz;
    const K1 = .5 * p.m1 * f1 ** 2 * speed2, K2 = .5 * p.m2 * f2 ** 2 * speed2;
    const U = -G * p.m1 * p.m2 / r;
    return {t, y, r, x1: -f1*x, z1: -f1*z, x2: f2*x, z2: f2*z,
      vx1: -f1*vx, vz1: -f1*vz, vx2: f2*vx, vz2: f2*vz,
      K: K1 + K2, U, D: 0, E: K1 + K2 + U, parts: [K1, K2, U]};
  }
  function gravityRhs(p, y) {
    const [x, z, vx, vz] = y, r = Math.hypot(x, z);
    const factor = -G * (p.m1 + p.m2) / r ** 3;
    return [vx, vz, factor * x, factor * z];
  }
  function rhs(p, y) {
    const [a, b, u, v] = y, delta = a - b;
    const cross = p.m2 * p.l1 * p.l2;
    const A = (p.m1 + p.m2) * p.l1 ** 2, B = cross * Math.cos(delta), C = p.m2 * p.l2 ** 2;
    const f = -cross * Math.sin(delta) * v * v - (p.m1 + p.m2) * p.g * p.l1 * Math.sin(a);
    const h = cross * Math.sin(delta) * u * u - p.m2 * p.g * p.l2 * Math.sin(b);
    const determinant = A * C - B * B;
    // Cartesian viscous forces -gamma*m_i*v_i give Q = -gamma*M*qdot.
    // The last component integrates the dissipated work independently of E.
    const gamma = p.gamma || 0;
    return [u, v, (f * C - B * h) / determinant - gamma * u,
      (A * h - B * f) / determinant - gamma * v,
      gamma * (A * u * u + 2 * B * u * v + C * v * v)];
  }
  function step(p, y, dt, derivative = rhs) {
    const shift = (k, scale) => y.map((v, i) => v + scale * k[i]);
    const a = derivative(p, y), b = derivative(p, shift(a, dt / 2)), c = derivative(p, shift(b, dt / 2)), d = derivative(p, shift(c, dt));
    return y.map((v, i) => v + dt * (a[i] + 2 * b[i] + 2 * c[i] + d[i]) / 6);
  }
  function pendulum(p, y, t) {
    const [a, b, u, v] = y;
    const x1 = p.l1 * Math.sin(a), z1 = -p.l1 * Math.cos(a);
    const x2 = x1 + p.l2 * Math.sin(b), z2 = z1 - p.l2 * Math.cos(b);
    const K1 = .5 * p.m1 * p.l1 ** 2 * u * u;
    // Sum squared Cartesian velocities to keep kinetic energy nonnegative.
    const vx2 = p.l1 * u * Math.cos(a) + p.l2 * v * Math.cos(b);
    const vz2 = p.l1 * u * Math.sin(a) + p.l2 * v * Math.sin(b);
    const K2 = .5 * p.m2 * (vx2 * vx2 + vz2 * vz2);
    const U1 = p.m1 * p.g * p.l1 * (1 - Math.cos(a));
    const U2 = p.m2 * p.g * (p.l1 * (1 - Math.cos(a)) + p.l2 * (1 - Math.cos(b)));
    return {t, y, x1, z1, x2, z2, K: K1 + K2, U: U1 + U2, D: y[4] || 0, E: K1 + U1 + K2 + U2, parts: [K1, U1, K2, U2]};
  }
  function simulate(model, p, duration) {
    const count = Math.round(duration * 60), samples = [];
    if (model === 'oscillator' && !(p.gamma > 0)) {
      for (let i = 0; i <= count; i++) samples.push(oscillator(p, i / 60));
      return {samples, at: t => oscillator(p, t), maxError: 0};
    }
    const evaluate = {oscillator: oscillatorState, anharmonic: oscillatorState, 'simple-pendulum': simplePendulum, gravity, pendulum}[model];
    const derivative = {oscillator: oscillatorRhs, anharmonic: oscillatorRhs, 'simple-pendulum': simplePendulumRhs, gravity: gravityRhs, pendulum: rhs}[model];
    const phi = (p.phi0 || 0) * Math.PI / 180;
    const orbitalSpeed = model === 'gravity' ? p.speedRatio * Math.sqrt(G * (p.m1 + p.m2) / p.r0) : 0;
    let y = ['oscillator', 'anharmonic'].includes(model) ? [p.x0, p.v0, 0]
      : model === 'simple-pendulum' ? [p.theta0 * Math.PI / 180, p.omega0, 0]
      : model === 'gravity' ? [p.r0 * Math.cos(phi), p.r0 * Math.sin(phi), -orbitalSpeed * Math.sin(phi), orbitalSpeed * Math.cos(phi)]
      : [p.theta1 * Math.PI / 180, p.theta2 * Math.PI / 180, p.omega1, p.omega2, 0];
    const advance = (initial, dt) => {
      // Step doubling controls local error even for extreme mass ratios. The
      // Richardson correction raises accuracy without forcing energy to match.
      let next = initial, elapsed = 0, h = Math.min(dt, 1 / 240), attempts = 0;
      while (elapsed < dt - 1e-14) {
        if (++attempts > 10000) throw new Error('Le calcul demande un pas de temps trop petit.');
        h = Math.min(h, dt - elapsed);
        const full = step(p, next, h, derivative);
        const half = step(p, step(p, next, h / 2, derivative), h / 2, derivative);
        const error = Math.max(...half.map((v, i) => Math.abs(v - full[i]) / (15 * (1 + Math.max(Math.abs(next[i]), Math.abs(v))))));
        if (!Number.isFinite(error)) throw new Error('Le calcul du mouvement a échoué.');
        if (error <= 1e-11) {
          next = half.map((v, i) => v + (v - full[i]) / 15);
          elapsed += h;
        }
        h *= Math.max(.2, Math.min(2, .85 * Math.pow(1e-11 / Math.max(error, 1e-30), .2)));
        // A tiny final remainder is valid (notably after floating-point clock
        // accumulation). Only reject a tiny step when its error is too large.
        if (error > 1e-11 && h < 1e-9) throw new Error('Le calcul demande un pas de temps trop petit.');
      }
      return next;
    };
    samples.push(evaluate(p, y, 0));
    let maxError = 0;
    for (let i = 1; i <= count; i++) {
      y = advance(y, 1 / 60);
      const sample = evaluate(p, y, i / 60);
      if (!Number.isFinite(sample.E)) throw new Error('Le calcul du mouvement a échoué.');
      maxError = Math.max(maxError, Math.abs(sample.E + sample.D - samples[0].E));
      samples.push(sample);
    }
    return {samples, maxError, at(t) {
      const bounded = Math.max(0, Math.min(duration, t));
      const base = samples[Math.min(count, Math.floor(bounded * 60))];
      return evaluate(p, advance(base.y, bounded - base.t), bounded);
    }};
  }
  return {G, oscillatorPotential, oscillatorAmplitude, oscillatorPeriod, oscillator, oscillatorState, oscillatorRhs, simplePendulum, simplePendulumRhs, gravity, gravityRhs, rhs, step, pendulum, simulate};
})();

// A projected helix: fixed turn count, smoothly changing pitch, straight leads.
function coilSpringPoints(start, end, centerY) {
  const turns = 12, samplesPerTurn = 48, length = Math.max(0, end - start);
  const lead = Math.min(9, length * .15), radiusX = length / (4 * turns + 8);
  const radiusY = Math.min(10, length / 2);
  const first = start + lead + 2 * radiusX, last = end - lead;
  const points = [[start, centerY], [first, centerY]];
  for (let i = 1; i <= turns * samplesPerTurn; i++) {
    const u = i / (turns * samplesPerTurn), angle = 2 * Math.PI * turns * u;
    points.push([first + (last - first) * u + radiusX * (Math.cos(angle) - 1), centerY + radiusY * Math.sin(angle)]);
  }
  points.push([end, centerY]);
  return points;
}

// Length relative to equilibrium: a restrained slate-blue / slate-warm tint.
function springColor(length, equilibriumLength) {
  const strain = Math.max(-1, Math.min(1, (length - equilibriumLength) / Math.max(1, equilibriumLength)));
  const neutral = [96, 113, 133], target = strain < 0 ? [71, 112, 145] : [136, 110, 108];
  return `rgb(${neutral.map((channel, i) => Math.round(channel + Math.abs(strain) * (target[i] - channel))).join(', ')})`;
}

// One fixed scale per experiment. The energy envelope leaves room for the arrow.
// A fixed drag view may crop the future trajectory; retain a nonzero scale then.
function oscillatorVelocityArrow(x, velocity, amplitude, maxSpeed, center, pixelsPerMetre, width, y, anharmonic = false) {
  const radius = Math.max(0, Math.min(center - 12, width - 12 - center));
  const maxLength = anharmonic
    ? Math.min(90, Math.max(5, radius - amplitude * pixelsPerMetre))
    : Math.min(90, Math.sqrt(Math.max((radius * .2) ** 2, radius ** 2 - (amplitude * pixelsPerMetre) ** 2)));
  const delta = maxSpeed > 0 ? velocity / maxSpeed * maxLength : 0;
  const start = center + x * pixelsPerMetre, end = start + delta;
  const head = Math.min(8, Math.abs(delta) * .45), direction = Math.sign(delta);
  return {start, end, y, delta, head,
    labelX: Math.max(28, Math.min(width - 28, (start + end) / 2)),
    zero: Math.abs(velocity) <= 1e-10 * Math.max(1, maxSpeed),
    tip: [[end - direction * head, y - head * .55], [end, y], [end - direction * head, y + head * .55]]};
}

function gravityVelocityScale(p, maxLength) {
  const q2 = p.speedRatio ** 2;
  const initialSpeed = p.speedRatio * Math.sqrt(EnergyModels.G * (p.m1 + p.m2) / p.r0);
  // Maximum relative speed at periapsis, including unbound trajectories.
  const maxSpeed = initialSpeed * (1 + Math.abs(q2 - 1)) / q2 * Math.max(p.m1, p.m2) / (p.m1 + p.m2);
  return maxLength / maxSpeed;
}

function velocityArrow2D(center, vx, vz, scale, bodyRadius, outward) {
  const speed = Math.hypot(vx, vz);
  if (speed < 1e-12) return null;
  const u = [vx / speed, -vz / speed], normal = [-u[1], u[0]];
  const start = center.map((value, i) => value + u[i] * (bodyRadius + 1));
  const length = speed * scale, end = start.map((value, i) => value + u[i] * length);
  const head = Math.min(7, length * .45);
  const side = normal[0] * outward[0] + normal[1] * outward[1] < 0 ? -1 : 1;
  return {start, end, length,
    tip: [-1, 0, 1].map(sign => sign === 0 ? end : end.map((value, i) => value - u[i] * head + sign * normal[i] * head * .55)),
    label: start.map((value, i) => value + u[i] * length * .55 + side * normal[i] * 20),
    massLabel: center.map((value, i) => value - u[i] * (bodyRadius + 17))};
}

// The same file works when embedded in the standalone page or deferred in sources.
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startEnergyApp);
  else startEnergyApp();
}

async function startEnergyApp() {
  'use strict';
  const $ = id => document.getElementById(id);
  try {
    await MathJax.startup.promise;
    const tex = String.raw;
    const COLORS = {K: '#2775b6', U: '#b5688b', E: '#268576', K2: '#499e88', body2: '#74c9b2', body2Ink: '#237a68', U2: '#bc8b3b', D: '#a0acb9', ink: '#233449', muted: '#607185', grid: '#dce4ec'};
    const DEFINITIONS = {
      oscillator: {
        title: 'Oscillateur harmonique',
        note: 'Une masse reliée à un ressort horizontal. Aux extrémités, l’énergie est potentielle ; au passage par l’équilibre, elle est cinétique.',
        defaults: {m: 1, k: 4, x0: 1, v0: 0},
        fields: [
          ['m', 'Masse', 'm', .2, 5, .1, tex`\mathrm{kg}`],
          ['k', 'Raideur', 'k', .5, 20, .5, tex`\mathrm{N\,m^{-1}}`],
          ['x0', 'Position initiale', 'x_0', -2, 2, .05, tex`\mathrm m`],
          ['v0', 'Vitesse initiale', 'v_{x0}', -4, 4, .1, tex`\mathrm{m\,s^{-1}}`],
        ],
        examples: [
          ['Lâché sans vitesse', {x0: 1, v0: 0}],
          ['Passage par l’équilibre', {x0: 0, v0: 2}],
          ['Position et vitesse initiales', {x0: .7, v0: 1.4}],
          ['Au repos à l’équilibre', {x0: 0, v0: 0}],
        ],
        equations: [tex`U=\frac12 kx^2`, tex`K=\frac12 mv_x^2`, tex`E=K+U=\mathrm{constante}`, tex`\omega=\sqrt{\frac{k}{m}},\quad T=\frac{2\pi}{\omega}`, tex`x(t)=x_0\cos\omega t+\frac{v_{x0}}{\omega}\sin\omega t`],
        reference: 'L’origine de l’énergie potentielle est la position d’équilibre du ressort. Le mouvement est horizontal.',
      },
      'simple-pendulum': {
        title: 'Pendule simple',
        note: 'Une masse oscille au bout d’une tige. L’énergie potentielle se transforme en énergie cinétique pendant la descente, puis l’inverse pendant la remontée.',
        defaults: {m: 1, l: 1.2, theta0: 15, omega0: 0, g: 9.81},
        fields: [
          ['m', 'Masse', 'm', .2, 5, .1, tex`\mathrm{kg}`],
          ['l', 'Longueur', tex`\ell`, .5, 2.5, .05, tex`\mathrm m`],
          ['theta0', 'Angle initial', tex`\theta_0`, -180, 180, 1, tex`{}^\circ`],
          ['omega0', 'Vitesse angulaire initiale', tex`\dot\theta_0`, -8, 8, .1, tex`\mathrm{rad\,s^{-1}}`],
          ['g', 'Pesanteur', 'g', .5, 20, .01, tex`\mathrm{m\,s^{-2}}`],
        ],
        examples: [
          ['Petites oscillations', {}],
          ['Grandes oscillations', {theta0: 120}],
          ['Rotations complètes', {theta0: 0, omega0: 7}],
          ['Au repos à l’équilibre', {theta0: 0, omega0: 0}],
        ],
        equations: [tex`U=mg\ell(1-\cos\theta)=mgh`, tex`K=\frac12 m\ell^2\dot\theta^2`, tex`E=K+U=\mathrm{constante}`, tex`\ddot\theta+\frac{g}{\ell}\sin\theta=0`, tex`T\simeq 2\pi\sqrt{\frac{\ell}{g}}\quad(\lvert\theta\rvert\ll1)`],
        reference: 'Tige rigide, sans masse, pivot fixe. Le potentiel est nul au point le plus bas. L’angle est mesuré depuis la verticale descendante et affiché modulo un tour. L’équation complète est utilisée, sans approximation des petites oscillations.',
      },
      gravity: {
        title: 'Deux corps gravitationnels',
        note: 'Deux masses s’attirent suivant la loi de gravitation universelle et se déplacent autour de leur centre de masse. L’énergie potentielle de la paire est négative, avec son zéro à l’infini.',
        defaults: {m1: 1e12, m2: 1e12, r0: 10, speedRatio: 1, phi0: 0},
        energyScale: 1e12, energyUnit: tex`10^{12}\,\mathrm J`,
        fields: [
          ['m1', 'Premier corps', 'm_1', .2e12, 5e12, .1e12, tex`\times10^{12}\,\mathrm{kg}`, 1e12],
          ['m2', 'Deuxième corps', 'm_2', .2e12, 5e12, .1e12, tex`\times10^{12}\,\mathrm{kg}`, 1e12],
          ['r0', 'Séparation initiale', 'r_0', 6, 20, .1, tex`\mathrm m`],
          ['phi0', 'Orientation initiale', tex`\varphi_0`, -180, 180, 1, tex`{}^\circ`],
          ['speedRatio', 'Vitesse relative initiale', tex`v_0/v_{\mathrm{circ}}`, .5, 1.8, .01, ''],
        ],
        examples: [
          ['Orbites circulaires — masses égales', {}],
          ['Orbites elliptiques', {speedRatio: .65}],
          ['Un corps plus massif', {m1: 5e12, m2: .2e12}],
          ['Trajectoires d’échappement', {speedRatio: 1.6}],
        ],
        equations: [tex`\vec F_{1\leftarrow2}=Gm_1m_2\frac{\vec r_2-\vec r_1}{r^3}=-\vec F_{2\leftarrow1}`,
          tex`r=\lvert\vec r_2-\vec r_1\rvert,\quad U=-\frac{Gm_1m_2}{r}`,
          tex`K=\frac12m_1\lvert\vec v_1\rvert^2+\frac12m_2\lvert\vec v_2\rvert^2`,
          tex`E=K+U=\mathrm{constante}`, tex`v_{\mathrm{circ}}=\sqrt{\frac{G(m_1+m_2)}{r_0}}`,
          tex`G=6.67430\times10^{-11}\,\mathrm{m^3\,kg^{-1}\,s^{-2}}`],
        reference: 'Masses ponctuelles, sans collision ni frottement ; leur taille dessinée est symbolique. C désigne le centre de masse, ici immobile. L’orientation initiale est mesurée depuis l’horizontale. La vitesse relative initiale est perpendiculaire à la séparation. Le potentiel appartient à la paire et n’est compté qu’une fois. Les facteurs d’échelle des masses et des énergies sont indiqués dans les unités.',
      },
      pendulum: {
        title: 'Pendule double',
        defaultDuration: 10,
        note: 'Deux masses échangent de l’énergie par les tiges. Le mouvement peut être complexe, mais l’énergie mécanique totale reste constante.',
        defaults: {m1: 1, m2: 1, l1: 1.2, l2: 1, theta1: 120, theta2: -30, omega1: 0, omega2: 0, g: 9.81},
        fields: [
          ['m1', 'Masse supérieure', 'm_1', .2, 5, .1, tex`\mathrm{kg}`],
          ['m2', 'Masse inférieure', 'm_2', .2, 5, .1, tex`\mathrm{kg}`],
          ['l1', 'Première longueur', '\\ell_1', .5, 2, .05, tex`\mathrm m`],
          ['l2', 'Deuxième longueur', '\\ell_2', .5, 2, .05, tex`\mathrm m`],
          ['theta1', 'Angle initial supérieur', '\\theta_{10}', -180, 180, 1, tex`{}^\circ`],
          ['theta2', 'Angle initial inférieur', '\\theta_{20}', -180, 180, 1, tex`{}^\circ`],
          ['omega1', 'Vitesse angulaire initiale', tex`\dot{\theta}_{10}`, -3, 3, .1, tex`\mathrm{rad\,s^{-1}}`],
          ['omega2', 'Vitesse angulaire initiale', tex`\dot{\theta}_{20}`, -3, 3, .1, tex`\mathrm{rad\,s^{-1}}`],
          ['g', 'Pesanteur', 'g', .5, 20, .01, tex`\mathrm{m\,s^{-2}}`],
        ],
        examples: [
          ['Grands échanges d’énergie', {}],
          ['Petites oscillations couplées', {theta1: 15, theta2: 0}],
          ['Masses différentes', {m1: 2, m2: .5, theta1: 90, theta2: -60}],
          ['Au repos à l’équilibre', {theta1: 0, theta2: 0}],
        ],
        equations: [tex`K_i=\frac12 m_i\lvert\vec v_i\rvert^2`, tex`U_i=m_i g(z_i-z_{i,\min})`, tex`K=K_1+K_2,\quad U=U_1+U_2`, tex`E=K_1+U_1+K_2+U_2`, tex`\frac{\mathrm dE}{\mathrm dt}=0`],
        reference: 'Tiges rigides, sans masse, pivot fixe. Les angles sont mesurés depuis la verticale descendante. Pour chaque masse, le potentiel est nul à sa hauteur minimale, lorsque les deux tiges sont verticales vers le bas.',
      },
    };
    DEFINITIONS.anharmonic = {
      ...DEFINITIONS.oscillator,
      title: 'Oscillateur anharmonique',
      note: 'Un ressort qui se raidit avec l’allongement : la force contient un terme cubique. La période dépend de l’amplitude, contrairement au cas harmonique.',
      defaults: {...DEFINITIONS.oscillator.defaults, alpha: 4},
      fields: [...DEFINITIONS.oscillator.fields.slice(0, 2),
        ['alpha', 'Terme anharmonique', tex`\alpha`, 0, 20, .25, tex`\mathrm{N\,m^{-3}}`],
        ...DEFINITIONS.oscillator.fields.slice(2)],
      examples: [['Oscillations anharmoniques', {}], ['Anharmonicité forte', {alpha: 16}],
        ['Passage par l’équilibre', {x0: 0, v0: 2}], ['Limite harmonique', {alpha: 0}]],
      equations: [tex`U(x)=\frac12kx^2+\frac14\alpha x^4`, tex`K=\frac12mv_x^2`,
        tex`F_x=-kx-\alpha x^3`, tex`m\ddot x+kx+\alpha x^3=0`, tex`E=K+U=\mathrm{constante}`],
      reference: 'Mouvement horizontal, potentiel nul à l’équilibre. Le coefficient positif α rend le ressort plus raide loin de l’équilibre ; α = 0 retrouve le modèle harmonique. La courbe est un potentiel, pas la forme d’une piste.',
    };
    const state = {model: 'oscillator', p: {}, t: 0, duration: 30, playing: false, simulation: null, last: null, frame: 0, dirty: false, readoutTime: -1};
    const isOscillator = () => ['oscillator', 'anharmonic'].includes(state.model);
    Object.assign(state, {drag: null, initialGeometry: null, sceneGeometry: null, massPositions: []});
    const glyphs = new Map(), units = new Map();
    function energyValue(value) { return value / (DEFINITIONS[state.model].energyScale || 1); }
    function energyUnit() { return DEFINITIONS[state.model].energyUnit || tex`\mathrm J`; }
    function energyReadoutUnit() { return (DEFINITIONS[state.model].energyScale ? tex`\times` : '') + energyUnit(); }
    function math(el, value) {
      if (el.dataset.math === value) return;
      el.replaceChildren(MathJax.tex2svg(value, {display: false}));
      el.dataset.math = value;
    }
    for (const el of document.querySelectorAll('[data-tex]')) math(el, el.dataset.tex);
    function numericPart(value) {
      const svg = MathJax.tex2svg(value, {display: false}).querySelector('svg');
      const [x, y, width, height] = svg.getAttribute('viewBox').split(/\s+/).map(Number);
      return {svg, x, y, width, height, exPerUnit: parseFloat(svg.getAttribute('width')) / width};
    }
    for (const char of '0123456789.-') glyphs.set(char, numericPart(char));
    const numericTop = Math.min(...[...glyphs.values()].map(part => part.y));
    const numericBottom = Math.max(...[...glyphs.values()].map(part => part.y + part.height));
    // tex2svg creates both the visible SVG and accessible MathML, but does not
    // install page styles itself. Install them before showing any math output.
    MathJax.startup.document.updateDocument();
    function number(el, value, digits = 2, unit = '') {
      if (!Number.isFinite(value)) throw new Error('Valeur non finie.');
      const clean = Math.abs(value) < .5 * 10 ** (-digits) ? 0 : value;
      const string = clean.toFixed(digits);
      const key = `${string}|${unit}`;
      if (el.dataset.number === key) return;
      el.classList.add('number');
      // Assemble cached LaTeX paths in ONE SVG: all digits, the decimal point,
      // and the unit share y=0, without per-glyph HTML/flex baselines (Safari).
      // Keep the same vertical extent as digits change, and never typeset a
      // whole changing number on each animation frame.
      const parts = [...string].map(char => glyphs.get(char));
      if (unit) {
        if (!units.has(unit)) units.set(unit, numericPart(unit));
        parts.push(units.get(unit));
      }
      const svg = parts[0].svg.cloneNode(false), exPerUnit = glyphs.get('0').exPerUnit;
      let width = 0, top = numericTop, bottom = numericBottom;
      for (const [i, part] of parts.entries()) {
        if (i === string.length) width += 1000 / 6; // LaTeX thin space before the unit.
        const group = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        group.setAttribute('transform', `translate(${width - part.x},0)`);
        group.append(...[...part.svg.children].map(child => child.cloneNode(true)));
        svg.append(group); width += part.width;
        top = Math.min(top, part.y); bottom = Math.max(bottom, part.y + part.height);
      }
      svg.setAttribute('viewBox', `0 ${top} ${width} ${bottom - top}`);
      svg.setAttribute('width', `${width * exPerUnit}ex`);
      svg.setAttribute('height', `${(bottom - top) * exPerUnit}ex`);
      svg.style.verticalAlign = `${-bottom * exPerUnit}ex`;
      const description = string + (unit ? ' ' + unit.replace(/\\mathrm|[{}]/g, '').replace(/\\,/g, ' ').trim() : '');
      svg.setAttribute('role', 'img'); svg.setAttribute('aria-label', description);
      el.replaceChildren(svg); el.dataset.number = key;
      el.setAttribute('aria-label', description);
    }
    function components(sample) {
      const parts = state.model === 'pendulum' && $('detail').checked ? [
        {symbol: 'K_1', value: sample.parts[0], color: COLORS.K},
        {symbol: 'U_1', value: sample.parts[1], color: COLORS.U},
        {symbol: 'K_2', value: sample.parts[2], color: COLORS.K2},
        {symbol: 'U_2', value: sample.parts[3], color: COLORS.U2},
      ] : state.model === 'gravity' && $('detail').checked ? [
        {symbol: 'K_1', value: sample.parts[0], color: COLORS.K},
        {symbol: 'K_2', value: sample.parts[1], color: COLORS.K2},
        {symbol: 'U', value: sample.U, color: COLORS.U},
      ] : [{symbol: 'K', value: sample.K, color: COLORS.K}, {symbol: 'U', value: sample.U, color: COLORS.U}];
      if (state.p.gamma > 0) parts.push({symbol: tex`E_{\mathrm{diss}}`, value: sample.D, color: COLORS.D});
      return parts;
    }
    function setPlaying(value) {
      state.playing = value; state.last = null;
      $('play').textContent = value ? 'Pause' : 'Lire';
      $('play').setAttribute('aria-pressed', String(value));
      updateMassHandles();
      if (value && !state.frame) state.frame = requestAnimationFrame(frame);
    }
    function setTime(value) {
      finishInitialDrag(true);
      state.t = Math.max(0, Math.min(state.duration, value)); render();
    }
    function makeParameters() {
      const definition = DEFINITIONS[state.model];
      $('parameters').replaceChildren();
      for (const [key, title, symbol, min, max, step, unit, displayScale = 1] of definition.fields) {
        const root = document.createElement('div'); root.className = 'parameter';
        const row = document.createElement('div'); row.className = 'parameter-title';
        const label = document.createElement('label'); label.className = 'field-label'; label.htmlFor = `param-${key}`;
        label.append(title + ' '); const formula = document.createElement('span'); math(formula, symbol); label.append(formula);
        const output = document.createElement('output'); output.htmlFor = `param-${key}`; output.id = `value-${key}`;
        row.append(label); root.append(row);
        const input = document.createElement('input'); input.type = 'range'; input.id = `param-${key}`;
        Object.assign(input, {min, max, step, value: state.p[key]});
        input.addEventListener('input', () => {
          state.p[key] = Number(input.value); number(output, state.p[key] / displayScale, key.startsWith('theta') ? 0 : 2, unit);
          $('example-select').value = 'custom'; scheduleRebuild();
        });
        root.append(input, output); number(output, state.p[key] / displayScale, key.startsWith('theta') ? 0 : 2, unit);
        $('parameters').append(root);
      }
    }
    function setExample(index) {
      finishInitialDrag(false); state.initialGeometry = null;
      const definition = DEFINITIONS[state.model];
      state.p = {...definition.defaults, ...definition.examples[index][1]};
      $('example-select').value = String(index); makeParameters(); rebuild();
    }
    function setModel() {
      finishInitialDrag(false); state.initialGeometry = null;
      state.model = $('model-select').value;
      const definition = DEFINITIONS[state.model];
      $('duration').value = definition.defaultDuration ?? 30;
      $('scene-title').textContent = definition.title;
      $('example-select').replaceChildren(...definition.examples.map(([label], i) => new Option(label, String(i))));
      const custom = new Option('Réglage personnalisé', 'custom'); custom.disabled = true; $('example-select').append(custom);
      $('detail-row').hidden = !['pendulum', 'gravity'].includes(state.model);
      $('trail-row').hidden = isOscillator();
      $('velocity-row').hidden = !(isOscillator() || state.model === 'gravity');
      $('velocity-label').textContent = state.model === 'gravity' ? 'Vitesses instantanées' : 'Vitesse instantanée';
      math($('velocity-symbol'), state.model === 'gravity' ? tex`\vec v_1(t),\;\vec v_2(t)` : tex`\vec v(t)`);
      $('position-badge').hidden = state.model === 'pendulum';
      math($('position-symbol'), state.model === 'simple-pendulum' ? tex`\theta=` : state.model === 'gravity' ? 'r=' : 'x=');
      $('friction-row').hidden = state.model === 'gravity';
      setExample(0);
    }
    function updateFrictionInterface() {
      const on = $('friction-toggle').checked && state.model !== 'gravity', definition = DEFINITIONS[state.model];
      state.p.gamma = on ? Number($('damping-slider').value) : 0;
      $('damping-controls').hidden = !on;
      $('dissipation-card').hidden = !on;
      $('friction-badge').textContent = state.model === 'gravity' ? 'Gravitation seule' : on ? 'Avec frottements' : 'Sans frottement';
      number($('damping-readout'), Number($('damping-slider').value), 2, tex`\mathrm{s^{-1}}`);
      $('model-note').textContent = on
        ? (state.model === 'pendulum' ? 'Les deux masses échangent de l’énergie et subissent un frottement. Leur énergie mécanique totale diminue.' : 'La force de frottement freine la masse. L’énergie mécanique est progressivement dissipée.')
        : definition.note;
      $('reference-note').textContent = definition.reference;
      $('conservation-note').textContent = on
        ? 'Frottement visqueux sur chaque masse, proportionnel à sa vitesse. L’énergie mécanique perdue est transférée au milieu ; elle n’est pas détruite.'
        : 'Système idéal, sans frottement. Les échanges modifient la répartition de l’énergie, pas son total.';
      let equations = definition.equations;
      if (on) {
        equations = state.model === 'anharmonic'
          ? [definition.equations[0], definition.equations[1], tex`\vec F_{\mathrm f}=-m\gamma\vec v`, tex`m\ddot x+m\gamma\dot x+kx+\alpha x^3=0`]
          : state.model === 'oscillator'
          ? [tex`U=\frac12 kx^2,\quad K=\frac12 mv_x^2`, tex`\vec F_{\mathrm f}=-m\gamma\vec v`, tex`\ddot x+\gamma\dot x+\frac{k}{m}x=0`]
          : state.model === 'simple-pendulum'
          ? [definition.equations[0], definition.equations[1], tex`\vec F_{\mathrm f}=-m\gamma\vec v`, tex`\ddot\theta+\gamma\dot\theta+\frac{g}{\ell}\sin\theta=0`]
          : [definition.equations[0], definition.equations[1], tex`\vec F_{\mathrm f,i}=-m_i\gamma\vec v_i`];
        equations = [...equations, tex`E=K+U`, tex`\frac{\mathrm dE}{\mathrm dt}=-2\gamma K`, tex`E_{\mathrm{diss}}=\int_0^t 2\gamma K(\tau)\,\mathrm d\tau`, tex`E+E_{\mathrm{diss}}=E(0)`];
      }
      $('relations').replaceChildren(...equations.map(eq => {
        const div = document.createElement('div'); div.className = 'equation'; math(div, eq); return div;
      }));
      math($('balance-symbol'), on ? tex`E+E_{\mathrm{diss}}=E(0)` : 'E=K+U');
      $('balance-intro').textContent = state.model === 'gravity' ? 'Au-dessus de zéro : énergies positives ; au-dessous : négatives. ' : 'La hauteur totale représente ';
      math($('error-symbol'), on ? tex`\Delta E+E_{\mathrm{diss}}` : 'E(t)-E(0)');
    }
    function scheduleRebuild() {
      finishInitialDrag(false); state.initialGeometry = null;
      setPlaying(false);
      if (state.dirty) return;
      state.dirty = true;
      requestAnimationFrame(() => { state.dirty = false; rebuild(); });
    }
    function rebuild(preview = false) {
      const previewOnly = preview === true;
      if (!previewOnly) finishInitialDrag(false);
      setPlaying(false); state.t = 0;
      state.duration = Number($('duration').value);
      if (!previewOnly) updateFrictionInterface();
      // While dragging, update only the initial state. Integrate the complete
      // experiment once on release so mouse/touch input stays responsive.
      state.simulation = EnergyModels.simulate(state.model, state.p, previewOnly ? 0 : state.duration);
      const initial = state.simulation.samples[0];
      $('period-info').hidden = !isOscillator();
      if (isOscillator()) {
        const damped = state.p.gamma > 0, resting = initial.E === 0;
        number($('period-readout'), EnergyModels.oscillatorPeriod(state.p, initial.E), 3, tex`\mathrm s`);
        math($('period-symbol'), damped ? tex`T_{\mathrm{ref}}=` : 'T=');
        $('period-label').textContent = damped ? 'Période de référence' : 'Période d’oscillation';
        $('period-note').textContent = (damped ? 'Sans frottements, pour l’amplitude initiale. ' : '')
          + (resting ? 'Masse au repos : limite des petites oscillations.' : state.model === 'anharmonic' && !damped ? 'Calculée pour l’amplitude initiale.' : '');
        $('period-note').hidden = !$('period-note').textContent;
      }
      if (state.model === 'gravity') {
        state.gravityRange = state.simulation.samples.reduce((range, s) => ({
          min: Math.min(range.min, s.U), max: Math.max(range.max, s.K), radius: Math.max(range.radius, s.r),
        }), {min: 0, max: 0, radius: state.p.r0});
      }
      $('time-slider').max = state.duration; $('history').setAttribute('aria-valuemax', state.duration);
      number($('duration-readout'), state.duration, 0, tex`\mathrm s`);
      $('accuracy-note').textContent = state.simulation.maxError > 1e-5 * Math.max(1, initial.K + Math.abs(initial.U)) ? 'écart numérique à surveiller' : 'écart numérique';
      if (!previewOnly) updateKeys();
      render();
    }
    function updateKeys() {
      const parts = components(state.simulation.at(state.t));
      $('energy-key').replaceChildren(); $('energy-stack').replaceChildren(); $('chart-key').replaceChildren();
      for (const [i, part] of parts.entries()) {
        const row = document.createElement('div'); row.className = 'key-row';
        const swatch = document.createElement('span'); swatch.className = 'key-swatch'; swatch.style.background = part.color;
        const label = document.createElement('span'); math(label, part.symbol);
        const value = document.createElement('span'); value.id = `part-${i}`; value.className = 'key-value';
        row.append(swatch, label, value); $('energy-key').append(row);
        const segment = document.createElement('div'); segment.className = 'energy-segment'; segment.id = `segment-${i}`; segment.style.background = part.color;
        $('energy-stack').append(segment);
        const legend = document.createElement('span'); legend.append(swatch.cloneNode(), label.cloneNode(true)); $('chart-key').append(legend);
      }
      const on = state.p.gamma > 0;
      const total = document.createElement('span'); const dash = document.createElement('span'); dash.className = 'legend-line'; dash.style.borderTop = `2px ${on ? 'solid' : 'dashed'} ${COLORS.ink}`;
      const label = document.createElement('span'); math(label, on ? 'E(t)' : 'E'); total.append(dash, label); $('chart-key').append(total);
      if (on) {
        const reference = document.createElement('span'), marker = dash.cloneNode(), symbol = document.createElement('span');
        marker.style.borderTop = `2px dashed ${COLORS.muted}`; math(symbol, 'E(0)'); reference.append(marker, symbol); $('chart-key').append(reference);
      }
    }
    function surface(id) {
      const canvas = $(id), rect = canvas.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(1, rect.width), h = Math.max(1, rect.height);
      if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
        canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      }
      const ctx = canvas.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
      return {ctx, w, h};
    }
    const labels = new Map();
    function label(layer, name, text, x, y, color = COLORS.ink, tick = false) {
      const key = layer + '-' + name;
      if (!labels.has(key)) {
        const node = document.createElement('span'); $(layer).append(node); labels.set(key, node);
      }
      const node = labels.get(key); node.hidden = false; node.className = 'plot-label' + (tick ? ' tick' : '');
      math(node, text); node.style.left = `${x}px`; node.style.top = `${y}px`; node.style.color = color;
    }
    function hideLabels(layer) { for (const node of $(layer).children) node.hidden = true; }
    function line(ctx, points, color, width = 2, dash = []) {
      if (!points.length) return;
      ctx.beginPath(); ctx.moveTo(...points[0]); for (let i = 1; i < points.length; i++) ctx.lineTo(...points[i]);
      ctx.strokeStyle = color; ctx.lineWidth = width; ctx.setLineDash(dash); ctx.stroke(); ctx.setLineDash([]);
    }
    function dot(ctx, x, y, radius, color, outline = null) {
      ctx.beginPath(); ctx.arc(x, y, radius, 0, 2 * Math.PI); ctx.fillStyle = color; ctx.fill();
      if (outline) { ctx.strokeStyle = outline; ctx.lineWidth = 1.25; ctx.stroke(); }
    }
    // Same purely graphical relief as Collisions; physical radii are unchanged.
    function sphere(ctx,x,y,r,index){
      const colors=index===1?['#b8ddf6','#62a8d9','#2775b6','#1c5280']:['#e1f8ee','#b6e8d7','#94d9c5','#529c89'];
      const shade=ctx.createRadialGradient(x-r*.34,y-r*.38,r*.03,x-r*.08,y-r*.1,r*1.14);
      for(const [offset,color]of [[0,colors[0]],[.3,colors[1]],[.7,colors[2]],[1,colors[3]]])shade.addColorStop(offset,color);
      ctx.save();ctx.shadowColor='rgba(35,52,73,.16)';ctx.shadowBlur=Math.min(7,r*.3);ctx.shadowOffsetY=Math.min(3,r*.12);
      ctx.beginPath();ctx.arc(x,y,r,0,2*Math.PI);ctx.fillStyle=shade;ctx.fill();ctx.restore();
      ctx.strokeStyle=index===1?'#23679c':'#68ae9a';ctx.lineWidth=.7;ctx.stroke();
    }
    function sceneGeometry(w, h, geometry) {
      const saved = state.drag?.geometry || state.initialGeometry;
      // Keep the projection fixed through a gesture and subsequent playback.
      // A resize or an explicit parameter/example change starts a fresh view.
      const same = saved && saved.model === state.model && saved.w === w && saved.h === h;
      state.sceneGeometry = same ? saved : {model: state.model, w, h, ...geometry};
      return state.sceneGeometry;
    }
    function drawOscillator(sample) {
      const {ctx, w, h} = surface('scene-canvas'), p = state.p;
      const showVelocity = $('velocity-toggle').checked;
      const initial = state.simulation.samples[0], A = EnergyModels.oscillatorAmplitude(p, initial.E);
      const initialRange = Math.max(state.model === 'anharmonic' ? .6 : 2.15, A * 1.12);
      const {range} = sceneGeometry(w, h, {range: initialRange});
      const yMax = Math.max(.1, initial.E * 1.4, 1.1 * EnergyModels.oscillatorPotential(p, range));
      const left = 44, right = w - 28, top = 70, bottom = (h - (showVelocity ? 60 : 0)) * .65;
      const X = x => (left + right) / 2 + x / range * (right - left) / 2;
      const Y = u => bottom - u / yMax * (bottom - top);
      line(ctx, [[left, bottom], [right, bottom]], COLORS.grid, 1);
      line(ctx, [[X(0), top], [X(0), bottom]], COLORS.grid, 1);
      const curve = [];
      for (let i = 0; i <= 120; i++) { const x = -range + 2 * range * i / 120; curve.push([X(x), Y(EnergyModels.oscillatorPotential(p, x))]); }
      line(ctx, curve, COLORS.U, 2);
      line(ctx, [[left, Y(sample.E)], [right, Y(sample.E)]], COLORS.E, 1.5, [5, 4]);
      line(ctx, [[X(sample.x), bottom], [X(sample.x), Y(sample.U)]], COLORS.U, 4);
      line(ctx, [[X(sample.x), Y(sample.U)], [X(sample.x), Y(sample.E)]], COLORS.K, 4);
      dot(ctx, X(sample.x), Y(sample.U), 5, COLORS.ink);
      label('scene-labels', 'potential', state.model === 'anharmonic' ? tex`U(x)=\tfrac12 kx^2+\tfrac14\alpha x^4` : tex`U(x)=\tfrac12 kx^2`, (left + right) / 2, 54, COLORS.U);
      label('scene-labels', 'energy', p.gamma > 0 ? 'E(t)' : 'E', right - 8, Y(sample.E) - 13, COLORS.E);
      label('scene-labels', 'zero', '0', X(0), bottom + 18, COLORS.muted, true);
      if (A > 1e-8) {
        label('scene-labels', 'aminus', p.gamma > 0 ? '-A_0' : '-A', X(-A), bottom + 18, COLORS.muted, true);
        label('scene-labels', 'aplus', p.gamma > 0 ? 'A_0' : 'A', X(A), bottom + 18, COLORS.muted, true);
      }
      const rail = h - 52, massX = X(sample.x), anchor = 20;
      line(ctx, [[anchor, rail - 25], [anchor, rail + 20]], COLORS.muted, 3);
      line(ctx, [[anchor, rail + 20], [w - 20, rail + 20]], COLORS.grid, 1);
      line(ctx, [[X(0), rail - 25], [X(0), rail + 20]], COLORS.grid, 1, [3, 3]);
      ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      line(ctx, coilSpringPoints(anchor, massX - 15, rail), springColor(massX - 15 - anchor, X(0) - 15 - anchor), 2);
      ctx.restore();
      ctx.fillStyle = COLORS.K; ctx.fillRect(massX - 15, rail - 15, 30, 30);
      label('scene-labels', 'mass', 'm', massX, rail - 29, COLORS.K);
      if (showVelocity) {
        const arrow = oscillatorVelocityArrow(sample.x, sample.v, A, Math.sqrt(2 * initial.E / p.m),
          X(0), (right - left) / (2 * range), w, rail - 50, state.model === 'anharmonic');
        // A light guide associates the translated vector with the moving mass.
        line(ctx, [[massX, rail - 40], [massX, arrow.y]], COLORS.grid, 1, [2, 3]);
        if (!arrow.zero && Math.abs(arrow.delta) >= .1) {
          line(ctx, [[arrow.start, arrow.y], [arrow.end, arrow.y]], COLORS.U2, 2.5);
          line(ctx, arrow.tip, COLORS.U2, 2.5);
        }
        label('scene-labels', 'velocity', arrow.zero ? tex`\vec v=\vec 0` : tex`\vec v(t)`, arrow.labelX, arrow.y - 22, COLORS.U2);
      }
      state.massPositions = [[massX, rail]];
    }
    function drawSimplePendulum(sample) {
      const {ctx, w, h} = surface('scene-canvas'), p = state.p;
      const radius = Math.min((w - 110) / 2, (h - 130) / 2);
      const {scale, origin} = sceneGeometry(w, h, {scale: radius / p.l, origin: [w / 2 - 10, h / 2 + 8]});
      const point = (x, z) => [origin[0] + scale * x, origin[1] - scale * z];
      const bob = point(sample.x, sample.z), bottom = origin[1] + radius;
      state.massPositions = [bob];
      const theta = Math.atan2(Math.sin(sample.theta), Math.cos(sample.theta));
      if ($('trail').checked) {
        const start = Math.max(0, Math.floor(state.t * 60) - 360), end = Math.floor(state.t * 60);
        const points = state.simulation.samples.slice(start, end + 1).map(s => point(s.x, s.z)); points.push(bob);
        line(ctx, points, '#c3d5e1', 1.5);
      }
      line(ctx, [[origin[0], origin[1]], [origin[0], bottom]], COLORS.grid, 1, [4, 5]);
      line(ctx, [[origin[0] - radius - 10, bottom], [origin[0] + radius + 30, bottom]], COLORS.grid, 1);
      if (bottom - bob[1] > 4) {
        const hx = origin[0] + radius + 25;
        line(ctx, [[bob[0], bob[1]], [hx, bob[1]]], COLORS.grid, 1, [3, 4]);
        line(ctx, [[hx, bob[1]], [hx, bottom]], COLORS.U, 1.5);
        for (const y of [bob[1], bottom]) line(ctx, [[hx - 4, y], [hx + 4, y]], COLORS.U, 1.5);
        label('scene-labels', 'height', 'h', hx + 12, (bob[1] + bottom) / 2, COLORS.U);
      }
      if (Math.abs(theta) > .05) {
        const arc = Array.from({length: 41}, (_, i) => {
          const a = theta * i / 40; return [origin[0] + 26 * Math.sin(a), origin[1] + 26 * Math.cos(a)];
        });
        line(ctx, arc, COLORS.muted, 1.25);
        // Place the symbol outside the sector for very small angles.
        const labelAngle = Math.sign(theta) * Math.max(Math.abs(theta) / 2, .45);
        label('scene-labels', 'theta', tex`\theta`, origin[0] + 39 * Math.sin(labelAngle), origin[1] + 39 * Math.cos(labelAngle), COLORS.muted);
      }
      line(ctx, [origin, bob], '#778da0', 3);
      dot(ctx, ...origin, 4, COLORS.ink);
      sphere(ctx, ...bob, 7 + Math.sqrt(p.m) * 3, 1);
      label('scene-labels', 'mass', 'm', bob[0] + (sample.x < 0 ? -19 : 19), bob[1] - 15, COLORS.K);
      label('scene-labels', 'length', tex`\ell`, origin[0] + .62 * (bob[0] - origin[0]) - 13 * Math.cos(theta), origin[1] + .62 * (bob[1] - origin[1]) + 13 * Math.sin(theta), COLORS.muted);
      label('scene-labels', 'origin', 'O', origin[0] - 14, origin[1] - 12, COLORS.muted);
      label('scene-labels', 'potential-zero', 'U=0', origin[0] - .65 * radius, bottom + 17, COLORS.U);
      const gx = w - 27, gy = h - 70;
      line(ctx, [[gx, gy], [gx, gy + 27]], COLORS.muted, 2);
      line(ctx, [[gx - 4, gy + 21], [gx, gy + 27], [gx + 4, gy + 21]], COLORS.muted, 2);
      label('scene-labels', 'gravity', tex`\vec g`, gx - 13, gy + 12, COLORS.muted);
    }
    function drawGravity(sample) {
      const {ctx, w, h} = surface('scene-canvas'), p = state.p;
      const showVelocity = $('velocity-toggle').checked;
      // Reserve the same space for annotations in every display mode. Neither
      // trails nor vectors may change the projection of the physical scene.
      const available = Math.max(1, Math.min(w - 135, h - 150));
      const initial = state.simulation.samples[0], bound = initial.E < 0;
      const separation = Math.max(20, bound ? state.gravityRange.radius : sample.r);
      const radius = separation * Math.max(p.m1, p.m2) / (p.m1 + p.m2);
      const camera = sceneGeometry(w, h, {scale: available / (2 * radius), origin: [w / 2, h / 2 + 8]});
      const visibleRadius = sample.r * Math.max(p.m1, p.m2) / (p.m1 + p.m2);
      const scale = state.t > 0 ? Math.min(camera.scale, available / (2 * visibleRadius)) : camera.scale;
      // Escaping bodies must visibly shrink with the camera, rather than seem
      // stationary at a constant size. Reference the initial framing (not the
      // previous frame), so scrubbing, replay and resizing remain deterministic.
      const initialRadius = Math.max(20, initial.r) * Math.max(p.m1, p.m2) / (p.m1 + p.m2);
      const bodyZoom = bound ? 1 : Math.min(1, scale / (available / (2 * initialRadius)));
      const {origin} = camera, point = (x, z) => [origin[0] + scale*x, origin[1] - scale*z];
      const a = point(sample.x1, sample.z1), b = point(sample.x2, sample.z2);
      state.massPositions = [a, b];
      if ($('trail').checked) {
        if (bound) {
          const preview = state.simulation.samples.filter((s, i) => i % 6 === 0);
          line(ctx, preview.map(s => point(s.x1, s.z1)), '#e0e9f1', 1);
          line(ctx, preview.map(s => point(s.x2, s.z2)), '#e0ede9', 1);
        }
        const end = Math.floor(state.t * 60);
        const trail = state.simulation.samples.slice(0, end + 1);
        line(ctx, [...trail.map(s => point(s.x1, s.z1)), a], COLORS.K, 1.5);
        line(ctx, [...trail.map(s => point(s.x2, s.z2)), b], COLORS.K2, 1.5);
      }
      line(ctx, [a, b], COLORS.grid, 1, [4, 4]);
      line(ctx, [[origin[0]-5,origin[1]], [origin[0]+5,origin[1]]], COLORS.muted, 1.5);
      line(ctx, [[origin[0],origin[1]-5], [origin[0],origin[1]+5]], COLORS.muted, 1.5);
      const velocityScale = gravityVelocityScale(p, Math.min(40, w * .12));
      for (const [i, body, color, mass] of [[1, a, COLORS.K, p.m1], [2, b, COLORS.K2, p.m2]]) {
        // Approach a small visible marker smoothly at very large distances;
        // the symbolic mass sizes are not physical radii. Text stays readable.
        const bodyRadius = 2 + (3 + 2 * Math.cbrt(mass / 1e12)) * bodyZoom;
        const labelColor = i === 2 ? COLORS.body2Ink : color;
        sphere(ctx, ...body, bodyRadius, i);
        // Compute annotation anchors independently of visibility, so mass
        // labels do not jump when velocity arrows are shown or hidden.
        const arrow = velocityArrow2D(body, sample[`vx${i}`], sample[`vz${i}`], velocityScale,
          bodyRadius, [body[0] - origin[0], body[1] - origin[1]]);
        if (showVelocity && arrow) {
          line(ctx, [arrow.start, arrow.end], color, 2.5);
          line(ctx, arrow.tip, color, 2.5);
          label('scene-labels', `velocity${i}`, tex`\vec v_${i}(t)`,
            Math.max(25, Math.min(w - 25, arrow.label[0])), Math.max(65, Math.min(h - 45, arrow.label[1])), labelColor);
        }
        const massLabel = arrow ? arrow.massLabel : [body[0], body[1] - 21];
        label('scene-labels', `mass${i}`, `m_${i}`, ...massLabel, labelColor);
      }
      label('scene-labels', 'barycenter', 'C', origin[0] + 13, origin[1] + 16, COLORS.muted);
    }
    function drawPendulum(sample) {
      const {ctx, w, h} = surface('scene-canvas'), p = state.p;
      const length = p.l1 + p.l2;
      const {scale, origin} = sceneGeometry(w, h, {scale: Math.min((w - 80) / (2 * length), (h - 75) / (2 * length)), origin: [w / 2, h / 2 + 20]});
      const point = (x, z) => [origin[0] + scale * x, origin[1] - scale * z];
      const a = point(sample.x1, sample.z1), b = point(sample.x2, sample.z2);
      state.massPositions = [a, b];
      if ($('trail').checked) {
        const start = Math.max(0, Math.floor(state.t * 60) - 360), end = Math.floor(state.t * 60);
        const points = state.simulation.samples.slice(start, end + 1).map(s => point(s.x2, s.z2)); points.push(b);
        line(ctx, points, '#c3d5e1', 1.5);
      }
      line(ctx, [[origin[0], origin[1] - length * scale], [origin[0], origin[1] + length * scale]], COLORS.grid, 1, [4, 5]);
      line(ctx, [origin, a, b], '#778da0', 3);
      dot(ctx, ...origin, 4, COLORS.ink);
      sphere(ctx, ...a, 7 + Math.sqrt(p.m1) * 3, 1);
      sphere(ctx, ...b, 7 + Math.sqrt(p.m2) * 3, 2);
      label('scene-labels', 'mass1', 'm_1', a[0] + 22, a[1] - 16, COLORS.K);
      label('scene-labels', 'mass2', 'm_2', b[0] + 22, b[1] + 17, COLORS.body2Ink);
      label('scene-labels', 'origin', 'O', origin[0] - 14, origin[1] - 12, COLORS.muted);
      const gx = w - 30, gy = h - 64;
      line(ctx, [[gx, gy], [gx, gy + 27]], COLORS.muted, 2);
      line(ctx, [[gx - 4, gy + 21], [gx, gy + 27], [gx + 4, gy + 21]], COLORS.muted, 2);
      label('scene-labels', 'gravity', tex`\vec g`, gx - 14, gy + 12, COLORS.muted);
    }
    function chartGeometry(w, h) {
      const signed = state.model === 'gravity';
      const ymin = signed ? state.gravityRange.min * 1.12 : 0;
      const ymax = signed ? state.gravityRange.max * 1.12 : Math.max(.1, state.simulation.samples[0].E * 1.16);
      // Keep a separate header row for the unit, above every y-axis tick.
      return {left: 66, right: w - 28, top: 48, bottom: h - 45, ymin, ymax};
    }
    function drawHistory(sample) {
      const {ctx, w, h} = surface('history-canvas'), r = chartGeometry(w, h);
      const X = t => r.left + t / state.duration * (r.right - r.left), Y = e => r.bottom - (e - r.ymin) / (r.ymax - r.ymin) * (r.bottom - r.top);
      hideLabels('history-labels');
      const nx = w < 500 ? 3 : 5;
      for (let i = 0; i <= nx; i++) {
        const t = state.duration * i / nx;
        line(ctx, [[X(t), r.top], [X(t), r.bottom]], COLORS.grid, 1);
        label('history-labels', `x${i}`, t.toFixed(t % 1 ? 1 : 0), X(t), r.bottom + 17, COLORS.muted, true);
      }
      for (let i = 0; i <= 4; i++) {
        const e = r.ymin + (r.ymax - r.ymin) * i / 4;
        line(ctx, [[r.left, Y(e)], [r.right, Y(e)]], COLORS.grid, 1);
        if (Math.abs(Y(e) - Y(0)) >= 22) label('history-labels', `y${i}`, energyValue(e).toFixed(energyValue(r.ymax - r.ymin) < 1 ? 2 : 1), r.left - 25, Y(e), COLORS.muted, true);
      }
      label('history-labels', 'y-zero', '0', r.left - 25, Y(0), COLORS.muted, true);
      label('history-labels', 'xunit', tex`t\,[\mathrm s]`, (r.left + r.right) / 2, h - 10);
      label('history-labels', 'yunit', `E\\,[${energyUnit()}]`, state.model === 'gravity' ? 98 : 36, 18);
      if (state.model === 'gravity') line(ctx, [[r.left,Y(0)], [r.right,Y(0)]], COLORS.muted, 1, [4, 4]);
      const stride = Math.max(1, Math.floor(state.simulation.samples.length / Math.max(200, w)));
      const samples = state.simulation.samples.filter((s, i) => i % stride === 0 && s.t < state.t);
      samples.push(sample);
      const parts = components(sample), stacked = $('stacked').checked;
      let positive = samples.map(() => 0), negative = samples.map(() => 0);
      for (let k = 0; k < parts.length; k++) {
        const values = samples.map(s => components(s)[k].value);
        const lower = values.map((v, i) => stacked ? (v < 0 ? negative[i] : positive[i]) : 0);
        const upper = values.map((v, i) => v + lower[i]);
        const points = samples.map((s, i) => [X(s.t), Y(upper[i])]);
        if (stacked) {
          ctx.beginPath(); points.forEach((p, i) => i ? ctx.lineTo(...p) : ctx.moveTo(...p));
          for (let i = samples.length - 1; i >= 0; i--) ctx.lineTo(X(samples[i].t), Y(lower[i]));
          ctx.closePath(); ctx.globalAlpha = .72; ctx.fillStyle = parts[k].color; ctx.fill(); ctx.globalAlpha = 1;
        }
        line(ctx, points, parts[k].color, stacked ? 1 : 2);
        if (!stacked) dot(ctx, X(sample.t), Y(values[values.length - 1]), 3, parts[k].color);
        if (stacked) values.forEach((v, i) => { if (v < 0) negative[i] = upper[i]; else positive[i] = upper[i]; });
      }
      line(ctx, [[r.left, Y(state.simulation.samples[0].E)], [r.right, Y(state.simulation.samples[0].E)]], state.p.gamma > 0 ? COLORS.muted : COLORS.ink, 1.5, [6, 4]);
      if (state.p.gamma > 0) line(ctx, samples.map(s => [X(s.t), Y(s.E)]), COLORS.ink, 2);
      line(ctx, [[X(state.t), r.top], [X(state.t), r.bottom]], '#8998a7', 1.5, [3, 3]);
      dot(ctx, X(state.t), Y(sample.E), 4, COLORS.ink);
    }
    function render() {
      if (!state.simulation) return;
      const sample = state.simulation.at(state.t), E0 = state.simulation.samples[0].E;
      $('time-slider').value = state.t; $('history').setAttribute('aria-valuenow', state.t.toFixed(2));
      $('history').setAttribute('aria-valuetext', state.t.toFixed(2) + ' secondes');
      if (!state.playing || Math.abs(state.t - state.readoutTime) >= 1 / 15) {
        state.readoutTime = state.t;
        number($('time-readout'), state.t, 2, tex`\mathrm s`); number($('scene-time'), state.t, 2, tex`\mathrm s`);
        if (isOscillator()) number($('position-readout'), sample.x, 2, tex`\mathrm m`);
        if (state.model === 'simple-pendulum') number($('position-readout'), Math.atan2(Math.sin(sample.theta), Math.cos(sample.theta)) * 180 / Math.PI, 2, tex`{}^\circ`);
        if (state.model === 'gravity') number($('position-readout'), sample.r, 2, tex`\mathrm m`);
        number($('kinetic-readout'), energyValue(sample.K), 3, energyReadoutUnit());
        number($('potential-readout'), energyValue(sample.U), 3, energyReadoutUnit());
        number($('total-readout'), energyValue(sample.E), 3, energyReadoutUnit());
        number($('dissipation-readout'), energyValue(sample.D), 3, energyReadoutUnit());
        const error = energyValue(sample.E + sample.D - E0);
        number($('error-readout'), error, Math.abs(error) < .0000005 ? 0 : 6, energyReadoutUnit());
        for (const [i, part] of components(sample).entries()) {
          number($(`part-${i}`), energyValue(part.value), 3, energyReadoutUnit());
        }
      }
      const budget = sample.E + sample.D;
      const signed = state.model === 'gravity';
      $('energy-meter').dataset.signed = String(signed);
      const extent = signed ? Math.max(state.gravityRange.max, -state.gravityRange.min) * 1.08 : 1;
      let positive = 0, negative = 0;
      for (const [i, part] of components(sample).entries()) {
        const segment = $(`segment-${i}`);
        if (signed) {
          const size = 50 * Math.abs(part.value) / extent;
          segment.style.height = `${size}%`;
          segment.style.top = `${part.value < 0 ? 50 + negative : 50 - positive - size}%`;
          if (part.value < 0) negative += size; else positive += size;
        } else {
          segment.style.top = '';
          segment.style.height = `${budget > 1e-12 ? 100 * part.value / budget : 0}%`;
        }
      }
      $('energy-stack').style.height = `${signed ? 100 : E0 > 1e-12 ? Math.min(100, 100 * budget / E0) : 0}%`;
      const scene = $('scene'); scene.setAttribute('aria-label', `${DEFINITIONS[state.model].title}. Instant ${state.t.toFixed(2)} s ; énergie cinétique ${sample.K.toFixed(3)} J ; énergie potentielle ${sample.U.toFixed(3)} J ; énergie dissipée ${sample.D.toFixed(3)} J.`);
      scene.dataset.velocity = String(isOscillator() && $('velocity-toggle').checked);
      if (scene.dataset.velocity === 'true') scene.setAttribute('aria-label', scene.getAttribute('aria-label') + ` Vitesse horizontale ${sample.v.toFixed(3)} m/s.`);
      if (state.model === 'gravity' && $('velocity-toggle').checked) scene.setAttribute('aria-label', scene.getAttribute('aria-label') +
        ` Vitesses dans le référentiel du centre de masse : premier corps (${sample.vx1.toFixed(3)}, ${sample.vz1.toFixed(3)}) m/s ; deuxième corps (${sample.vx2.toFixed(3)}, ${sample.vz2.toFixed(3)}) m/s.`);
      hideLabels('scene-labels');
      if (isOscillator()) drawOscillator(sample);
      else if (state.model === 'simple-pendulum') drawSimplePendulum(sample);
      else if (state.model === 'gravity') drawGravity(sample);
      else drawPendulum(sample);
      updateMassHandles();
      drawHistory(sample);
      $('observation').textContent = signed
        ? (E0 < 0 ? 'L’énergie mécanique est négative : les deux corps restent liés. La somme des énergies cinétiques et du potentiel gravitationnel est conservée.' : 'L’énergie mécanique permet l’échappement : les deux corps s’éloignent indéfiniment. Le potentiel négatif tend vers zéro à grande distance.')
        : E0 < 1e-12 ? 'Le système reste au repos à l’équilibre : les énergies cinétique et potentielle sont nulles.'
        : state.p.gamma > 0 ? 'Les frottements dissipent de l’énergie. La partie grise représente l’énergie transférée au milieu ; ajoutée à l’énergie mécanique restante, elle retrouve l’énergie initiale.'
        : state.model === 'pendulum' ? 'Chaque masse peut gagner ou perdre de l’énergie. Seule la somme des énergies des deux masses est conservée.'
        : state.model === 'simple-pendulum' && E0 > 2 * state.p.m * state.p.g * state.p.l ? 'L’énergie permet de franchir le point le plus haut : le pendule effectue des tours complets. Il ralentit en montant et accélère en descendant.'
        : sample.K / E0 < .05 ? 'Près d’une extrémité, la masse ralentit : l’énergie est essentiellement potentielle.'
        : sample.U / E0 < .05 ? 'Près de l’équilibre, la vitesse est maximale : l’énergie est essentiellement cinétique.'
        : 'Pendant le mouvement, l’énergie cinétique et l’énergie potentielle se transforment l’une en l’autre.';
    }
    function canEditInitialPosition() { return !state.playing && state.t === 0 && !state.dirty; }
    function updateMassHandles() {
      const editable = canEditInitialPosition();
      for (let i = 0; i < 2; i++) {
        const handle = $(`mass-handle-${i}`), position = state.massPositions[i];
        handle.hidden = !editable || !position; handle.disabled = !editable;
        handle.dataset.dragging = String(state.drag?.index === i);
        if (position) { handle.style.left = `${position[0]}px`; handle.style.top = `${position[1]}px`; }
        const name = state.massPositions.length === 1 ? 'Masse' : i === 0 ? 'Première masse' : 'Deuxième masse';
        handle.setAttribute('aria-label', name + ' : faire glisser pour choisir la position initiale, ou utiliser les touches fléchées.');
      }
      $('initial-position-hint').textContent = (state.model === 'gravity' ? 'C représente le centre de masse. ' : '') + (editable
        ? (state.model === 'gravity' ? 'Avant de lire, faites glisser une masse : séparation et orientation changent autour du centre de masse.' : 'Avant de lire, faites glisser la masse ou les masses pour choisir leur position initiale.')
        : 'Recommencer permet de déplacer les masses à leur position initiale.');
    }
    function syncInitialParameters() {
      for (const [key, , , , , , unit, displayScale = 1] of DEFINITIONS[state.model].fields) {
        $(`param-${key}`).value = state.p[key];
        number($(`value-${key}`), state.p[key] / displayScale, key.startsWith('theta') ? 0 : 2, unit);
      }
    }
    function initialParameter(key, value) {
      const [, , , min, max, step] = DEFINITIONS[state.model].fields.find(field => field[0] === key);
      const snapped = min + Math.round((value - min) / step) * step;
      state.p[key] = Number(Math.max(min, Math.min(max, snapped)).toFixed(8));
    }
    function moveInitialMass(index, screenX, screenY, geometry) {
      if (isOscillator()) {
        const left = 44, right = geometry.w - 28;
        initialParameter('x0', (screenX - (left + right) / 2) * 2 * geometry.range / (right - left));
      } else {
        let x = (screenX - geometry.origin[0]) / geometry.scale;
        let z = (geometry.origin[1] - screenY) / geometry.scale;
        if (state.model === 'gravity') {
          const factor = index === 0 ? -state.p.m2 / (state.p.m1 + state.p.m2) : state.p.m1 / (state.p.m1 + state.p.m2);
          x /= factor; z /= factor;
          initialParameter('r0', Math.hypot(x, z));
          if (Math.hypot(x, z) > 1e-8) initialParameter('phi0', Math.atan2(z, x) * 180 / Math.PI);
        } else {
          if (state.model === 'pendulum' && index === 1) {
            const a = state.p.theta1 * Math.PI / 180;
            x -= state.p.l1 * Math.sin(a); z += state.p.l1 * Math.cos(a);
          }
          if (Math.hypot(x, z) < 1e-8) return;
          initialParameter(state.model === 'simple-pendulum' ? 'theta0' : index === 0 ? 'theta1' : 'theta2', Math.atan2(x, -z) * 180 / Math.PI);
        }
      }
      if (state.drag) state.drag.changed = true;
      $('example-select').value = 'custom'; syncInitialParameters(); rebuild(true);
    }
    function finishInitialDrag(commit) {
      const drag = state.drag;
      if (!drag) return;
      state.drag = null;
      const handle = $(`mass-handle-${drag.index}`);
      if (handle.hasPointerCapture(drag.pointerId)) handle.releasePointerCapture(drag.pointerId);
      if (!drag.changed) state.initialGeometry = drag.previousView;
      if (commit && drag.changed) rebuild();
      else updateMassHandles();
    }
    function cancelInitialDrag() {
      if (!state.drag) return;
      const drag = state.drag;
      state.p = {...drag.parameters}; state.initialGeometry = drag.previousView;
      $('example-select').value = drag.example;
      finishInitialDrag(false); syncInitialParameters(); rebuild();
    }
    for (let index = 0; index < 2; index++) {
      const handle = $(`mass-handle-${index}`);
      handle.addEventListener('pointerdown', event => {
        if (!canEditInitialPosition() || state.drag || event.isPrimary === false || (event.button !== undefined && event.button !== 0)) return;
        const position = state.massPositions[index];
        if (!position) return;
        event.preventDefault();
        const rect = $('scene-canvas').getBoundingClientRect();
        state.drag = {index, pointerId: event.pointerId, geometry: state.sceneGeometry, parameters: {...state.p},
          previousView: state.initialGeometry, example: $('example-select').value, changed: false,
          offsetX: event.clientX - rect.left - position[0], offsetY: event.clientY - rect.top - position[1]};
        state.initialGeometry = state.sceneGeometry;
        handle.focus({preventScroll: true}); handle.setPointerCapture(event.pointerId); updateMassHandles();
      });
      const move = event => {
        const drag = state.drag;
        if (!drag || drag.index !== index || drag.pointerId !== event.pointerId) return;
        if (!Number.isFinite(event.clientX) || !Number.isFinite(event.clientY)) return;
        event.preventDefault();
        const rect = $('scene-canvas').getBoundingClientRect();
        moveInitialMass(index, event.clientX - rect.left - drag.offsetX, event.clientY - rect.top - drag.offsetY, drag.geometry);
      };
      handle.addEventListener('pointermove', move);
      handle.addEventListener('pointerup', event => {
        if (state.drag?.index !== index || state.drag.pointerId !== event.pointerId) return;
        // A click without a move must not round or otherwise alter parameters.
        if (state.drag.changed) move(event);
        finishInitialDrag(true);
      });
      for (const name of ['pointercancel', 'lostpointercapture']) handle.addEventListener(name, event => {
        if (state.drag?.index === index && state.drag.pointerId === event.pointerId) cancelInitialDrag();
      });
      handle.addEventListener('keydown', event => {
        if (event.key === 'Escape' && state.drag) { event.preventDefault(); cancelInitialDrag(); return; }
        const direction = {ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1]}[event.key];
        if (!direction || !canEditInitialPosition() || state.drag) return;
        event.preventDefault();
        const point = state.massPositions[index];
        let step = event.shiftKey ? 15 : 5;
        // At a close zoom, five pixels can be less than half a slider step.
        // A keyboard action must still change the selected initial position.
        if (isOscillator()) step = Math.max(step, .05 * (state.sceneGeometry.w - 72) / (2 * state.sceneGeometry.range) * (event.shiftKey ? 3 : 1));
        state.initialGeometry = state.sceneGeometry;
        moveInitialMass(index, point[0] + direction[0]*step, point[1] + direction[1]*step, state.sceneGeometry); rebuild();
      });
    }
    function frame(now) {
      state.frame = 0;
      if (!state.playing) return;
      if (state.last !== null) state.t += Math.min(.1, (now - state.last) / 1000) * Number($('playback-speed').value);
      state.last = now;
      if (state.t >= state.duration) {
        if ($('loop').checked) state.t %= state.duration;
        else { state.t = state.duration; setPlaying(false); }
      }
      render(); if (state.playing) state.frame = requestAnimationFrame(frame);
    }
    $('model-select').addEventListener('change', setModel);
    $('example-select').addEventListener('change', () => setExample(Number($('example-select').value)));
    $('reset-parameters').addEventListener('click', () => { $('damping-slider').value = '0.25'; setExample(0); });
    $('friction-toggle').addEventListener('change', rebuild);
    $('damping-slider').addEventListener('input', () => {
      number($('damping-readout'), Number($('damping-slider').value), 2, tex`\mathrm{s^{-1}}`);
      scheduleRebuild();
    });
    $('play').addEventListener('click', () => { finishInitialDrag(true); if (state.t >= state.duration) state.t = 0; setPlaying(!state.playing); });
    $('restart').addEventListener('click', () => { setPlaying(false); setTime(0); });
    $('time-slider').addEventListener('input', () => { setPlaying(false); setTime(Number($('time-slider').value)); });
    $('duration').addEventListener('input', () => { number($('duration-readout'), Number($('duration').value), 0, tex`\mathrm s`); scheduleRebuild(); });
    $('detail').addEventListener('change', () => { updateKeys(); render(); });
    for (const id of ['stacked', 'trail', 'velocity-toggle']) $(id).addEventListener('change', render);
    function seek(event) {
      const rect = $('history').getBoundingClientRect(), r = chartGeometry(rect.width, rect.height);
      setPlaying(false); setTime((event.clientX - rect.left - r.left) / (r.right - r.left) * state.duration);
    }
    $('history').addEventListener('pointerdown', event => { $('history').setPointerCapture(event.pointerId); seek(event); });
    $('history').addEventListener('pointermove', event => { if ($('history').hasPointerCapture(event.pointerId)) seek(event); });
    $('history').addEventListener('keydown', event => {
      const change = {ArrowLeft: -.1, ArrowRight: .1, ArrowDown: -1, ArrowUp: 1};
      if (event.key in change) { event.preventDefault(); setPlaying(false); setTime(state.t + change[event.key]); }
      if (event.key === 'Home' || event.key === 'End') { event.preventDefault(); setPlaying(false); setTime(event.key === 'Home' ? 0 : state.duration); }
    });
    document.addEventListener('keydown', event => {
      if (event.target.closest('input, select, button, [role="slider"]') || event.ctrlKey || event.metaKey || event.altKey) return;
      if (event.code === 'Space') { event.preventDefault(); $('play').click(); }
      if (event.key.toLowerCase() === 'r') $('restart').click();
    });
    document.addEventListener('visibilitychange', () => { if (document.hidden) setPlaying(false); });
    new ResizeObserver(() => {
      const rect = $('scene-canvas').getBoundingClientRect();
      if (state.drag && (rect.width !== state.drag.geometry.w || rect.height !== state.drag.geometry.h)) cancelInitialDrag();
      render();
    }).observe($('scene'));
    new ResizeObserver(() => render()).observe($('history'));
    setModel(); $('loading').hidden = true;
    await window.PhysShare?.register({id:'conservation',pause:()=>setPlaying(false),
      capture:()=>({model:state.model,p:{...state.p},t:state.t,duration:state.duration}),
      restore:(s,ui)=>{
        PhysShare.member(s.model,Object.keys(DEFINITIONS));PhysShare.range(s.duration,.1,120);PhysShare.range(s.t,0,s.duration);
        $('model-select').value=s.model;setModel();state.p={...s.p};makeParameters();ui();$('duration').value=s.duration;rebuild();setTime(s.t);setPlaying(false);ui();render();
      }
    });
  } catch (error) {
    $('loading').hidden = false;
    $('loading').textContent = 'L’animation n’a pas pu démarrer. Rechargez la page. ' + error.message;
    console.error(error);
  }
}
